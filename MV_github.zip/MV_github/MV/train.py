import chainer
import numpy as np
import model_MV as M
import math
import csv

TERM = 20
TRAIN_NUM = 100000
TEST_NUM = 1000
EPOCH = 1000
USE_EPOCH = 0
CONTINUE_FLG = False

#make data
def make_data(num):
    data = []
    for i in range(num):
        rtn = np.random.randn(TERM-1)
        org = []
        org.append(100)
        
        for r in rtn:
            org.append(org[len(org)-1] * np.exp(r/40))
        data.append(np.array(org).astype(np.float32).reshape(1, TERM))
    return data

#make label
def make_label(data):
    label = []
    for d in data:
        label.append(np.average(d))
    return label
    
#get loss
def get_loss(y, t):
    loss = 0
    for i in range(len(y)):
        loss += pow(y[i] - t[i], 2)
    return loss

#calc loss
def calc_loss(model, optimizer, x, t, batchsize, epoch, update):
    perm = np.random.permutation(len(x))
    sum_loss = 0
    cnt = 0
    for i in range(0, len(x), batchsize):
        cnt += 1
        indices = perm[i : i + batchsize]
        x_batch = np.asarray(x).astype(np.float32)[indices]
        t_batch = np.asarray(t).astype(np.float32)[indices]
        
        model.zerograds()
        y = model.forward(x_batch)
        loss = get_loss(y, t_batch)
        if update == True:
            loss.backward()
            optimizer.update()
        if cnt % 10 == 0:
            print('epoch:' + str(epoch + 1) + ', batch:' + str(cnt) + r'/20 : ' + str(math.sqrt(float(loss.data)/len(t_batch))))
        sum_loss += float(loss.data)
    sum_loss /= len(x)
    return sum_loss

def main():
    train_data = []
    train_label = []
    test_data = []
    test_label = []
    
    train_data = make_data(TRAIN_NUM)
    train_label = make_label(train_data)
    test_data = make_data(TEST_NUM)
    test_label = make_label(test_data)
    
    #create model
    model = M.NN()
    if CONTINUE_FLG == True:
        modelpath = r'..\model\model_MV_' + str(USE_EPOCH) + 'epoch.npz'
        lasttime_end_epoch = USE_EPOCH
    else:
        lasttime_end_epoch = 0

    #set up an optimizer
    optimizer = chainer.optimizers.Adam()
    optimizer.setup(model)
    optimizer.add_hook(chainer.optimizer.WeightDecay(0.0001))
    optimizer.add_hook(chainer.optimizer.GradientClipping(5.0))
    
    #write log
    f = open(r'..\log\log_MV.csv', 'a')
    writer = csv.writer(f, lineterminator='\n')
    csvlist = []
    csvlist.append('epoch')
    csvlist.append('train loss')
    csvlist.append('test loss')
    writer.writerow(csvlist)
    f.close()
    
    for epoch in range(EPOCH):
        #train
        batchsize = int(len(train_label)/200)
        train_loss = math.sqrt(calc_loss(model, optimizer, train_data, train_label, batchsize, lasttime_end_epoch + epoch, True))
        print('train_loss: ', train_loss)

        #evaluation
        batchsize = int(len(test_label)/20)
        test_loss = math.sqrt(calc_loss(model, optimizer, test_data, test_label, batchsize, lasttime_end_epoch + epoch, True))
        print('test_loss: ', test_loss)

        #save model
        modelpath = r'..\model\moel_MV' + str(lasttime_end_epoch + epoch + 1) + 'epock.npz'
        chainer.serializers.save_npz(modelpath, model)
        
        #write log
        f = open(r'..\log\log_MV.csv', 'a')
        writer = csv.writer(f, lineterminator='\n')
        csvlist = []
        csvlist.append(lasttime_end_epoch + epoch + 1)        
        csvlist.append(train_loss)        
        csvlist.append(test_loss)
        writer.writerow(csvlist)
        f.close()
        
if __name__=='__main__':
    main()