import chainer
from chainer import functions as F
from chainer import links as L

class NN(chainer.Chain):
    def __init__(self, f1=20, f2=256, f3=128, fout=1):
        super(NN, self).__init__(
            l1 = L.Linear(f1, f2),
            l2 = L.Linear(f2, f3),
            l3 = L.Linear(f3, fout)
        )
    
    def forward(self, x):
        h = F.dropout(F.relu(self.l1(x)))
        h = F.dropout(F.relu(self.l2(h)))
        y = self.l3(h)
        return y