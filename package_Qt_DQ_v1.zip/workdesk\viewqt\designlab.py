"""デザインラボ（外観の調整）。Tk 版 `view/designlab.py` の「スタイル」タブ相当。

**エディット（業務・タスク・動作のプロパティ編集）はここに置かない**
（2026-09-05 の設計変更。編集は独立した「編集ウィンドウ」＝設定モードのスイッチで開く）。
役割が違うものを同居させない:

- **デザインラボ** … 全体に効く外観。**開いていてもタスクは実行できる**
  （テーマを試しながら動作を確かめられる）。
- **編集ウィンドウ** … 階層の編集。開いている間は**タスクを実行しない**。

**単独の窓ではない**（2026-09-06 に設定パネルと統合）。`AppearanceHub` の
1 タブとして `QWidget` で作り、窓としての振る舞い（タイトル・位置の永続化・
タイトルバーのダークモード）は `appearancehub.py` が持つ。

**操作要素は qt-material の既定スタイルに任せない**（2026-09-05 に実機で発覚）。
qt-material の `primaryTextColor` は `primaryColor` の上で **18/26 テーマが AA 4.5 未満**
（`dark_yellow` は 1.07 でほぼ見えない）。我々が計算する `on_accent` は 26/26 で AA を満たすので、
**アクセントを塗る要素は必ず自分のトークンで色を付ける**。

ここで触るものはすべて `theme_tokens.STATE` のキーで、`PERSIST_KEYS` に自動で入るので
`settings.appearance` へ永続化される。変更は `set_option()` → `subscribe()` した
メインウィンドウが最小限の再描画を選ぶ。
"""

from __future__ import annotations

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontDatabase, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QComboBox, QHBoxLayout, QLabel, QPushButton, QSlider, QVBoxLayout,
    QWidget,
)

from .. import theme_tokens as T
from . import qtheme, uikit
from .uikit import pal as _pal

GROUP_STYLES = [
    ("A", "区切り線"),
    ("D", "カード"),
    ("E", "レール"),
    ("F", "レール（色）"),
]
DENSITIES = [("compact", "詰める"), ("normal", "ふつう"), ("roomy", "ゆったり")]
# 選べる書体（2026-09-06 ユーザー指定の 10 種）。
#
# `QFontComboBox`（システムの全書体）をやめた理由は 2 つ:
#  ① 数百件から選ばせても実際に使うのは数種類。探すのが手間になっていた。
#  ② `QFontComboBox` は**編集できるコンボ**なので、文字の上を押しても一覧が
#     開かない（右端の ▼ だけ）。素の `QComboBox` は領域のどこを押しても開く。
#
# `Roboto` は qt-material が同梱しているものが `apply_stylesheet` 時に
# フォントデータベースへ入る（OS には無い）。実際に入っているものだけを出す。
FONT_FAMILIES = [
    "Yu Gothic UI", "BIZ UDPGothic", "Meiryo UI", "Noto Sans JP",
    "Microsoft Sans Serif", "MS PGothic", "Roboto", "游明朝",
    "HGP行書体", "HGP創英角ﾎﾟｯﾌﾟ体",
]
# スクロールバーの見せ方（Tk 版から移植）。`hover` はつまみに触れるまで透明。
SCROLLBARS = [("always", "常に"), ("auto", "自動"), ("thin", "細く"), ("hover", "触れたら")]

# --- テーマ選択の 2 段階（2026-09-06 要望） -------------------------- #
# qt-material のテーマ名は `{mode}_{color}.xml`。ただし `orange` と `_500` 付きは
# **ライトにしかない**ので選択肢から外す（両モードで揃う 9 色だけを見せる）。
THEME_MODES = [("light", "ライトモード"), ("dark", "ダークモード"),
               ("retro", "レトロ")]
# 2 段階に収まらないテーマ（＝色を選ばせない自前スキン）。`THEME_MODES` の
# キー → そのモードが取りうるテーマ名。選ぶと「テーマ2」の色は意味を持たない
# ので伏せる。レトロは**枠の色ちがいが 3 つ**あり、どれを当てるかは
# `qtheme.retro_theme_name()`（＝「枠の色」の設定と時計）が決める。
CUSTOM_MODE_THEMES: dict[str, tuple[str, ...]] = {
    "retro": tuple(qtheme.RETRO_FRAMES.values()),
}
_THEME_MODE_OF = {name: mode
                  for mode, names in CUSTOM_MODE_THEMES.items() for name in names}
# レトロのときの「テーマ2」＝枠の色。ライト/ダークの 9 色と**同じ行**に出す
# （2026-09-09 ユーザー指定）── モードによって選ぶものが入れ替わるだけ。
#
# **名前は色ではなく「状態」で見せる**（2026-09-09 ユーザー指定）── 原作で
# HP が減るほど窓の色が変わるのになぞらえているので、意味のほうが実体に近い。
# 色見本も出さない（キーが色名なのは、種の XML がその色で作られているという事実）。
RETRO_FRAMES_UI = ["white", "yellow", "orange", "auto"]
RETRO_FRAME_LABELS = {"white": "通常", "yellow": "注意", "orange": "危険",
                      "auto": "時間"}
# 色は **qt-material のテーマ名と同じ英語キー**をそのまま出す（2026-09-06 ユーザー指定）。
# 和訳を当てると「保存された設定に入っている名前」と画面の表記がずれるため。
THEME_COLORS = ["amber", "blue", "cyan", "lightgreen", "pink", "purple",
                "red", "teal", "yellow"]
# 各色の見本（qt-material 各テーマの primaryColor に相当する Material Design の
# 標準色）。**これは自前テーマの色理論とは別物**＝選択肢そのものの見本という
# 固定の識別子なので、ここだけは直書きを許す。
_COLOR_SWATCH = {
    "amber": "#FFC107", "blue": "#2196F3", "cyan": "#00BCD4",
    "lightgreen": "#8BC34A", "pink": "#E91E63", "purple": "#9C27B0",
    "red": "#F44336", "teal": "#009688", "yellow": "#FFEB3B",
}
_COLOR_KEYS = set(THEME_COLORS)


def split_theme_name(name: str) -> tuple[str, str]:
    """`"dark_blue.xml"` → `("dark", "blue")`。

    `_500` 付きや `orange`（ライト専用）が保存済み設定に残っていても**落ちない**
    ように、選択肢に無ければ一番近いものへ寄せる（後方互換）。

    自前スキン（色を選ばせないもの）は**色が空文字**で返る ── 呼び出し側は
    「テーマ2」の表示をいじらない（切り替えて戻ったとき選び直しにならない）。
    """
    if name in _THEME_MODE_OF:
        return _THEME_MODE_OF[name], ""
    base = name[:-4] if name.endswith(".xml") else name
    mode, _, color = base.partition("_")
    color = color.removesuffix("_500")
    if color == "orange":
        color = "amber"
    if mode not in ("light", "dark"):
        mode = "dark"
    if color not in _COLOR_KEYS:
        color = "blue"
    return mode, color


def compose_theme_name(mode: str, color: str) -> str:
    if mode == "retro":
        return qtheme.retro_theme_name()    # 色は「枠の色」の設定と時計が決める
    return "%s_%s.xml" % (mode, color)


class _Segmented(QWidget):
    """選択肢が少ないものを横並びのボタンで選ばせる（Tk 版 `_segmented` 相当）。"""

    changed = Signal(str)

    def __init__(self, options: list[tuple[str, str]], current: str) -> None:
        super().__init__()
        uikit.transparent(self)
        self._buttons: dict[str, QPushButton] = {}
        self._value = current
        h = QHBoxLayout(self)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        for key, label in options:
            b = QPushButton(label)
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _c=False, k=key: self._pick(k))
            self._buttons[key] = b
            h.addWidget(b)
        self.set_value(current)

    def value(self) -> str:
        return self._value

    def set_value(self, key: str) -> None:
        self._value = key
        for k, b in self._buttons.items():
            b.setChecked(k == key)
        self.restyle()

    def restyle(self) -> None:
        """**自分のトークンで塗る。** qt-material の既定に任せると 18/26 テーマで
        アクセント上の文字が AA 未満になる（`dark_yellow` は CR 1.07）。

        **無効のときの見た目も自分で書く**（2026-09-09）── 自前の QSS が
        既定の「灰色にする」描き方に勝つので、書かないと**押せないのに
        押せるように見える**（スキンが決めてしまう項目で実際にそう見えた）。
        """
        on = ("QPushButton{background:%s;color:%s;border:1px solid %s;font-size:15px;"
              "border-radius:5px;padding:6px 12px;}"
              % (_pal("accent"), _pal("on_accent"), _pal("accent")))
        off = ("QPushButton{background:transparent;color:%s;border:1px solid %s;"
               "border-radius:5px;padding:6px 12px;font-size:15px;}"
               "QPushButton:hover{background:%s;}"
               % (_pal("ink"), _pal("input_border"), _pal("row_hover")))
        # 無効: 面は地のまま・文字と枠は `faint`（＝選べないことが分かる濃さ）
        dim = ("QPushButton:disabled{background:transparent;color:%s;"
               "border:1px solid %s;}" % (_pal("faint"), _pal("faint")))
        for k, b in self._buttons.items():
            b.setStyleSheet((on if k == self._value else off) + dim)

    def _pick(self, key: str) -> None:
        self.set_value(key)
        self.changed.emit(key)


def _swatch_icon(color: str, size: int = 14) -> QIcon:
    """プルダウンの項目に付ける色見本（角丸の四角）。"""
    pm = QPixmap(size, size)
    pm.fill(Qt.transparent)
    pt = QPainter(pm)
    pt.setRenderHint(QPainter.Antialiasing, True)
    pt.setPen(Qt.NoPen)
    pt.setBrush(QColor(_COLOR_SWATCH.get(color, "#808080")))
    pt.drawRoundedRect(0, 0, size, size, 3, 3)
    pt.end()
    return QIcon(pm)


class _ColorCombo(QComboBox):
    """テーマの色（9 色）を選ぶプルダウン（2026-09-06 要望）。

    以前は 9 色を塗ったボタンの格子だった。色見本そのもので塗るので**彩度の高い面が
    画面の 1/3 を占める**ことになり、「選ぶための一覧」ではなく見せ場になっていた
    ── ユーザー判断でプルダウンへ変更。色の識別は項目左の小さな見本で足りる。

    項目の文字は `THEME_COLORS` の英語キー（＝qt-material のテーマ名の一部）。
    """

    changed = Signal(str)

    def __init__(self, colors: list[str], current: str, *,
                 labels: dict[str, str] | None = None,
                 swatch: bool = True) -> None:
        super().__init__()
        self.setCursor(Qt.PointingHandCursor)
        self.setIconSize(QSize(14, 14))
        for key in colors:
            text = (labels or {}).get(key, key)
            if swatch:
                self.addItem(_swatch_icon(key), text, key)
            else:
                self.addItem(text, key)     # 色見本を見せない（意味だけで選ばせる）
        self.set_value(current)
        self.currentIndexChanged.connect(
            lambda _i: self.changed.emit(self.value()))

    def keys(self) -> list[str]:
        return [str(self.itemData(i)) for i in range(self.count())]

    def value(self) -> str:
        return str(self.currentData() or "")

    def set_value(self, key: str) -> None:
        """**通知せずに**表示だけ合わせる（他所からのテーマ変更に追随するとき）。"""
        i = self.findData(key)
        if i < 0 or i == self.currentIndex():
            return
        blocked = self.blockSignals(True)
        self.setCurrentIndex(i)
        self.blockSignals(blocked)

    def pick(self, key: str) -> None:
        """ユーザーが選んだのと同じ経路（`changed` が飛ぶ）。テストの入口でもある。"""
        i = self.findData(key)
        if i < 0:
            return
        if i == self.currentIndex():
            self.changed.emit(key)
        else:
            self.setCurrentIndex(i)


class DesignLab(QWidget):
    """外観の調整パネル。`AppearanceHub` の 1 タブ（開いていてもタスクは実行できる）。"""

    def __init__(self, host, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._host = host                      # MainWindow（テーマ適用と再描画の口）
        # 素の QWidget のまま置くと qt-material の既定の地色が透ける。`_restyle()` が
        # 毎回スタイルシートを丸ごと差し替えるので、透明化の規則もそちらに含める
        # （`uikit.transparent` を単発で呼ぶと `_restyle()` の初回呼び出しで消える）。
        self.setObjectName("designLab")

        v = QVBoxLayout(self)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(18)   # 項目間の縦の余白（2026-09-05 少し広げた）

        # --- テーマ（2 段階。2026-09-06） ----------------------------- #
        cur_mode, cur_color = split_theme_name(qtheme.current_theme())
        self.mode_seg = _Segmented(THEME_MODES, cur_mode)
        self.mode_seg.changed.connect(self._on_theme_changed)
        v.addWidget(uikit.form_row("テーマ1", self.mode_seg, label_width=96))

        # 「テーマ2」は**モードによって中身が入れ替わる** ── ライト/ダークなら
        # 9 色、レトロなら枠の色（白 / 黄 / オレンジ / 時間変化）。行を増やさず
        # 同じ場所で切り替える（2026-09-09 ユーザー指定）。
        self.color_box = _ColorCombo(THEME_COLORS, cur_color or "blue")
        self.color_box.changed.connect(self._on_theme_changed)
        self.frame_box = _ColorCombo(RETRO_FRAMES_UI,
                                     str(T.STATE.get("retro_frame", "white")),
                                     labels=RETRO_FRAME_LABELS, swatch=False)
        self.frame_box.changed.connect(lambda k: self._set("retro_frame", k))
        self._color_slot = uikit.transparent(QWidget())
        slot = QVBoxLayout(self._color_slot)
        slot.setContentsMargins(0, 0, 0, 0)
        slot.setSpacing(0)
        slot.addWidget(self.color_box)
        slot.addWidget(self.frame_box)
        self.frame_box.setVisible(False)
        self._color_row = uikit.form_row("テーマ2", self._color_slot, label_width=96)
        v.addWidget(self._color_row)

        # --- 業務グループの見せ方（サイドバー専用） ------------------ #
        self.group_seg = _Segmented(GROUP_STYLES, str(T.STATE.get("group_style", "A")))
        self.group_seg.changed.connect(lambda k: self._set("group_style", k))
        self._group_row = uikit.form_row("グループ", self.group_seg, label_width=96)
        v.addWidget(self._group_row)

        # --- フォント ------------------------------------------------ #
        self.font_box = QComboBox()
        self.font_box.setCursor(Qt.PointingHandCursor)
        self._fill_fonts()
        self.font_box.currentIndexChanged.connect(
            lambda _i: self._set("font_family", self.font_box.currentData()))
        self._font_row = uikit.form_row("書体", self.font_box, label_width=96)
        v.addWidget(self._font_row)

        self.size_slider = QSlider(Qt.Horizontal)
        self.size_slider.setRange(T.FONT_PT_MIN, T.FONT_PT_MAX)
        self.size_slider.setValue(int(T.STATE.get("font_size", 10)))
        self.size_slider.valueChanged.connect(lambda n: self._set("font_size", int(n)))
        v.addWidget(uikit.form_row("文字の大きさ", self.size_slider, label_width=96))

        # --- クリック密度 -------------------------------------------- #
        self.density_seg = _Segmented(DENSITIES, str(T.STATE.get("click_density", "normal")))
        self.density_seg.changed.connect(lambda k: self._set("click_density", k))
        v.addWidget(uikit.form_row("行の高さ", self.density_seg, label_width=96))

        # --- スクロールバー（Tk 版から移植） -------------------------- #
        self.scrollbar_seg = _Segmented(
            SCROLLBARS, str(T.STATE.get("scrollbar_mode", "auto")))
        self.scrollbar_seg.changed.connect(lambda k: self._set("scrollbar_mode", k))
        self._scrollbar_row = uikit.form_row("スクロールバー", self.scrollbar_seg,
                                             label_width=96)
        v.addWidget(self._scrollbar_row)

        v.addStretch(1)
        # 「スキンが決めてしまう項目」を伏せるのは**全部の行を作ってから**
        self._sync_color_row(cur_mode)
        self._restyle()

    def _fill_fonts(self) -> None:
        """`FONT_FAMILIES` のうち**実際に入っているもの**だけを並べる。

        各項目はその書体自身で描く（行書体・ポップ体は名前だけでは分からない）。
        保存済みの選択が一覧に無いときは**先頭に足して残す** ── 選んだ覚えの
        ないものへ勝手に変えない。
        """
        installed = set(QFontDatabase.families())
        # スキンが書体を固定しているなら**その名前を出す**（欄は無効にしてある）。
        # ユーザーの選択を出すと、画面に見えている書体と食い違って嘘になる。
        cur = T.skin_font() or str(T.STATE.get("font_family", "Yu Gothic UI"))
        items = [f for f in FONT_FAMILIES if f in installed]
        if cur not in items:
            items.insert(0, cur)
        blocked = self.font_box.blockSignals(True)
        self.font_box.clear()
        for i, family in enumerate(items):
            self.font_box.addItem(family, family)
            self.font_box.setItemData(i, QFont(family, 11), Qt.FontRole)
        self.font_box.setCurrentIndex(items.index(cur))
        self.font_box.blockSignals(blocked)

    # --- 変更 -------------------------------------------------------- #
    def _sync_color_row(self, mode: str) -> None:
        """スキンが決めてしまう項目を伏せる（2026-09-09）。

        レトロは**見た目一式が 1 つの決め事**なので、書体・グループの見せ方・
        スクロールバーはユーザーに選ばせない ── 選ばせても効かない（スキン側の
        値が勝つ）ものを操作できるように見せない。

        消さずに**無効にして残す** ── 行が消えると下の項目が繰り上がって、
        モードを行き来するたびに画面が跳ねる。**「テーマ1」「テーマ2」は
        どちらのモードでも操作できる** ── テーマ1 はここからしかレトロを
        出入りできないから、テーマ2 はレトロでは枠の色を選ぶ場所になるから。
        """
        retro = mode in CUSTOM_MODE_THEMES
        # 「テーマ2」は**どちらのモードでも操作できる**（中身が入れ替わるだけ）。
        self.color_box.setVisible(not retro)
        self.frame_box.setVisible(retro)
        self._font_row.setEnabled(not T.skin_font())
        self._fill_fonts()                  # 固定された書体の名前に入れ替える
        self._group_row.setEnabled(not T.forced_group_style())
        self._scrollbar_row.setEnabled(T.scrollbars_visible())

    def _on_theme_changed(self, _val: str = "") -> None:
        mode = self.mode_seg.value()
        name = compose_theme_name(mode, self.color_box.value())
        self._host.apply_theme(name)       # PALETTE 差し替え → 全再描画
        # **スキンを当てたあと**に伏せる項目を決める（`T.SKIN` が新しくなっている）
        self._sync_color_row(mode)
        self._restyle()

    def apply_theme(self) -> None:
        """他所（編集ウィンドウ等）からのテーマ変更にも追従する（2026-09-05）。

        `MainWindow.apply_theme()` から呼ばれる。**自分の操作から変えたときは
        `_on_theme_changed` が既に塗り直す**ので、ここはモード／色の表示を
        同期しつつ塗り直すだけ（`_host.apply_theme` を呼び返さない＝無限ループに
        しない）。
        """
        mode, color = split_theme_name(qtheme.current_theme())
        if mode != self.mode_seg.value():
            self.mode_seg.set_value(mode)
        if color and color != self.color_box.value():
            self.color_box.set_value(color)
        frame = str(T.STATE.get("retro_frame", "white"))
        if frame != self.frame_box.value():
            self.frame_box.set_value(frame)
        self._sync_color_row(mode)
        self._restyle()

    def _set(self, key: str, value) -> None:
        """`set_option` が `subscribe` 済みのメインウィンドウへ通知し、保存も走る。"""
        T.set_option(key, value)

    def _restyle(self) -> None:
        """テーマが変わったら**すべての操作要素を塗り直す**（既定スタイルに戻らないように）。

        文字サイズ（2026-09-05 一時調整機能で確認して確定）:
          項目名（"モード"/"グループ" 等）＝ 13px ／ テキストボックス・ボタン内 ＝ 15px。
        """
        css = (
            "#designLab{background:transparent;border:none;}"
            "QLabel{color:%s;background:transparent;border:none;font-size:15px;}"
            "#rowLabel{font-size:13px;}"
            "QComboBox{background:%s;color:%s;border:1px solid %s;border-radius:5px;"
            "padding:5px 8px;font-size:15px;}"
            # 無効なプルダウン・見出しは `faint`（選べないことが分かる濃さ）
            "QComboBox:disabled{color:%s;border-color:%s;}"
            "QLabel:disabled{color:%s;}"
            # プルダウンを開いたときの一覧は `uikit.selection_qss()` が持つ
            "QSlider{background:transparent;}"
            "QSlider::groove:horizontal{background:%s;height:4px;border-radius:2px;}"
            "QSlider::handle:horizontal{background:%s;width:14px;height:14px;"
            "margin:-5px 0;border-radius:7px;}"
            "QSlider::sub-page:horizontal{background:%s;border-radius:2px;}"
            % (_pal("ink"),
               _pal("card_face"), _pal("ink"), _pal("input_border"),
               _pal("faint"), _pal("faint"), _pal("faint"),
               _pal("divider"), _pal("accent"), _pal("accent"))
        )
        self.setStyleSheet(css + uikit.selection_qss())
        uikit.style_combo_popups(self)
        uikit.fit_label_column(self)        # 見出し列を実幅へ（左に帯を残さない）
        for seg in (getattr(self, "group_seg", None), getattr(self, "density_seg", None),
                    getattr(self, "scrollbar_seg", None), getattr(self, "mode_seg", None)):
            if seg is not None:
                seg.restyle()
