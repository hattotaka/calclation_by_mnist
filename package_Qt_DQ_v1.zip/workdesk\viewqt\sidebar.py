"""サイドバー（業務一覧）。Tk 版 `view/sidebar.py` の置き換え（Phase 3d）。

design-notes「2026-09-04/05 グループ表現」で決めたこと:

- 業務グループの見せ方は **A 区切り線 / D カード / E レール(無彩色) / F レール(グループ色)**
  の 4 つから選べる（`theme_tokens.STATE["group_style"]`。**既定は A**
  ＝グループ間のドラッグ移動を考えると横線が境界として分かりやすい）。
- 4 つは別実装ではなく「グループの入れ物をどう飾るか」だけが違う → `_group_block()` に集約。
- **色は「状態」に予約されている**（選択＝アクセント）。グループという静的な属性に
  面の色を使わない。F だけは 3px のレールに載せる（面積が小さいので競合しない）。
- 濃さはテーマの色をそのまま使わず、`qtheme` が目標コントラストから逆算したトークンを使う。

Qt のスタイリングでの注意（スパイク9 で実際に踏んだもの）:
  - `QFrame` には border が当たる → 細い矩形は `QWidget` で作る
  - ウィジェット側 QSS はセレクタ無しだと詳細度で負ける → `QLabel{...}` / `#id{...}`
  - `QScrollArea` の地色は palette では塗れない → ID セレクタ ＋ `WA_StyledBackground`
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, Qt, Signal
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QScrollArea, QSizePolicy, QVBoxLayout, QWidget,
)

from .. import theme_tokens as T
from ..model import AppData
from . import icons, qtheme, uikit
from .uikit import pal as _pal
from .dragdrop import RowReorder

SIDEBAR_WIDTH = 248        # 既定の幅（`QSplitter` で可変。settings に覚える）
MIN_WIDTH, MAX_WIDTH = 150, 480
# 見出しは**英語＝場所の名前**にする（2026-09-07 ユーザー判断）。画面の中で
# 「日本語＝自分のデータ／英語＝場所の名前」の二層になり、目線がデータへ集まる。
# 語の割り当ては 一覧＝`Menu` / フッター＝`Tools` で固定する。
HEADER_TEXT = "Menu"
FOOTER_TEXT = "Tools"
RAIL_WIDTH = 3
_ROW_RADIUS = 4
# `Menu` と `Tools` の間の余白（2026-09-07）。**線では分けない** ── グループ表現 A
# （区切り線）のとき、グループの線と見分けがつかなくなるため（ユーザー指摘）。
# 代わりに近接で分ける＝見出しを自分の行に寄せ、一覧との間を開ける。
FOOT_GAP = 12           # レイアウトの間隔 8 に足す分（実測 上 20px / 下 9px）
ICON_BOX = 20           # フッター行の先頭アイコンの枠（幅を揃えて文字の左端を合わせる）
FRAME_GAP = 2           # 枠を描くスキンで、ペインの枠を仕切りへ寄せる距離
# **スクロールバーは仕切り線に寄せる**（2026-09-08 要望。参考にした UI では
# どれも境界線と接するか、接するかどうかの距離だった）。そのために一覧の
# 右余白を「外側（`outer` / `_card`）」から「内側（`body`）」へ移す ──
# 見た目の行の位置は今までどおりで、スクロールバーだけがペインの右端へ来る。
PANE_PAD = 14           # 窓の枠から一覧までの余白（左・上・下）
LIST_PAD_L = 10         # `body` の左余白（`_card` の 4px と合わせて行の左端を決める）
LIST_PAD_R = 26         # `body` の右余白（＝以前の 12 ＋ 4 ＋ 10。行の位置を変えない）
# 実寸はアイコンごと（Tk 版で詰めた値をそのまま使う ── 歯車は線が多いぶん
# 小さく見えるので一回り大きくする）。
_ICON_PX = {"sliders": 18, "gear": 20}


class _SidebarRow(QWidget):
    """サイドバーの 1 行。通常 / ホバー / 選択 の 3 状態を持つ。

    選択だけがアクセント色で塗られる（＝色は状態のもの）。ホバーはごく薄い面。

    **業務行とフッター行（デザインラボ／設定）で共有する**（2026-09-06 要望＝
    フッターも「業務のカードと同じ雰囲気」にする）。同じ見た目にするために
    `objectName` まで同じにしてある ── 塗りの規則を 2 つに書き分けない。
    """

    def __init__(self, text: str, parent: QWidget | None = None, *,
                 icon: str = "") -> None:
        super().__init__(parent)
        self._selected = False
        self._hover = False
        self._icon_name = icon
        self.setObjectName("workRow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setCursor(Qt.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        pad = T.metrics()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(pad["side_padx"], pad["side_pady"],
                               pad["side_padx"], pad["side_pady"])
        # アイコンは**常に作る**。出す/出さないはスキン次第で切り替わるので、
        # 判断は `_restyle()` に置く（フッター行は `render()` で作り直されない
        # ＝テーマを変えた瞬間に追随できる必要がある）。
        lay.setSpacing(8 if icon else 0)
        # 選択を示す `▶`（面を塗らないスキン用）。**幅を固定して常に置く**
        # ── 選択が動くたびに文字の左端がずれないように。出すかどうかは
        # `_restyle()` が決める（既定のスキンでは最初から隠す）。
        self._cursor = QLabel("", self)
        self._cursor.setObjectName("workRowCursor")
        # 幅は `uikit.fit_cursor()` が**文字の大きさに合わせて**決める（左寄せ
        # ＝余りが名前との隙間になる）。固定幅だと大きい文字で名前と重なった。
        self._cursor.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        lay.addWidget(self._cursor)
        self._cursor.setVisible(False)
        self._icon_label: QLabel | None = None
        if icon:
            self._icon_label = QLabel()
            self._icon_label.setObjectName("workRowIcon")
            self._icon_label.setFixedSize(ICON_BOX, ICON_BOX)
            self._icon_label.setAlignment(Qt.AlignCenter)
            lay.addWidget(self._icon_label)
        self._label = QLabel(text)
        self._label.setObjectName("workRowLabel")
        lay.addWidget(self._label)
        self._restyle()

    # --- 状態 ------------------------------------------------------- #
    def set_selected(self, on: bool) -> None:
        if self._selected != on:
            self._selected = on
            self._restyle()

    def set_text(self, text: str) -> None:
        self._label.setText(text)

    def begin_rename(self, on_commit) -> None:
        """名前ラベルの上に入力欄をかぶせる（設定モードのダブルクリック）。"""
        uikit.inline_rename(self, self._label, on_commit)

    def enterEvent(self, _e) -> None:   # noqa: N802
        self._hover = True
        self._restyle()

    def leaveEvent(self, _e) -> None:   # noqa: N802
        self._hover = False
        self._restyle()

    def _restyle(self) -> None:
        # 選択を `▶` で示すスキン（レトロ）では**面を塗らない** ── 2 色の画面に
        # 白ベタを置くと強すぎる（2026-09-09 ユーザー判断）。
        cursor = T.use_cursor()
        if self._selected and cursor:
            face, ink = "transparent", _pal("ink")
            weight = "600"
        elif self._selected:
            face, ink = _pal("accent"), _pal("on_accent")
            weight = "600"
        elif self._hover:
            face, ink = _pal("row_hover"), _pal("ink")
            weight = "400"
        else:
            face, ink = "transparent", _pal("ink")
            weight = "400"
        # ID セレクタで書く（セレクタ無しだと qt-material のグローバル QSS に負ける）。
        # フォントも自分の QSS に書く ── `setFont()` は qt-material のグローバル
        # QSS に負けて反映されない（qtheme.font_css の docstring 参照）。
        self.setStyleSheet(
            "#workRow{background:%s;border:none;border-radius:%dpx;}"
            "#workRowIcon{background:transparent;border:none;}"
            "#workRowCursor{color:%s;background:transparent;border:none;%s}"
            "#workRowLabel{color:%s;background:transparent;border:none;"
            "font-weight:%s;%s}" % (face, _ROW_RADIUS, ink, qtheme.font_css(),
                                    ink, weight, qtheme.font_css())
        )
        uikit.pixel_font(self)      # ドット字体ならアンチエイリアスを切る
        # `▶` は選択中だけ。枠は残す（文字の左端を動かさない）。
        self._cursor.setVisible(cursor)
        self._cursor.setText(T.CURSOR_MARK if (cursor and self._selected) else "")
        if cursor:
            uikit.fit_cursor(self._cursor)
        if self._icon_label is not None:
            # アイコンを出さないスキン（レトロ）では**場所ごと詰める**。
            show = T.show_icons()
            self._icon_label.setVisible(show)
            self.layout().setSpacing(8 if show else 0)
            # アイコンは文字と同じ色（面が変われば一緒に変わる）。描けなければ
            # **アイコン無しで成立させる**（Tk 版からの約束）。
            pm = icons.pixmap(self._icon_name, ink, _ICON_PX.get(self._icon_name, 18))
            self._icon_label.setPixmap(pm) if pm else self._icon_label.clear()


class _WorkRow(_SidebarRow):
    """業務 1 行（選択・右クリックの対象）。"""

    clicked = Signal(str)
    rightClicked = Signal(str, int, int)
    doubleClicked = Signal(str)

    def __init__(self, work_id: str, name: str, parent: QWidget | None = None) -> None:
        super().__init__(name, parent)
        self.work_id = work_id
        self.setContextMenuPolicy(Qt.CustomContextMenu)

    def mousePressEvent(self, e) -> None:   # noqa: N802
        if e.button() == Qt.LeftButton:
            self.clicked.emit(self.work_id)
        elif e.button() == Qt.RightButton:
            p = e.globalPosition().toPoint()
            self.rightClicked.emit(self.work_id, p.x(), p.y())

    def mouseDoubleClickEvent(self, e) -> None:   # noqa: N802
        """設定モードでの改名の入口（判断は App が持つ。行はモードを知らない）。"""
        if e.button() == Qt.LeftButton:
            self.doubleClicked.emit(self.work_id)


class _FooterRow(_SidebarRow):
    """フッターの 1 行（デザインラボ／設定）。**選択状態は持たない**
    ── 押すと窓が開くだけで、一覧の選択とは別物だから。"""

    clicked = Signal()

    def mousePressEvent(self, e) -> None:   # noqa: N802
        if e.button() == Qt.LeftButton:
            self.clicked.emit()


def _clear(w: QWidget, name: str) -> QWidget:
    """**包みの地色を消す。**

    ただの `QWidget` で包むと qt-material のグローバル QSS が地色を塗り、
    そこだけ帯のように浮いて見える（2026-09-05 実機で発覚。設定パネルでも同じ）。
    包む必要がある場所（余白・区切り線・レール）は必ずこれを通す。
    """
    w.setObjectName(name)
    w.setStyleSheet("#%s{background:transparent;border:none;}" % name)
    return w


def _spaced(w: QWidget, top: int) -> QWidget:
    """上に余白を足すだけの包み（レイアウトの spacing だけではグループ間の余白を作り分けられないため）。"""
    if not top:
        return w
    wrap = QWidget()
    v = QVBoxLayout(wrap)
    v.setContentsMargins(0, top, 0, 0)
    v.setSpacing(0)
    v.addWidget(w)
    return _clear(wrap, "groupSpacer")


def _thin(name: str, color: str, *, width: int = 0, height: int = 0) -> QWidget:
    """細い矩形。**`QFrame` を使わない**（qt-material が border を当てて全部その色になる）。"""
    w = QWidget()
    w.setObjectName(name)
    if width:
        w.setFixedWidth(width)
    if height:
        w.setFixedHeight(height)
    w.setStyleSheet("#%s{background:%s;border:none;border-radius:%dpx;}"
                    % (name, color, 2 if width else 0))
    return w


def _group_block(index: int, rows: list[QWidget], style: str, first: bool) -> QWidget:
    """1 グループぶんの行をまとめて「入れ物」に入れる。**A/D/E/F の差はここだけ**。"""
    inner = QWidget()
    iv = QVBoxLayout(inner)
    iv.setContentsMargins(0, 0, 0, 0)
    iv.setSpacing(2)
    for r in rows:
        iv.addWidget(r)
    if style != "D":                                   # D は自分で面を塗る
        _clear(inner, "groupInner")

    if style == "D":                                   # カード＝面を一段上げる
        inner.setObjectName("groupCard")
        inner.setAttribute(Qt.WA_StyledBackground, True)
        inner.setStyleSheet(
            "#groupCard{background:%s;border:1px solid %s;border-radius:8px;}"
            % (_pal("card_face"), _pal("card_edge")))
        iv.setContentsMargins(5, 5, 5, 5)
        return _spaced(inner, 0 if first else 8)

    if style in ("E", "F"):                            # レール＝左に細い縦バー
        color = T.group_tone(index, "bar") if T.group_hue_visible(style) else _pal("rail")
        holder = QWidget()
        h = QHBoxLayout(holder)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        h.addWidget(_thin("groupRail", color, width=RAIL_WIDTH))
        h.addWidget(inner, 1)
        # グループ間の余白（2026-09-05 少し広げた。レールだけだと境界が詰まって見える）
        return _spaced(_clear(holder, "groupHolder"), 0 if first else 16)

    if first:                                          # A＝区切り線（先頭には引かない）
        return inner
    wrap = QWidget()
    v = QVBoxLayout(wrap)
    v.setContentsMargins(0, 0, 0, 0)
    v.setSpacing(0)
    v.addSpacing(9)
    v.addWidget(_thin("groupLine", _pal("divider"), height=1))
    v.addSpacing(9)
    v.addWidget(inner)
    return _clear(wrap, "groupDivided")


class Sidebar(QWidget):
    """業務一覧。`render(app_data)` で作り直す（Tk 版と同じく毎回まるごと作る）。"""

    workSelected = Signal(str)
    # 既に選択中の業務行を（再）クリックしたとき（設定モードでタスク/動作を選んだ
    # あと、その親業務の行をクリックして業務へ選択を戻すため。2026-09-05）。
    # `workSelected` はサイドバー上の識別が変わったときだけ飛ぶので、これとは別。
    workReselected = Signal(str)
    # 業務 id（**空白部なら None**）と画面座標。`object` なのは None を運ぶため。
    workRightClicked = Signal(object, int, int)
    # 並べ替え: (動かした業務, その手前に来る業務 or None, 行き先の業務グループ。
    # 新しいグループへ出すときは行き先が None)
    reorderRequested = Signal(str, object, object)
    # 業務行そのもののダブルクリック＝その場で改名（設定モードのときだけ。2026-09-06）
    renameRequested = Signal(str)
    # フッターのボタン（デザインラボ／設定。2026-09-05 に帯からここへ移した）
    designLabRequested = Signal()
    settingsRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        # 幅は `QSplitter` で可変（2026-09-05 ユーザー要望）。掴めるように上下限だけ持つ。
        self.setMinimumWidth(MIN_WIDTH)
        self.setMaximumWidth(MAX_WIDTH)
        # **自分の地も塗る**（メインパネルと同じ手当て。2026-09-07）。素の地は
        # qt-material の既定色（`#31363b`）で、一覧の地（`bg`）と違う。外枠が
        # あった間はそれが「枠の中と外」に見えていたが、枠を撤廃したら
        # **左ペインだけ明るい**形で表に出た（実測で発覚）。
        self.setObjectName("sidebarPane")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self._rows: dict[str, _WorkRow] = {}
        self._selected_id: str | None = None

        outer = self._outer = QVBoxLayout(self)
        # ウィンドウ枠との距離は少し広めに取る（2026-09-05 要望）。**右だけは 0**
        # ＝スクロールバーを仕切り線に寄せるため（余白は `body` が内側で持つ）。
        # 枠を描くスキン（`T.frame_width()` > 0）では右も空ける ── 枠が仕切りに
        # 貼り付かないように。実際の値は `_apply_frame()` が入れる。
        outer.setContentsMargins(PANE_PAD, PANE_PAD, 0, PANE_PAD)
        outer.setSpacing(8)

        # 見出し（一覧の外・窓の地の上）。**左上に小さく・控えめな色**で置く
        # ＝読ませずに場所だけ示す（2026-09-07。中央・太字・`ink` だと画面で
        # 一番強い文字になり、業務名より先に目に入っていた）。
        self._head = QLabel(HEADER_TEXT)
        self._head.setObjectName("sidebarHead")
        self._head.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        outer.addWidget(self._head)

        # 一覧の入れ物（2026-09-05 フラットな地へ変更。以前は「カード」として
        # 面・枠を分けていたが、ユーザー提示の参考イメージ＝窓の地と同じ色に
        # 溶け込ませ、グループ表現（A/D/E/F）だけで区切りを出す形にした）。
        self._card = QWidget()
        self._card.setObjectName("sidebarCard")
        self._card.setAttribute(Qt.WA_StyledBackground, True)
        card_v = self._card_v = QVBoxLayout(self._card)
        # 行の左端の位置を決める余白（枠を撤廃した今は見えない）。**右は 0**
        # ＝スクロール領域をペインの右端まで伸ばす。上下は合図の帯が引き受ける。
        card_v.setContentsMargins(4, 0, 0, 0)
        card_v.setSpacing(0)
        # 一覧の上下に「まだ続きがある」の合図（`∧` `∨`）を置く。メインパネルに
        # 2026-09-06 に入れたものと**同じ帯・同じ大きさ**（2026-09-07 要望＝
        # 業務一覧もスクロールできることが分かるように）。帯は常にあり、
        # 中身だけが出たり消えたりする（一覧の高さを動かさないため）。
        self._up = uikit.hint_band("sidebarUp")
        card_v.addWidget(self._up)
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        card_v.addWidget(self._scroll)
        self._more = uikit.hint_band("sidebarMore")
        card_v.addWidget(self._more)
        bar = self._scroll.verticalScrollBar()
        bar.valueChanged.connect(self._sync_more_hint)
        bar.rangeChanged.connect(lambda *_a: self._sync_more_hint())
        outer.addWidget(self._card, 1)

        # フッターの見出し（一覧の見出しと同じ扱い＝場所の名前）。**枠を撤廃した
        # ので、一覧とフッターを分けているのはこの見出しと隙間だけ**になった。
        self._foot = QLabel(FOOTER_TEXT)
        self._foot.setObjectName("sidebarFoot")
        self._foot.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

        # フッター（デザインラボ／設定への導線。2026-09-05 要望で帯からここへ移した。
        # Tk 版と同じ位置）。**業務一覧と同じ作り**にする（2026-09-06 要望）
        # ＝同じ地の上に、業務行と同じ行を縦に並べる。枠付きボタンを 2 つ横に
        # 並べる形は、一覧とは別部品に見えてしまっていた。
        self._footer_card = QWidget()
        self._footer_card.setObjectName("sidebarFooterCard")
        self._footer_card.setAttribute(Qt.WA_StyledBackground, True)
        fv = self._footer_v = QVBoxLayout(self._footer_card)
        # 行の左右の端を一覧の業務行と揃える（一覧側はカードの 4px ＋ body の余白）。
        # 右は `outer` の余白を 0 にしたぶんをここで持つ。
        fv.setContentsMargins(4 + LIST_PAD_L, 6, LIST_PAD_R, 6)
        fv.setSpacing(2)
        self._footer_rows: list[_FooterRow] = []
        # アイコンは Tk 版と同じもの（デザインラボ＝つまみ / 設定＝歯車）
        for text, icon, signal in (("デザインラボ", "sliders", self.designLabRequested),
                                   ("設定", "gear", self.settingsRequested)):
            row = _FooterRow(text, icon=icon)
            row.clicked.connect(signal.emit)
            fv.addWidget(row)
            self._footer_rows.append(row)

        # **見出しとフッターの行は 1 つのまとまり**にする。見出しを自分の行へ寄せ
        # （間隔 2px）、一覧との間には `FOOT_GAP` を足す ── これで見出しが
        # 「一覧の続き」ではなく「フッターの名前」に見える（近接で分ける）。
        foot_unit = self._foot_unit = QWidget()
        foot_unit.setObjectName("sidebarFootUnit")
        fu = self._fu = QVBoxLayout(foot_unit)
        fu.setContentsMargins(0, 0, 0, 0)
        fu.setSpacing(2)
        fu.addWidget(self._foot)
        fu.addWidget(self._footer_card)
        outer.addSpacing(FOOT_GAP)
        outer.addWidget(foot_unit)

        # 見出し（`Menu` / `Tools`）を枠の上辺に載せているか（レトロスキン）。
        self._headings_on_frame = False
        self._body: QWidget | None = None
        # 行のどこでもドラッグで並べ替え（設定モード限定。§16bis Phase D の Qt 版）。
        # 最終行の下まで運べば新しいグループへ出せる（2026-09-05・操作の一貫性）。
        self._drag = RowReorder(self._scroll, self.reorderRequested.emit, self,
                                 allow_new_container=True)
        # 選択が動く直前に App が挟むガード（動作フォームの未適用の編集を保存する。
        # 入力漏れなら False ＝クリックを無視して移動させない）
        self._leave_guard = None
        self.apply_theme()

    # --- 枠まわりの塗り（テーマ切替で作り直さずに済ませる） ----------- #
    def apply_theme(self) -> None:
        # **地は窓と同じ色・枠は無し**（2026-09-07）。実測すると面の色は元から
        # 窓の地と同一で、境界を作っていたのは 1px の枠だけだった ── 区切りは
        # グループの `divider` と行の間隔が担っていて、外枠は働いていない。
        # 外したことで**メインパネル（カード無し）との左右の非対称も消える**。
        # 見出し 2 つは `sub`（二次テキスト）＋ 1pt 小さく ＝ 場所の名前として弱く。
        # メインパネルの `#mainHead` とは**わざと揃えない**（あちらは選択中の
        # 業務名＝データなので強いまま）。
        self._apply_frame()
        # 枠の上辺に載せる見出しは**地色で塗る**（白い線を文字のぶんだけ断つ）。
        # 枠が無いスキンでは今までどおり透過＝一覧の上に置いた小さな見出し。
        head_bg = _pal("bg") if self._headings_on_frame else "transparent"
        self.setStyleSheet(
            "#sidebarPane{background:%s;border:none;}"
            "#sidebarHead,#sidebarFoot{color:%s;background:%s;"
            "border:none;font-weight:500;padding:0 %dpx;%s}"
            "#sidebarCard,#sidebarFooterCard{background:%s;%s}"
            "#sidebarUp,#sidebarMore,#sidebarFootUnit{background:%s;border:none;}"
            % (_pal("bg"), _pal("sub"), head_bg,
               6 if self._headings_on_frame else 4, qtheme.font_css(-1), _pal("bg"),
               uikit.frame_css(), _pal("bg")))
        uikit.pixel_font(self)      # 見出し（`Menu` / `Tools`）にも効かせる
        self._position_headings()
        self._sync_more_hint()
        # フッター行は自分で色を焼き込むので個別に塗り直す（一覧の行と同じ規則）。
        for row in getattr(self, "_footer_rows", ()):
            row._restyle()
        uikit.apply_scrollbar_mode(self._scroll)

    def _apply_frame(self) -> None:
        """枠を描くスキンのときだけレイアウトの余白を開ける。

        QSS の `border` はウィジェットの縁に描かれるだけで、**中のレイアウトは
        よけてくれない**（行やスクロールバーが枠に貼り付く）。枠の内側の余白は
        コードで持つ ── 枠が無いスキン（既定の 26 テーマ）では従来の値のまま。
        """
        pad = T.frame_pad() if T.frame_width() else 0
        # 右は普段 0（スクロールバーを仕切り線に寄せる。2026-09-08）。枠があるときは
        # **メインパネルの枠のすぐ隣まで寄せる**（`FRAME_GAP`）── 2 ペインの仕切りは
        # 線を引かないので、掴む場所は「枠と枠のあいだ」で見当をつけることになる。
        # 離すと掴めない／近すぎると幅を変えられないので、両側 2px ＋ 仕切りの
        # 帯 5px ＝ 9px を残す（2026-09-09 ユーザー要望）。
        self._outer.setContentsMargins(PANE_PAD, PANE_PAD,
                                       FRAME_GAP if pad else 0, PANE_PAD)
        self._card_v.setContentsMargins(4 + pad, pad, pad, pad)
        self._footer_v.setContentsMargins(4 + LIST_PAD_L, 6 + pad,
                                          LIST_PAD_R, 6 + pad)
        self._float_headings(bool(pad))

    # --- 見出しを枠の上辺に載せる（レトロスキン。2026-09-09 要望） ------ #
    def _float_headings(self, on: bool) -> None:
        """`Menu` / `Tools` をレイアウトから外して**枠の線の上**に置く／戻す。

        レイアウトに入れたままでは箱の外にしか置けない（親のクリップに従う）。
        外して親を直接ペインにし、位置は `_position_headings()` が計算する。
        戻すときは元の位置（どちらも先頭）へ挿し直す。
        """
        if on == self._headings_on_frame:
            return
        self._headings_on_frame = on
        if on:
            for lay, lab in ((self._outer, self._head), (self._fu, self._foot)):
                lay.removeWidget(lab)
                lab.setParent(self)
                lab.show()
                lab.raise_()
            for box in (self._card, self._footer_card):
                box.installEventFilter(self)    # 箱が動いたら見出しも動かす
        else:
            for box in (self._card, self._footer_card):
                box.removeEventFilter(self)
            self._outer.insertWidget(0, self._head)
            self._fu.insertWidget(0, self._foot)

    def _position_headings(self) -> None:
        """浮かせた見出しを、それぞれの箱の**上辺の線の中央**へ置く（2026-09-09）。"""
        if not self._headings_on_frame:
            return
        for lab, box in ((self._head, self._card), (self._foot, self._footer_card)):
            lab.adjustSize()
            top_left = box.mapTo(self, box.rect().topLeft())
            x = top_left.x() + (box.width() - lab.width()) // 2
            lab.move(x, top_left.y() - lab.height() // 2)
            lab.raise_()

    def resizeEvent(self, e) -> None:   # noqa: N802
        super().resizeEvent(e)
        self._position_headings()

    def eventFilter(self, obj, event) -> bool:   # noqa: N802
        """**箱が動いたら見出しも動かす。**

        見出しはレイアウトの外に出してあるので、箱の位置・大きさが変わっても
        自動では追随しない。文字の大きさを変えると行の高さが変わり、`Tools` の
        箱が上下にずれる ── そのとき `apply_theme()` の中で位置を計算しても、
        レイアウトはまだ動いていないので**古い座標**になる（2026-09-09 実機で
        発覚）。箱自身の Resize / Move を拾うのが確実。
        """
        if event.type() in (QEvent.Resize, QEvent.Move):
            self._position_headings()
        return super().eventFilter(obj, event)

    def _sync_more_hint(self) -> None:
        """**続きがある側にだけ**小さな `∧` `∨` を出す（メインパネルと同じ）。"""
        uikit.sync_scroll_hints(self._scroll, self._up, self._more)

    def refresh_font(self) -> None:
        """フォント設定が変わったとき、**行を作り直さずに**塗り直す。"""
        self.apply_theme()
        for row in self._rows.values():
            row._restyle()

    # --- 公開 API（Tk 版の Sidebar に合わせる） ---------------------- #
    @property
    def selected_work_id(self) -> str | None:
        return self._selected_id

    def render(self, data: AppData, select_work: str | None = None) -> None:
        """階層から作り直す。`select_work` が無ければ先頭の業務を選ぶ。"""
        # 作り直しでスクロールが一番上へ飛ばないように覚えておく（2026-09-08 要望）。
        # 一覧の中身は同じ（業務が 1 つ増減するだけ）なので、位置は常に保つ。
        keep_scroll = self._scroll.verticalScrollBar().value()
        # スキンが見せ方を固定していればそちらが優先（レトロ＝仕切り線のみ。
        # 枠やレールは窓の枠と見分けがつかない。2026-09-09 ユーザー指定）。
        style = T.effective_group_style()
        ground = _pal("bg")                 # 窓の地と同じ（フラット。2026-09-05）

        body = QWidget()
        body.setObjectName("sidebarBody")
        body.setAttribute(Qt.WA_StyledBackground, True)
        # 地色は ID セレクタで塗る（palette / autoFillBackground は QSS に負ける）
        body.setStyleSheet("#sidebarBody{background:%s;border:none;}" % ground)
        v = QVBoxLayout(body)
        v.setContentsMargins(LIST_PAD_L, 0, LIST_PAD_R, 0)
        v.setSpacing(0)

        self._rows = {}
        self._drag.reset()
        first = True
        for gi, wg in enumerate(data.work_groups):
            if not wg.works:
                continue                     # 空グループは飾らない
            rows: list[QWidget] = []
            for w in wg.works:
                row = _WorkRow(w.id, w.name)
                row.clicked.connect(self._on_row_clicked)
                row.rightClicked.connect(self.workRightClicked.emit)
                row.doubleClicked.connect(self.renameRequested.emit)
                self._rows[w.id] = row
                self._drag.add_row(row, w.id, wg.id)
                rows.append(row)
            v.addWidget(_group_block(gi, rows, style, first))
            first = False
        v.addStretch(1)

        # 業務チップの外（空白部）で右クリック＝アンカー無しのメニュー。
        # **業務が 0 件でも追加できる**ようにこれが要る（Tk 版から移植）。
        body.setContextMenuPolicy(Qt.CustomContextMenu)
        body.customContextMenuRequested.connect(
            lambda pos, w=body: self._blank_context(w, pos))

        self._scroll.setWidget(body)
        self._sync_more_hint()
        vp = self._scroll.viewport()
        vp.setObjectName("sidebarViewport")
        vp.setStyleSheet("#sidebarViewport{background:%s;border:none;}" % ground)
        vp.setContextMenuPolicy(Qt.CustomContextMenu)
        vp.customContextMenuRequested.connect(
            lambda pos, w=vp: self._blank_context(w, pos))
        self._body = body
        uikit.apply_scrollbar_mode(self._scroll)
        uikit.restore_scroll(self._scroll, keep_scroll)
        self._position_headings()   # 一覧を作り直すと箱の高さが変わる

        target = select_work if select_work in self._rows else None
        if target is None:
            target = next(iter(self._rows), None)
        self._selected_id = None
        if target is not None:
            self.select_work(target)

    def select_work(self, work_id: str, *, notify: bool = True) -> None:
        if work_id not in self._rows:
            return
        if self._selected_id == work_id:
            return
        if self._selected_id in self._rows:
            self._rows[self._selected_id].set_selected(False)
        self._selected_id = work_id
        self._rows[work_id].set_selected(True)
        if notify:
            self.workSelected.emit(work_id)

    def _blank_context(self, widget, pos) -> None:
        g = widget.mapToGlobal(pos)
        self.workRightClicked.emit(None, g.x(), g.y())

    def set_drag_enabled(self, on: bool) -> None:
        """設定モードのときだけ並べ替えを有効にする。"""
        self._drag.set_enabled(on)

    def set_leave_guard(self, fn) -> None:
        """行クリックで選択が動く前に呼ぶ関数（False を返したら移動しない）。"""
        self._leave_guard = fn

    def update_row_label(self, work_id: str, text: str) -> None:
        """改名の即時反映（保存はデバウンスして別途）。"""
        row = self._rows.get(work_id)
        if row is not None:
            row.set_text(text)

    def row(self, work_id: str):
        """業務行そのもの（その場で改名するときに App が使う）。"""
        return self._rows.get(work_id)

    def row_ids(self) -> list[str]:
        """表示順の業務 ID（テスト・並べ替え用）。"""
        return list(self._rows)

    # --- 内部 ------------------------------------------------------- #
    def _on_row_clicked(self, work_id: str) -> None:
        if (work_id != self._selected_id and self._leave_guard is not None
                and not self._leave_guard()):
            return
        # クリックは「この業務を選ぶ」という明示的な操作。設定モードでタスク／動作を
        # 選んだあと、その親業務（＝サイドバーは既にそれを選択中）をクリックしても
        # `select_work` は「変わっていない」として通知を省く ── その結果、選択が
        # タスク／動作のまま戻らなかった（2026-09-05 実機で発覚）。既に選択中の行への
        # クリックは**別の信号**で知らせる（`workSelected` は識別が変わったときだけ、
        # という既存の契約をテーマ切替の再選択ロジックが当てにしているため乗らない）。
        already = work_id == self._selected_id
        self.select_work(work_id)
        if already:
            self.workReselected.emit(work_id)
