"""メインウィンドウ（2 ペイン＋タスク実行）。Tk 版 `view/app.py` の置き換え（Phase 4a）。

Tk 版の `App` は「Tk の窓 ＋ 合成ルート ＋ コントローラ」を兼ねていたが、Phase 2 で
合成ルートは `bootstrap`、データ操作は `uicore.UiCore` に出した。ここは**描画と配線だけ**:

    サイドバー選択 → メインパネル再描画
    タスククリック → Dispatcher へ Command → Event → 3 層フィードバック
    連打ロック（`max(min_lock_seconds, 完了まで)`）

**スレッドの渡し方が Tk 版と違う**（design-notes Phase 1 ⑤で検証済み）:
Tk 版は `_ui_q` / `_event_q` ＋ `after` ポーリングでマーシャルしていたが、Qt では
**シグナル/スロット（`Qt.QueuedConnection`）**が標準。ワーカースレッドから
`_ui_call` / `_event` を emit すれば UI スレッドで受け取れる。
"""

from __future__ import annotations

import time
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QTimer, Signal
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QMainWindow, QSplitter, QVBoxLayout, QWidget,
)

from .. import bootstrap, hierarchy, persistence, theme_tokens as T, uicore
from ..dispatch import Command, Event
from ..model import AppData
from . import actionmeta, qtheme, sidebar as sidebar_mod
from .main_panel import MainPanel
from .popups import QtMentionPicker, QtOneTimePopup
from .sidebar import Sidebar
from .titlebar import MODE_TEXT, ResizeGrips, TitleBar, round_corners
from .uikit import pal as _pal

DEFAULT_THEME = "dark_cyan.xml"

# 実行中の色が「一瞬すぎて見えない」を防ぐ最小表示時間（押せたことは分かるように）。
# 一瞬で終わるタスクでもこれだけは色が残る。
RUNNING_MIN_MS = 260

# 「＋動作」「動作の挿入」で**即作成**するときの種類（種類コンボの先頭に合わせる）。
# 名前ダイアログを出さないのと同じ考え方＝作業を止めず、あとからフォームで詰める。
DEFAULT_ACTION_ID = "open_file"

# 2 ペインの仕切り。**掴む幅と見える太さを分ける**（2026-09-08 要望）
# ── 見える線はグループの区切り線（`_thin(..., height=1)`）と同じ 1px にし、
# ドラッグで掴める帯はそのまま持つ。帯そのものを 1px にすると掴めなくなるので、
# 帯の中央 1px だけを `divider` で塗り、残りは窓の地で塗る。
PANE_HANDLE = 5


def _pt(x: int, y: int):
    from PySide6.QtCore import QPoint

    return QPoint(int(x), int(y))


def _pane_handle_qss() -> str:
    """2 ペインの仕切りの QSS。**帯は `PANE_HANDLE` 幅・線は中央の 1px だけ**。

    横方向のグラデーションで中央 1px 分だけ `divider`、残りを窓の地にする
    （`transparent` にすると下に何が来るかがテーマ・環境で変わるので塗る）。
    ホバーでも色を変えない（2026-09-05 要望）。

    **ペインを枠で囲うスキン（レトロ）では線を引かない** ── 枠が境界を作って
    いるので、その間にもう 1 本線があると仕切りが二重に見える（2026-09-09）。
    """
    lo = (PANE_HANDLE // 2) / PANE_HANDLE
    hi = (PANE_HANDLE // 2 + 1) / PANE_HANDLE
    line = _pal("bg") if T.frame_width() else _pal("divider")
    grad = ("qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            "stop:0 %(bg)s,stop:%(lo).4f %(bg)s,stop:%(lo2).4f %(div)s,"
            "stop:%(hi).4f %(div)s,stop:%(hi2).4f %(bg)s,stop:1 %(bg)s)"
            % {"bg": _pal("bg"), "div": line,
               "lo": lo - 0.0001, "lo2": lo, "hi": hi - 0.0001, "hi2": hi})
    return ("#paneSplitter{background:%(bg)s;border:none;}"
            "#paneSplitter::handle{background:%(g)s;}"
            "#paneSplitter::handle:hover{background:%(g)s;}"
            % {"bg": _pal("bg"), "g": grad})


class _Bridge(QObject):
    """ワーカースレッド → UI スレッドの受け渡し（Tk 版の `_ui_q`＋`after` の置き換え）。"""

    ui_call = Signal(object)
    event = Signal(object)


class MainWindow(QMainWindow):
    def __init__(
        self,
        data_path: str | Path,
        *,
        save_path: str | Path | None = None,
        clipboard=None,
        log=None,
        crypto=None,
        templates=None,
        theme_name: str = DEFAULT_THEME,
    ) -> None:
        super().__init__()
        self.setWindowTitle("WorkDesk Launcher")
        self.resize(880, 620)
        self.setMinimumSize(560, 380)
        # 枠なし窓＋自作タイトル帯（Phase 4g）。**OS の移動 / リサイズループは使わない**
        # ── `WH_KEYBOARD_LL` のポンプと再入して落ちる（CLAUDE.md §3）。
        self.setWindowFlag(Qt.FramelessWindowHint, True)

        self.data_path = Path(data_path)
        self.save_path = Path(save_path) if save_path else persistence.default_path()
        self.app_data: AppData = persistence.load(self.data_path)

        # 外観の復元（テーマ名も settings に持つ）
        T.load_state(self.app_data.settings.get("appearance", {}))
        T.set_save_hook(self._save_appearance)

        self._bridge = _Bridge()
        self._bridge.ui_call.connect(lambda fn: fn(), Qt.QueuedConnection)
        self._bridge.event.connect(self._handle_event, Qt.QueuedConnection)

        # --- 画面 ---------------------------------------------------- #
        self.sidebar = Sidebar()
        self.main_panel = MainPanel()

        self.title_bar = TitleBar()
        self.title_bar.modeToggled.connect(self.set_edit_mode)
        self.title_bar.minimizeRequested.connect(self.showMinimized)
        self.title_bar.closeRequested.connect(self.close)

        central = QWidget()
        col = QVBoxLayout(central)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(0)
        col.addWidget(self.title_bar)
        # 2 ペインは `QSplitter`＝**サイドバーの幅をユーザーが決められる**
        # （2026-09-05 要望）。幅は settings に覚える。
        self.splitter = QSplitter(Qt.Horizontal)
        self.splitter.setObjectName("paneSplitter")
        self.splitter.setChildrenCollapsible(False)
        self.splitter.setHandleWidth(PANE_HANDLE)
        self.splitter.addWidget(self.sidebar)
        self.splitter.addWidget(self.main_panel)
        self.splitter.setStretchFactor(0, 0)
        self.splitter.setStretchFactor(1, 1)
        self.splitter.splitterMoved.connect(lambda *_a: self._debounced_save())
        col.addWidget(self.splitter, 1)
        self.setCentralWidget(central)

        # 導線は帯（`TitleBar`）に置く。ここはキーボードから同じことをするための
        # `QAction`（メニューバーは無い ── 枠なし窓に帯とメニューが二重に並ぶのを避ける）。
        self.mode_action = QAction(MODE_TEXT, self)
        self.mode_action.setCheckable(True)
        self.mode_action.setShortcut("Ctrl+E")
        self.mode_action.toggled.connect(self.set_edit_mode)
        self.addAction(self.mode_action)
        for label, seq, fn in (("デザインラボ", "Ctrl+D", self.toggle_design_lab),
                               ("設定", "Ctrl+,", self.toggle_settings_panel)):
            act = QAction(label, self)
            act.setShortcut(seq)
            act.triggered.connect(fn)
            self.addAction(act)

        # --- 実行基盤（合成は bootstrap。view が渡すのは 3 つだけ） ---- #
        self.onetime_popup = QtOneTimePopup(self, on_cancel=lambda: self.onetime.cancel())
        self.mention_picker = QtMentionPicker(self, anchor_rect=self._running_task_rect)
        rt = bootstrap.build(
            self.app_data, self.save_path,
            run_on_ui=self._run_on_ui,
            onetime_popup=self.onetime_popup,
            mention_picker=self.mention_picker,
            clipboard=clipboard, log=log, crypto=crypto, templates=templates,
        )
        self.settings = rt.settings
        self.onetime = rt.onetime
        self.crypto = rt.crypto
        self.templates = rt.templates
        self.mention_dir = rt.mention_directory
        self.dispatcher = rt.dispatcher
        self.core = uicore.UiCore(self.app_data, self.save_path)
        # 既存の JSON に残っている空グループは**起動時に片付ける**
        # （2026-09-06 ユーザー判断。以降は削除・移動のたびに片付く）。
        self._prune_on_start = self.core.prune_empty_groups()

        # --- 実行状態 ------------------------------------------------- #
        self._busy = False
        self._run_started_at = 0.0
        self._running_task_id: str | None = None
        self._run_failures: list[tuple[str, str]] = []   # (動作の表示名, 原因)
        self._run_gen: dict[str, int] = {}      # task_id -> 世代（stale revert 防止）
        self._alive = True
        self._save_failed = False               # 保存の失敗を知らせたか（連発を防ぐ）

        self.sidebar.workSelected.connect(self._on_select_work)
        self.sidebar.workReselected.connect(self._on_work_reselected)
        # 業務を切り替える前に、開いている動作フォームの未適用の編集を確定する
        self.sidebar.set_leave_guard(self.commit_edits)
        self.main_panel.taskClicked.connect(self._on_task_click)
        self.sidebar.workRightClicked.connect(
            lambda wid, x, y: self.show_context_menu("work", wid, x, y))
        self.main_panel.taskRightClicked.connect(
            lambda tid, x, y: self.show_context_menu("task", tid, x, y))
        # 行のどこでもドラッグで並べ替え（設定モード限定）
        self.sidebar.reorderRequested.connect(self.reorder_work)
        self.main_panel.reorderRequested.connect(self.reorder_task)
        # 行そのもののダブルクリック＝その場で改名（設定モード限定。2026-09-06 要望）
        self.sidebar.renameRequested.connect(
            lambda wid: self.begin_inline_rename("work", wid))
        self.main_panel.renameRequested.connect(
            lambda tid: self.begin_inline_rename("task", tid))
        # デザインラボ／設定への導線（2026-09-06 に帯からサイドバー最下部へ移した）
        self.sidebar.designLabRequested.connect(self.toggle_design_lab)
        self.sidebar.settingsRequested.connect(self.toggle_settings_panel)
        self._install_shortcuts()

        self._appearance_hub = None
        self._edit_window = None
        self.mode = "normal"                    # normal | settings
        self._sel: tuple[str | None, str | None] = (None, None)   # (種類, id)
        self._sel_action: str | None = None   # 選択中の動作（編集ウィンドウの一覧）
        # 外観 STATE が変わったら最小限の再描画を選ぶ（Tk 版 `_on_theme_change` 相当）
        T.subscribe(self._on_appearance_change)

        # 復元したテーマがあればそれを使う（無ければ引数の既定）
        self.apply_theme(str(T.STATE.get("qt_theme") or theme_name))
        self._grips = ResizeGrips(self)
        self._restore_geometry()
        self._sidebar_width_restored = False
        self._restore_sidebar_width()
        self.refresh()
        if self._prune_on_start:
            self.save()                     # 起動時の片付けを書き戻す
        QTimer.singleShot(0, self._startup_crypto_check)
        # 「枠の色＝時間帯」のときに時刻をまたいだら当て直す（2026-09-09）。
        # 1 分ごとに見るだけ ── 変わるのは 1 日 2 回なので、ほとんどは空振り。
        self._sync_retro_frame()            # 前回終了時と時間帯が変わっていたら直す
        self._retro_timer = QTimer(self)
        self._retro_timer.setInterval(60_000)
        self._retro_timer.timeout.connect(self._sync_retro_frame)
        self._retro_timer.start()

    # ================================================================ #
    # テーマ / 再描画
    # ================================================================ #
    def _sync_retro_frame(self) -> None:
        """時間帯で枠の色が変わる設定のとき、時刻に合わせてテーマを当て直す。

        **実行中は見送る**（両ペインを作り直すので、押した直後に画面が
        入れ替わると驚く）── 次の 1 分後に拾い直せばよい。
        """
        if not self._alive or self._busy:
            return
        if str(T.STATE.get("retro_frame", "white")) != "auto":
            return
        current = qtheme.current_theme()
        if current not in qtheme.CUSTOM_THEMES:
            return                          # レトロ以外を選んでいるなら関係ない
        want = qtheme.retro_theme_name()
        if want != current:
            self.apply_theme(want)

    def apply_theme(self, theme_name: str) -> None:
        """テーマを差し替えて**両ペインを作り直す**（色は描画時に焼き込まれるため）。"""
        from PySide6.QtWidgets import QApplication

        from . import icons

        qtheme.apply(QApplication.instance(), theme_name)
        icons.clear_cache()                    # アイコンの色が変わる
        self._apply_mode_chrome()
        if getattr(self, "title_bar", None) is not None:
            self.title_bar.apply_theme()
        if getattr(self, "splitter", None) is not None:
            # ホバーで色を変えない（2026-09-05 要望）＝常に区切り線と同じ濃さのまま。
            self.splitter.setStyleSheet(_pane_handle_qss())
        if getattr(self, "_grips", None) is not None:
            self._grips.restyle()
        if getattr(self, "sidebar", None) is not None and self._alive:
            self.sidebar.apply_theme()      # カードの面と枠（行の作り直しでは直らない）
            self.refresh()
        # 編集ウィンドウ・デザインラボ/設定の窓は `refresh()` の対象外（別窓）
        # なので明示的に塗り直す。作り直しはしない ── 入力中の動作フォームを
        # 壊さないため。
        for panel in (self._edit_window, self._appearance_hub):
            if panel is not None and panel.isVisible():
                panel.apply_theme()
        # **グループ色の欄だけは出し入れが要る。** スキンがグループの見せ方を
        # 固定する（レトロ＝仕切り線）と、色は画面に出ないので欄も消す
        # ── `apply_theme()` は塗り直すだけなので拾えない（2026-09-10）。
        # 作り直すのは業務のカードだけ＝入力中の動作フォームは壊れない。
        if self._edit_window is not None and self._edit_window.isVisible():
            self._edit_window.refresh_group_color()
        # `qtheme.apply` は STATE["qt_theme"] を直接書く（set_option を通らない）ので、
        # ここで通知して保存フックを走らせる。購読側は "qt_theme" を no-op にする
        # （この関数が既に再描画済みなので、二重に作り直さない）。
        T.notify("qt_theme")

    def _on_appearance_change(self, changed: str) -> None:
        """デザインラボの変更を受けて**必要な分だけ**描き直す。

        `group_style` / `click_density` は行の作りが変わるので両ペインの作り直し。
        `font_*` はアプリのフォントを差し替えるだけで済む。
        """
        if not self._alive:
            return
        if changed == "qt_theme":
            return                              # `apply_theme` が既に描き直している
        if changed == "retro_frame":
            # 枠の色（レトロ）はテーマそのものの差し替え。`auto` なら時計で決まる。
            self.apply_theme(qtheme.retro_theme_name())
            return
        if changed in ("font_family", "font_size"):
            from PySide6.QtGui import QFont
            from PySide6.QtWidgets import QApplication

            QApplication.instance().setFont(QFont(
                str(T.STATE.get("font_family", "Yu Gothic UI")),
                int(T.STATE.get("font_size", 10))))
            # `QApplication.setFont` は qt-material のグローバル QSS の
            # `font-family` に負けて既存の行に反映されない（2026-09-05 実機で
            # 発覚）。**作り直しはしない**（行を作り直す必要は無いという前提の
            # テストがある）── 行は自分の QSS にも同じ値を書いており
            # （`qtheme.font_css`）、`refresh_font()` がそれを塗り直す。
            self.sidebar.refresh_font()
            self.main_panel.refresh_font()
            return
        if changed == "group_style" and self._edit_window is not None:
            # グループ色の欄は「レール（色）」のときだけ出す（2026-09-06 要望）
            self._edit_window.refresh_group_color()
        if changed == "scrollbar_mode" and self._appearance_hub is not None:
            # 統合窓の中身もスクロール領域（2026-09-06）。開いていれば追随させる。
            self._appearance_hub.refresh_scrollbars()
        self.refresh()

    def refresh(self, select_work: str | None = None) -> None:
        """両ペインを作り直す（`sidebar.render` が必ず選択を 1 回通知する）。"""
        keep = select_work or self.sidebar.selected_work_id
        self.sidebar.render(self.app_data, select_work=keep)
        self._sync_secret_uses()

    def _sync_secret_uses(self) -> None:
        """設定パネルが開いたままなら「使用件数」を数え直す（2026-09-09）。

        「N 件の動作で使用」は階層を数えて出すので、動作を編集・削除・貼り付け
        すると古くなる。**階層が変わる道は必ず `save()` か `refresh()` を通る**
        ので、その 2 つから呼んで数え漏らさないようにする（呼び出し側を
        1 つずつ書き足すと必ずどれか忘れる）。パネルを開いていなければ何もしない。
        """
        if not self._alive or getattr(self, "_appearance_hub", None) is None:
            return
        panel = self._settings_panel
        if panel is not None:
            panel.reload_secrets()

    def save(self) -> None:
        """保存する。**失敗を黙って捨てない**（2026-09-05 実機で踏んだ）。

        OneDrive 等が保存先を掴んでいると `os.replace` が弾かれる。
        `persistence` 側でやり直しても駄目だったときは、例外がスロットの外へ
        抜けてログに出るだけ＝**画面には何も出ないのに変更が保存されない**、
        という一番まずい形になる。ここで受けて知らせる。

        保存は入力のたびに走る（デバウンス）ので、**失敗が続いている間は 1 回だけ**
        出す。次に成功したら忘れる。終了処理中は出さない（閉じ際に窓を出さない）。
        """
        try:
            self.core.save()
            self._sync_secret_uses()
        except OSError as e:
            if self._alive and not self._save_failed:
                self._save_failed = True
                self.warn(
                    "保存できませんでした",
                    "変更はまだファイルに書けていません。同期中か、"
                    "ほかのプログラムがファイルを掴んでいる可能性があります。\n\n%s" % e)
            return
        self._save_failed = False

    # ================================================================ #
    # 設定モード（スイッチ＝編集ウィンドウの開閉。状態は 1 つ）
    # ================================================================ #
    def set_edit_mode(self, on: bool) -> None:
        """通常 ⇄ 設定 を切り替える。**設定モードではタスクを実行しない**。"""
        target = "settings" if on else "normal"
        if target == self.mode:
            return
        self.mode = target
        if self.mode_action.isChecked() != on:
            self.mode_action.setChecked(on)
        self.title_bar.set_mode(on)
        self._apply_mode_chrome()
        self.sidebar.set_drag_enabled(on)
        self.main_panel.set_drag_enabled(on)
        if on:
            self._open_edit_window()
        elif self._edit_window is not None:
            self._edit_window.close()
        self._sel_action = None
        self.main_panel.clear_selection()
        self._recompute_sel()

    def _apply_mode_chrome(self) -> None:
        """設定モードだと分かるよう窓の縁取りを変える（Tk 版と同じ考え方）。"""
        settings = self.mode == "settings"
        edge = str(T.PALETTE["accent"] if settings else T.PALETTE["bg"])
        self.setStyleSheet(
            "QMainWindow{background:%s;border:%dpx solid %s;}"
            % (str(T.PALETTE["bg"]), 2 if settings else 0, edge))

    def _open_edit_window(self) -> None:
        from .editwindow import EditWindow

        if self._edit_window is None:
            self._edit_window = EditWindow(self, self)
        # **中身を入れてから開く**（2026-09-07）。空のまま `show()` すると
        # 既定の小さい窓が一度実体化してから中身の高さへ広がるので、古い
        # Windows では「小さい窓が一瞬開いて閉じた」ように見える。
        self._edit_window.refresh(force=True)
        self._edit_window.adjustSize()      # 先に実寸を確定させる（下の注記）
        self._edit_window.show()
        self._edit_window.raise_()

    def edit_window_open(self) -> bool:
        return self._edit_window is not None and self._edit_window.isVisible()

    # ================================================================ #
    # 選択（最も具体的なものを 1 つ持つ）
    # ================================================================ #
    @property
    def selection(self) -> tuple[str | None, str | None]:
        """いま選択している `(種類, id)`。種類は "work" / "task" / None。"""
        return self._sel

    def _recompute_sel(self, *, force: bool = False) -> None:
        """いちばん具体的な選択を決めて編集ウィンドウへ知らせる。

        `force=True` は**階層が変わったとき**（編集ウィンドウの動作一覧を作り直す）。
        選択が動いただけなら作り直さない ── 入力中のフォームを壊さないため。
        """
        tid = self.main_panel.selected_task_id
        wid = self.sidebar.selected_work_id
        aid = self._sel_action
        if aid is not None:
            parent = hierarchy.parent_task_of_action(self.app_data, aid)
            if parent is None or parent.id != tid:
                aid = self._sel_action = None   # 親タスクから外れた選択は捨てる
        if aid:
            self._sel = ("action", aid)
        else:
            self._sel = ("task", tid) if tid else (("work", wid) if wid else (None, None))
        if self._edit_window is not None and self._edit_window.isVisible():
            self._edit_window.refresh(force=force)

    def select_entity(self, kind: str, entity_id: str) -> bool:
        """`(種類, id)` を選択状態にする。**選択が動いたら True**。

        **上位を選んだら下位の選択を解除する** ── そうしないと「最も具体的な選択」が
        指定した種類にならない（業務を右クリックしたのにタスクが選ばれたまま、になる）。
        Tk 版 `_select_entity` と同じ考え方。

        移る前に**動作フォームの未適用の編集を確定する**。入力漏れなら False を返し、
        選択は動かさない（Tk 版の `_can_leave_action_edit` と同じ）。
        """
        if self._sel == (kind, entity_id):
            return True
        if not self.commit_edits():
            return False
        if kind == "work":
            self._sel_action = None
            self.main_panel.clear_selection()
            self.sidebar.select_work(entity_id)
        elif kind == "task":
            self._sel_action = None
            self.main_panel.select_task(entity_id)
        elif kind == "action":
            task = hierarchy.parent_task_of_action(self.app_data, entity_id)
            if task is None:
                return False
            self.main_panel.select_task(task.id)
            self._sel_action = entity_id
        self._recompute_sel()
        return True

    def _dialog_parent(self):
        """いま操作している窓を親にする。**常に `self`（本体窓）にしない**
        ── 編集ウィンドウの「削除」ボタンから出す確認が本体窓の位置に出ると、
        目線とマウスが余分に往復する（2026-09-05 実機の指摘）。"""
        from PySide6.QtWidgets import QApplication

        active = QApplication.activeWindow()
        return active if active is not None else self

    @property
    def alive(self) -> bool:
        """まだ終了処理に入っていない。**閉じ際に窓を出さない**ための口
        （子ウィジェットが private を読まずに判断できるように）。"""
        return self._alive

    def confirm(self, title: str, text: str) -> bool:
        """はい / いいえの確認。**窓を出す口をここに一本化する**
        （テストが差し替えられる＝モーダルで止まらない）。"""
        from PySide6.QtWidgets import QMessageBox

        return QMessageBox.question(
            self._dialog_parent(), title, text) == QMessageBox.Yes

    def warn(self, title: str, text: str) -> None:
        """入力エラーなどの警告。子ウィジェット（編集ウィンドウ）もこの口を使う。"""
        from PySide6.QtWidgets import QMessageBox

        QMessageBox.warning(self._dialog_parent(), title, text)

    def inform(self, title: str, text: str) -> None:
        """完了の知らせ。`confirm` / `warn` と同じくここに一本化する。"""
        from PySide6.QtWidgets import QMessageBox

        QMessageBox.information(self._dialog_parent(), title, text)

    def commit_edits(self) -> bool:
        """開いている動作フォームの未適用の編集を確定する（入力漏れなら False）。"""
        if self._edit_window is not None and self._edit_window.isVisible():
            return self._edit_window.commit_pending_edits()
        return True

    # ================================================================ #
    # 編集操作（実体は uicore。ここは保存と再描画だけ）
    # ================================================================ #
    def rename_live(self, entity_id: str, text: str) -> None:
        """名前の即時反映。モデルの改名と保存は非空のときだけ（Tk 版と同じ）。"""
        name = text.strip()
        self.sidebar.update_row_label(entity_id, name)
        self.main_panel.update_row_label(entity_id, name)
        if self.core.rename(entity_id, name):
            self._debounced_save()

    def begin_inline_rename(self, kind: str, entity_id: str) -> None:
        """行をその場で改名する（設定モードで行をダブルクリック。2026-09-06 要望）。

        **編集ウィンドウの名前欄は残してある** ── どちらからでも変えられる
        （ユーザー判断 2026-09-06。編集の場所が完全に分かれるのも一長一短なので、
        まずは両方使える形にする）。実行中は割り込まない。
        """
        if self.mode != "settings" or self._busy:
            return
        row = (self.sidebar.row(entity_id) if kind == "work"
               else self.main_panel.row(entity_id))
        if row is None:
            return
        row.begin_rename(lambda text: self._commit_inline_rename(entity_id, text))

    def _commit_inline_rename(self, entity_id: str, text: str) -> None:
        """その場の改名を確定する（空文字は `inline_rename` 側で弾いてある）。"""
        self.rename_live(entity_id, text)
        self.save()
        if self._edit_window is not None:
            self._edit_window.sync_name(entity_id, text)

    def set_task_description(self, task_id: str, text: str) -> None:
        if self.core.set_task_description(task_id, text.strip()):
            self.main_panel.update_task_description(task_id, text.strip())
            self._debounced_save()

    def set_group_hue(self, index: int, hue: float) -> None:
        """業務グループの色相（度）。**色相だけがユーザーのもの**で明度彩度はテーマが決める。"""
        hues = list(T.STATE.get("group_hues") or [])
        while len(hues) <= index:
            hues.append(None)
        hues[index] = float(hue) % 360.0
        T.set_option("group_hues", hues)      # 通知 → 再描画 → 保存

    def apply_action_edit(self, action_id: str, res: tuple[str, dict]) -> None:
        """動作フォームの内容をモデルへ反映して保存する（編集ウィンドウから呼ばれる）。

        タスク行の色つきタイルは**先頭動作の種類**で決まるので、そこだけ塗り直す
        （両ペインの作り直しはしない ── 入力中のフォームを壊すため）。
        """
        if self.core.apply_action_edit(action_id, res) is None:
            return
        self.save()
        self._sync_task_icon(hierarchy.parent_task_of_action(self.app_data, action_id))

    def reorder_action(self, task_id: str, action_id: str, before_id: str | None) -> None:
        """動作の並べ替え（編集ウィンドウの一覧の `InternalMove` から）。"""
        if self.mode != "settings":
            return
        if not self.core.reorder_action(task_id, action_id, before_id):
            return
        self.save()
        self._sync_task_icon(hierarchy.find_task(self.app_data, task_id))

    def reorder_work(self, work_id: str, before_id, group_id: str | None) -> None:
        """業務の並べ替え / 業務グループ間の移動（サイドバーのドラッグから）。"""
        if self.mode != "settings" or not self.commit_edits():
            return
        if not self.core.reorder_work(work_id, group_id, before_id):
            return                              # 順序が変わらなかった＝保存しない
        self.save()
        self._sel_action = None
        self.refresh(select_work=work_id)
        self._recompute_sel(force=True)

    def reorder_task(self, task_id: str, before_id, group_id: str | None) -> None:
        """タスクの並べ替え / タスクグループ間の移動（メインパネルのドラッグから）。"""
        if self.mode != "settings" or not self.commit_edits():
            return
        work = hierarchy.parent_work_of_task(self.app_data, task_id)
        if work is None or not self.core.reorder_task(
                work.id, task_id, group_id, before_id):
            return
        self.save()
        self._refresh_select("task", task_id)

    def add_action(self, task_id: str) -> None:
        """**即作成**して、そのままフォームで詰めさせる（作業を止めない。2026-09-02）。"""
        if self.mode != "settings" or not self.commit_edits():
            return
        node = self.core.add_action(task_id, DEFAULT_ACTION_ID, {})
        if node is None:
            return
        self.save()
        self._refresh_select("action", node.id)

    def paste_action_head(self, task_id: str) -> None:
        """タスク選択＝「0 番目の動作」とみなし、動作バッファを先頭へ貼る。"""
        if self.mode != "settings" or not self.commit_edits():
            return
        new = self.core.paste_action_head(task_id)
        if new is None:
            return
        self.save()
        self._refresh_select("action", new.id)

    def template_names(self) -> dict[str, str]:
        """テンプレート id → 名前（動作の要約に使う）。"""
        return self.templates.names() if self.templates is not None else {}

    def secret_names(self) -> dict[str, str]:
        """暗号文 id → 表示名（動作の要約・動作フォームの一覧に使う）。"""
        return self.crypto.secret_names() if self.crypto is not None else {}

    def _sync_task_icon(self, task) -> None:
        """タスク行のタイルを先頭動作の種類に合わせる。"""
        if task is None:
            return
        first = task.actions[0] if task.actions else None
        self.main_panel.update_task_icon(
            task.id, actionmeta.icon_name(first) if first is not None else "file")

    def _debounced_save(self) -> None:
        """入力のたびに走る保存はまとめる（Tk 版 `uikit.Debouncer` 相当）。"""
        if getattr(self, "_save_timer", None) is None:
            self._save_timer = QTimer(self)
            self._save_timer.setSingleShot(True)
            self._save_timer.timeout.connect(self.save)
        self._save_timer.start(400)

    # ================================================================ #
    # 右クリックメニュー / ショートカット（設定モード限定）
    # ================================================================ #
    def show_context_menu(self, kind: str, entity_id: str | None, x: int, y: int) -> None:
        """設定モードのときだけ出す。**右クリックした要素をその場で選択する**。"""
        from PySide6.QtWidgets import QMenu

        if self.mode != "settings" or self._busy:
            return
        if entity_id is not None:
            self.select_entity(kind, entity_id)
        ja = uicore.KIND_JA.get(kind, "")
        has = entity_id is not None
        # 動作はタスクの中の並びなので**グループの概念が無い**（Tk 版と同じく落とす）
        grouped = kind != "action"
        menu = QMenu(self)

        def item(label: str, fn, enabled: bool = True):
            a = menu.addAction(label)
            a.setEnabled(enabled)
            a.triggered.connect(fn)

        # **並びは固定**（2026-09-06 ユーザー指定）。まず「その要素そのものの手当て」
        # ＝コピー → 貼り付け → 挿入 → 削除。そのあとに「グループを動かす操作」。
        item("%sのコピー" % ja, lambda: self.copy_entity(kind, entity_id), has)
        item("%sの貼り付け" % ja, lambda: self.paste_entity(kind, entity_id),
             has and self.core.can_paste(kind))
        item("%sの挿入" % ja, lambda: self.insert_entity(kind, entity_id), has)
        item("%sの削除" % ja, lambda: self.delete_entity(kind, entity_id), has)
        item("新しいグループに%sを作る" % ja, lambda: self.new_group_entity(kind), grouped)
        item("グループを分ける", lambda: self.split_group(entity_id), has and grouped)
        menu.exec(self.mapToGlobal(self.mapFromGlobal(_pt(x, y))))

    def _install_shortcuts(self) -> None:
        from PySide6.QtGui import QKeySequence, QShortcut

        for seq, fn in ((QKeySequence.Delete, self._shortcut_delete),
                        (QKeySequence.Copy, lambda: self._shortcut_copy_paste("copy")),
                        (QKeySequence.Paste, lambda: self._shortcut_copy_paste("paste"))):
            sc = QShortcut(seq, self)
            sc.activated.connect(fn)

    def _shortcut_delete(self) -> None:
        kind, ident = self._sel
        if self.mode == "settings" and kind and ident:
            self.delete_entity(kind, ident)

    def _shortcut_copy_paste(self, which: str) -> None:
        kind, ident = self._sel
        if self.mode != "settings" or not (kind and ident):
            return
        if which == "copy":
            self.copy_entity(kind, ident)
        elif kind == "task" and self.core.can_paste("action"):
            self.paste_action_head(ident)
        else:
            self.paste_entity(kind, ident)

    # --- 個々の操作（core を呼んで保存＋再描画＋選択） ---------------- #
    def insert_entity(self, kind: str, anchor_id: str | None) -> None:
        if self.mode != "settings" or not anchor_id:
            return
        node = self.core.insert_after(
            kind, anchor_id, action=(DEFAULT_ACTION_ID, {}) if kind == "action" else None)
        if node is None:
            return
        self.save()
        self._refresh_select(kind, node.id)

    def new_group_entity(self, kind: str) -> None:
        if self.mode != "settings" or kind == "action":
            return
        if kind == "work":
            node = self.core.add_work_in_new_group()
        else:
            wid = self.sidebar.selected_work_id
            node = self.core.add_task_in_new_group(wid) if wid else None
        if node is None:
            return
        self.save()
        self._refresh_select(kind, node.id)

    def delete_entity(self, kind: str, entity_id: str) -> None:
        if self.mode != "settings":
            return
        label = self._entity_label(kind, entity_id)
        if not self.confirm(
                "削除の確認",
                "「%s」を削除しますか？\n（中の要素もすべて削除されます）" % label):
            return
        nxt = self.core.next_after_delete(entity_id)
        self.core.delete(entity_id)             # 保存まで core が行う
        if nxt is None:
            self._sel_action = None
            self.refresh()
            self._recompute_sel(force=True)
            return
        self._refresh_select(nxt[0], nxt[1])

    def copy_entity(self, kind: str, entity_id: str) -> None:
        if self.mode == "settings":
            self.core.copy_entity(kind, entity_id)

    def paste_entity(self, kind: str, anchor_id: str) -> None:
        if self.mode != "settings":
            return
        new = self.core.paste_entity(kind, anchor_id)
        if new is None:
            return
        self.save()
        self._refresh_select(kind, new.id)

    def split_group(self, entity_id: str) -> None:
        if self.mode != "settings" or not self.core.split_group(entity_id):
            return
        self.save()
        self.refresh()

    def _entity_label(self, kind: str, entity_id: str) -> str:
        if kind == "action":
            act = hierarchy.find_action(self.app_data, entity_id)
            return (actionmeta.summary(act, self.template_names(), self.secret_names())
                    if act is not None else uicore.KIND_JA["action"])
        node = (hierarchy.find_work(self.app_data, entity_id) if kind == "work"
                else hierarchy.find_task(self.app_data, entity_id))
        return node.name if node is not None else uicore.KIND_JA.get(kind, "")

    def _refresh_select(self, kind: str, entity_id: str) -> None:
        """作った / 隣の要素を選択した状態で描き直す。

        階層が変わったあとなので `_recompute_sel(force=True)`＝編集ウィンドウの
        動作一覧まで作り直す。
        """
        if kind == "work":
            self._sel_action = None
            self.refresh(select_work=entity_id)
        elif kind == "task":
            self._sel_action = None
            self.refresh()
            self.main_panel.select_task(entity_id)
        else:                                   # action
            task = hierarchy.parent_task_of_action(self.app_data, entity_id)
            self.refresh()
            if task is not None:
                self.main_panel.select_task(task.id)
            self._sel_action = entity_id
        self._recompute_sel(force=True)

    # ================================================================ #
    # 暗号鍵（解錠 UI）
    # ================================================================ #
    def _startup_crypto_check(self) -> None:
        """鍵がこの端末に無く、暗号化済み設定があるとき（別 PC 等）は解錠を促す。"""
        try:
            if self.crypto.is_configured() and not self.crypto.load_from_store():
                self._prompt_unlock()
        except Exception:  # noqa: BLE001  資格情報 API の失敗等で起動は止めない
            pass

    def _prompt_unlock(self) -> bool:
        from PySide6.QtWidgets import QMessageBox

        from .passdialog import ask_passphrase

        for _ in range(3):
            pp = ask_passphrase(
                self, "この端末に暗号鍵がありません。\nパスフレーズを入力してください。")
            if pp is None:
                return False
            if self.crypto.unlock(pp):
                return True
            QMessageBox.warning(self, "パスフレーズ", "パスフレーズが違います。")
        return False

    def secret_uses(self) -> dict[str, int]:
        """`{secret_id: それを使っている動作の数}`（設定パネルの一覧が使う）。

        パネルが `core`（private ではないが内部）を直接辿らずに済むよう、
        App の公開メソッドとして出す（CLAUDE.md §11）。
        """
        return self.core.secret_use_counts()

    # --- 暗号文の登録（動作フォームと設定パネルが共通で使う口） ------ #
    def ask_text(self, title: str, label: str, initial: str = "") -> str | None:
        """1 欄だけ聞く（窓を出す口は `MainWindow` に一本化する）。"""
        from .uikit import ask_text

        return ask_text(self, title, label, initial)

    def ask_secret_value(self, title: str) -> str | None:
        """暗号化する文字列を伏字で 2 回聞く。食い違いは**知らせる**。

        窓を出す口は `MainWindow` に一本化する（テストが差し替えられる）。
        """
        from .uikit import ask_secret_value

        value, err = ask_secret_value(self, title)
        if err:
            self.warn("暗号化した文字列", err)
        return value

    def register_secret(self) -> str | None:
        """名前と値を尋ねて暗号文を 1 つ登録し、その `secret_id` を返す。

        動作フォームの「新規登録…」と設定パネルの「登録」が**同じ道**を通る
        （2026-09-09）。キャンセル・失敗は `None`（失敗は知らせる）。
        """
        name = self.ask_text("暗号化した文字列の登録", "名前:")
        if not name:
            return None
        value = self.ask_secret_value("暗号化した文字列の登録")
        if value is None:
            return None
        if not self.ensure_crypto_ready():
            return None
        try:
            return self.crypto.add_secret(name, value)
        except Exception as e:  # noqa: BLE001  保存の失敗を黙って捨てない
            self.warn("暗号化した文字列", "登録できませんでした:\n%s" % e)
            return None

    def ensure_crypto_ready(self) -> bool:
        """暗号化を使う直前に呼ぶ（動作フォームの暗号化コピー）。"""
        from PySide6.QtWidgets import QMessageBox

        from .passdialog import ask_new_passphrase

        if self.crypto.unlocked:
            return True
        if self.crypto.is_configured():
            return self._prompt_unlock()
        pp = ask_new_passphrase(self)
        if not pp:
            return False
        try:
            self.crypto.setup(pp)
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "パスフレーズの設定", "設定に失敗しました:\n%s" % e)
            return False
        return True

    def _unlock_for_task(self, task_id: str) -> bool:
        """暗号化コピーを含むタスクは**実行前に**解錠を促す（2026-09-05 の申し送り）。

        黙って失敗させない ── ワンタイムの窓が「1/2」で出てから何も起きない、を避ける。
        鍵が未設定なら通す（そもそも暗号文が無い＝通常の失敗として層3 に出る）。
        """
        task = hierarchy.find_task(self.app_data, task_id)
        if task is None or self.crypto.unlocked:
            return True
        if not any(a.action_id == "copy" and a.args.get("encrypt") for a in task.actions):
            return True
        try:
            if not self.crypto.is_configured() or self.crypto.load_from_store():
                return True
        except Exception:  # noqa: BLE001  資格情報 API の失敗は「解錠を尋ねる」へ倒す
            pass
        return self._prompt_unlock()

    # ================================================================ #
    # デザインラボ／設定 ── 1つの窓をタブで切り替える（2026-09-06）。
    # **開いていてもタスクは実行できる**（実行を止めるのは編集ウィンドウだけ）。
    # ================================================================ #
    @property
    def _design_lab(self):
        """後方互換のアクセサ（テスト・他コードが `win._design_lab.xxx` で
        中の操作要素へ触れる。実体は `AppearanceHub` の 1 タブ）。"""
        return self._appearance_hub.design_lab if self._appearance_hub is not None else None

    @property
    def _settings_panel(self):
        return self._appearance_hub.settings_panel if self._appearance_hub is not None else None

    def design_lab_open(self) -> bool:
        return (self._appearance_hub is not None and self._appearance_hub.isVisible()
                and self._appearance_hub.current_tab() == "design")

    def toggle_design_lab(self) -> None:
        self._toggle_appearance_hub("design")

    def settings_panel_open(self) -> bool:
        return (self._appearance_hub is not None and self._appearance_hub.isVisible()
                and self._appearance_hub.current_tab() == "settings")

    def toggle_settings_panel(self) -> None:
        self._toggle_appearance_hub("settings")

    def _toggle_appearance_hub(self, tab: str) -> None:
        """**同じタブが既に開いていれば閉じる**。別タブが開いていればそちらへ
        切り替える（窓自体は閉じない）。"""
        from .appearancehub import AppearanceHub

        hub = self._appearance_hub
        if hub is not None and hub.isVisible() and hub.current_tab() == tab:
            hub.close()
            return
        if hub is None:
            hub = self._appearance_hub = AppearanceHub(self, self)
        hub.show_tab(tab)

    def refresh_action_summaries(self) -> None:
        """テンプレート名が変わった → 動作の要約を描き直す（設定パネルから呼ばれる）。"""
        if self._edit_window is not None and self._edit_window.isVisible():
            self._edit_window.refresh_action_labels()

    # ================================================================ #
    # 選択
    # ================================================================ #
    def _on_select_work(self, work_id: str) -> None:
        self.main_panel.render(hierarchy.find_work(self.app_data, work_id))
        self._recompute_sel()

    def _on_work_reselected(self, work_id: str) -> None:
        """**既に選択中の**業務行を（再）クリックしたとき。

        `workSelected` は「業務の識別が変わった」ときだけ通知される（テーマ切替の
        たびに `sidebar.render()` が「今の業務を選び直す」ため、`_on_select_work`
        自体はここに `_sel_action` のクリアを入れると**テーマ切替のたびに開いている
        動作フォームを巻き込んで壊してしまう**。2026-09-05 実機で発覚）。

        一方、設定モードでタスク／動作を選んだあと**その親業務の行をクリック**した
        場合はサイドバー上は「変わっていない」ので `workSelected` が飛ばず、
        選択がタスク／動作のまま戻らなかった。これは別の合図（`workReselected`）で
        受け、タスク／動作の選択だけを解いて業務へ戻す（一覧の作り直しは不要）。
        """
        self._sel_action = None
        self.main_panel.clear_selection()
        self._recompute_sel(force=True)

    # ================================================================ #
    # タスク実行（継ぎ目の呼び出し）
    # ================================================================ #
    def _on_task_click(self, task_id: str) -> None:
        # **設定モードではタスクを実行しない**（選択するだけ）。デザインラボが開いて
        # いても実行できる（2026-09-05 の設計変更。ガードの条件は編集モードだけ）。
        if self.mode == "settings":
            self.select_entity("task", task_id)
            return
        if self._busy:
            # ワンタイムの Ctrl+V 待ち中に他タスク押下 → シーケンス中止（§9）
            if self.onetime.is_waiting:
                self.onetime.cancel()
            # 実行中に他を押しても**何も出さない**（フッターを廃したため。2026-09-06）。
            # 走っているタスクの行には色が付いているので、動いていることは見える。
            return

        if not self._unlock_for_task(task_id):
            return

        self._busy = True
        self._run_started_at = time.monotonic()
        self._running_task_id = task_id
        self._run_failures = []
        self._run_gen[task_id] = self._run_gen.get(task_id, 0) + 1
        self.main_panel.set_task_state(task_id, "running")
        self.dispatcher.dispatch(Command(task_id), self._emit)

    def _emit(self, event: Event) -> None:
        """**ワーカースレッドから呼ばれる。** UI へはシグナルで渡す。"""
        self._bridge.event.emit(event)

    def _run_on_ui(self, fn) -> None:
        """services が使う「UI スレッドで実行して」の口。"""
        self._bridge.ui_call.emit(fn)

    def _handle_event(self, event: Event) -> None:
        """UI スレッド。3 層フィードバックの層2（面と要約）と層3（動作ごとの詳細）。"""
        if not self._alive:
            return
        row = self.main_panel.row(event.task_id)
        if event.kind == "task_started":
            if row is not None:
                row.set_sub("")
        elif event.kind == "action_done":
            # **失敗した動作だけ溜める**。途中経過を出すと実行中に注意を引いてしまう。
            # 終わって失敗があれば `_finish` が 1 動作 1 行でまとめて見せる。
            if event.status == "FAILED":
                self._run_failures.append(
                    (event.feature_name, event.message or "失敗しました"))
        elif event.kind == "task_finished":
            self._finish(event, row)

    def _finish(self, event: Event, row) -> None:
        """**成功は消える / 失敗は知らせる**（2026-09-05 に非対称化、2026-09-06 に出し先を変更）。

        - 成功・中止 … 何も残さない。実行中の色が最小表示時間のあと静かに消えるだけ。
          ユーザーは既に次の作業へ移っている。ここで注意を引くのは**作業阻害**。
        - 失敗 … 一覧には残さず（行はすぐ通常へ戻す）、**その場でダイアログ**に出す。
          以前はフッターに静かに残していたが、実機で「フッターは見ていない」と
          分かった（2026-09-06）── 気づかない場所に残すのは残していないのと同じ。
        """
        self._running_task_id = None
        gen = self._run_gen.get(event.task_id)

        if event.outcome == "has_failure":
            self.main_panel.set_task_state(event.task_id, None)
            if row is not None:
                row.set_sub("")
        else:
            # 成功・中止＝痕跡を残さない。ただし押した実感が要るので最小時間は色を保つ。
            elapsed_ms = int((time.monotonic() - self._run_started_at) * 1000)
            QTimer.singleShot(max(0, RUNNING_MIN_MS - elapsed_ms),
                              lambda: self._revert(event.task_id, gen))

        # 連打ロック解除: max(min_lock_seconds, 完了まで)
        elapsed = time.monotonic() - self._run_started_at
        min_lock = float(self.settings.get("min_lock_seconds", 1.0))
        QTimer.singleShot(max(0, int((min_lock - elapsed) * 1000)), self._unlock)

        # **ダイアログは最後に**（モーダルなので、ここより下は閉じるまで動かない）。
        # ロック解除のタイマーは上で仕掛けてある＝閉じ待ちでも時間は進む。
        if event.outcome == "has_failure":
            self._report_failure(event.task_id)

    def _report_failure(self, task_id: str) -> None:
        """失敗を知らせる。**フッターではなくその場のダイアログ**（2026-09-06）。

        フッターは「見ていない場所」だった（実機で確認）── 静かに残しても
        気づかないなら、残していないのと同じ。失敗は例外的な出来事なので、
        そのときだけ手を止めてよい。成功・中止は今までどおり痕跡を残さない。

        中身は**失敗した動作 1 つにつき 1 行**（何が・なぜ）。原因の文言は機能側の
        `PreflightError` がユーザーの言葉で持っている（「ファイルが見つかりません」等）。
        """
        task = hierarchy.find_task(self.app_data, task_id)
        name = task.name if task is not None else ""
        text = "タスク「%s」でエラーが出ました。" % name
        if self._run_failures:
            text += "\n\n" + "\n".join("・%s — %s" % (f, why)
                                       for f, why in self._run_failures)
        self.warn("エラー", text)

    def _revert(self, task_id: str, gen: int | None) -> None:
        if not self._alive or self._run_gen.get(task_id) != gen:
            return          # 破棄済み or その後に再実行された
        self.main_panel.set_task_state(task_id, None)
        row = self.main_panel.row(task_id)
        if row is not None:
            row.set_sub("")

    def _unlock(self) -> None:
        if self._alive:
            self._busy = False

    # ================================================================ #
    # 補助
    # ================================================================ #
    def _running_task_rect(self) -> tuple[int, int, int, int] | None:
        """実行中タスク行の画面矩形（メンション先ポップアップの位置決め）。"""
        rid = self._running_task_id
        row = self.main_panel.row(rid) if rid else None
        if row is None or not row.isVisible():
            return None
        p = row.mapToGlobal(row.rect().topLeft())
        return (p.x(), p.y(), row.width(), row.height())

    def _save_appearance(self, values: dict) -> None:
        self.app_data.settings["appearance"] = dict(values)
        self.save()

    def _restore_geometry(self) -> None:
        """前回の位置と大きさ（`settings["window"]["main"]`）。

        枠なし窓は OS が位置を覚えてくれないので自分で持つ。**画面の外に出ていたら
        使わない**（モニタ構成が変わったときに窓が行方不明にならないように）。
        """
        geo = (self.app_data.settings.get("window", {}) or {}).get("main")
        if not geo or len(geo) != 4:
            return
        from PySide6.QtCore import QRect
        from PySide6.QtGui import QGuiApplication

        x, y, w, h = (int(v) for v in geo)
        rect = QRect(x, y, max(w, self.minimumWidth()), max(h, self.minimumHeight()))
        if not any(sc.availableGeometry().intersects(rect)
                   for sc in QGuiApplication.screens()):
            return
        self.setGeometry(rect)

    def _restore_sidebar_width(self) -> None:
        win = self.app_data.settings.get("window", {}) or {}
        w = int(win.get("sidebar_width") or 0) or sidebar_mod.SIDEBAR_WIDTH
        w = max(sidebar_mod.MIN_WIDTH, min(sidebar_mod.MAX_WIDTH, w))
        self.splitter.setSizes([w, max(1, self.width() - w)])

    def _save_geometry(self) -> None:
        g = self.geometry()
        win = self.app_data.settings.setdefault("window", {})
        win["main"] = [g.x(), g.y(), g.width(), g.height()]
        sizes = self.splitter.sizes()
        if sizes:
            win["sidebar_width"] = int(sizes[0])

    def resizeEvent(self, e) -> None:   # noqa: N802
        super().resizeEvent(e)
        if getattr(self, "_grips", None) is not None:
            self._grips.relayout()

    def showEvent(self, e) -> None:   # noqa: N802
        super().showEvent(e)
        round_corners(self)            # Win11 の角丸（対応外なら何もしない）
        # **表示前の `setSizes` はスプリッタに無視される**ので、出てから一度だけ当てる。
        # `showEvent` の時点ではまだスプリッタの実寸が決まっていないので、
        # レイアウトが落ち着いてから（イベントループを 1 周してから）当てる。
        if not self._sidebar_width_restored:
            self._sidebar_width_restored = True
            QTimer.singleShot(0, self._restore_sidebar_width)

    def closeEvent(self, e) -> None:   # noqa: N802
        self._alive = False
        self._save_geometry()
        T.unsubscribe(self._on_appearance_change)
        for w in (self._edit_window, self._appearance_hub):
            if w is not None:
                w.close()
        try:
            self.save()
        except Exception:  # noqa: BLE001  終了時は何があっても閉じる
            pass
        try:
            self.onetime.shutdown()
            self.mention_dir.shutdown()
        except Exception:  # noqa: BLE001  終了時は何があっても閉じる
            pass
        super().closeEvent(e)
