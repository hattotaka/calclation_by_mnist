#from __future__ import print_function
import numpy as np
import chainer
import chainer.functions as F
import chainer.links as L
from chainer import Variable, optimizers, Chain, serializers
import sys
import csv

BASE_STRING = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ/='
INPUT_STRING = '+'
OUTPUT_STRING = ''
N = 10

def create_inout_string():
    instr = BASE_STRING[0:N] + INPUT_STRING
    outstr = BASE_STRING[0:N]
    print(instr)
    print(outstr)
    return instr, outstr

def generate(numbersize, datasize):
    a = (np.random.uniform(1, pow(N, numbersize) - 1, datasize)).astype(np.int32)
    b = (np.random.uniform(1, pow(N, numbersize) - 1, datasize)).astype(np.int32)
    print(min(a))
    print(max(a))
    print(min(b))
    print(max(b))
    c = a + b
    return a, b, c

def encode_in(a, b, args, instr):
    alphabet = np.array(list(instr))
    texts = np.array([ '{}+{}'.format(convert_10_to_N_number(a_, N).rjust(args.numbersize, '0'), convert_10_to_N_number(b_, N).rjust(args.numbersize, '0')) for a_, b_ in zip(a, b) ])
    return np.array([[alphabet == c for c in s] for s in texts]).astype(np.float32)

def encode_out(c, args, outstr):
    texts = np.array([ '{}'.format(convert_10_to_N_number(c_, N)).rjust(args.numbersize + 1, '0') for c_ in c ])
    return np.array([[outstr.index(c) for c in s] for s in texts]).astype(np.int32)

def convert_N_to_10_number(a, n):
    operator={'0':'0',
              '1':'1',
              '2':'2',
              '3':'3',
              '4':'4',
              '5':'5',
              '6':'6',
              '7':'7',
              '8':'8',
              '9':'9',
              'a':'10',
              'b':'11',
              'c':'12',
              'd':'13',
              'e':'14',
              'f':'15',
              'g':'16',
              'h':'17',
              'i':'18',
              'j':'19',
              'k':'20',
              'l':'21',
              'm':'22',
              'n':'23',
              'o':'24',
              'p':'25',
              'q':'26',
              'r':'27',
              's':'28',
              't':'29',
              'u':'30',
              'v':'31',
              'w':'32',
              'x':'33',
              'y':'34',
              'z':'35',
              'A':'36',
              'B':'37',
              'C':'38',
              'D':'39',
              'E':'40',
              'F':'41',
              'G':'42',
              'H':'43',
              'I':'44',
              'J':'45',
              'K':'46',
              'L':'47',
              'M':'48',
              'N':'49',
              'O':'50',
              'P':'51',
              'Q':'52',
              'R':'53',
              'S':'54',
              'T':'55',
              'U':'56',
              'V':'57',
              'W':'58',
              'X':'59',
              'Y':'60',
              'Z':'61',
              '/':'62',
              '=':'63'
              }
    b = 0
    for i in range(len(a)):
        b = b + pow(n, len(a) - i - 1) * int(operator[str(a[i])])
    return b
             
def convert_10_to_N_number(a, n):
    operator={'0':'0',
              '1':'1',
              '2':'2',
              '3':'3',
              '4':'4',
              '5':'5',
              '6':'6',
              '7':'7',
              '8':'8',
              '9':'9',
              '10':'a',
              '11':'b',
              '12':'c',
              '13':'d',
              '14':'e',
              '15':'f',
              '16':'g',
              '17':'h',
              '18':'i',
              '19':'j',
              '20':'k',
              '21':'l',
              '22':'m',
              '23':'n',
              '24':'o',
              '25':'p',
              '26':'q',
              '27':'r',
              '28':'s',
              '29':'t',
              '30':'u',
              '31':'v',
              '32':'w',
              '33':'x',
              '34':'y',
              '35':'z',
              '36':'A',
              '37':'B',
              '38':'C',
              '39':'D',
              '40':'E',
              '41':'F',
              '42':'G',
              '43':'H',
              '44':'I',
              '45':'J',
              '46':'K',
              '47':'L',
              '48':'M',
              '49':'N',
              '50':'O',
              '51':'P',
              '52':'Q',
              '53':'R',
              '54':'S',
              '55':'T',
              '56':'U',
              '57':'V',
              '58':'W',
              '59':'X',
              '60':'Y',
              '61':'Z',
              '62':'/',
              '63':'='
              }
    d = ''
    for i in range(10):
        b = int(a % n)
        a = (a - b) / n
        d = str(operator[str(b)]) + d
        if a == 0:
            break
    return d
 
class Model(Chain):
    def __init__(self, unit, instr, outstr):
        super(Model, self).__init__(
            l1=L.Linear(len(instr), unit),
            l2=L.LSTM(unit, unit),
            l3=L.Linear(unit, len(outstr)),
        )
    def forward(self, x, k):
        self.l2.reset_state()
        for i in range(x.shape[1]):
            h = F.relu(self.l1( Variable(x[:, i, :]) ))
            h = self.l2(h)
        result = []
        for i in range(k):
            h = F.relu(h)
            h = self.l2(h)
            result += [ self.l3(h) ]
        return result
 
def init(args, instr, outstr, filename, model_load_flg):
    #global xp
    model = Model(args.unit, instr, outstr)
    if model_load_flg == True:
        serializers.load_npz(filename, model)
    #xp = np
    #optimizer = optimizers.Adam()
    #optimizer.setup(model)
    #optimizer.add_hook(chainer.optimizer.WeightDecay(0.0001))
    #optimizer.add_hook(chainer.optimizer.GradientClipping(5.0))
    #return model, optimizer
    return model

def train(model, optimizer, args, n, instr, outstr):
    train_a, train_b, train_c = generate(args.numbersize, 1)
    x_train = encode_in(train_a, train_b, args, instr)
    #t_train = encode_out(train_c, args, outstr)

    y = model.forward(x_train, args.numbersize + 1)
    print('test example:\t%d\t+ %d\t= %d\t-> %s' % (train_a[0], train_b[0], train_c[0], convert_N_to_10_number(''.join([ outstr[int(y_.data[i].argmax())] for y_ in y ]), n)))

def main(args):
    n = N
    filename = r'model/model_sum_AI_10000.npz'
    instr, outstr = create_inout_string()
    model, optimizer = init(args, instr, outstr, filename, False)
    train(model, optimizer, args, n, instr, outstr)
 
if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--unit', type=int, default=200)
    parser.add_argument('--datasize', type=int, default=10000)
    parser.add_argument('--numbersize', type=int, default=5)
    args = parser.parse_args()
    main(args)