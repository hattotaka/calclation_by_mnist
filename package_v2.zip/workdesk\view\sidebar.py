"""サイドバー: 業務グループでソートした業務の縦一列。

- 同じ業務グループの業務は背景同色（`theme.group_color(i)`＝`fit_tint` でテーマ適応）。
  グループの色帯は左右マージン `theme.box_margin()` を取って「バー」でなく「パネル」に見せる。
  グループ間は隙間大きめ（`GROUP_GAP`）。業務行に種類アイコンは付けない（全行同一で無意味）。
- 通常モードも設定モードも**同じレイアウト**（§16 Phase A）。**グループ名は表示しない**（§2/§9）。
  業務クリックで `on_select_work(work_id)`。改名・追加・削除・色・並べ替えはデザインラボの
  カード＋「行のどこでもドラッグ」（§16bis。行ホバーの編集ボタンオーバーレイは全廃）。

業務行は `_WorkChip(tk.Canvas)`＝角丸チップ（`create_polygon(smooth=True)` の角丸矩形）。
選択表現（2026-08-31 に単純化）: **左にアクセント色バー＋ラベルをアクセント色**のみ。
地色（グループ色）は選択でも不変＝「同グループが別グループに見える」ことがない。
インデント量だけデザインラボ「位置調整」で可変（`sel_indent_px`。0＝なし）。旧 `sel_bar` /
`sel_border` / `sel_fill` / `hover_bar` / `hover_border` は撤去。
ホバー表現: 地色を `theme.lighten(base, 0.22)` の薄い面にする（`<Leave>` は不要＝canvas
は子を持たないので確実に 1 回で抜ける。保険で `uikit.pointer_within` は残す）。

最下部フッター（§16 ステージ2 / §16bis まとまり A）: 設定系の導線を最下部の行に集約する
（設定 / デザインラボ の 2 行。旧「⇄ 設定モードに切替」行は撤去＝モード切替はデザインラボの
スイッチだけ）。この 2 行は業務行とは別系統で、**枠色ではなく地色（グレー）** で状態を示す
（`footer_hover_bg` / `footer_active_bg`）。ホバー設定（`hover_*`）の対象外。
`widget` は「フッター付きの外枠」を返す。スクロールバー制御は `scrollable` を使う。
"""

from __future__ import annotations

import tkinter as tk
import tkinter.font as tkfont
from collections.abc import Callable

from ..model import AppData
from . import theme
from .dragdrop import RowReorderDrag
from .scrollable import ScrollableFrame
from .uikit import pointer_within

GROUP_GAP = 18      # 業務グループ間の隙間（クリック領域なし）
_WORKROW_GAP = 3    # 同一グループ内の業務行どうしの隙間（地色が細く覗く）
# 色帯の左右マージン／帯からの距離は `theme.box_margin()` / `theme.list_top_pad()`
# （デザインラボで可変。list_top_pad はメインパネルと同じ関数＝先頭行の上辺が揃う）。
_ICON_GEAR = 23      # 「設定」＝かなり小さく見えたので他よりさらに大きめ（§17 ユーザー指摘）
_ICON_SLIDERS = 21   # 「デザインラボ」＝今よりちょっとだけ大きく


def _round_pts(x0, y0, x1, y1, r):
    """角丸矩形を `create_polygon(..., smooth=True)` 用の点列で返す。"""
    r = max(0, min(r, (x1 - x0) / 2, (y1 - y0) / 2))
    return [
        x0 + r, y0, x1 - r, y0, x1, y0, x1, y0 + r,
        x1, y1 - r, x1, y1, x1 - r, y1, x0 + r, y1,
        x0, y1, x0, y1 - r, x0, y0 + r, x0, y0,
    ]


class _WorkChip(tk.Canvas):
    """1 業務ぶんの丸角チップ（canvas 描画）。地色は動かさず、
    選択＝左アクセントバー／ホバー＝薄い面（`sel_*` トグルは業務行では使わない）。"""

    _RADIUS = 9

    def __init__(self, parent: tk.Misc, text: str, color: str) -> None:
        m = theme.metrics()
        self._font = theme.font("body")
        h = tkfont.Font(font=self._font).metrics("linespace") + 2 * m["side_pady"]
        super().__init__(
            parent, height=h, bd=0, highlightthickness=0,
            bg=str(parent["bg"]), cursor="hand2",
        )
        self.base = color
        self._padx = m["side_padx"]
        self._selected = False
        self._hovering = False
        self._box = self.create_polygon(
            _round_pts(0, 0, 1, h, self._RADIUS), fill=color, outline="", smooth=True
        )
        self._bar = self.create_rectangle(0, 0, 0, 0, fill=color, width=0)
        self._lbl = self.create_text(
            self._padx, h / 2, text=text, anchor="w",
            fill=theme.readable_ink(color), font=self._font,
        )
        self.bind("<Configure>", lambda _e: self.redraw())

    # --- 描画 --------------------------------------------------- #
    def _fill(self) -> str:
        if self._hovering and not self._selected:
            return theme.lighten(self.base, 0.22)
        return self.base

    def redraw(self) -> None:
        w = max(self.winfo_width(), 1)
        h = max(self.winfo_height(), 1)
        self.coords(self._box, *_round_pts(0, 0, w, h, self._RADIUS))
        self.itemconfigure(self._box, fill=self._fill())
        bw = theme.SEL_BAR_WIDTH
        if self._selected:
            self.coords(self._bar, 0, self._RADIUS, bw, h - self._RADIUS)
            self.itemconfigure(self._bar, state="normal",
                               fill=str(theme.PALETTE["accent"]))
        else:
            self.itemconfigure(self._bar, state="hidden")
        # 選択時のインデント量はデザインラボ「位置調整」の `sel_indent_px`（0＝なし。2026-09-02
        # にチェックボックスは廃止＝0 で「無し」と同じ）
        indent = int(theme.STATE["sel_indent_px"]) if self._selected else 0
        self.coords(self._lbl, self._padx + (bw if self._selected else 0) + indent, h / 2)
        self.itemconfigure(
            self._lbl,
            fill=(str(theme.PALETTE["accent"]) if self._selected
                  else theme.readable_ink(self.base)),
        )

    # --- 状態 --------------------------------------------------- #
    def set_selected(self, on: bool) -> None:
        self._selected = bool(on)
        self.redraw()

    def set_hover(self, on: bool) -> None:
        self._hovering = bool(on)
        self.redraw()

    def set_text(self, text: str) -> None:
        self.itemconfigure(self._lbl, text=text)


def _build_footer_row(parent: tk.Misc, text: str, color: str, icon):
    """フッター行（設定 / デザインラボ）の骨格 `outer > [bar | inner > icon label]`。
    `outer` の pack は呼び出し側が行う。戻り値は常に 5 要素
    `(outer, bar, inner, label, icon_label)`（業務行は `_WorkChip` に移行したのでここは
    フッター専用＝アイコンは必ず付く。2026-09-02）。"""
    m = theme.metrics()
    outer = tk.Frame(
        parent, bg=color, cursor="hand2",
        highlightthickness=1, highlightbackground=color, highlightcolor=color,
    )
    bar = tk.Frame(outer, bg=color, width=theme.SEL_BAR_WIDTH)
    bar.pack(side="left", fill="y")
    inner = tk.Frame(outer, bg=color, padx=m["side_padx"], pady=m["side_pady"])
    inner.pack(side="left", fill="x", expand=True)
    ic = tk.Label(inner, image=icon, bg=color)
    ic.image = icon   # GC 防止（theme._icon_cache も持つが二重に握る）
    ic.pack(side="left", padx=(0, 7))
    label = tk.Label(
        inner, text=text, bg=color, fg=theme.readable_ink(color), anchor="w",
        font=theme.font("body"),
    )
    label.pack(side="left", fill="x", expand=True)
    return outer, bar, inner, label, ic


class _SidebarFooter:
    """サイドバー最下部の設定系の行（設定 / デザインラボ）。

    どちらも**同じ行をもう一度押すと閉じる**トグル（ドック的な操作感）。
    開いている間はその行を地色グレー（`footer_active_bg`）にして「開」を示す
    ＝窓内の「閉じる」ボタンの代わり。枠色ではなく地色で状態を示すので、
    業務行の `hover_*` 設定とは無関係。フッター行は「対話要素」なので、
    その上でのダブルクリックでは最背面化しない（`frame._wd_no_send_back`）。

    ※ 旧「⇄ 設定モードに切替」行は撤去（§16bis まとまり A）。設定モードの切替口は
      デザインラボ最上部の「設定モード」スイッチだけ。
    """

    def __init__(
        self,
        parent: tk.Misc,
        on_toggle_common_settings: Callable[[], None] | None,
        on_toggle_design_lab: Callable[[], None] | None,
    ) -> None:
        self._on_common = on_toggle_common_settings
        self._on_design = on_toggle_design_lab
        self._panel_open = {"common": False, "design": False}
        self._resting_bg = str(theme.PALETTE["sidebar_bg"])   # 設定モードで着色されうる
        bg = self._resting_bg

        self.frame = tk.Frame(parent, bg=bg)
        # フッターは「対話要素」＝ダブルクリックで最背面へ行かせない（App._on_double_click）。
        self.frame._wd_no_send_back = True
        self._dividers: list[tk.Frame] = []
        # リストとフッターの境目（全幅）
        top = tk.Frame(self.frame, height=1, bg=theme.PALETTE["divider"])
        top.pack(fill="x")
        self._dividers.append(top)

        # 使用頻度が高いデザインラボを上に（ユーザー指示）。絵文字 → 単色アイコン（§17.7 ステージ5。
        # アイコンは業務行より少し大きく＝ユーザー指摘）。
        self._design_row = _build_footer_row(
            self.frame, "デザインラボ", bg, theme.icon("sliders", "sub", _ICON_SLIDERS)
        )
        self._design_row[0].pack(fill="x", pady=(4, 3))
        self._item_divider()
        self._common_row = _build_footer_row(
            self.frame, "設定", bg, theme.icon("gear", "sub", _ICON_GEAR)
        )
        self._common_row[0].pack(fill="x", pady=(3, 4))

        self._rows = (self._design_row, self._common_row)
        self._wire_row(self._design_row, self._fire_design)
        self._wire_row(self._common_row, self._fire_common)

        self._paint()

    def _item_divider(self) -> None:
        # 項目区切り（やや内側寄せ。リストとの境目＝全幅と使い分ける）
        d = tk.Frame(self.frame, height=1, bg=theme.PALETTE["divider"])
        d.pack(fill="x", padx=8)
        self._dividers.append(d)

    def _wire_row(self, row, on_click: Callable[[], None]) -> None:
        for w in row:
            w.bind("<Button-1>", lambda _e, fn=on_click: fn())
            w.bind("<Enter>", lambda _e, r=row: self._hover_on(r))
            w.bind("<Leave>", lambda _e, r=row: self._hover_off(r))

    @property
    def widget(self) -> tk.Widget:
        return self.frame

    def set_panel_open(self, name: str, is_open: bool) -> None:
        """共通設定 / デザインラボ の開閉状態を行の見た目へ反映する。"""
        self._panel_open[name] = is_open
        self._paint()

    def set_bg(self, color: str) -> None:
        """フッターの静止地色を差し替える（設定モードのペイン着色に合わせる）。"""
        self._resting_bg = color
        self.frame.configure(bg=color)
        self._paint()

    def apply_density(self) -> None:
        """クリック密度変更時に内側余白だけ追従させる（フッターは再構築しないため）。"""
        m = theme.metrics()
        for row in self._rows:
            row[2].configure(padx=m["side_padx"], pady=m["side_pady"])

    def apply_theme(self) -> None:
        """テーマ切替時にフッターを塗り直す（フッターは再構築されないため）。
        `Sidebar.set_background()` から呼ばれる（モード切替でも呼ばれる）。
        アイコン・区切り線・文字色を新テーマで読み直し、`_paint()` で地色一式。"""
        fg = theme.readable_ink(self._resting_bg)
        for row, nm, sz in (
            (self._design_row, "sliders", _ICON_SLIDERS),
            (self._common_row, "gear", _ICON_GEAR),
        ):
            row[3].configure(fg=fg)   # テキストラベル（旧テーマの色のままだと潰れる）
            img = theme.icon(nm, "sub", sz)
            row[4].configure(image=img or "")
            row[4].image = img
        for d in self._dividers:
            d.configure(bg=str(theme.PALETTE["divider"]))
        self._paint()

    def _fire_common(self) -> None:
        if self._on_common is not None:
            self._on_common()

    def _fire_design(self) -> None:
        if self._on_design is not None:
            self._on_design()

    # --- 表現（枠色ではなく地色グレー。業務行の hover_* とは無関係） ---- #
    @staticmethod
    def _fill(row, color: str) -> None:
        for w in row:
            w.configure(bg=color)
        row[0].configure(highlightbackground=color, highlightcolor=color)

    def _is_active(self, row) -> bool:
        if row is self._common_row:
            return self._panel_open["common"]
        if row is self._design_row:
            return self._panel_open["design"]
        return False

    def _hover_on(self, row) -> None:
        if self._is_active(row):
            return  # 有効時の地色を優先
        self._fill(row, theme.PALETTE["footer_hover_bg"])

    def _hover_off(self, row) -> None:
        if pointer_within(row[0]):
            return
        self._paint()

    def _paint(self) -> None:
        """全行を静止状態に描く（ホバー解除時の復帰先も兼ねる）。"""
        bg = self._resting_bg
        active_bg = theme.PALETTE["footer_active_bg"]
        for row in self._rows:
            self._fill(row, active_bg if self._is_active(row) else bg)


class Sidebar:
    def __init__(
        self,
        parent: tk.Misc,
        on_select_work: Callable[[str], None],
        *,
        on_toggle_common_settings: Callable[[], None] | None = None,
        on_toggle_design_lab: Callable[[], None] | None = None,
        on_reorder_work: Callable[[str, str, str | None], None] | None = None,
        on_reselect_work: Callable[[str], None] | None = None,
    ) -> None:
        bg = theme.PALETTE["sidebar_bg"]
        self.container = tk.Frame(parent, bg=bg)
        self.frame = ScrollableFrame(self.container, bg=bg)
        self.frame.pack(side="top", fill="both", expand=True)
        self._footer = _SidebarFooter(
            self.container, on_toggle_common_settings, on_toggle_design_lab
        )
        self._footer.widget.pack(side="bottom", fill="x")

        self._on_select_work = on_select_work
        self._on_reselect_work = on_reselect_work   # 選択中の業務を再クリック（パネル非再構築）
        self._on_reorder_work = on_reorder_work
        self._leave_guard: Callable[[], bool] | None = None
        self._on_context: Callable[[str, int, int], None] | None = None  # 右クリック
        self._rows: dict[str, _WorkChip] = {}
        self._layout: list[tuple[str, str, tk.Widget]] = []   # 表示順 (work_id, group_id, outer)
        self._selected: str | None = None
        self._dragging = False
        self._drag = RowReorderDrag(
            scroll=self.frame,
            get_layout=lambda: [
                (i, c, w) for i, c, w in self._layout if w.winfo_exists()
            ],
            on_drop=self._on_drag_drop,
            indicator_parent=lambda: self.frame.body,
            on_state=self._set_dragging,
            allow_new_container=True,   # 最終グループの下へドロップ＝新しいグループ
        )

    @property
    def widget(self) -> tk.Widget:
        return self.container

    @property
    def scrollable(self) -> ScrollableFrame:
        """スクロールバーモード適用など、スクロール部品そのものが要るとき用。"""
        return self.frame

    def set_panel_open(self, name: str, is_open: bool) -> None:
        """共通設定 / デザインラボ の開閉をフッターの行の見た目に反映する。"""
        self._footer.set_panel_open(name, is_open)

    def set_background(self, settings: bool) -> None:
        """設定モードでサイドバー全体の地色を暖色に（`render()` の直前に呼ぶ）。"""
        bg = str(
            theme.PALETTE["settings_pane_bg"] if settings else theme.PALETTE["sidebar_bg"]
        )
        self.container.configure(bg=bg)
        self.frame.set_bg(bg)
        self._footer.set_bg(bg)
        self._footer.apply_theme()   # テーマ切替でアイコン色を追随（§17.7 ステージ5）

    def apply_density(self) -> None:
        self._footer.apply_density()

    @property
    def selected_work_id(self) -> str | None:
        return self._selected

    def select_work(self, work_id: str) -> None:
        """外部（App の業務作成／貼り付け）から指定業務を選択させる。"""
        if work_id in self._rows:
            self._select(work_id, force=True)

    def update_row_label(self, entity_id: str, name: str) -> None:
        """インライン改名から。該当業務行の見出しだけ差し替える（再構築しない）。"""
        chip = self._rows.get(entity_id)
        if chip is not None:
            chip.set_text(name)

    # --------------------------------------------------------------- #
    def render(
        self,
        data: AppData,
        *,
        mode: str = "normal",
        settings_mode: bool | None = None,
        keep_selection: str | None = None,
    ) -> None:
        """業務一覧を作り直す。`settings_mode` は「行をドラッグで並べ替えられるか」だけを
        決める（サイドバー自身は編集アクションを持たないので、コールバックは受け取らない）。
        省略時は `mode` から判断する。"""
        self._drag.reset()
        self._rows.clear()
        self._layout.clear()
        body = self.frame.begin_rebuild()
        editing = mode == "settings" if settings_mode is None else settings_mode

        # §16 Phase A: 設定モードでもグループ見出し・上部 `＋` は出さない
        # （通常モードと同一レイアウト。追加は別途デザインラボで行う）。

        first = True
        for gi, wg in enumerate(data.work_groups):
            if not wg.works:
                continue   # 空グループは描かない（隙間が2つ分空くのを防ぐ）
            color = theme.group_color(gi)   # 色は元のインデックスで（上書きの位置がずれない）
            group_box = tk.Frame(body, bg=body["bg"])
            # 業務リスト（色帯＋行＋行間 1px 線）は「対話要素」＝ダブルクリックで
            # 最背面に行かせない（App._on_double_click が祖先のこのフラグを見る）。
            group_box._wd_no_send_back = True
            # 左右にマージン＝色帯を「バー」でなく「パネル」に見せる。
            # 先頭グループは帯との間に少し隙間（隙間ゼロだと「見上げる」錯覚。§17 ユーザー指摘）。
            group_box.pack(
                fill="x", padx=theme.box_margin(),
                pady=(theme.list_top_pad() if first else GROUP_GAP, 0),
            )
            first = False

            # 同一グループ内の業務行は、同じグループ色の「チップ」を少しだけ離して積む
            # （間の地色＝ペイン地色が細く覗いて分離が出る。旧「くっつけ＋1px線」から変更。
            #  グループ間の隙間 GROUP_GAP はより広い＝グルーピングは近接で示す）。
            for wi, work in enumerate(wg.works):
                self._render_work_row(
                    group_box, work, color, editing, wg.id,
                    last=(wi == len(wg.works) - 1),
                )

        self.frame.commit_rebuild()

        # `render()` は必ず `on_select_work` を 1 回だけ呼ぶ＝これでメインパネルも
        # 描き直る（呼び出し側が追加で選択通知を投げると二重描画になる。2026-09-02）。
        target = keep_selection if keep_selection in self._rows else next(iter(self._rows), None)
        if target:
            self._select(target, force=True)   # 再構築後はメインパネルを必ず描き直す
        else:
            # 業務が 1 つも無いときも、メインパネルを空表示へ更新させる
            self._selected = None
            self._on_select_work("")

    def refresh_selected_indent(self) -> None:
        """インデント量スライダーから。選択中チップのラベル位置だけ更新
        （量は `theme.STATE["sel_indent_px"]` を chip 自身が読む）。"""
        chip = self._rows.get(self._selected or "")
        if chip is not None:
            chip.redraw()

    # --------------------------------------------------------------- #
    def _render_work_row(
        self, parent: tk.Misc, work, color: str, editing: bool,
        group_id: str, *, last: bool = True,
    ) -> None:
        chip = _WorkChip(parent, work.name, color)
        chip._wd_no_send_back = True
        # 同一グループ内は各行の下に細い隙間（最後の行だけ 0）＝チップの積み重ね
        chip.pack(fill="x", pady=(0, 0 if last else _WORKROW_GAP))
        self._rows[work.id] = chip
        self._layout.append((work.id, group_id, chip))
        if editing:
            # 行のどこでも掴んでドラッグ（§16bis Phase D）。ドラッグしなければ release で選択。
            self._drag.bind_row(
                (chip,), work.id, on_click=lambda wid=work.id: self._click(wid)
            )
        else:
            chip.bind("<Button-1>", lambda _e, wid=work.id: self._click(wid))
        chip.bind("<Enter>", lambda _e, wid=work.id: self._hover_on(wid))
        chip.bind("<Leave>", lambda _e, wid=work.id: self._hover_off(wid))
        chip.bind(
            "<Button-3>",
            lambda e, wid=work.id: self._on_context(wid, e.x_root, e.y_root)
            if self._on_context else None,
        )

    # --- ドラッグ中は編集オーバーレイの出し入れを止める ----------------- #
    def _set_dragging(self, active: bool) -> None:
        self._dragging = active
        if not active:
            self._decorate_all_resting()

    def _decorate_all_resting(self) -> None:
        for wid in self._rows:
            self._decorate(wid, selected=(wid == self._selected))

    def _on_drag_drop(
        self, work_id: str, before_id: str | None, group_id: str | None
    ) -> None:
        if self._on_reorder_work is None:
            return
        if group_id is None:                       # 新しいグループへ
            self._on_reorder_work(work_id, None, None)
        elif group_id:
            self._on_reorder_work(work_id, group_id, before_id)

    # --- ホバー表現（薄い面。選択＝左アクセントバー。§A 2026-08-31 で単純化） ---- #
    def _hover_on(self, work_id: str) -> None:
        if work_id in self._rows and not self._dragging:
            self._rows[work_id].set_hover(True)

    def _hover_off(self, work_id: str) -> None:
        if self._dragging or work_id not in self._rows:
            return
        chip = self._rows[work_id]
        if not pointer_within(chip):
            chip.set_hover(False)

    # --------------------------------------------------------------- #
    def set_leave_guard(self, guard: Callable[[], bool]) -> None:
        """業務行クリックで選択が動く直前に呼ぶ関数（False なら移動しない）。
        App が「開いている動作フォームの未適用の編集を保存 / 入力漏れなら止める」を差す。"""
        self._leave_guard = guard

    def set_context_handler(self, handler: Callable[[str, int, int], None]) -> None:
        """業務行の右クリック → `handler(work_id, x_root, y_root)`（App がメニューを出す）。"""
        self._on_context = handler

    def _click(self, work_id: str) -> None:
        """行クリック＝即座に選択（遅延なし）。ダブルクリックは業務行の上では
        最背面化しない（`group_box` の `_wd_no_send_back`）ので、2 回目の
        クリックは同じ業務を選び直すだけ＝実害なし。"""
        if self._leave_guard is not None and not self._leave_guard():
            return
        self._select(work_id)

    # --------------------------------------------------------------- #
    def _select(self, work_id: str, *, force: bool = False) -> None:
        # 既に選択中の業務を再クリックしただけならメインパネルは作り直さない（チラつき対策）。
        # ただし配下のタスク／動作の選択は解除して「業務が選択対象」に戻す（§16bis まとまり B 追補）。
        if not force and work_id == self._selected and work_id in self._rows:
            if self._on_reselect_work is not None:
                self._on_reselect_work(work_id)
            return
        if self._selected in self._rows:
            self._decorate(self._selected, selected=False)
        self._selected = work_id
        self._decorate(work_id, selected=True)
        self._on_select_work(work_id)

    def _decorate(self, work_id: str, *, selected: bool) -> None:
        """選択表現＝左アクセントバー（＋文字をアクセント色）。地色は変えない
        （面の色が変わると別グループに見えるため。ユーザー指摘 2026-08-31）。"""
        chip = self._rows.get(work_id)
        if chip is not None:
            chip.set_selected(selected)
