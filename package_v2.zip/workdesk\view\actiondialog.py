"""動作（タスクにぶら下がる処理）の追加・編集フォーム。

- `ActionForm(parent_frame, app, action)` … 種類選択＋種類別の入力欄を `parent_frame` に組む
  再利用コンポーネント。`.collect() -> (action_id, args)`（不正なら ValueError）。
  デザインラボの動作カードにインライン表示するのと、追加ダイアログの両方で使う（§16bis まとまり B 追補）。
- `add_action_dialog(app) -> (action_id, args) | None` … **追加時**に開くモーダル
  （編集はデザインラボのインラインフォームに一本化済み＝ここは新規作成専用）。
- コピーのオプション: ワンタイム / 書式（HTMLテンプレート）/ 暗号化 / Slackメンション。
  書式・暗号化・Slackメンションは三者排他（ワンタイムはどれとも併用可）。
  Slackメンション ON = 実行時に宛先名一覧を出し、選んだ "@xxx" を定型文の先頭に付ける。
- 暗号化ON時: 2フォーム（入力＋確認再入力）→ app.ensure_crypto_ready() →
  app.crypto.encrypt(secret_id, 値) して args には secret_id のみ入れる（平文は保存しない）。

見た目はデザインラボ／共通設定と揃える（Yu Gothic UI 固定・基準フォントに追従しない）。
"""

from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from ..model import Action, new_id
from . import actionmeta, theme
from .uikit import accent_button

_UI = ("Yu Gothic UI", 12)
_INPUT = ("Yu Gothic UI", 12)

# 種類の一覧・表示名は `actionmeta` が単一の情報源（アイコン・要約文と同じテーブル）。


def add_action_dialog(app):
    """動作を新規追加するモーダル。OK なら `(action_id, args)`、キャンセルなら None。"""
    dlg = _ActionDialog(app)
    app.wait_window(dlg)
    return dlg.result


class ActionForm:
    """種類選択＋種類別入力欄を `parent` に組む。`collect()` で `(action_id, args)`。"""

    def __init__(self, parent: tk.Misc, app, action: Action | None) -> None:
        self.app = app
        self.action = action
        # dirty＝ユーザーが1つでも入力欄に触れたか。デザインラボが「移動時の自動保存」
        # 要否をこれで判定する（未変更なら collect() すら呼ばない＝暗号化コピーの再暗号化・
        # 保存を無駄に走らせない）。
        self.dirty = False
        self.frame = tk.Frame(parent, bg=parent["bg"])
        self._bg = parent["bg"]
        self._fg = str(theme.PALETTE["ink"])

        top = tk.Frame(self.frame, bg=self._bg)
        top.pack(fill="x")
        tk.Label(top, text="種類:", bg=self._bg, fg=self._fg, font=_UI).pack(side="left")
        self.type_var = tk.StringVar(
            value=actionmeta.LABEL_BY_ID.get(
                action.action_id if action else "open_file", actionmeta.LABELS[0]
            )
        )
        self.type_cb = ttk.Combobox(
            top, textvariable=self.type_var, state="readonly",
            values=actionmeta.LABELS, width=26, font=_UI,
        )
        self.type_cb.pack(side="left", padx=(6, 0))
        self.type_cb.bind(
            "<<ComboboxSelected>>", lambda _e: (self._mark_dirty(), self._build_body())
        )

        self.body = tk.Frame(self.frame, bg=self._bg)
        self.body.pack(fill="x", pady=(6, 0))
        self._collect = None
        self._build_body()

    # --- dirty 追跡（移動時の自動保存判定用） ------------------------ #
    def _mark_dirty(self, _e: tk.Event | None = None) -> None:
        self.dirty = True

    def _watch_dirty(self) -> None:
        """`self.frame` 配下の入力ウィジェットに「触れたら dirty」を仕込む。
        `_build_body` / `_render_copy_fields` の末尾で毎回呼ぶ（作り直しに追従）。"""
        stack = list(self.frame.winfo_children())
        while stack:
            w = stack.pop()
            stack.extend(w.winfo_children())
            cls = w.winfo_class()
            if cls in ("Entry", "Text"):
                w.bind("<KeyRelease>", self._mark_dirty, add="+")
            elif cls == "TCombobox":
                w.bind("<<ComboboxSelected>>", self._mark_dirty, add="+")
            elif cls in ("Checkbutton", "Radiobutton", "Button"):
                w.bind("<ButtonRelease-1>", self._mark_dirty, add="+")

    # --------------------------------------------------------------- #
    def _cur_type(self) -> str:
        return actionmeta.ID_BY_LABEL[self.type_var.get()]

    def _args(self) -> dict:
        return dict(self.action.args) if self.action else {}

    def _toplevel(self) -> tk.Misc:
        return self.frame.winfo_toplevel()

    def _build_body(self) -> None:
        for w in self.body.winfo_children():
            w.destroy()
        kind = self._cur_type()
        if kind in ("open_file", "open_folder"):
            self._collect = self._body_path(kind)
        elif kind == "open_url":
            self._collect = self._body_url()
        elif kind == "os_exec":
            self._collect = self._body_single("実行対象", "target")
        elif kind == "launch_app":
            self._collect = self._body_launch_app()
        elif kind == "copy":
            self._collect = self._body_copy()
        elif kind == "wait":
            self._collect = self._body_wait()
        self._watch_dirty()

    # --- 種類別ボディ ------------------------------------------------ #
    def _lbl(self, parent: tk.Misc, text: str, **grid) -> None:
        tk.Label(parent, text=text, bg=self._bg, fg=self._fg, font=_UI).grid(**grid)

    def _entry(self, parent: tk.Misc, **kw) -> tk.Entry:
        """入力欄。枠は `relief="solid"`（黒）ではなく `highlightbackground`（テーマ色）
        ＝ダークで黒枠が浮かない（CLAUDE.md §11 色使いの原則 ③）。"""
        kw.setdefault("bg", str(theme.PALETTE["row_normal"]))
        kw.setdefault("fg", self._fg)
        kw.setdefault("insertbackground", self._fg)
        return tk.Entry(
            parent, font=_INPUT, bd=0, relief="flat", highlightthickness=1,
            highlightbackground=str(theme.PALETTE["input_border"]),
            highlightcolor=str(theme.PALETTE["accent"]), **kw,
        )

    def _browse_button(self, parent: tk.Misc, command) -> tk.Button:
        """「参照…」ボタン。地色・文字色を明示しないとダークで OS 既定の明るい灰色が浮く。"""
        return tk.Button(
            parent, text="参照…", command=command, font=_UI,
            bg=str(theme.PALETTE["row_normal"]), fg=self._fg,
            activebackground=str(theme.PALETTE["row_hover"]), activeforeground=self._fg,
            bd=0, relief="flat", highlightthickness=1,
            highlightbackground=str(theme.PALETTE["input_border"]),
            cursor="hand2", padx=6,
        )

    def _body_single(self, label: str, key: str):
        self._lbl(self.body, label + ":", row=0, column=0, sticky="w")
        ent = self._entry(self.body, width=44)
        ent.grid(row=0, column=1, sticky="we", pady=4, padx=(6, 0))
        ent.insert(0, str(self._args().get(key, "")))

        def collect() -> dict:
            v = ent.get().strip()
            if not v:
                raise ValueError(f"{label} を入力してください")
            return {key: v}

        return collect

    def _body_url(self):
        a = self._args()
        self._lbl(self.body, "URL:", row=0, column=0, sticky="w")
        ent = self._entry(self.body, width=44)
        ent.grid(row=0, column=1, sticky="we", pady=4, padx=(6, 0))
        ent.insert(0, str(a.get("url", "")))
        nw = tk.IntVar(value=1 if a.get("new_window") else 0)
        tk.Checkbutton(
            self.body, text="新規ウィンドウで開く", variable=nw,
            bg=self._bg, fg=self._fg, font=_UI, activebackground=self._bg,
            activeforeground=self._fg, selectcolor=self._bg,
        ).grid(row=1, column=1, sticky="w", padx=(6, 0), pady=(2, 0))
        tk.Label(
            self.body,
            text="複数ページをまとめて開くとき、先頭の URL だけ ON にすると\n"
                 "その新しいウィンドウに残りがタブで入る（既存の窓を汚さない）",
            bg=self._bg, fg=str(theme.PALETTE["sub"]), font=_UI, justify="left",
        ).grid(row=2, column=1, sticky="w", padx=(6, 0), pady=(2, 0))

        def collect() -> dict:
            v = ent.get().strip()
            if not v:
                raise ValueError("URL を入力してください")
            if "://" not in v:
                raise ValueError("URL の形式が不正です（scheme:// が必要）")
            out: dict = {"url": v}
            if nw.get():
                out["new_window"] = True
            return out

        return collect

    def _body_wait(self):
        self._lbl(self.body, "待機秒数:", row=0, column=0, sticky="w")
        ent = self._entry(self.body, width=10)
        ent.grid(row=0, column=1, sticky="w", pady=4, padx=(6, 0))
        ent.insert(0, str(self._args().get("seconds", "1")))
        tk.Label(
            self.body,
            text="秒。この動作が終わるまで次の動作は始まりません\n"
                 "（例: URL を開く動作の間に挟むと 1 本ずつ順に開く）",
            bg=self._bg, fg=str(theme.PALETTE["sub"]), font=_UI, justify="left",
        ).grid(row=1, column=1, sticky="w", padx=(6, 0), pady=(2, 0))

        def collect() -> dict:
            raw = ent.get().strip()
            try:
                v = float(raw)
            except ValueError as e:
                raise ValueError("待機秒数は数値で入力してください") from e
            if v < 0:
                raise ValueError("待機秒数は 0 以上で入力してください")
            return {"seconds": v}

        return collect

    def _body_path(self, kind: str):
        self._lbl(self.body, "パス:", row=0, column=0, sticky="w")
        ent = self._entry(self.body, width=38)
        ent.grid(row=0, column=1, sticky="we", pady=4, padx=(6, 0))
        ent.insert(0, str(self._args().get("path", "")))

        def browse() -> None:
            top = self._toplevel()
            p = (
                filedialog.askdirectory(parent=top)
                if kind == "open_folder"
                else filedialog.askopenfilename(parent=top)
            )
            if p:
                ent.delete(0, "end")
                ent.insert(0, p)

        self._browse_button(self.body, browse).grid(row=0, column=2, padx=4)

        def collect() -> dict:
            v = ent.get().strip()
            if not v:
                raise ValueError("パスを入力してください")
            return {"path": v}

        return collect

    def _body_launch_app(self):
        """exe を直接実行（`os.startfile` で開けない業務アプリ向け）。引数・作業フォルダは任意。"""
        a = self._args()
        self._lbl(self.body, "exe パス:", row=0, column=0, sticky="w")
        e_path = self._entry(self.body, width=38)
        e_path.grid(row=0, column=1, sticky="we", pady=4, padx=(6, 0))
        e_path.insert(0, str(a.get("path", "")))

        def browse_exe() -> None:
            p = filedialog.askopenfilename(
                parent=self._toplevel(),
                filetypes=[("実行ファイル", "*.exe"), ("すべて", "*.*")],
            )
            if p:
                e_path.delete(0, "end")
                e_path.insert(0, p)

        self._browse_button(self.body, browse_exe).grid(row=0, column=2, padx=4)

        self._lbl(self.body, "引数（任意）:", row=1, column=0, sticky="w")
        e_args = self._entry(self.body, width=38)
        e_args.grid(row=1, column=1, sticky="we", pady=4, padx=(6, 0))
        e_args.insert(0, str(a.get("args", "")))

        self._lbl(self.body, "作業フォルダ（任意）:", row=2, column=0, sticky="w")
        e_wd = self._entry(self.body, width=38)
        e_wd.grid(row=2, column=1, sticky="we", pady=4, padx=(6, 0))
        e_wd.insert(0, str(a.get("workdir", "")))

        def browse_wd() -> None:
            p = filedialog.askdirectory(parent=self._toplevel())
            if p:
                e_wd.delete(0, "end")
                e_wd.insert(0, p)

        self._browse_button(self.body, browse_wd).grid(row=2, column=2, padx=4)

        tk.Label(
            self.body,
            text="未指定なら exe のあるフォルダで起動します",
            bg=self._bg, fg=str(theme.PALETTE["sub"]), font=_UI, justify="left",
        ).grid(row=3, column=1, sticky="w", padx=(6, 0), pady=(2, 0))

        def collect() -> dict:
            p = e_path.get().strip()
            if not p:
                raise ValueError("exe パスを入力してください")
            out: dict = {"path": p}
            if e_args.get().strip():
                out["args"] = e_args.get().strip()
            if e_wd.get().strip():
                out["workdir"] = e_wd.get().strip()
            return out

        return collect

    def _body_copy(self):
        a = self._args()
        self.v_onetime = tk.IntVar(value=1 if a.get("onetime") else 0)
        self.v_html = tk.IntVar(value=1 if a.get("format") == "html" else 0)
        self.v_enc = tk.IntVar(value=1 if a.get("encrypt") else 0)
        self.v_mention = tk.IntVar(value=1 if a.get("mention") else 0)

        self._lbl(self.body, "呼称（任意）:", row=0, column=0, sticky="w")
        self.e_label = self._entry(self.body, width=28)
        self.e_label.grid(row=0, column=1, sticky="w", pady=4, padx=(6, 0))
        self.e_label.insert(0, str(a.get("label", "")))

        opt = tk.Frame(self.body, bg=self._bg)
        opt.grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 6))
        ckw = dict(
            bg=self._bg, fg=self._fg, font=_UI, activebackground=self._bg,
            activeforeground=self._fg, selectcolor=self._bg,
        )
        tk.Checkbutton(
            opt, text="ワンタイム", variable=self.v_onetime, **ckw,
        ).pack(side="left")
        self.cb_html = tk.Checkbutton(
            opt, text="書式", variable=self.v_html, command=self._copy_excl_html,
            **ckw,
        )
        self.cb_html.pack(side="left", padx=8)
        self.cb_enc = tk.Checkbutton(
            opt, text="暗号化", variable=self.v_enc, command=self._copy_excl_enc, **ckw,
        )
        self.cb_enc.pack(side="left")
        self.cb_mention = tk.Checkbutton(
            opt, text="Slackメンション", variable=self.v_mention,
            command=self._copy_excl_mention, **ckw,
        )
        self.cb_mention.pack(side="left", padx=8)

        self.copy_fields = tk.Frame(self.body, bg=self._bg)
        self.copy_fields.grid(row=2, column=0, columnspan=3, sticky="we")
        self._render_copy_fields()
        return self._collect_copy

    def _copy_excl_html(self) -> None:
        if self.v_html.get():
            self.v_enc.set(0)
            self.v_mention.set(0)
        self._render_copy_fields()

    def _copy_excl_enc(self) -> None:
        if self.v_enc.get():
            self.v_html.set(0)
            self.v_mention.set(0)
        self._render_copy_fields()

    def _copy_excl_mention(self) -> None:
        # Slack メンションは平文の定型文にだけ効く（暗号化 / HTML とは排他）。
        if self.v_mention.get():
            self.v_html.set(0)
            self.v_enc.set(0)
        self._render_copy_fields()

    def _has_stored_secret(self) -> bool:
        """この動作に **実際に登録済みの暗号文がある** か（`secret_id` が非空）。
        コピー＆貼り付けで複製された暗号化動作は `secret_id` が空＝未登録なので、
        『登録済み』扱いにせず入力を必須にする（2026-09-01 の指摘）。"""
        a = self._args()
        return bool(self.action and a.get("encrypt") and a.get("secret_id"))

    def _render_copy_fields(self) -> None:
        for w in self.copy_fields.winfo_children():
            w.destroy()
        a = self._args()
        has_secret = self._has_stored_secret()
        self._tmpl_var = None
        self._tmpl_id_by_name = {}

        if self.v_enc.get():
            # 登録済みの秘密文字列は **復号して欄に流し込まない**（平文・文字数をランチャーに
            # 極力残さない。2026-09-01 の指摘）。空のまま保存＝現在の登録内容を維持、
            # 両方に新しい値を入れて保存＝差し替え。未登録（貼り付け直後など）は入力必須。
            head = (
                "文字列（登録済み・変更するときだけ入力）:" if has_secret
                else "文字列（未登録。入力してください）:"
            )
            self._lbl(self.copy_fields, head, row=0, column=0, columnspan=2, sticky="w")
            self._lbl(self.copy_fields, "入力:", row=1, column=0, sticky="e")
            self.e_s1 = self._entry(self.copy_fields, width=36, show="*")
            self.e_s1.grid(row=1, column=1, pady=3, padx=(6, 0))
            self._lbl(self.copy_fields, "再入力:", row=2, column=0, sticky="e")
            self.e_s2 = self._entry(self.copy_fields, width=36, show="*")
            self.e_s2.grid(row=2, column=1, pady=3, padx=(6, 0))
        elif self.v_html.get():
            tmpls = self.app.templates.list()
            if not tmpls:
                tk.Label(
                    self.copy_fields, fg=str(theme.PALETTE["danger_ink"]), bg=self._bg,
                    font=_UI, justify="left",
                    text="※ テンプレートが未登録です。\n"
                         "  「設定」→ 書式付きコピー（テンプレート）で登録してください。",
                ).grid(row=0, column=0, columnspan=2, sticky="w")
                return
            self._tmpl_id_by_name = {t.name: t.id for t in tmpls}
            self._lbl(self.copy_fields, "テンプレート:", row=0, column=0, sticky="w")
            self._tmpl_var = tk.StringVar()
            ttk.Combobox(
                self.copy_fields, textvariable=self._tmpl_var, state="readonly",
                values=[t.name for t in tmpls], width=34, font=_UI,
            ).grid(row=0, column=1, pady=3, padx=(6, 0))
            cur_id = a.get("template_id")
            for t in tmpls:
                if t.id == cur_id:
                    self._tmpl_var.set(t.name)
                    break
        else:
            self._lbl(self.copy_fields, "文字列:", row=0, column=0, sticky="nw")
            self.t_text = tk.Text(
                self.copy_fields, width=42, height=3, font=_INPUT, bd=0, relief="flat",
                highlightthickness=1,
                highlightbackground=str(theme.PALETTE["input_border"]),
                highlightcolor=str(theme.PALETTE["accent"]),
                bg=str(theme.PALETTE["row_normal"]), fg=self._fg,
                insertbackground=self._fg,
            )
            self.t_text.grid(row=0, column=1, pady=3, padx=(6, 0))
            self.t_text.insert("1.0", str(a.get("text", "")))
        self._watch_dirty()

    def _collect_copy(self) -> dict:
        args: dict = {}
        lbl = self.e_label.get().strip()
        if lbl:
            args["label"] = lbl
        if self.v_onetime.get():
            args["onetime"] = True
        if self.v_mention.get():
            args["mention"] = True

        a = self._args()
        has_secret = self._has_stored_secret()   # 登録済みの暗号文がある（secret_id 非空）

        if self.v_enc.get():
            v1, v2 = self.e_s1.get(), self.e_s2.get()
            if has_secret and not v1 and not v2:
                args.update({"encrypt": True, "secret_id": a["secret_id"]})
                return args
            if not v1:
                # 未登録（貼り付け直後など）で空 → ここで止まり、移動もブロックされる
                raise ValueError("暗号化する文字列を入力してください")
            if v1 != v2:
                raise ValueError("確認再入力が一致しません")
            if not self.app.ensure_crypto_ready():
                raise ValueError("パスフレーズが設定されていません")
            sid = a["secret_id"] if has_secret else new_id()
            self.app.crypto.encrypt(sid, v1)
            args.update({"encrypt": True, "secret_id": sid})
            return args

        # 非暗号化。以前 暗号化で **登録済みだった** なら暗号文を破棄
        if has_secret:
            try:
                self.app.crypto.remove_secret(a["secret_id"])
            except Exception:  # noqa: BLE001
                pass

        if self.v_html.get():
            if not self._tmpl_var or not self._tmpl_var.get():
                raise ValueError(
                    "テンプレートを選択してください"
                    "（未登録なら「設定」→ 書式付きコピー（テンプレート）で登録）"
                )
            args.update({
                "format": "html",
                "template_id": self._tmpl_id_by_name[self._tmpl_var.get()],
            })
        else:
            args["text"] = self.t_text.get("1.0", "end").rstrip("\n")
        return args

    # --------------------------------------------------------------- #
    def collect(self) -> tuple[str, dict]:
        """`(action_id, args)` を返す。不正なら ValueError。"""
        return self._cur_type(), self._collect()


class _ActionDialog(tk.Toplevel):
    """動作を**新規追加**するモーダル（`ActionForm` ＋ OK / キャンセル）。

    既存動作の編集はデザインラボのカード内インラインフォームに一本化してあるので、
    ここは常に新規作成（`action=None` 相当）。親は必ず App。
    """

    def __init__(self, app) -> None:
        super().__init__(app)
        self.result: tuple[str, dict] | None = None
        self.configure(bg=str(theme.PALETTE["row_normal"]))
        self.title("動作の追加")
        self.resizable(False, False)
        self.transient(app)

        self.form = ActionForm(self, app, None)
        self.form.frame.pack(fill="both", expand=True, padx=12, pady=10)

        btns = tk.Frame(self, bg=self["bg"])
        btns.pack(fill="x", padx=12, pady=(0, 10))
        accent_button(btns, "キャンセル", self.destroy).pack(side="right", padx=(8, 0))
        accent_button(btns, "OK", self._on_ok).pack(side="right")

        self.grab_set()
        self.update_idletasks()
        self.geometry(f"+{app.winfo_rootx() + 60}+{app.winfo_rooty() + 60}")

    def _on_ok(self) -> None:
        try:
            action_id, args = self.form.collect()
        except ValueError as e:
            messagebox.showerror("入力エラー", str(e), parent=self)
            return
        self.result = (action_id, args)
        self.destroy()
