"""view 層の共有 UI パーツ（アプリ調の自作ウィジェット）。

- `Debouncer` … 「連打すると最後の1回だけ遅延実行」を Tk の `after` で。
- `ancestors` / `pointer_within` … ウィジェットの祖先を辿る小物。
- `accent_button` … Label ベースのボタン。ホバーでアクセント色に反転。
- `ask_fields` / `_FieldPrompt` … 1〜数個のテキスト入力を大きめの欄でまとめて聞く
  モーダルダイアログ（`tkinter.simpledialog` の置き換え）。パスフレーズ用に `show="*"` 対応。

パネル文字はデザインラボ／共通設定と同じく固定フォント（Yu Gothic UI）。
基準フォント（`theme.STATE["font_family"]`）には追従させない。
"""

from __future__ import annotations

import tkinter as tk
from collections.abc import Callable, Iterator

from . import theme

_UI = ("Yu Gothic UI", 12)
_INPUT = ("Yu Gothic UI", 15)


def ancestors(widget) -> Iterator[tk.Misc]:
    """`widget` 自身から親へ向かって辿る（`master` を持たなくなるまで）。

    「この祖先にフラグが立っているか」「祖先に特定の型がいるか」を調べる箇所が
    複数あるので、辿り方をここに 1 本化する（ダブルクリック最背面の除外判定、
    ホイールのスクロール対象探索、ホバー解除判定）。
    """
    node = widget
    while node is not None:
        yield node
        node = getattr(node, "master", None)


def pointer_within(widget: tk.Misc) -> bool:
    """ポインタが `widget`（またはその子孫）の上にあるか。

    `<Enter>`/`<Leave>` は子ウィジェットへの出入りでも発火するため、
    ホバー解除の判定はこれでポインタ実位置を確かめる（ちらつき防止）。
    """
    try:
        under = widget.winfo_containing(*widget.winfo_pointerxy())
    except tk.TclError:
        return False
    return any(node is widget for node in ancestors(under))


class Debouncer:
    """`schedule(ms, fn)` を連打すると **最後の1回だけ** `ms` 後に実行する。

    位置保存・外観保存・インライン改名など「入力/移動のたびに走る保存」を
    まとめるための小物。id 追跡・`after_cancel`・`TclError` 握りつぶしをここに閉じる
    （各所での手書き再実装をやめる）。`widget` の Tk `after` を使う。
    """

    def __init__(self, widget: tk.Misc) -> None:
        self._w = widget
        self._id: str | None = None
        self._fn: Callable[[], None] | None = None

    def schedule(self, delay_ms: int, fn: Callable[[], None]) -> None:
        self.cancel()
        self._fn = fn
        self._id = self._w.after(delay_ms, self._fire)

    def cancel(self) -> None:
        if self._id is not None:
            try:
                self._w.after_cancel(self._id)
            except tk.TclError:
                pass
        self._id = None
        self._fn = None

    def flush(self) -> None:
        """未発火の予約があれば今すぐ実行する（`destroy` 時の取りこぼし防止）。"""
        if self._id is not None:
            fn = self._fn
            self.cancel()
            if fn is not None:
                fn()

    def _fire(self) -> None:
        self._id = None
        fn, self._fn = self._fn, None
        if fn is not None:
            fn()


def accent_button(parent: tk.Misc, text: str, command) -> tk.Label:
    """面地・1px 枠。ホバーでアクセント色＋反転する自作ボタン。
    枠は `relief="solid"`（＝黒）ではなく `highlightbackground`（テーマ色）で描く
    ── ダークで黒枠が見えなくなるのを避ける（§17 ユーザー指摘）。"""
    normal_bg = str(theme.PALETTE["row_normal"])
    accent = str(theme.PALETTE["accent"])
    ink = str(theme.PALETTE["ink"])
    on_accent = str(theme.PALETTE["on_accent"])
    border = str(theme.PALETTE["input_border"])
    b = tk.Label(
        parent, text=text, font=_UI, bg=normal_bg, fg=ink,
        bd=0, relief="flat", highlightthickness=1,
        highlightbackground=border, highlightcolor=border,
        padx=12, pady=6, cursor="hand2",
    )
    b.bind("<Button-1>", lambda _e: command())
    b.bind(
        "<Enter>",
        lambda _e: b.configure(bg=accent, fg=on_accent,
                               highlightbackground=accent, highlightcolor=accent),
    )
    b.bind(
        "<Leave>",
        lambda _e: b.configure(bg=normal_bg, fg=ink,
                               highlightbackground=border, highlightcolor=border),
    )
    return b


class _FieldPrompt(tk.Toplevel):
    """ラベル＋大きめ Entry を縦に並べたモーダル入力ダイアログ。"""

    def __init__(
        self,
        parent: tk.Misc,
        title: str,
        fields: list[tuple],
        *,
        show: str | None,
        strip: bool,
    ) -> None:
        super().__init__(parent)
        self.result: dict[str, str] | None = None
        self._strip = strip
        bg = str(theme.PALETTE["row_normal"])
        self.configure(bg=bg)
        self.title(title)
        self.resizable(False, False)
        self.transient(parent)

        wrap = tk.Frame(self, bg=bg, padx=18, pady=16)
        wrap.pack(fill="both", expand=True)

        accent = str(theme.PALETTE["accent"])
        self._vars: dict[str, tk.StringVar] = {}
        for i, field in enumerate(fields):
            key, label = field[0], field[1]
            initial = field[2] if len(field) > 2 else ""
            lrow = tk.Frame(wrap, bg=bg)
            # 項目間はやや広め、縦線＋項目名 とテキストボックスの間は少しだけ空ける
            lrow.pack(fill="x", pady=(0 if i == 0 else 24, 7))
            tk.Frame(lrow, bg=accent, width=3).pack(side="left", fill="y")
            tk.Label(
                lrow, text=label, bg=bg, fg=str(theme.PALETTE["ink"]), font=_UI,
                anchor="w",
            ).pack(side="left", padx=(7, 0))
            var = tk.StringVar(value=initial)
            entry = tk.Entry(
                wrap, textvariable=var, font=_INPUT, width=30, show=show or "",
                bd=1, relief="solid", highlightthickness=1,
                highlightbackground=str(theme.PALETTE["input_border"]),
                highlightcolor=str(theme.PALETTE["accent"]),
            )
            entry.pack(fill="x", ipady=6)
            self._vars[key] = var
            if i == 0:
                entry.focus_set()
                entry.icursor("end")

        btns = tk.Frame(wrap, bg=bg)
        btns.pack(fill="x", pady=(16, 0))
        accent_button(btns, "キャンセル", self._cancel).pack(side="right")
        accent_button(btns, "OK", self._ok).pack(side="right", padx=(0, 8))

        self.bind("<Return>", lambda _e: self._ok())
        self.bind("<Escape>", lambda _e: self._cancel())
        self.protocol("WM_DELETE_WINDOW", self._cancel)

        self.grab_set()
        self.update_idletasks()
        self.geometry(f"+{parent.winfo_rootx() + 60}+{parent.winfo_rooty() + 80}")

    def _ok(self) -> None:
        self.result = {
            k: (v.get().strip() if self._strip else v.get()) for k, v in self._vars.items()
        }
        self.destroy()

    def _cancel(self) -> None:
        self.result = None
        self.destroy()


def ask_fields(
    parent: tk.Misc,
    title: str,
    fields: list[tuple],
    *,
    show: str | None = None,
    strip: bool = True,
) -> dict[str, str] | None:
    """`fields` は `(key, label)` か `(key, label, initial)` のリスト。
    OK で `{key: 値}`、キャンセル/×/Esc で None。"""
    dlg = _FieldPrompt(parent, title, fields, show=show, strip=strip)
    parent.wait_window(dlg)
    return dlg.result


def ask_text(parent: tk.Misc, title: str, prompt: str, *, initial: str = "") -> str | None:
    """1 行テキストを聞く（名前入力など）。前後空白は除去。"""
    res = ask_fields(parent, title, [("v", prompt, initial)])
    return res["v"] or None if res else None
