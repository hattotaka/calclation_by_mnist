"""手実装のドラッグ&ドロップ並べ替え（design-notes §16bis Phase D）。

Tk には D&D が無いので `<ButtonPress-1>` / `<B1-Motion>` / `<ButtonRelease-1>` で組む。
掴めるのは **行のどこでも**（`bind_row`）。行本体のクリック（選択／アコーディオン開閉）は
`<ButtonRelease-1>` で「ドラッグしていなければ」発火させる（`on_click`）。
閾値 `_START_DIST` px 動くまではクリック扱い。

ドラッグ中は半透明ゴースト（`Toplevel`）と、挿入位置のインジケータを出し、
スクロール端ではオートスクロールする。インジケータは通常は 2px のアクセント線、
**新しいグループ**へのドロップ時は空白部に「＋ 新しいグループ」の点線枠（線だけでは
位置が伝わらないため）。ドロップで
`on_drop(item_id, before_id, container_key)` を呼ぶ:
- `before_id` 指定 … その要素の直前へ（同じ container 内）
- `before_id=None` かつ `container_key` 指定 … その container の末尾へ
- `container_key=None`（`before_id` も None）… **新しいグループ**を作ってそこへ（`allow_new_container` 時のみ）

`get_layout()` は **表示順** の `(item_id, container_key, row_widget)` を返す。
座標は毎フレーム `winfo_rooty()` で読み直す（オートスクロール後もズレない）。
グループ境界のギャップは中点で二分し、上半分＝手前グループの末尾／下半分＝次グループの先頭に割り当てる
（行の下半分に居るだけで隣グループへ飛ぶ、を防ぐ）。
"""

from __future__ import annotations

import tkinter as tk
from collections import deque
from collections.abc import Callable

from . import theme

Slot = tuple[str, str, tk.Widget]

_START_DIST = 6    # このpx動いたらドラッグ開始（クリックと区別する）
_EDGE = 26         # ビューポート端 このpx 内でオートスクロール
_AUTO_MS = 40
_NEW_ZONE = 28     # 最終行の下 このpx より下 ＝「新しいグループ」ゾーン


def _row_text(w: tk.Widget) -> str:
    """行ウィジェット配下の最初の非空ラベル文字列（ゴーストの表示に使う）。"""
    queue = deque([w])
    while queue:
        cur = queue.popleft()
        if isinstance(cur, tk.Label):
            t = str(cur.cget("text")).strip()
            if t:
                return t
        queue.extend(cur.winfo_children())
    return "（移動中）"


class RowReorderDrag:
    def __init__(
        self,
        *,
        scroll,                                       # ScrollableFrame | None（オートスクロール用）
        get_layout: Callable[[], list[Slot]],
        on_drop: Callable[[str, str | None, str | None], None],
        indicator_parent: Callable[[], tk.Widget],
        on_state: Callable[[bool], None] | None = None,
        allow_new_container: bool = False,
    ) -> None:
        self._scroll = scroll
        self._get_layout = get_layout
        self._on_drop = on_drop
        self._indicator_parent = indicator_parent
        self._on_state = on_state
        self._allow_new = allow_new_container

        self._item: str | None = None
        self._start: tuple[int, int] = (0, 0)
        self._py = 0
        self._pending_click: Callable[[], None] | None = None
        self._active = False
        self._ghost: tk.Toplevel | None = None
        self._line: tk.Frame | None = None
        self._newbox: tk.Canvas | None = None
        self._auto: str | None = None
        self._drop: tuple[str | None, str | None] | None = None

    # --- 配線 --------------------------------------------------------- #
    def bind_row(
        self, widgets, item_id: str, on_click: Callable[[], None] | None = None
    ) -> None:
        """行の本体ウィジェット群。ドラッグしなければ `<ButtonRelease-1>` で on_click。"""
        for w in widgets:
            w.bind("<ButtonPress-1>", lambda e, i=item_id: self._press(e, i, on_click), add="+")
            w.bind("<B1-Motion>", self._motion, add="+")
            w.bind("<ButtonRelease-1>", self._release, add="+")

    def reset(self) -> None:
        """ペインの再構築時に呼ぶ（ドラッグ中の後片付け）。"""
        self._cleanup()

    @property
    def active(self) -> bool:
        return self._active

    # --- ライフサイクル ------------------------------------------- #
    def _press(self, e: tk.Event, item_id: str, on_click: Callable[[], None] | None) -> None:
        self._item = item_id
        self._start = (e.x_root, e.y_root)
        self._pending_click = on_click
        self._active = False

    def _motion(self, e: tk.Event) -> None:
        if self._item is None:
            return
        self._py = e.y_root
        if not self._active:
            dx, dy = e.x_root - self._start[0], e.y_root - self._start[1]
            if dx * dx + dy * dy < _START_DIST * _START_DIST:
                return
            self._begin()
        self._update(e.x_root, e.y_root)

    def _release(self, _e: tk.Event) -> None:
        click = self._pending_click
        was_active = self._active
        if was_active:
            self._commit()
        self._cleanup()
        if not was_active and click is not None:
            click()

    def _begin(self) -> None:
        self._active = True
        if self._on_state is not None:
            self._on_state(True)
        text = "（移動中）"
        for iid, _ck, w in self._get_layout():
            if iid == self._item:
                text = _row_text(w)
                break
        parent = self._indicator_parent()
        top = parent.winfo_toplevel()
        g = tk.Toplevel(top)
        g.overrideredirect(True)
        try:
            g.attributes("-topmost", True)
            g.attributes("-alpha", 0.85)
        except tk.TclError:
            pass
        tk.Label(
            g, text=text, bg=str(theme.PALETTE["accent"]),
            fg=str(theme.PALETTE["on_accent"]),
            padx=10, pady=4, font=theme.font("body"),
        ).pack()
        self._ghost = g

    def _update(self, px: int, py: int) -> None:
        if self._ghost is not None:
            try:
                self._ghost.geometry(f"+{px + 12}+{py + 10}")
            except tk.TclError:
                pass
        self._drop = self._hit(py)
        self._show_line(*self._drop)
        self._arm_autoscroll(py)

    # --- ヒットテスト ------------------------------------------- #
    def _hit(self, py: int) -> tuple[str | None, str | None]:
        """ポインタの縦位置から挿入先 `(before_id, container_key)` を求める。
        container_key=None は「新しいグループ」。"""
        geo = [
            (iid, ck, w.winfo_rooty(), w.winfo_rooty() + w.winfo_height())
            for iid, ck, w in self._get_layout()
            if w.winfo_exists() and w.winfo_ismapped()
        ]
        if not geo:
            return (None, None) if self._allow_new else (None, "")

        first_id, first_ck, first_top, first_bot = geo[0]
        if py < (first_top + first_bot) / 2:
            return (first_id, first_ck)

        last_id, last_ck, _lt, last_bot = geo[-1]
        if py >= last_bot:
            if self._allow_new and py >= last_bot + _NEW_ZONE:
                return (None, None)          # 新しいグループ
            return (None, last_ck)           # 末尾グループの最後へ

        for i in range(len(geo) - 1):
            c_id, c_ck, c_top, c_bot = geo[i]
            n_id, n_ck, n_top, n_bot = geo[i + 1]
            c_mid = (c_top + c_bot) / 2
            n_mid = (n_top + n_bot) / 2
            if c_mid <= py < n_mid:
                if c_ck == n_ck:
                    return (n_id, n_ck)      # 同一グループ内: 次行の前
                # グループ境界: ギャップ中点で二分
                if py < (c_bot + n_top) / 2:
                    return (None, c_ck)      # 手前グループの末尾へ（= その行の直後）
                return (n_id, n_ck)          # 次グループの先頭へ
        return (None, last_ck)

    # --- 挿入インジケータ ------------------------------------- #
    def _show_line(self, before_id: str | None, container: str | None) -> None:
        if container is None and before_id is None:
            # 新しいグループ … 空白部に点線の枠（挿入線では位置が伝わらないため）
            self._hide(self._line)
            self._line = None
            self._show_newgroup_box()
            return
        self._hide(self._newbox)
        self._newbox = None

        parent = self._indicator_parent()
        if not parent.winfo_exists():
            return
        geo = [(iid, ck, w) for iid, ck, w in self._get_layout() if w.winfo_exists()]
        if not geo:
            return
        base_y = parent.winfo_rooty()
        if before_id is not None:
            ref = next((w for iid, _c, w in geo if iid == before_id), None)
            if ref is None:
                return
            y = ref.winfo_rooty() - base_y
        else:
            refs = [w for _i, c, w in geo if c == container] if container else []
            ref = refs[-1] if refs else geo[-1][2]
            y = ref.winfo_rooty() + ref.winfo_height() - base_y

        if self._line is None or not self._line.winfo_exists():
            self._line = tk.Frame(parent, height=2, bg=str(theme.PALETTE["accent"]))
        self._line.place(x=0, y=max(0, y - 1), relwidth=1.0)
        self._line.lift()

    def _show_newgroup_box(self) -> None:
        """最終グループの下（空白部）に「＋ 新しいグループ」の点線枠を出す。"""
        if self._scroll is None:
            return
        cv = self._scroll.canvas
        if not cv.winfo_exists():
            return
        geo = [
            w for _i, _c, w in self._get_layout()
            if w.winfo_exists() and w.winfo_ismapped()
        ]
        if not geo:
            return
        last = geo[-1]
        accent = str(theme.PALETTE["accent"])
        box_h = 36
        w = max(40, cv.winfo_width() - 12)
        if self._newbox is None or not self._newbox.winfo_exists():
            self._newbox = tk.Canvas(cv, bg=cv["bg"], highlightthickness=0)
        c = self._newbox
        c.delete("all")
        c.configure(width=w, height=box_h)
        c.create_rectangle(2, 2, w - 2, box_h - 2, outline=accent, dash=(5, 3), width=2)
        c.create_text(
            w / 2, box_h / 2, text="＋ 新しいグループ", fill=accent,
            font=theme.font("action"),
        )
        y = last.winfo_rooty() - cv.winfo_rooty() + last.winfo_height() + 8
        y = max(2, min(y, cv.winfo_height() - box_h - 4))
        c.place(x=6, y=y)
        tk.Misc.lift(c)   # Canvas.lift は tag_raise なので基底の widget raise を使う

    @staticmethod
    def _hide(w) -> None:
        if w is not None:
            try:
                w.destroy()
            except tk.TclError:
                pass

    # --- オートスクロール ---------------------------------------- #
    def _arm_autoscroll(self, py: int) -> None:
        self._stop_autoscroll()
        if self._scroll is None:
            return
        cv = self._scroll.canvas
        if not cv.winfo_exists():
            return
        top = cv.winfo_rooty()
        bot = top + cv.winfo_height()
        direction = 0
        if py < top + _EDGE:
            direction = -1
        elif py > bot - _EDGE:
            direction = 1
        if direction:
            self._auto = cv.after(_AUTO_MS, lambda d=direction: self._auto_tick(d))

    def _auto_tick(self, direction: int) -> None:
        if not self._active or self._scroll is None:
            return
        cv = self._scroll.canvas
        lo, hi = cv.yview()
        if not (direction < 0 and lo <= 0.0) and not (direction > 0 and hi >= 1.0):
            cv.yview_scroll(direction, "units")
        self._drop = self._hit(self._py)
        self._show_line(*self._drop)
        self._auto = cv.after(_AUTO_MS, lambda d=direction: self._auto_tick(d))

    def _stop_autoscroll(self) -> None:
        if self._auto is not None and self._scroll is not None:
            try:
                self._scroll.canvas.after_cancel(self._auto)
            except tk.TclError:
                pass
        self._auto = None

    # --- 確定・後片付け ---------------------------------------- #
    def _commit(self) -> None:
        if self._drop is None or self._item is None:
            return
        before_id, container = self._drop
        if before_id == self._item and container is not None:
            return          # 自分の直前＝動かない
        self._on_drop(self._item, before_id, container)

    def _cleanup(self) -> None:
        self._stop_autoscroll()
        for attr in ("_ghost", "_line", "_newbox"):
            w = getattr(self, attr)
            if w is not None:
                try:
                    w.destroy()
                except tk.TclError:
                    pass
                setattr(self, attr, None)
        was = self._active
        self._item = None
        self._pending_click = None
        self._drop = None
        self._active = False
        if was and self._on_state is not None:
            self._on_state(False)
