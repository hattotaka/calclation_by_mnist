"""パスフレーズ入力ダイアログ。

- ask_new_passphrase: 新規設定（入力 ＋ 確認再入力）
- ask_passphrase: 1 回入力（別端末での解錠など）
- ask_change_passphrase: 現在 ＋ 新規 ＋ 確認

見た目は共通設定・名前入力と揃える（`uikit.ask_fields`＝大きめの入力欄・自作ボタン）。
パスフレーズは前後空白も有効な文字なので `strip=False`、伏字表示 `show="*"`。
不一致はその場で messagebox を出し None を返す（呼び出し側が必要ならやり直す）。
"""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox

from .uikit import ask_fields


def ask_new_passphrase(parent: tk.Misc) -> str | None:
    res = ask_fields(
        parent, "パスフレーズの設定",
        [("p1", "新しいパスフレーズ:"), ("p2", "確認のためもう一度:")],
        show="*", strip=False,
    )
    if not res or not res["p1"]:
        return None
    if res["p1"] != res["p2"]:
        messagebox.showerror(
            "パスフレーズの設定", "一致しません。もう一度お試しください。", parent=parent
        )
        return None
    return res["p1"]


def ask_passphrase(parent: tk.Misc, prompt: str) -> str | None:
    res = ask_fields(parent, "パスフレーズ", [("p", prompt)], show="*", strip=False)
    return res["p"] or None if res else None


def ask_change_passphrase(parent: tk.Misc) -> tuple[str, str] | None:
    """(現在のパスフレーズ, 新しいパスフレーズ) を返す。キャンセル/不一致で None。"""
    res = ask_fields(
        parent, "パスフレーズの変更",
        [
            ("cur", "現在のパスフレーズ:"),
            ("new1", "新しいパスフレーズ:"),
            ("new2", "確認のためもう一度:"),
        ],
        show="*", strip=False,
    )
    if not res or not res["cur"] or not res["new1"]:
        return None
    if res["new1"] != res["new2"]:
        messagebox.showerror(
            "パスフレーズの変更", "新しいパスフレーズが一致しません。", parent=parent
        )
        return None
    return res["cur"], res["new1"]
