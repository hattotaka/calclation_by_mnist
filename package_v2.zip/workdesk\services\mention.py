"""Slack メンションの宛先辞書と、実行時の宛先選択（design-notes §5 / §10.6）。

役割:
- **宛先辞書** = `settings["mention_directory"]` = `[{"id","name","mention"}]`。
  設定パネルから CRUD する。`id` は UUID で辞書エントリ内部用（改名・削除しても
  動作は壊れない＝**動作 args は id を参照しない**。動作側は `mention: true/false` だけ）。
- `pick()` … コピー機能がワーカースレッドから呼ぶ。宛先名の一覧ウィンドウを出し、
  ユーザーが 1 つ選ぶ or「メンション無し」を選ぶまで **ワーカースレッドをブロック**する。
  戻り値は選ばれたメンション文字列（"@xxx"）。「メンション無し」/ 候補 0 件 は "" を返す。
  **タイトルバーの 最小化 / 最大化 / × は表示しない・Esc も無い**（必ず選ばせる。
  `_strip_caption_buttons` で `WS_SYSMENU` 等を除去）。アプリ終了時のみ `shutdown()` で待ちを解放する。
  宛先は「箱」＝大きめの矩形行（`Listbox` ではなく `Frame`+`Label` を縦に積む。2026-09-02。
  項目が多いときだけ Canvas でスクロール）。マウスが乗っている箱だけがうっすら色づく。
  **キーボード操作は無い**（`↑↓` / Enter / 既定ハイライトは 2026-09-02 に全廃＝
  右手はマウスの上にあるので、箱のクリックだけで確定する）。
  出現位置＝`anchor_rect()`（実行中タスク行）の中央。取れなければ本体の横中央・
  上から 80px（`_place()`）。
  配色は `colors()` で App から注入する（services は view.theme に依存しない）。

スレッド: OneTimeService と同じ考え方。UI 生成は `run_on_ui` 経由、ワーカーは
`queue.Queue.get()` で待つ（`wait_window` は使わない＝キーボードフックのポンプと
再入しての GIL クラッシュを避ける。CLAUDE.md §3）。
"""

from __future__ import annotations

import queue
import tkinter as tk
from collections.abc import Callable

_HEAD = ("Yu Gothic UI", 11)   # 見出し＝控えめ・太字にしない（選択肢より目立たせない）
_PREVIEW = ("Yu Gothic UI", 11)
_ROW_FONT = ("Yu Gothic UI", 16)   # 箱の中の文字（見やすさ優先で大きめ）
_NO_MENTION = "（メンション無し）"
# 既定はライトテーマ相当。App は `colors=` でテーマの色を注入する（B9）。
# services 層は view.theme を import しない（層をまたがない）ので、値だけ受け取る。
DEFAULT_COLORS: dict[str, str] = {
    "bg": "#ffffff",          # 窓・箱の地色
    "fg": "#222222",          # 箱の文字
    "hover": "#f2f2f2",       # ホバー＝ごく薄い面（青くしない）
    "line": "#bdbdbd",        # 箱の枠線（常時）
    "line_hover": "#777777",
    "head": "#888888",        # 見出し（選択肢より目立たせない）
    "preview_bg": "#f4f4f4",  # コピー文字列のプレビュー
    "preview_fg": "#666666",
}
_ROW_PADY = 11             # 箱の縦の余白（＝箱の高さ。旧 15 の約 75%）
_ROW_GAP = 8
_LIST_MAX_HEIGHT = 420     # これを超える分は Canvas でスクロール
_LIST_WIDTH = 270          # プレビュー箱・宛先箱で共通（旧 360 の約 75%）


def _strip_caption_buttons(win: tk.Misc) -> None:
    """Toplevel のタイトルバーから 最小化 / 最大化 / × / システムメニューを消す
    （キャプション文字とドラッグは残す）。Windows 専用・失敗は握り潰す（§4）。"""
    try:
        import ctypes

        GWL_STYLE = -16
        WS_SYSMENU, WS_MINIMIZEBOX, WS_MAXIMIZEBOX = 0x00080000, 0x00020000, 0x00010000
        SWP = 0x1 | 0x2 | 0x4 | 0x20  # NOSIZE | NOMOVE | NOZORDER | FRAMECHANGED
        u = ctypes.windll.user32
        hwnd = u.GetAncestor(win.winfo_id(), 2) or win.winfo_id()  # GA_ROOT
        style = u.GetWindowLongW(hwnd, GWL_STYLE)
        u.SetWindowLongW(
            hwnd, GWL_STYLE, style & ~(WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX)
        )
        u.SetWindowPos(hwnd, 0, 0, 0, 0, 0, SWP)
    except Exception:  # noqa: BLE001
        pass


class MentionDirectory:
    def __init__(
        self,
        run_on_ui: Callable[[Callable[[], None]], None],
        *,
        entries: Callable[[], list[dict]],
        master: tk.Misc | None = None,
        anchor_rect: Callable[[], tuple[int, int, int, int] | None] | None = None,
        colors: Callable[[], dict[str, str]] | None = None,
    ) -> None:
        self._run_on_ui = run_on_ui
        self._entries = entries          # live な settings["mention_directory"] を返す callable
        self._master = master
        # 実行中タスク行の画面矩形 (x,y,w,h) を返す callable。あればその中央に出す。
        self._anchor_rect = anchor_rect
        # 配色を返す callable（テーマ切替に毎回追従させるので値ではなく関数で持つ）。
        self._colors = colors
        self._result: queue.Queue = queue.Queue(maxsize=1)
        self._shutdown = False
        self._popup: tk.Toplevel | None = None

    # ------------------------------------------------------------- #
    # コピー機能が呼ぶ（ワーカースレッド）
    # ------------------------------------------------------------- #
    def pick(self, preview: str = "") -> str:
        """宛先名一覧を出し、選ばれたメンション文字列を返す。

        「メンション無し」を選んだ / 候補が 0 件 / headless（master=None）/ 終了中 は "".
        """
        if self._shutdown or self._master is None:
            return ""
        rows = [
            (str(e.get("name", "")), str(e.get("mention", "")))
            for e in (self._entries() or [])
            if e.get("mention")
        ]
        # 取り残しのドレイン（前回 shutdown 等）
        while not self._result.empty():
            try:
                self._result.get_nowait()
            except queue.Empty:
                break
        self._run_on_ui(lambda: self._ui_open(rows, preview))
        chosen = self._result.get()          # ← ここでブロック
        return "" if chosen is None else str(chosen)

    def shutdown(self) -> None:
        self._shutdown = True
        try:
            self._result.put_nowait(None)
        except queue.Full:
            pass

    # ------------------------------------------------------------- #
    # UI（UI スレッドでのみ実行）
    # ------------------------------------------------------------- #
    def _palette(self) -> dict[str, str]:
        c = dict(DEFAULT_COLORS)
        if self._colors is not None:
            try:
                c.update(self._colors() or {})
            except Exception:  # noqa: BLE001  配色の取得失敗で選択を止めない
                pass
        return c

    def _ui_open(self, rows: list[tuple[str, str]], preview: str) -> None:
        if self._master is None:
            self._finish(None)
            return
        c = self._palette()
        top = tk.Toplevel(self._master)
        self._popup = top
        top.title("メンション先を選択")
        top.resizable(False, False)
        top.attributes("-topmost", True)
        top.configure(bg=c["bg"])
        top.protocol("WM_DELETE_WINDOW", lambda: None)   # × では閉じない（必ず選ばせる）

        tk.Label(
            top, text="メンション先を選んでください", bg=c["bg"], fg=c["head"],
            font=_HEAD, anchor="w",
        ).pack(fill="x", padx=22, pady=(16, 6))

        # コンテンツ列（プレビュー・宛先箱は同じ横幅 `_LIST_WIDTH` にそろえる）。
        # 幅は下の Canvas の `width=_LIST_WIDTH` が決め、プレビューは fill="x" で追従。
        body = tk.Frame(top, bg=c["bg"])
        body.pack(fill="x", padx=22, pady=(0, 20))

        if preview:
            snippet = preview.strip().splitlines()
            text = "  ".join(snippet[:2])
            if len(text) > 60:
                text = text[:60] + "…"
            # コピーする文字列のプレビュー＝枠線なし（うっすらグレー地のみ）
            tk.Label(
                body, text=text, bg=c["preview_bg"], fg=c["preview_fg"], font=_PREVIEW,
                anchor="w", justify="left", padx=10, pady=6,
                wraplength=_LIST_WIDTH - 24,
            ).pack(fill="x", pady=(0, 10))

        # 宛先＝大きめの矩形「箱」を縦に積む。背景は塗らず（青くしない）、常に線で囲う。
        # マウスが乗った箱だけごく薄いグレー。クリックで確定（キーボード操作は無し）。
        mentions: list[str] = [m for _n, m in rows] + [""]      # 末尾＝「メンション無し」
        labels: list[str] = [n or m for n, m in rows] + [_NO_MENTION]

        listwrap = tk.Frame(body, bg=c["bg"])
        listwrap.pack(fill="x")
        canvas = tk.Canvas(
            listwrap, bg=c["bg"], highlightthickness=0, width=_LIST_WIDTH,
        )
        inner = tk.Frame(canvas, bg=c["bg"])
        win = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(win, width=e.width))

        def hover(widgets: tuple, on: bool) -> None:
            for w in widgets:
                w.configure(bg=c["hover"] if on else c["bg"])
            edge = c["line_hover"] if on else c["line"]
            widgets[0].configure(highlightbackground=edge, highlightcolor=edge)

        def confirm(mention: str, bx: tk.Misc, e: tk.Event) -> None:
            # ポインタが箱の外へ出てからのボタン離しは無視（誤選択防止）
            if bx.winfo_containing(e.x_root, e.y_root) not in (bx, *bx.winfo_children()):
                return
            self._finish(mention)

        for i, text in enumerate(labels):
            bx = tk.Frame(
                inner, bg=c["bg"], cursor="hand2",
                highlightthickness=1, highlightbackground=c["line"],
                highlightcolor=c["line"],
            )
            bx.pack(fill="x", pady=(0 if i == 0 else _ROW_GAP, 0))
            lbl = tk.Label(
                bx, text=text, bg=c["bg"], fg=c["fg"], font=_ROW_FONT,
                anchor="center", pady=_ROW_PADY,
            )
            lbl.pack(fill="x")
            parts = (bx, lbl)
            for w in parts:
                w.bind("<Enter>", lambda _e, p=parts: hover(p, True))
                w.bind("<Leave>", lambda _e, p=parts: hover(p, False))
                w.bind(
                    "<ButtonRelease-1>",
                    lambda e, m=mentions[i], b=bx: confirm(m, b, e),
                )

        top.update_idletasks()
        content_h = inner.winfo_reqheight()
        view_h = min(content_h, _LIST_MAX_HEIGHT)
        canvas.configure(height=view_h, scrollregion=(0, 0, 0, content_h))
        if content_h > view_h:   # 箱が多くて溢れるときだけスクロールバーを出す
            sb = tk.Scrollbar(listwrap, orient="vertical", command=canvas.yview)
            canvas.configure(yscrollcommand=sb.set, width=_LIST_WIDTH - 16)   # sb 込みで _LIST_WIDTH
            sb.pack(side="right", fill="y")
            canvas.bind(
                "<MouseWheel>",
                lambda e: canvas.yview_scroll(-1 if e.delta > 0 else 1, "units"),
            )
        canvas.pack(side="left", fill="both", expand=True)

        top.update_idletasks()
        _strip_caption_buttons(top)                  # 最小化 / 最大化 / × を消す
        self._place(top)

    def _place(self, top: tk.Toplevel) -> None:
        """実行中タスク行の中央に出す（`anchor_rect`）。取れなければ本体の横中央・上から80px。"""
        pw, ph = top.winfo_width(), top.winfo_height()
        sw, sh = top.winfo_screenwidth(), top.winfo_screenheight()
        rect = self._anchor_rect() if self._anchor_rect is not None else None
        if rect is not None:
            rx, ry, rw, rh = rect
            x = rx + rw // 2 - pw // 2
            y = ry + rh // 2 - ph // 2
        else:
            x = self._master.winfo_rootx() + (self._master.winfo_width() - pw) // 2
            y = self._master.winfo_rooty() + 80
        x = max(0, min(x, sw - pw))
        y = max(0, min(y, sh - ph))
        top.geometry(f"+{x}+{y}")

    def _finish(self, mention: str | None) -> None:
        if self._popup is not None:
            try:
                self._popup.destroy()
            except tk.TclError:
                pass
            self._popup = None
        try:
            self._result.put_nowait(mention)
        except queue.Full:
            pass


class FakeMentionDirectory:
    """headless / テスト用。`pick()` は事前設定した戻り値を即返す（ブロックしない）。"""

    def __init__(self, chosen: str = "") -> None:
        self.chosen = chosen
        self.calls: list[str] = []

    def pick(self, preview: str = "") -> str:
        self.calls.append(preview)
        return self.chosen

    def shutdown(self) -> None:
        pass
