"""クリップボード操作（Windows, ctypes）。

- 平文: CF_UNICODETEXT
- 書式付き: CF_HTML（"HTML Format"）＋ 平文フォールバックを同時に載せる
"""

from __future__ import annotations

import ctypes
from ctypes import wintypes
from dataclasses import dataclass

CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002

_user32 = ctypes.WinDLL("user32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

_user32.OpenClipboard.argtypes = [wintypes.HWND]
_user32.OpenClipboard.restype = wintypes.BOOL
_user32.EmptyClipboard.restype = wintypes.BOOL
_user32.CloseClipboard.restype = wintypes.BOOL
_user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
_user32.SetClipboardData.restype = wintypes.HANDLE
_user32.GetClipboardData.argtypes = [wintypes.UINT]
_user32.GetClipboardData.restype = wintypes.HANDLE
_user32.RegisterClipboardFormatW.argtypes = [wintypes.LPCWSTR]
_user32.RegisterClipboardFormatW.restype = wintypes.UINT

_kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
_kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
_kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
_kernel32.GlobalLock.restype = wintypes.LPVOID
_kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
_kernel32.GlobalUnlock.restype = wintypes.BOOL
_kernel32.GlobalFree.argtypes = [wintypes.HGLOBAL]
_kernel32.GlobalFree.restype = wintypes.HGLOBAL
_kernel32.GlobalSize.argtypes = [wintypes.HGLOBAL]
_kernel32.GlobalSize.restype = ctypes.c_size_t

_CF_HTML = _user32.RegisterClipboardFormatW("HTML Format")


def parse_cf_html_fragment(blob: bytes) -> str:
    """CF_HTML バイト列から StartFragment〜EndFragment を取り出して返す。"""
    text = blob.split(b"\x00", 1)[0]
    off: dict[str, int] = {}
    head_end = text.find(b"<")
    header = text[: head_end if head_end > 0 else len(text)].decode("ascii", "replace")
    for line in header.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            if v.strip().isdigit():
                off[k.strip()] = int(v)
    sf, ef = off.get("StartFragment"), off.get("EndFragment")
    if sf is not None and ef is not None and 0 <= sf <= ef <= len(text):
        return text[sf:ef].decode("utf-8", "replace")
    sh, eh = off.get("StartHTML"), off.get("EndHTML")
    if sh is not None and eh is not None and 0 <= sh <= eh <= len(text):
        return text[sh:eh].decode("utf-8", "replace")
    return text.decode("utf-8", "replace")


def cf_html_blob(fragment_html: str) -> bytes:
    """CF_HTML のバイト列（UTF-8、オフセットヘッダ付き）を作る。"""
    header = (
        "Version:0.9\r\n"
        "StartHTML:{sh:010d}\r\n"
        "EndHTML:{eh:010d}\r\n"
        "StartFragment:{sf:010d}\r\n"
        "EndFragment:{ef:010d}\r\n"
    )
    pre = "<html><body><!--StartFragment-->"
    post = "<!--EndFragment--></body></html>"

    hlen = len(header.format(sh=0, eh=0, sf=0, ef=0).encode("utf-8"))
    start_html = hlen
    start_frag = hlen + len(pre.encode("utf-8"))
    end_frag = start_frag + len(fragment_html.encode("utf-8"))
    end_html = end_frag + len(post.encode("utf-8"))

    doc = header.format(sh=start_html, eh=end_html, sf=start_frag, ef=end_frag) + pre + fragment_html + post
    return doc.encode("utf-8")


@dataclass
class ClipboardPayload:
    """コピー機能が用意する「載せるもの」。html があれば書式付き。"""

    text: str = ""
    html: str | None = None

    def apply(self, clipboard) -> None:
        if self.html is not None:
            clipboard.set_html(self.html, self.text)
        else:
            clipboard.set_text(self.text)


class ClipboardService:
    def _open(self) -> None:
        for _ in range(10):
            if _user32.OpenClipboard(None):
                return
            _kernel32.Sleep(10)
        raise OSError(f"OpenClipboard failed (err={ctypes.get_last_error()})")

    def _set_handle(self, fmt: int, buf: bytes) -> None:
        handle = _kernel32.GlobalAlloc(GMEM_MOVEABLE, len(buf))
        if not handle:
            raise OSError("GlobalAlloc failed")
        ptr = _kernel32.GlobalLock(handle)
        if not ptr:
            _kernel32.GlobalFree(handle)
            raise OSError("GlobalLock failed")
        ctypes.memmove(ptr, buf, len(buf))
        _kernel32.GlobalUnlock(handle)
        if not _user32.SetClipboardData(fmt, handle):
            _kernel32.GlobalFree(handle)
            raise OSError(f"SetClipboardData failed (fmt={fmt}, err={ctypes.get_last_error()})")

    def warmup(self) -> None:
        """初回 OpenClipboard の一度きりのコストを起動時に払っておく（中身は触らない）。"""
        try:
            self._open()
            _user32.CloseClipboard()
        except OSError:
            pass

    def clear(self) -> None:
        self._open()
        try:
            _user32.EmptyClipboard()
        finally:
            _user32.CloseClipboard()

    def set_text(self, text: str) -> None:
        self._open()
        try:
            _user32.EmptyClipboard()
            if text:
                self._set_handle(CF_UNICODETEXT, text.encode("utf-16-le") + b"\x00\x00")
        finally:
            _user32.CloseClipboard()

    def set_html(self, html: str, plain_fallback: str = "") -> None:
        self._open()
        try:
            _user32.EmptyClipboard()
            if plain_fallback:
                self._set_handle(CF_UNICODETEXT, plain_fallback.encode("utf-16-le") + b"\x00\x00")
            self._set_handle(_CF_HTML, cf_html_blob(html) + b"\x00")
        finally:
            _user32.CloseClipboard()

    def get_html(self) -> tuple[str, str] | None:
        """現在のクリップボードから (HTML断片, 平文) を読む。CF_HTML が無ければ None。"""
        self._open()
        try:
            h = _user32.GetClipboardData(_CF_HTML)
            if not h:
                return None
            ptr = _kernel32.GlobalLock(h)
            if not ptr:
                return None
            try:
                raw = ctypes.string_at(ptr, _kernel32.GlobalSize(h))
            finally:
                _kernel32.GlobalUnlock(h)
            html = parse_cf_html_fragment(raw)

            text = ""
            ht = _user32.GetClipboardData(CF_UNICODETEXT)
            if ht:
                p = _kernel32.GlobalLock(ht)
                if p:
                    try:
                        text = ctypes.wstring_at(p)
                    finally:
                        _kernel32.GlobalUnlock(ht)
            return html, text
        finally:
            _user32.CloseClipboard()


class FakeClipboard:
    """テスト・ヘッドレス用。実クリップボードに触れない。"""

    def __init__(self) -> None:
        self.text: str | None = None
        self.html: str | None = None
        self.history: list = []

    def clear(self) -> None:
        self.text = None
        self.html = None
        self.history.append(None)

    def set_text(self, text: str) -> None:
        self.text = text
        self.html = None
        self.history.append(text)

    def set_html(self, html: str, plain_fallback: str = "") -> None:
        self.text = plain_fallback or None
        self.html = html
        self.history.append(("html", html, plain_fallback))

    def get_html(self) -> tuple[str, str] | None:
        if self.html is None:
            return None
        return self.html, self.text or ""
