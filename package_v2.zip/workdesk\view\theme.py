"""view 層の見た目を一元管理する（design-notes §16 デザイン詰め / 画面調整機能）。

方針:
- **名前付きフォント（Tk named font）を1組だけ作り**、全 view がそれを参照する。
  `set_font()` で family/size を変えると Tk が全ウィジェットへ即反映する（再描画不要）。
- 色・余白・選択表現・スクロールバー挙動は `PALETTE` / `_DENSITY` / `STATE` に集約。
  `STATE` を変えたら `subscribe()` されたコールバック（＝各ペインの再描画）を呼び、
  併せて `set_save_hook()` で渡された保存関数へ永続化する（workdesk.json の settings）。
- 画面調整パネル（[designlab.py](designlab.py)）はここを叩くだけ。
"""

from __future__ import annotations

import colorsys
import tkinter as tk
import tkinter.font as tkfont
from collections.abc import Callable
from tkinter import ttk

# --- フォント候補（同系統を隣り合わせに並べる） ------------------- #
# 各グループは別名リスト。日本語 Windows では英語名・日本語名の両方が
# families() に出ることがあるので、最初にヒットした別名を採用する。
_FONT_GROUPS: list[list[str]] = [
    # ゴシック（サンセリフ）
    ["Yu Gothic UI", "Yu Gothic", "游ゴシック"],
    ["Noto Sans JP", "Noto Sans CJK JP", "Noto Sans CJK", "NotoSansCJKjp-Regular",
     "Noto Sans Japanese"],
    # ヒラギノは基本 macOS 同梱（会社 Windows に入れていれば出る）
    ["ヒラギノ角ゴ ProN", "ヒラギノ角ゴシック", "Hiragino Sans", "Hiragino Kaku Gothic ProN",
     "HiraKakuProN-W3"],
    ["Meiryo UI", "Meiryo", "メイリオ"],
    ["BIZ UDPGothic", "BIZ UDGothic"],
    ["MS UI Gothic", "MS PGothic"],
    ["Segoe UI Variable Text", "Segoe UI Variable", "Segoe UI"],
    ["Bahnschrift", "Bahnschrift SemiLight"],
    # 丸ゴシック・教科書・ポップ・手書き
    ["ヒラギノ丸ゴ ProN", "ヒラギノ丸ゴシック", "Hiragino Maru Gothic ProN",
     "HiraMaruProN-W4"],
    ["Zen Maru Gothic", "ZenMaruGothic-Regular"],
    ["UD デジタル 教科書体 NK-R", "UD Digi Kyokasho NK-R", "UD Digi Kyokasho NP-R"],
    ["HGP創英角ﾎﾟｯﾌﾟ体", "HG創英角ポップ体", "HGSoeiKakupoptai"],
    ["Comic Sans MS"],
    ["Ink Free"],
    # 明朝・毛筆
    ["Yu Mincho", "游明朝", "Yu Mincho Light"],
    ["BIZ UDPMincho", "BIZ UDMincho"],
    ["MS PMincho", "MS Mincho", "ＭＳ 明朝"],
    ["HGP行書体", "HG行書体"],
    # 等幅
    ["Consolas"],
    ["Cascadia Mono", "Cascadia Code"],
    ["MS Gothic", "ＭＳ ゴシック"],
]
# 別名も含めた平坦なフォールバック順。`init()` が「設定された書体が実在しないとき」に
# ここを上から探す（一覧表示は実在するものだけ返す `available_families()` を使う）。
_FONT_FALLBACKS: list[str] = [name for grp in _FONT_GROUPS for name in grp]

# role -> (基準サイズからの差分, weight)
# §17.7 ステージ4: 役割ごとの強さ差を効かせる（「文字が全部同じ強さ」の解消）。
#   task（主）= base+1 bold ＞ body（サイドバー項目）= base ＞ sub / action（従）= base-1 muted。
#   色の muted は fg トークン（sub / faint）側で付ける。
_ROLE_SPECS: dict[str, tuple[int, str]] = {
    "body": (0, "normal"),     # サイドバーの業務名など（一覧の項目）
    "task": (1, "bold"),       # メインパネルのタスク名（画面の主役）
    "sub": (-1, "normal"),     # 層3 テキスト（実行結果の詳細＝従）
    "action": (-1, "normal"),  # 設定モードの動作サマリ（従）
    "mode": (1, "bold"),       # トップバー（アプリ名 / モード表示）
}
FONT_NAMES: dict[str, str] = {role: f"WD_{role}" for role in _ROLE_SPECS}

# --- 変更しうる状態（画面調整パネルが書き換える。settings に永続化） ---- #
STATE: dict[str, object] = {
    "theme": "light",                # light | dark（§17 Fluent リスタイル）
    "font_family": "Yu Gothic UI",   # 未インストールなら init 時に実在候補へ寄せる
    "font_size": 12,                 # 基準サイズ
    "scrollbar_mode": "auto",        # always | auto | thin | hover
    # 選択中の業務チップのインデント（2026-08-31 以降はこれだけ。縦バー/枠色/淡い面と
    # マウスオーバーの縦バー/枠色は _WorkChip 化で不要になり撤去）。
    "sel_indent_px": 10,             # 選択中の業務チップのインデント量（0＝なし。デザインラボ「位置調整」）
    # 業務グループの色の上書き（インデックス別。空 or 短ければ既定パレットへフォールバック）。
    "group_colors": [],
    # 「その他…」で選んだ色を貯めるユーザーパレット（クイックピックに並ぶ）。
    "group_color_palette": [],
    "click_density": "normal",       # compact | normal | roomy
    # 「死んだ面」（タイトル帯・ペインの余白・窓枠）でのダブルクリックで最背面へ。
    # 対話要素（行・フッター等）の上では発火しない。ダブルクリックの判定間隔は
    # OS 設定（GetDoubleClickTime）に従う＝ランチャー側では調整しない。
    "send_to_back_dblclick": True,
    # 余白（§17 ユーザー要望でデザインラボから可変に）。
    "list_top_pad": 14,             # 先頭の業務行／タスクカードと帯の間（両ペイン共通＝上辺が揃う）
    "box_margin": 14,              # 業務の色帯／タスクカードの左右マージン（枠・サイドバーとの距離）
}
# workdesk.json の settings に保存/復元するキー
PERSIST_KEYS: tuple[str, ...] = tuple(STATE)

# --- 色（テーマ別。§17 Fluent リスタイル） ------------------------- #
# `THEMES` は「テーマ名 → 色 dict」。3 種目（ネオン等）はキーを足すだけ。
# `PALETTE` は「現在テーマの色 dict」を指す名前として維持する
# （既存の `theme.PALETTE["x"]` 参照を壊さないよう、差し替えは
#  同じ dict オブジェクトの clear()+update() で行う＝再代入しない）。
# §17.7 ステージ3: 面を3段化（`bg` < `sidebar_bg` / `surface`(=row_normal)）＋淡い選択面
# `accent_soft`。実 hex は `THEMES` が正（design-notes §17.3 の表は当時の目安）。
THEMES: dict[str, dict[str, object]] = {
    "light": {
        "bg": "#f4f6f8",                # 窓／メインパネルの地色（面の最下段。行はこの上に浮く）
        "sidebar_bg": "#eef1f4",        # サイドバー地色（やや寒色）
        "group_colors": ["#b4cdf0", "#bfe1c6", "#efd9a6", "#d3c1ea", "#eec1c9", "#cdd4dc"],
        "accent": "#2e6fa8",             # 選択／有効時の縦バー・枠色（フル・アクセント）
        "accent_soft": "#e8f1f8",       # 選択面・フォーカスリング（淡いアクセント）
        # サイドバー最下部フッター（設定モード切替 / 共通設定）。枠色ではなく地色で状態を示す。
        "footer_hover_bg": "#e4e8ec",    # ホバー時の地色（濃さは調整余地）
        "footer_active_bg": "#d6dce2",   # 設定モード有効時の地色（ホバーより一段濃く）
        "sash_bg": "#e6e6e6",           # 2 ペインのサッシ（仕切り）地色
        "row_normal": "#ffffff",        # ＝ surface（カード／行の面）
        "row_hover": "#e9edf2",         # タスク行のマウスオーバー地色（普段は地に溶け込む）
        # 層2（§7）の面＋文字（§17.7 ステージ6 で retune＋文字色トークンを新設）
        "row_running": "#fbf3d6",        # 実行中（琥珀）
        "run_ink": "#8a6a1e",           # 実行中の要約文字
        "row_ok": "#e5f2e7",            # 成功
        "ok_ink": "#3c7a4c",           # 成功バッジ／要約文字
        "row_fail": "#f6e3e7",          # 失敗 / 中止
        "fail_ink": "#b0475f",         # 失敗 / 中止の要約文字
        "divider": "#d3d9e0",           # 1px 罫（グループ区切りが見える濃さに）
        "subrow_bg": "#f6f6f6",
        "subrow_hover": "#eceef2",      # アコーディオン動作行／「＋動作」のホバー地色（subrow_bg より一段）
        # 文字 3 段（§17.3）。現行は個別 fg 直書きだったのを集約。
        "ink": "#1a222b",               # 主要テキスト（旧 #333 / #333333 / #444）
        "sub": "#5b6672",               # 二次テキスト・要約・ヒント（旧 #555〜#888）
        "faint": "#8b95a1",             # プレースホルダ・OFF 状態・空メッセージ（旧 #999）
        "on_accent": "#ffffff",         # accent 塗りの上に載る文字・前景
        "input_border": "#cccccc",      # Entry / Listbox の resting 枠
        "danger_ink": "#a33333",        # 警告・エラー文言（旧 #a33）
        "settings_ink": "#a3540b",      # 設定モードのモード表示テキスト（暖色）
        "switch_off": "#c7c7c7",        # デザインラボのトグル OFF トラック
        "switch_knob": "#ffffff",       # デザインラボのトグルつまみ
        "trough": "#e0e0e0",            # Scale の trough
        # 枠なしメイン窓（§16 ステージ3）
        "titlebar_bg": "#edeef0",        # 自作タイトル帯の地色（素の Windows グレーを避ける）
        "window_border": "#c9c9c9",      # 通常時の 1px 縁取り（角丸＋影があるので控えめ）
        "close_hover": "#d64545",        # 閉じるボタンのホバー地色
        "min_hover": "#c7c7c7",          # 最小化ボタンのホバー地色（✕ と同じくらい視認できる濃さ）
        # 設定モードの識別（帯・窓の縁取り・ペイン地色を暖色に）
        "settings_titlebar_bg": "#f6e6cf",
        "settings_border": "#d98a3d",
        "settings_pane_bg": "#faf1e0",   # 設定モード時のサイドバー／メインパネルの地色
    },
    "dark": {
        # 「真っ黒＝昔の PC」印象を避け、デザインラボ相当のスレート系に寄せた（§17 ユーザー指摘）。
        # VS Code / GitHub 等の現代的ダークは #1e1e1e〜#282c34 帯＝near-black は使わない。
        # 面3段は保つ：bg < sidebar_bg / surface、divider が 1px 枠に効く濃さ。
        "bg": "#262d37",               # 窓／メインパネル地色（デザインラボ相当のスレート。2026-08-31）
        "sidebar_bg": "#1c212a",
        # 業務グループ色の raw hue はライトと同じ＝`fit_tint()` がテーマ別に正規化する。
        "group_colors": ["#b4cdf0", "#bfe1c6", "#efd9a6", "#d3c1ea", "#eec1c9", "#cdd4dc"],
        "accent": "#74aee0",
        "accent_soft": "#2a405c",      # 選択面
        "footer_hover_bg": "#2b323d",
        "footer_active_bg": "#39424e",
        "sash_bg": "#2c333d",
        "row_normal": "#2a313c",        # ＝ surface（bg より 1 段明るいカード面）
        "row_hover": "#313a46",         # タスク行のマウスオーバー地色（bg より一段明るく）
        "row_running": "#3d3722",
        "run_ink": "#e6c67e",
        "row_ok": "#26332d",
        "ok_ink": "#8cc19d",
        "row_fail": "#3b2a34",
        "fail_ink": "#e6a0aa",
        "divider": "#3d4653",          # 1px カード枠がちゃんと見える濃さ
        "subrow_bg": "#313945",
        "subrow_hover": "#3d4756",      # アコーディオン動作行／「＋動作」のホバー地色（一段明るく）
        "ink": "#e9ecef",
        "sub": "#9aa4af",
        "faint": "#727c88",
        "on_accent": "#12161b",
        "input_border": "#4a5563",
        "danger_ink": "#e39aa0",
        "settings_ink": "#d9a066",
        "switch_off": "#3f4956",
        "switch_knob": "#e6e9ec",
        "trough": "#2f3742",
        "titlebar_bg": "#20252e",
        "window_border": "#2f3540",     # 1px 縁取り
        "close_hover": "#d64545",
        "min_hover": "#3a3a3a",
        "settings_titlebar_bg": "#3a3020",
        "settings_border": "#b57a3a",
        "settings_pane_bg": "#26211a",
    },
}

PALETTE: dict[str, object] = dict(THEMES["light"])

# クリック領域（行の内側余白）。side_* はサイドバー、row_* はメインパネル。
# §17.7 ステージ3: 「詰まって見える」対策で行内 pady を一段広げた（normal ≒10）。
_DENSITY: dict[str, dict[str, int]] = {
    "compact": {"row_padx": 10, "row_pady": 6, "side_padx": 9, "side_pady": 6},
    "normal": {"row_padx": 13, "row_pady": 10, "side_padx": 11, "side_pady": 9},
    "roomy": {"row_padx": 16, "row_pady": 14, "side_padx": 14, "side_pady": 12},
}

SEL_BAR_WIDTH = 4   # 選択／ホバーの先頭バー（§17.7 改善: 3 だと細くて見えづらかった）
# 「帯からの隙間」`STATE["list_top_pad"]` と「箱の左右マージン」`STATE["box_margin"]` は
# デザインラボから可変（§17 ユーザー要望）。参照は `list_top_pad()` / `box_margin()`（下）で、
# sidebar / main_panel が同じ関数を呼ぶので先頭の業務行とタスクカードの上辺は常に揃う。

# 動作種別アイコンの色（ライト基準。`icon_badge()` が白グリフを乗せる）。
# キーは icons.py のアイコン名。既存の自作ランチャーの「色つき・大きめアイコン」に寄せる狙い。
_ICON_TINTS: dict[str, str] = {
    "link":     "#2f6fb0",   # URL
    "file":     "#5b6b8c",   # ファイル
    "doc":      "#5b6b8c",   # 汎用
    "folder":   "#c98a2e",   # フォルダ
    "terminal": "#3f8f5f",   # OS実行
    "copy":     "#2f8f86",   # コピー
    "lock":     "#b0603a",   # 暗号化コピー
    "clock":    "#6b7280",   # 待機
}


def _badge_colors(icon_name: str) -> tuple[str, str]:
    """タイルの (塗り色, グリフ色)。既存ランチャー風に **淡い面＋その色みのグリフ**。
    ライト＝ごく淡い面＋中間色グリフ／ダーク＝暗い面＋明るい色グリフ。"""
    base = _ICON_TINTS.get(icon_name, _ICON_TINTS["doc"])
    try:
        r, g, b = _hex_to_rgb(base)
        h, l, s = colorsys.rgb_to_hls(r, g, b)
    except Exception:  # noqa: BLE001
        return base, "#ffffff"
    if str(STATE.get("theme", "light")) == "dark":
        fill = _rgb_to_hex(*colorsys.hls_to_rgb(h, 0.24, min(s, 0.40)))
        glyph = _rgb_to_hex(*colorsys.hls_to_rgb(h, min(0.76, l + 0.30), max(0.35, s - 0.06)))
    else:
        fill = _rgb_to_hex(*colorsys.hls_to_rgb(h, 0.90, min(s, 0.42)))
        glyph = base
    return fill, glyph


def icon_badge(name: str, size: int = 24):
    """角丸の色つきタイル（淡い面＋色みのグリフ）のアイコン（ImageTk.PhotoImage）。生成不能なら None。

    `_badge_colors(name)` の色。`(badge, name, fill, glyph, size)` で module キャッシュ
    （テーマ切替の `_apply_theme` で捨てられる＝テーマ別の色へ作り直し）。
    """
    fill, glyph = _badge_colors(name)
    key = ("badge", name, fill, glyph, int(size))
    hit = _icon_cache.get(key)
    if hit is not None:
        return hit
    try:
        from . import icons as _icons
        img = _icons.make_tile(name, fill, int(size), glyph)
    except Exception:  # noqa: BLE001
        return None
    _icon_cache[key] = img
    return img


# 業務グループ色のクイックピック（デザインラボ）。淡すぎると区別がつかないので
# 「はっきり色みが分かる中間トーン」を厳選（2026-08-31。`fit_tint` の緩和とセット）。
GROUP_COLOR_PRESETS: list[str] = [
    "#b4cdf0",  # 青
    "#bfe1c6",  # 緑
    "#efd9a6",  # 琥珀
    "#d3c1ea",  # 紫
    "#eec1c9",  # ローズ
    "#b3ddd9",  # ティール
    "#cdd4dc",  # スレート
    "#efcbac",  # ピーチ
]

_subscribers: list[Callable[[str], None]] = []   # fn(changed_key)
_fonts: dict[str, tkfont.Font] = {}   # role -> Font（set_font はこれを configure する）
_save_hook: Callable[[dict], None] | None = None
# アイコン（§17.7 ステージ5）。`(name, hex, size)` -> ImageTk.PhotoImage。
# PhotoImage の GC 事故を防ぐためここで参照を握る。テーマ切替（_apply_theme）と
# init()（＝Tk インタプリタが変わりうる）でクリアする。
_icon_cache: dict[tuple, object] = {}


# --- 起動時 --------------------------------------------------------- #
def load_state(saved: dict) -> None:
    """workdesk.json の settings から復元（init より前に呼ぶ）。"""
    for k in PERSIST_KEYS:
        if k in saved:
            STATE[k] = saved[k]
    _apply_theme(str(STATE["theme"]))   # 復元したテーマ名を PALETTE へ反映（通知なし）


def set_save_hook(fn: Callable[[dict], None] | None) -> None:
    global _save_hook
    _save_hook = fn


def init(root: tk.Misc) -> None:
    """名前付きフォントをこの Tk インタプリタに用意する。

    ``tk.Tk()`` ごとに Tcl インタプリタは別なので、テストが複数生成しても
    毎回張り直せるよう「無ければ作る／有れば掴み直す」で冪等にしている。
    生成した Font を ``_fonts`` に保持し、以降は名前引きせず直接 configure する。
    """
    have = set(tkfont.families(root))
    if STATE["font_family"] not in have:
        STATE["font_family"] = next(
            (c for c in _FONT_FALLBACKS if c in have), str(STATE["font_family"])
        )

    _icon_cache.clear()   # Tk インタプリタが変わると PhotoImage は無効になる
    existing = set(root.tk.call("font", "names"))
    _fonts.clear()
    for role, (delta, weight) in _ROLE_SPECS.items():
        name = FONT_NAMES[role]
        spec = dict(
            family=str(STATE["font_family"]),
            size=int(STATE["font_size"]) + delta,
            weight=weight,
        )
        if name in existing:
            f = tkfont.Font(root=root, name=name, exists=True)
            f.configure(**spec)
        else:
            f = tkfont.Font(root=root, name=name, **spec)
        _fonts[role] = f
    style_ttk(root)


def style_ttk(root: tk.Misc) -> None:
    """ttk（Combobox / Notebook）をテーマ色へ寄せる。

    Tk 既定の ttk テーマ（vista 等）は色差し替えがほぼ効かないので **clam** を土台にする
    ── アプリの ttk 使用は Combobox 数個と Notebook 1 つだけなので影響は限定的。
    `init()` とテーマ切替（App `_rebuild_for_theme`）から呼ぶ。失敗しても致命的ではない。
    """
    try:
        st = ttk.Style(root)
        if st.theme_use() != "clam":
            st.theme_use("clam")
        surf = str(PALETTE["row_normal"])
        ink = str(PALETTE["ink"])
        sub = str(PALETTE["sub"])
        ground = str(PALETTE["bg"])
        border = str(PALETTE["input_border"])
        acc = str(PALETTE["accent"])
        onacc = str(PALETTE["on_accent"])
        st.configure(
            "TCombobox", fieldbackground=surf, background=surf, foreground=ink,
            arrowcolor=ink, bordercolor=border, lightcolor=surf, darkcolor=surf,
            insertcolor=ink, selectbackground=acc, selectforeground=onacc, padding=3,
        )
        st.map(
            "TCombobox",
            fieldbackground=[("readonly", surf), ("disabled", surf)],
            foreground=[("readonly", ink), ("disabled", sub)],
            arrowcolor=[("active", acc)],
            bordercolor=[("focus", acc), ("active", acc)],
        )
        # ドロップダウンのリスト部（別 toplevel の Listbox。option DB でしか色を差せない）
        for opt, val in (
            ("*TCombobox*Listbox.background", surf),
            ("*TCombobox*Listbox.foreground", ink),
            ("*TCombobox*Listbox.selectBackground", acc),
            ("*TCombobox*Listbox.selectForeground", onacc),
        ):
            root.option_add(opt, val)
        st.configure("TNotebook", background=ground, borderwidth=0)
        st.configure(
            "TNotebook.Tab", background=ground, foreground=sub,
            bordercolor=border, lightcolor=ground, padding=(10, 5),
        )
        st.map(
            "TNotebook.Tab",
            background=[("selected", surf)],
            foreground=[("selected", ink)],
            lightcolor=[("selected", surf)],
        )
    except Exception:  # noqa: BLE001  ttk が無い環境や差し替え不可でも本体は動く
        pass


# --- 参照 --------------------------------------------------------- #
def font(role: str) -> str:
    """ウィジェットの ``font=`` に渡す名前付きフォント名を返す。"""
    return FONT_NAMES[role]


def icon(name: str, tone: str = "sub", size: int = 16):
    """単色ラインアイコン（`ImageTk.PhotoImage`）を返す。生成不能なら None。

    `tone` は PALETTE のキー（`ink` / `sub` / `faint` / `accent` / `on_accent` …）。
    `(name, 実色, size)` で module キャッシュ。テーマ切替でキャッシュは捨てられる。
    Label には ``label.configure(image=img, compound="left")`` で使い、**ref を必ず
    どこかに保持**する（キャッシュが持つが、widget 側にも ``label.image = img`` 推奨）。
    """
    # `tone` は PALETTE キー、または `#rrggbb` の実色（動作種別の色つきアイコン用）
    color = tone if tone.startswith("#") else str(PALETTE.get(tone, PALETTE.get("sub", "#000000")))
    key = (name, color, int(size))
    hit = _icon_cache.get(key)
    if hit is not None:
        return hit
    try:
        from . import icons as _icons
        img = _icons.make(name, color, int(size))
    except Exception:  # noqa: BLE001  Pillow 不在 / Tk root 不在 / 描画失敗
        return None
    _icon_cache[key] = img
    return img


def metrics() -> dict[str, int]:
    return _DENSITY[str(STATE["click_density"])]


def box_margin() -> int:
    """業務の色帯／タスクカードの左右マージン。

    `STATE["box_margin"]` に持つが**変更する UI は無い**（デザインラボ「余白」節は
    2026-09-02 に「位置調整」へ統合され、スライダーは `sel_indent_px` と
    `list_top_pad` の 2 本だけになった）。値を変えたいときは settings を直接編集する。
    """
    return int(STATE["box_margin"])


def list_top_pad() -> int:
    """先頭の業務行／タスクカードと帯の間（両ペイン共通＝先頭行の上辺が揃う）。
    デザインラボ「位置調整」の「帯からの距離」スライダーで可変。"""
    return int(STATE["list_top_pad"])


# --- 色ユーティリティ（ライト⇄ダークの色使いを1本の理屈で扱う） ------- #
def _hex_to_rgb(hx: str) -> tuple[float, float, float]:
    hx = hx.strip().lstrip("#")
    if len(hx) == 3:
        hx = "".join(c * 2 for c in hx)
    return (int(hx[0:2], 16) / 255, int(hx[2:4], 16) / 255, int(hx[4:6], 16) / 255)


def _rgb_to_hex(r: float, g: float, b: float) -> str:
    f = lambda v: max(0, min(255, round(v * 255)))  # noqa: E731
    return f"#{f(r):02x}{f(g):02x}{f(b):02x}"


# 背景色から導く「読める文字色」。テーマ既定の ink ではなく **実際に乗る地色** で決める
# （§17 ユーザー指摘: 文字色は背景色に合わせるべき＝全体の問題）。
_INK_ON_LIGHT = "#1e2733"
_INK_ON_DARK = "#e9ecef"


def lighten(hex_color: str, f: float) -> str:
    """`hex_color` を白へ f（0..1）だけ寄せる（業務チップのホバー面など）。"""
    try:
        r, g, b = _hex_to_rgb(hex_color)
    except Exception:  # noqa: BLE001
        return hex_color
    f = max(0.0, min(1.0, f))
    return _rgb_to_hex(r + (1 - r) * f, g + (1 - g) * f, b + (1 - b) * f)


def readable_ink(bg_hex: str) -> str:
    """`bg_hex` の上で読める文字色（明るい地→濃い文字／暗い地→明るい文字）。"""
    try:
        r, g, b = _hex_to_rgb(bg_hex)
    except Exception:  # noqa: BLE001
        return str(PALETTE["ink"])
    lum = 0.2126 * r + 0.7152 * g + 0.0722 * b   # 相対輝度（ざっくり）
    return _INK_ON_DARK if lum < 0.5 else _INK_ON_LIGHT


def fit_tint(hex_color: str, theme_name: str | None = None) -> str:
    """任意の色をテーマに馴染む地色へ整える。**色相は保ち、選んだ明度・彩度をできるだけ
    尊重しつつ、白飛び／黒潰れ／派手すぎだけをクランプで抑える**（§17。当初は明度を
    L=0.955 等へ強制正規化していたが「選んだ色とかけ離れて薄すぎる」ため 2026-08-31 に緩和）。"""
    name = theme_name or str(STATE.get("theme", "light"))
    try:
        r, g, b = _hex_to_rgb(hex_color)
    except Exception:  # noqa: BLE001
        return hex_color
    h, _l, s = colorsys.rgb_to_hls(r, g, b)
    if name == "dark":
        # 暗い地に載せる：明るすぎ・鮮やかすぎを抑え、暗すぎは底上げ
        l = min(max(_l, 0.16), 0.34)
        s = min(s, 0.50)
    else:
        # 明るい地：選んだ明度をほぼ尊重（下限 0.60＝黒潰れ回避 / 上限 0.93＝白飛び回避）
        l = min(max(_l, 0.60), 0.93)
        s = min(s, 0.62)
    r, g, b = colorsys.hls_to_rgb(h, l, s)
    return _rgb_to_hex(r, g, b)


def group_color(index: int) -> str:
    """業務グループ index の地色。STATE の上書き（無ければ既定パレット循環）を、
    現テーマ向けに `fit_tint()` で正規化して返す＝ライトで選んだ色もダークで浮かない。"""
    ov = STATE.get("group_colors") or []
    raw = None
    if 0 <= index < len(ov) and ov[index]:
        raw = str(ov[index])
    else:
        base = PALETTE["group_colors"]
        raw = str(base[index % len(base)])
    return fit_tint(raw)


def set_group_color(index: int, hex_color: str | None) -> None:
    """業務グループ index の色を上書き（None/"" で既定へ戻す）。購読者へ通知＋保存。"""
    ov = list(STATE.get("group_colors") or [])
    while len(ov) <= index:
        ov.append("")
    ov[index] = hex_color or ""
    STATE["group_colors"] = ov
    _notify("group_colors")


def set_group_colors(colors: list[str]) -> None:
    """業務グループ色の上書きリストを丸ごと差し替える（グループ分割で以降のグループの
    色が位置ずれしないよう、既存色を明示上書きに固定する用）。"""
    STATE["group_colors"] = [str(c or "") for c in colors]
    _notify("group_colors")


_PALETTE_CAP = 12


def add_palette_color(hex_color: str) -> None:
    """「その他…」で選んだ色をユーザーパレットへ追加（重複除去・上限あり）。自動保存。"""
    if not hex_color:
        return
    pal = [c for c in (STATE.get("group_color_palette") or []) if c.lower() != hex_color.lower()]
    pal.append(hex_color)
    STATE["group_color_palette"] = pal[-_PALETTE_CAP:]
    _notify("group_colors")


def available_families(root: tk.Misc) -> list[str]:
    """候補のうち実在する書体を、同系統が隣り合う順で返す。"""
    have = set(tkfont.families(root))
    out: list[str] = []
    for grp in _FONT_GROUPS:
        hit = next((name for name in grp if name in have), None)
        if hit:
            out.append(hit)
    cur = str(STATE["font_family"])
    if cur not in out and cur in have:
        out.append(cur)
    return out


# --- 変更 --------------------------------------------------------- #
def subscribe(fn: Callable[[str], None]) -> None:
    """外観 STATE が変わったら `fn(changed_key)` を呼ぶ（App が最小再描画を選ぶ）。"""
    _subscribers.append(fn)


def unsubscribe(fn: Callable[[str], None]) -> None:
    try:
        _subscribers.remove(fn)
    except ValueError:
        pass


def _apply_theme(name: str) -> None:
    """`name` のテーマ色を `PALETTE`（同一 dict）へその場反映する（通知しない）。"""
    src = THEMES.get(name) or THEMES["light"]
    PALETTE.clear()
    PALETTE.update(src)
    _icon_cache.clear()   # 色が変わるので作り直す（§17.7 ステージ5）


def set_theme(name: str) -> None:
    """テーマを切り替える。購読者（App）は `changed == "theme"` で**全再構築**する
    （色が view 各所に直書きのため部分再描画では追従しない。§17.7 ステージ1）。"""
    if name not in THEMES:
        return
    STATE["theme"] = name
    _apply_theme(name)
    _notify("theme")


def set_font(*, family: str | None = None, size: int | None = None) -> None:
    if family:
        STATE["font_family"] = family
    if size:
        STATE["font_size"] = int(size)
    for role, (delta, weight) in _ROLE_SPECS.items():
        f = _fonts.get(role)
        if f is not None:
            f.configure(
                family=str(STATE["font_family"]),
                size=int(STATE["font_size"]) + delta,
                weight=weight,
            )
    _notify("font_family" if family else "font_size")


def set_option(key: str, value: object) -> None:
    STATE[key] = value
    _notify(key)


def _notify(changed: str) -> None:
    """`changed` は変更されたキー。購読側（App）が必要最小限の再描画を選べる。"""
    for fn in list(_subscribers):
        try:
            fn(changed)
        except Exception:  # noqa: BLE001  パネル操作でアプリを落とさない
            pass
    if _save_hook is not None:
        try:
            _save_hook({k: STATE[k] for k in PERSIST_KEYS})
        except Exception:  # noqa: BLE001
            pass
