"""アプリのルートウィンドウ（コントローラ）。

- 2 ペイン（サイドバー＝業務 / メインパネル＝タスク）＋ 自作タイトル帯の枠なし窓。
- タスク行クリック → `dispatcher.dispatch(Command, on_event)` → `Event` を受けて
  層2の色・層3テキストを反映（連打ロックは `max(min_lock_seconds, 完了まで)`）。
  `Event` はワーカースレッドから来るので queue に積み、`after` ポーリングで UI スレッドへ。
- 設定モード（デザインラボのスイッチで切替）では階層の CRUD・コピー&貼り付け・
  行ドラッグ並べ替えを扱う（実体は `hierarchy` の純粋関数、UI は `designlab` / `main_panel`）。
- 見た目の調整は `theme` に委譲（`subscribe` した変更通知で最小限だけ描き直す）。
"""

from __future__ import annotations

import ctypes
import queue
import time
import tkinter as tk
from pathlib import Path
from tkinter import messagebox

from .. import hierarchy, model, persistence
from ..context import Context
from ..dispatch import Command, Dispatcher, Event
from ..model import AppData
from ..services.clipboard import ClipboardService
from ..services.crypto import CryptoService
from ..services.logger import Logger
from ..services.mention import MentionDirectory
from ..services.onetime import OneTimeService
from ..services.templates import TemplateStore
from ..settings import SettingsReader
from . import theme
from .actiondialog import add_action_dialog
from .commonsettings import CommonSettingsWindow
from .designlab import DesignLabWindow
from .main_panel import MainPanel
from .passdialog import ask_new_passphrase, ask_passphrase
from .scrollable import ScrollableFrame
from .sidebar import Sidebar
from .titlebar import TitleBar
from .uikit import Debouncer, ancestors

SIDEBAR_INIT_WIDTH = 240
_DEFAULT_WORK_NAME = "新しい業務"   # 業務追加＝ポップアップ無しでこの名前で作る（改名はデザインラボで）
_DEFAULT_TASK_NAME = "新しいタスク"
_OUTCOME_TEXT = {
    "all_ok": "成功しました",
    "has_failure": "失敗した動作があります",
    "aborted": "中止しました",
}


class App(tk.Tk):
    def __init__(
        self,
        data_path: str | Path,
        *,
        save_path: str | Path | None = None,
        clipboard=None,
        log=None,
        crypto=None,
        templates=None,
        persist_window: bool = True,
    ) -> None:
        super().__init__()
        self._persist_window = persist_window
        self.data_path = Path(data_path)
        # 編集の保存先。既定は実行フォルダの workdesk.json（同梱サンプルは上書きしない）。
        self.save_path = Path(save_path) if save_path else persistence.default_path()
        self.app_data: AppData = persistence.load(self.data_path)
        self.mode: str = "normal"

        # 外観設定（画面調整パネル）を settings から復元 → フォント用意 → 保存フック
        theme.load_state(self.app_data.settings.get("appearance", {}))
        theme.set_save_hook(self._save_appearance)
        theme.init(self)

        # --- 実行基盤（継ぎ目） ----------------------------------- #
        # SettingsReader は App が保持する live な AppData を包む（CRUD で最新を反映）。
        self.settings = SettingsReader(self.app_data)
        self._event_q: queue.Queue[Event] = queue.Queue()
        self._ui_q: queue.Queue = queue.Queue()   # 他スレッド → UI スレッドの呼び出し
        clip = clipboard or ClipboardService()
        if hasattr(clip, "warmup"):
            clip.warmup()   # 初回貼り付けの取りこぼし対策（cold OpenClipboard コストを先払い）
        self.onetime = OneTimeService(
            run_on_ui=self.run_on_ui,
            clipboard=clip,
            wait_ms=lambda: int(self.settings.get("onetime_wait_ms", 300)),
            master=self,
            colors=self._onetime_colors,
        )
        self.crypto = crypto or CryptoService(self.save_path.parent / "secrets.json")
        self.templates = templates or TemplateStore(self.save_path.parent / "templates", clip)
        self.mention_dir = MentionDirectory(
            run_on_ui=self.run_on_ui,
            entries=lambda: self.app_data.settings.get("mention_directory", []),
            master=self,
            anchor_rect=self._running_task_rect,   # 実行中タスク行の位置に出す
            colors=self._mention_colors,           # 配色はテーマから注入
        )
        self.context = Context(
            settings=self.settings,
            clipboard=clip,
            log=log or Logger(),
            onetime=self.onetime,
            crypto=self.crypto,
            templates=self.templates,
            mention_directory=self.mention_dir,
        )
        self.dispatcher = Dispatcher(self.context, self.settings)
        self._alive = True
        self._after_ids: set[str] = set()
        self._busy = False
        self._run_started_at = 0.0
        self._running_task_id: str | None = None  # 実行中タスク（メンション先ポップアップの位置決め用）
        self._run_gen: dict[str, int] = {}       # task_id -> 世代（stale revert 防止）
        self._run_lines: list[str] = []          # 実行中タスクの層3行
        self._design_lab = None                  # デザインラボ（開いている間はタスク実行しない）
        self._copy_buf: dict | None = None       # コピー&貼り付けバッファ（§16bis Phase C。1セッション限り）
        self._sel: tuple[str | None, str | None] = (None, None)   # 今選択中の (kind, id)（§16bis まとまり B）
        self._common_settings = None             # 共通設定（モードレス・単一・トグル）
        # 「入力/移動のたびに走る保存」はデバウンスでまとめる（uikit.Debouncer）
        self._rename_debounce = Debouncer(self)       # インライン改名 → JSON 保存
        self._appearance_debounce = Debouncer(self)   # 外観設定 → JSON 保存
        self._geom_debounce = Debouncer(self)         # ウィンドウ位置・サイズ → JSON 保存

        self.title("WorkDesk Launcher")   # 表示名はスペース入り（識別子は WorkDeskLauncher のまま）
        # 枠なし窓（§16 ステージ3）: overrideredirect ではなく WS_CAPTION だけを ctypes で外す
        # 「実ウィンドウ」。タスクバー / Alt+Tab / スナップ / Win11 角丸 / ネイティブ最小化を維持。
        # 補助ツールとして「縦に細長く」置けるよう下限は小さめ（特に幅）。
        self._min_wh = (320, 300)
        self._win_cfg: dict = self.app_data.settings.setdefault("window", {})
        self._win_drag = False   # 帯ドラッグ中フラグ（位置保存を抑止）
        self.minsize(*self._min_wh)
        saved = self._win_cfg.get("main")
        if self._persist_window and isinstance(saved, str) and saved:
            try:
                self.geometry(saved)
            except tk.TclError:
                self._center(960, 620)
        else:
            self._center(960, 620)
        self.bind("<Alt-F4>", lambda _e: self.destroy())
        self.bind("<Map>", lambda _e: self._schedule(10, self._strip_titlebar))
        if self._persist_window:
            self.bind("<Configure>", self._on_configure)

        # 枠なし窓の縁取り＝ルート窓の地色を縁取り色にして 1px だけ覗かせる
        # （padx/pady の隙間に OS 既定の白が出ていた＝ダークで白帯に見えた。§17 ユーザー指摘）。
        self.configure(bg=str(theme.PALETTE["window_border"]))
        self._frame = tk.Frame(self, bg=str(theme.PALETTE["window_border"]))
        self._frame.pack(fill="both", expand=True, padx=1, pady=1)

        self._build_titlebar()
        self._build_panes()
        # リサイズは Windows 標準の枠（`WS_THICKFRAME` は残してある）に任せる。
        # 四辺・四隅ともネイティブのヒットテストで斜めリサイズできる。自作グリップは廃止。
        self.bind_all("<MouseWheel>", self._on_mousewheel)
        self.bind_all("<Double-Button-1>", self._on_double_click)
        # 設定モードでの Ctrl+C / Ctrl+V ＝選択要素をコピー / 直下に貼り付け（§16bis まとまり C）
        self.bind_all("<Control-c>", lambda _e: self._shortcut_copy_paste("c"))
        self.bind_all("<Control-v>", lambda _e: self._shortcut_copy_paste("v"))
        self.main_panel.set_task_click_handler(self._on_task_click)
        self.main_panel.set_task_select_handler(self._on_task_select_edit)
        self.main_panel.set_action_select_handler(self._on_action_select_edit)
        self.main_panel.set_reorder_handlers(
            task_reorder=self.reorder_task,
            action_reorder=self.reorder_action,
        )
        # 設定モードの行クリックで選択が動く前に、開いている動作フォームの未適用の編集を
        # 自動保存する（入力漏れなら False ＝クリックを無視して移動させない。2026-09-01）
        self.main_panel.set_leave_guard(self._can_leave_action_edit)
        self.sidebar.set_leave_guard(self._can_leave_action_edit)
        # 右クリック → 「グループを分ける」（業務／タスク）
        self.main_panel.set_context_handler(self._show_group_menu)
        self.sidebar.set_context_handler(self._show_group_menu)

        self._apply_scrollbar_mode()
        theme.subscribe(self._on_theme_change)

        self._refresh()
        self._schedule(50, self._drain_events)
        self._schedule(0, self._startup_crypto_check)
        self._schedule(0, self._strip_titlebar)    # OS タイトルバーを外す
        self._schedule(30, self._round_corners)    # Win11 の角丸を明示要求

    # --- ポップアップの配色（services 層は theme を知らないので App が渡す） ----- #
    @staticmethod
    def _mention_colors() -> dict[str, str]:
        """メンション先ポップアップの配色（`services/mention.py` の DEFAULT_COLORS を上書き）。"""
        return {
            "bg": str(theme.PALETTE["row_normal"]),
            "fg": str(theme.PALETTE["ink"]),
            "hover": str(theme.PALETTE["row_hover"]),
            "line": str(theme.PALETTE["input_border"]),
            "line_hover": str(theme.PALETTE["sub"]),
            "head": str(theme.PALETTE["sub"]),
            "preview_bg": str(theme.PALETTE["bg"]),
            "preview_fg": str(theme.PALETTE["sub"]),
        }

    @staticmethod
    def _onetime_colors() -> dict[str, str]:
        """ワンタイム・ポップアップの配色（`services/onetime.py` の DEFAULT_COLORS を上書き）。"""
        return {
            "bg": str(theme.PALETTE["row_normal"]),
            "fg": str(theme.PALETTE["ink"]),
            "button_bg": str(theme.PALETTE["bg"]),
            "border": str(theme.PALETTE["input_border"]),
        }

    # --- 暗号鍵の準備 ------------------------------------------- #
    def _startup_crypto_check(self) -> None:
        """鍵がこの端末に無く、暗号化済み設定があるとき（別 PC 等）は解錠を促す。"""
        try:
            if self.crypto.is_configured() and not self.crypto.load_from_store():
                self._prompt_unlock()
        except Exception:  # noqa: BLE001  資格情報 API の失敗等で起動は止めない
            pass

    def _prompt_unlock(self) -> bool:
        for _ in range(3):
            pp = ask_passphrase(
                self, "この端末に暗号鍵がありません。\nパスフレーズを入力してください。"
            )
            if pp is None:
                return False
            if self.crypto.unlock(pp):
                return True
            messagebox.showerror("パスフレーズ", "パスフレーズが違います。", parent=self)
        return False

    def ensure_crypto_ready(self) -> bool:
        """暗号化を使う直前に呼ぶ（次工程の動作編集 UI から）。"""
        if self.crypto.unlocked:
            return True
        if self.crypto.is_configured():
            return self._prompt_unlock()
        pp = ask_new_passphrase(self)
        if not pp:
            return False
        try:
            self.crypto.setup(pp)
        except Exception as e:  # noqa: BLE001
            messagebox.showerror("パスフレーズの設定", f"設定に失敗しました:\n{e}", parent=self)
            return False
        return True

    # --- after のライフサイクル管理 ------------------------------- #
    def _schedule(self, ms: int, fn) -> None:
        """`after` を登録し、destroy 時に確実に after_cancel できるよう id を追跡する。"""
        if not self._alive:
            return

        def run() -> None:
            # run が呼ばれる頃には ident は束縛済み（クロージャの遅延束縛）
            self._after_ids.discard(ident)
            if self._alive:
                fn()

        ident = self.after(ms, run)
        self._after_ids.add(ident)

    # --- 構築 --------------------------------------------------------- #
    def _build_titlebar(self) -> None:
        self.title_bar = TitleBar(
            self._frame, self, on_minimize=self._minimize, on_close=self.destroy
        )
        self.title_bar.pack(fill="x", side="top")
        # 帯とペインの境目（帯がアプリの一部だと分かるように）
        tk.Frame(self._frame, height=1, bg=str(theme.PALETTE["divider"])).pack(
            fill="x", side="top"
        )
        # 既存コードは self.mode_label / self.status_label を更新するので橋渡し。
        self.mode_label = self.title_bar.mode_label
        self.status_label = self.title_bar.status_label

    # --- 自作タイトル帯からの窓移動（TitleBar が使う公開 API） --------- #
    def begin_window_drag(self) -> None:
        """帯のドラッグ開始。位置の自動保存を止める（Tcl after の連発が残像の一因）。"""
        self._win_drag = True

    def drag_window_to(self, x: int, y: int) -> None:
        """Tk の wm layer を通さず raw `SetWindowPos` で動かす（残像対策）。"""
        try:
            #  SWP_NOSIZE(1) | SWP_NOZORDER(4) | SWP_NOACTIVATE(0x10) | SWP_DEFERERASE(0x2000)
            ctypes.windll.user32.SetWindowPos(
                self._hwnd(), 0, int(x), int(y), 0, 0, 0x1 | 0x4 | 0x10 | 0x2000
            )
        except Exception:  # noqa: BLE001  非 Windows / 失敗時は Tk 版で代替
            self.geometry(f"+{int(x)}+{int(y)}")

    def end_window_drag(self, x: int, y: int) -> None:
        """帯のドラッグ終了。間引きで取りこぼした最終位置を確定して 1 度だけ保存する。"""
        self._win_drag = False
        self.geometry(f"+{int(x)}+{int(y)}")
        self._save_geom_now()

    # --- 枠なし窓のためのウィンドウ操作（ctypes） ------------------- #
    def _center(self, w: int, h: int) -> None:
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        x, y = max(0, (sw - w) // 2), max(0, (sh - h) // 3)
        self.geometry(f"{w}x{h}+{x}+{y}")

    def _hwnd(self) -> int:
        try:
            u = ctypes.windll.user32
            return u.GetAncestor(self.winfo_id(), 2) or self.winfo_id()  # GA_ROOT
        except Exception:  # noqa: BLE001
            return 0

    def _strip_titlebar(self) -> None:
        """OS のタイトルバー（`WS_CAPTION`）だけ外す。枠・タスクバー・スナップ・角丸は残す。
        deiconify などで戻ることがあるので `<Map>` でも呼ぶ（冪等）。"""
        try:
            GWL_STYLE, WS_CAPTION = -16, 0x00C00000
            SWP = 0x1 | 0x2 | 0x4 | 0x20  # NOSIZE | NOMOVE | NOZORDER | FRAMECHANGED
            u = ctypes.windll.user32
            hwnd = self._hwnd()
            if not hwnd:
                return
            style = u.GetWindowLongW(hwnd, GWL_STYLE)
            if style & WS_CAPTION:
                u.SetWindowLongW(hwnd, GWL_STYLE, style & ~WS_CAPTION)
                u.SetWindowPos(hwnd, 0, 0, 0, 0, 0, SWP)
        except Exception:  # noqa: BLE001
            pass

    def _round_corners(self) -> None:
        """Win11 の角丸を明示要求（古い OS では失敗を握り潰す）。"""
        try:
            DWMWA_WINDOW_CORNER_PREFERENCE = 33
            val = ctypes.c_int(2)  # DWMWCP_ROUND
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                self._hwnd(), DWMWA_WINDOW_CORNER_PREFERENCE,
                ctypes.byref(val), ctypes.sizeof(val),
            )
        except Exception:  # noqa: BLE001
            pass
        self._apply_dwm_colors()

    def _apply_dwm_colors(self) -> None:
        """Win11 (build 22000+): ウィンドウの縁（角丸含む）とキャプション色を DWM に指定。
        `WS_CAPTION` を外した窓の**上辺に出る 1px の明るい線**を消す（§17 ユーザー指摘）。
        ダーク描画モードも指定。古い OS / 失敗は握り潰す。"""
        try:
            dwm = ctypes.windll.dwmapi
            hwnd = self._hwnd()

            def _cref(hx: str) -> ctypes.c_int:
                hx = hx.lstrip("#")
                r, g, b = int(hx[0:2], 16), int(hx[2:4], 16), int(hx[4:6], 16)
                return ctypes.c_int((b << 16) | (g << 8) | r)   # 0x00BBGGRR

            border = _cref(str(theme.PALETTE["window_border"]))
            cap = _cref(str(theme.PALETTE["titlebar_bg"]))
            dark = ctypes.c_int(1 if str(theme.STATE.get("theme")) == "dark" else 0)
            #   20=USE_IMMERSIVE_DARK_MODE  34=BORDER_COLOR  35=CAPTION_COLOR
            for attr, v in ((20, dark), (34, border), (35, cap)):
                dwm.DwmSetWindowAttribute(hwnd, attr, ctypes.byref(v), 4)
        except Exception:  # noqa: BLE001
            pass

    def _minimize(self) -> None:
        # SW_MINIMIZE は「次のウィンドウを前面化」してくれる＝こちらにアクティブが残らない。
        try:
            ctypes.windll.user32.ShowWindow(self._hwnd(), 6)  # SW_MINIMIZE
        except Exception:  # noqa: BLE001
            try:
                self.iconify()
            except tk.TclError:
                pass

    # --- ウィンドウ位置・サイズの永続化 --------------------------- #
    def _on_configure(self, e: tk.Event) -> None:
        # 帯ドラッグ中は保存しない（Tcl after の連発が残像の一因になるため）。
        if e.widget is not self or not self._alive or self._win_drag:
            return
        self._geom_debounce.schedule(800, self._save_geom_now)

    def _save_geom_now(self) -> None:
        if not self._alive or not self._persist_window:
            return
        try:
            self._win_cfg["main"] = self.geometry()
            self.save()
        except Exception:  # noqa: BLE001
            pass

    def load_win_pos(self, key: str) -> str | None:
        """共通設定 / デザインラボ が前回位置を復元するために呼ぶ（`"+x+y"` か None）。"""
        v = self._win_cfg.get(key)
        return v if isinstance(v, str) and v else None

    def save_win_pos(self, key: str, x: int, y: int) -> None:
        if not self._persist_window:
            return
        try:
            self._win_cfg[key] = f"+{int(x)}+{int(y)}"
            self.save()
        except Exception:  # noqa: BLE001
            pass

    def _apply_scrollbar_mode(self) -> None:
        mode = str(theme.STATE["scrollbar_mode"])
        for sf in (self.sidebar.scrollable, self.main_panel.widget):
            sf.set_scrollbar_mode(mode)

    def _on_theme_change(self, changed: str) -> None:
        """theme の変更通知。必要最小限だけ描き直す（毎回の全再構築はチラつく）。"""
        if not self._alive:
            return
        if changed == "sel_indent_px":
            self.sidebar.refresh_selected_indent()      # 選択チップのラベル位置だけ
        elif changed == "scrollbar_mode":
            self._apply_scrollbar_mode()
        elif changed == "click_density":
            self._refresh()                            # 余白が変わるので両ペイン作り直し
            self.sidebar.apply_density()               # フッターは再構築されないので個別に追従
        elif changed in ("list_top_pad", "box_margin"):
            self._refresh()                            # 帯からの距離／箱の左右マージン
        elif changed == "group_colors":
            self._refresh()                            # サイドバーの色を貼り直す
        elif changed == "theme":
            # デザインラボのラジオ callback を抜けてから 1 回で全部塗り替える
            # （その場で走らせると子破棄が不安全＋要素ごとに順次切り替わって見える）。
            # `_schedule` 経由＝destroy 時に after_cancel される（テストの stderr ノイズ対策）。
            self._schedule(0, self._rebuild_for_theme)
        # font_family / font_size … 名前付きフォントが即反映されるので何もしない
        # send_to_back_dblclick … 見た目に影響なし

    def _rebuild_for_theme(self) -> None:
        """テーマ切替（§17.7 ステージ1）。色が各所に `bg=` 直書きのため全再構築する。
        `_set_mode` の色回りと同じ手順で窓枠・帯・両ペインを塗り直し、中身を作り直す。"""
        if not self._alive:
            return
        settings = self.mode == "settings"
        border = str(theme.PALETTE["settings_border" if settings else "window_border"])
        self.configure(bg=border)                      # ルート地色＝縁取り色（覗く 1px 用）
        self._frame.configure(bg=border)
        self.panes.configure(bg=str(theme.PALETTE["sash_bg"]))
        theme.style_ttk(self)                          # ttk（Combobox/Notebook）を新テーマ色へ
        self.title_bar.refresh_theme()                 # 帯の地色＋文字色を新テーマで読み直す
        self._apply_dwm_colors()                        # 窓の縁・キャプション色・ダーク描画
        self.mode_label.config(
            fg=str(theme.PALETTE["settings_ink" if settings else "ink"])
        )
        self.sidebar.set_background(settings)
        self.main_panel.set_background(settings)
        self._refresh()   # 両ペインを作り直す（メインパネルは sidebar.render の通知経由）
        # 開いているドックパネルも同じ同期パスで塗り直す（after(0) で 1tick 遅らせない）。
        for panel in (self._design_lab, self._common_settings):
            if panel is not None and panel.winfo_exists():
                panel.reskin()
        self.update_idletasks()   # ここで初めて 1 回だけ再描画（項目17）

    def _save_appearance(self, snapshot: dict) -> None:
        """theme の保存フック。外観設定を settings に反映し、書き込みはデバウンスする
        （スライダーのドラッグで JSON を連打しない）。"""
        self.app_data.settings["appearance"] = snapshot
        self._appearance_debounce.schedule(400, self.save)

    def _on_double_click(self, event: tk.Event) -> None:
        """ダブルクリックでランチャーを最背面へ（§16、設定で ON/OFF）。

        発火するのは「死んだ面」＝タイトル帯・ペインの余白・窓枠の上だけ。
        クリックで反応する対話要素（業務行・タスク行・フッター等）はコンテナに
        `_wd_no_send_back` フラグを持ち、その子孫の上では最背面化しない
        ＝単クリックの反応（選択・実行）と競合しない。入力系ウィジェットと
        別 Toplevel の上でも無効。ダブルクリックの判定間隔は OS 設定に従う。
        """
        if not theme.STATE.get("send_to_back_dblclick"):
            return
        w = event.widget
        if not isinstance(w, (tk.Frame, tk.Label, tk.Canvas, tk.Tk)):
            return
        if w.winfo_toplevel() is not self:
            return
        for node in ancestors(w):
            if node is self:
                break
            if getattr(node, "_wd_no_send_back", False):
                return
        self._send_to_back()

    def _send_to_back(self) -> None:
        """z 順を最背面へ送り、**アクティブ状態も手放す**。

        - `SetWindowPos(HWND_BOTTOM, NOACTIVATE)` で z 順だけ最背面へ。
        - そのままだとこのウィンドウが「アクティブ」のままで、タスクバーのアイコンを
          1 回クリックすると（アクティブなので）最小化されてしまう＝前面に戻らない。
          そこで直後に「今いちばん手前の別ウィンドウ」を前面化してアクティブを譲る。
        - どれも見つからなければ最小化にフォールバック。
        """
        try:
            u = ctypes.windll.user32
            me = u.GetAncestor(self.winfo_id(), 2) or self.winfo_id()  # GA_ROOT
            #        HWND_BOTTOM=1  SWP_NOSIZE=0x1 SWP_NOMOVE=0x2 SWP_NOACTIVATE=0x10
            u.SetWindowPos(me, 1, 0, 0, 0, 0, 0x1 | 0x2 | 0x10)

            nxt = self._topmost_other_window(u, me)
            if nxt:
                u.SetForegroundWindow(nxt)
            else:
                u.ShowWindow(me, 6)  # SW_MINIMIZE
        except Exception:  # noqa: BLE001  非 Windows / 失敗時は Tk 版で代替
            try:
                self.lower()
            except tk.TclError:
                pass

    @staticmethod
    def _topmost_other_window(u, me: int) -> int:
        """z 順で手前から見て、最初の「見える・オーナーなし・タイトルあり」の別窓。"""
        GW_HWNDNEXT, GW_OWNER = 2, 4
        h = u.GetTopWindow(0)
        while h:
            if (
                h != me
                and u.IsWindowVisible(h)
                and not u.GetWindow(h, GW_OWNER)
                and u.GetWindowTextLengthW(h) > 0
            ):
                return h
            h = u.GetWindow(h, GW_HWNDNEXT)
        return 0

    def _toggle_design_lab(self) -> None:
        """フッター行から呼ばれる。開いていれば閉じる（ドック的なトグル）。"""
        if self.design_lab_open():
            # 閉じる前に、開いている動作フォームの未適用の編集を保存（best-effort・告知なし）。
            self._design_lab.commit_pending_edits(silent=True)
            self._design_lab.destroy()
            return
        self._design_lab = DesignLabWindow(self)
        self._design_lab.bind("<Destroy>", self._on_design_lab_destroy, add="+")
        self.sidebar.set_panel_open("design", True)
        # 開いた直後は必ず通常モード（「設定モード」スイッチは既定 OFF）

    def _on_design_lab_destroy(self, event: tk.Event) -> None:
        if event.widget is self._design_lab:
            self._design_lab = None
            if self._alive:
                self.status_label.config(text="")
                self.sidebar.set_panel_open("design", False)
                self._set_mode("normal")   # パネルを閉じたら通常モードへ

    def design_lab_open(self) -> bool:
        """デザインラボが開いているか（設定パネルも重なり回避のために読む）。"""
        return self._design_lab is not None and self._design_lab.winfo_exists()

    def _toggle_common_settings(self) -> None:
        """フッター行から呼ばれる。開いていれば閉じる（モードレス・ドック的なトグル）。"""
        if self._common_settings is not None and self._common_settings.winfo_exists():
            self._common_settings.destroy()
            return
        self._common_settings = CommonSettingsWindow(self)
        self._common_settings.bind("<Destroy>", self._on_common_settings_destroy, add="+")
        self.sidebar.set_panel_open("common", True)

    def _on_common_settings_destroy(self, event: tk.Event) -> None:
        if event.widget is self._common_settings:
            self._common_settings = None
            if self._alive:
                self.sidebar.set_panel_open("common", False)
                self._refresh()   # テンプレート名の変化を動作一覧へ反映

    def _build_panes(self) -> None:
        self.panes = tk.PanedWindow(
            self._frame, orient="horizontal", sashwidth=6, sashrelief="groove",
            bg=str(theme.PALETTE["sash_bg"]),
        )
        self.panes.pack(fill="both", expand=True)
        self.sidebar = Sidebar(
            self.panes,
            on_select_work=self._on_select_work,
            on_toggle_common_settings=self._toggle_common_settings,
            on_toggle_design_lab=self._toggle_design_lab,
            on_reorder_work=self.reorder_work,
            on_reselect_work=self._on_reselect_work,
        )
        self.main_panel = MainPanel(self.panes)
        # ペインの下限も小さく（合計が窓の下限を超えると幅が詰められないため）
        self.panes.add(self.sidebar.widget, minsize=90, width=SIDEBAR_INIT_WIDTH, stretch="never")
        self.panes.add(self.main_panel.widget, minsize=150, stretch="always")

    # --- サイドバー / モード --------------------------------------- #
    def _refresh(self, select_work: str | None = None) -> None:
        """**両ペインを作り直す。** `sidebar.render()` が必ず `_on_select_work` を
        1 回呼ぶので、メインパネルもここで描き直る（追加で呼ぶと二重描画になる）。"""
        self.sidebar.render(
            self.app_data,
            mode=self.mode,
            settings_mode=self.mode == "settings",
            keep_selection=select_work or self.sidebar.selected_work_id,
        )

    def _on_select_work(self, work_id: str) -> None:
        work = hierarchy.find_work(self.app_data, work_id) if work_id else None
        self.main_panel.render(
            work, mode=self.mode,
            on_add_action=self.add_action if self.mode == "settings" else None,
            template_names=self.templates.names(),
        )
        self._recompute_sel()
        self._ping_design_lab_edit()

    def _on_reselect_work(self, _work_id: str) -> None:
        """選択中の業務を再クリック（メインパネルは作り直さない）＝配下の選択を解除して
        「業務」を選択対象に戻す（§16bis まとまり B 追補）。どの業務かは `_sel` から分かるので引数は使わない。"""
        self.main_panel.clear_selection()
        self._recompute_sel()
        self._ping_design_lab_edit()

    # --- デザインラボの編集セクション（§16bis Phase B / まとまり B） --- #
    def _on_task_select_edit(self, _task_id: str | None) -> None:
        self._recompute_sel()
        self._ping_design_lab_edit()

    def _on_action_select_edit(self, _action_id: str | None) -> None:
        self._recompute_sel()
        self._ping_design_lab_edit()

    @property
    def selection(self) -> tuple[str | None, str | None]:
        """いま選択している `(種類, id)`。種類は `"work"` / `"task"` / `"action"` / None。
        デザインラボが「どのカードを出すか」を決めるために読む（§16bis まとまり B）。"""
        return self._sel

    def _recompute_sel(self) -> None:
        """今の「最も具体的な選択」を `self._sel` に反映（動作 > タスク > 業務 > なし）。"""
        aid = self.main_panel.selected_action_id
        tid = self.main_panel.selected_task_id
        wid = self.sidebar.selected_work_id
        if aid:
            self._sel = ("action", aid)
        elif tid:
            self._sel = ("task", tid)
        elif wid:
            self._sel = ("work", wid)
        else:
            self._sel = (None, None)

    def rename_live(self, entity_id: str, text: str) -> None:
        """デザインラボの名前フォームから。

        行ラベルは**入力の実値に追従**させる（全文字を消したら行の見出しも空に
        なる＝入力欄とズレない）。モデルの改名とデバウンス保存は非空のときだけ。
        空欄のままフォーカスを外すとデザインラボ側（`_name_field`）が直近値へ戻し、
        その write でここが再度呼ばれて見出しも復帰する。
        """
        name = text.strip()
        self.sidebar.update_row_label(entity_id, name)
        self.main_panel.update_row_label(entity_id, name)
        if not name:
            return
        if not hierarchy.rename(self.app_data, entity_id, name):
            return
        self._rename_debounce.schedule(400, self.save)

    def set_task_description(self, task_id: str, text: str) -> None:
        """デザインラボの説明フォームから。空欄可。行のライン2を即差し替え＋デバウンス保存。"""
        t = hierarchy.find_task(self.app_data, task_id)
        if t is None:
            return
        new = text.strip()
        if t.description == new:
            return
        t.description = new
        self.main_panel.update_task_description(task_id, new)
        self._rename_debounce.schedule(400, self.save)

    def _shortcut_copy_paste(self, which: str) -> None:
        """Ctrl+C / Ctrl+V（§16bis まとまり C）。
        設定モードのときだけ・テキスト入力にフォーカスが無いときだけ働く
        （フォーカスが Entry/Text なら OS 標準の文字コピペに委ねる＝ここでは何もしない）。"""
        if self.mode != "settings":
            return
        try:
            focused = self.focus_get()
        except (KeyError, tk.TclError):
            focused = None
        if isinstance(focused, (tk.Entry, tk.Text, tk.Spinbox)):
            return
        kind, ident = self._sel
        if not kind or not ident:
            return
        if which == "c":
            self.copy_entity(kind, ident)
        elif kind == "task" and self.can_paste("action"):
            # タスク選択＝「0 番目の動作」とみなし、動作バッファを先頭へ貼る（§項目5）
            self.paste_action_head(ident)
        else:
            self.paste_entity(kind, ident)

    def _ping_design_lab_edit(self) -> None:
        """選択やモードが変わったらデザインラボの編集セクションを組み直させる。"""
        if self.design_lab_open():
            self._design_lab.request_edit_refresh()

    def _can_leave_action_edit(self) -> bool:
        """設定モードで行クリックによる選択が動く直前に、サイドバー / メインパネルが呼ぶ。
        開いている動作フォームの未適用の編集を保存し、入力漏れがあれば False（＝移動させない）。"""
        if self.design_lab_open():
            return self._design_lab.commit_pending_edits()
        return True

    # --- コピー&貼り付け（§16bis Phase C） ---------------------- #
    # kind（"work"/"task"/"action"）→ (探索関数, 複製関数)
    _ENTITY_OPS = {
        "work": (hierarchy.find_work, model.clone_work),
        "task": (hierarchy.find_task, model.clone_task),
        "action": (hierarchy.find_action, model.clone_action),
    }

    def can_paste(self, kind: str) -> bool:
        """指定種別（"work" / "task" / "action"）の貼り付けバッファがあるか。"""
        return bool(self._copy_buf) and self._copy_buf["kind"] == kind

    def copy_entity(self, kind: str, entity_id: str) -> None:
        """業務 / タスク / 動作を1セッション限りのバッファへ複製して控える。

        バッファには**コピー時点の複製**（新 ID）を持ち、貼り付けのたびに
        そこから更に複製する（複数回貼っても各々独立）。
        """
        ops = self._ENTITY_OPS.get(kind)
        if ops is None:
            return
        find, clone = ops
        src = find(self.app_data, entity_id)
        if src is None:
            return
        self._copy_buf = {"kind": kind, "data": clone(src)}
        # 貼り付けボタンを出すため編集セクション／動作アコーディオンを描き直す
        # （選択・展開状態は保つ＝アコーディオンだけ組み直す。全再描画はしない）
        self._ping_design_lab_edit()
        if kind == "action":
            self.main_panel.rebuild_open_accordion()

    def paste_entity(self, kind: str, anchor_id: str) -> None:
        """バッファの複製を `anchor_id` の直後へ兄弟として挿入する（全階層で新 ID）。"""
        ops = self._ENTITY_OPS.get(kind)
        if ops is None or not self.can_paste(kind):
            return
        _find, clone = ops
        new = clone(self._copy_buf["data"])
        if not hierarchy.insert_after(self.app_data, anchor_id, new):
            return
        self.save()
        if kind == "action":
            # 全再描画すると展開が消える。アコーディオンだけ組み直して貼った動作を選択
            self.main_panel.rebuild_open_accordion()
            ptask = hierarchy.parent_task_of_action(self.app_data, new.id)
            if ptask is not None:
                self.main_panel.select_action(ptask.id, new.id)
        elif kind == "task":
            self._refresh()
            self.main_panel.reselect_task(new.id)   # 貼ったタスクを選択
        else:
            self._refresh(select_work=new.id)       # 貼った業務を選択
        self._recompute_sel()
        self._ping_design_lab_edit()

    def paste_action_head(self, task_id: str) -> None:
        """動作バッファの複製をタスクの**先頭**へ挿入して選択する。

        「タスクを選択して Ctrl+V」＝『0 番目の動作が選択されている』とみなす解釈
        （動作0件のタスクにも貼れる。旧 `▽ 末尾に貼り付け` の置き換え）。
        """
        if not self.can_paste("action"):
            return
        task = hierarchy.find_task(self.app_data, task_id)
        if task is None:
            return
        new = model.clone_action(self._copy_buf["data"])
        task.actions.insert(0, new)
        self.save()
        self._refresh()   # 先頭動作が変わる→タスク行アイコンも full render で追従
        self.main_panel.select_action(task_id, new.id)
        self._recompute_sel()
        self._ping_design_lab_edit()

    def _commit_reorder(self, snapshot, do_move) -> bool:
        """`snapshot()`（順序の指紋）→ `do_move()` → 指紋が変わっていれば保存＋再描画。
        実際に順序が変わったときだけ True。"""
        was = snapshot()
        if not do_move() or snapshot() == was:
            return False
        self.save()
        self._refresh()
        return True

    def reorder_work(
        self, work_id: str, dest_group_id: str | None, before_id: str | None
    ) -> None:
        """業務をドラッグで並べ替え／グループ間移動。`dest_group_id=None` で新しいグループへ。"""
        def snapshot() -> list[tuple[str, str]]:
            return [(wg.id, w.id) for wg in self.app_data.work_groups for w in wg.works]

        def do_move() -> bool:
            if dest_group_id is None:
                return hierarchy.move_work_to_new_group(self.app_data, work_id)
            return hierarchy.move_work(self.app_data, work_id, dest_group_id, before_id)

        if self._commit_reorder(snapshot, do_move):
            self._ping_design_lab_edit()

    def reorder_task(
        self, task_id: str, dest_group_id: str | None, before_id: str | None
    ) -> None:
        """タスクをドラッグで並べ替え／タスクグループ間移動。`dest_group_id=None` で新グループへ。"""
        work = hierarchy.find_work(self.app_data, self.sidebar.selected_work_id or "")
        if work is None:
            return

        def snapshot() -> list[tuple[str, str]]:
            return [(tg.id, t.id) for tg in work.task_groups for t in tg.tasks]

        def do_move() -> bool:
            if dest_group_id is None:
                return hierarchy.move_task_to_new_group(self.app_data, task_id, work.id)
            return hierarchy.move_task(self.app_data, task_id, dest_group_id, before_id)

        self._commit_reorder(snapshot, do_move)

    def reorder_action(self, action_id: str, before_id: str | None) -> None:
        """動作をドラッグで並べ替え（同一タスク内）。アコーディオンは開いたまま。"""
        if before_id == action_id:
            return
        task = hierarchy.find_task(self.app_data, self.main_panel.selected_task_id or "")
        was = [a.id for a in task.actions] if task is not None else None
        if not hierarchy.move_before_sibling(self.app_data, action_id, before_id):
            return
        if task is not None and [a.id for a in task.actions] == was:
            return
        self.save()
        self.main_panel.rebuild_open_accordion()
        if task is not None:
            self.main_panel.refresh_task_icon(task.id)   # 先頭が入れ替われば行アイコンも

    def add_work_in_new_group(self) -> None:
        """新しい業務グループを作り、そこへ業務を1つ追加（空グループは作らない）。

        名前入力ポップアップは出さず既定名で作る（作業を止めない。2026-09-02）。
        改名はデザインラボのカードでその場でできる。
        """
        wg = hierarchy.add_work_group(self.app_data, "")
        w = hierarchy.add_work(self.app_data, wg.id, _DEFAULT_WORK_NAME)
        self._seed_default_task(w)
        self.save()
        self._refresh(select_work=w.id if w else None)   # 作った業務を選択

    def add_task_in_new_group(self, work_id: str) -> None:
        """新しいタスクグループを作り、そこへタスクを1つ追加（既定名・ポップアップ無し）。"""
        tg = hierarchy.add_task_group(self.app_data, work_id, "")
        if tg is None:
            return
        t = hierarchy.add_task(self.app_data, tg.id, _DEFAULT_TASK_NAME)
        self.save()
        self._refresh()
        if t is not None:
            self.main_panel.reselect_task(t.id)   # 作ったタスクを選択
            self._recompute_sel()
            self._ping_design_lab_edit()

    def _set_mode(self, target: str) -> None:
        """通常 ⇄ 設定 を目標値で切り替える（冪等）。

        モードの切替口はデザインラボ最上部の「設定モード」スイッチだけ
        （§16bis。旧サイドバー・フッターの切替行は撤去）。
        """
        if target not in ("normal", "settings") or target == self.mode:
            return
        self.mode = target
        settings = self.mode == "settings"
        self.title_bar.set_settings_mode(settings)
        self.mode_label.config(
            text="設定モード" if settings else "",
            fg=str(theme.PALETTE["settings_ink" if settings else "ink"]),
        )
        # 窓全体が設定モードだと分かるよう、縁取り・ペイン地色を暖色に（幅は変えない）
        border = str(theme.PALETTE["settings_border" if settings else "window_border"])
        self.configure(bg=border)
        self._frame.configure(bg=border)
        self.sidebar.set_background(settings)
        self.main_panel.set_background(settings)
        self.update_idletasks()      # 地色の切替を両ペイン同時に見せてから中身を作り直す
        self._refresh()
        self._ping_design_lab_edit()
        if self.design_lab_open():
            self._design_lab.sync_mode_switch()

    def _toggle_mode(self) -> None:
        """通常 ⇄ 設定 のトグル（テスト・内部用の薄いショートカット）。"""
        self._set_mode("normal" if self.mode == "settings" else "settings")

    def set_edit_mode(self, on: bool) -> None:
        """デザインラボの「設定モード」スイッチから呼ばれる（状態は保存しない＝開くたびに OFF）。"""
        self._set_mode("settings" if on else "normal")

    # --- 階層 CRUD（コントローラ） ------------------------------- #
    # 追加時は名前入力ポップアップを出さず既定名で作る（作業を止めない。2026-09-02）。
    def save(self) -> None:
        """階層＋設定を workdesk.json へ書き出す（原子的）。
        設定パネルなど**外部からも呼ぶ**ので public（Tk に触れないので破棄後でも安全）。"""
        persistence.save(self.save_path, self.app_data)

    def add_work(self, group_id: str) -> None:
        w = hierarchy.add_work(self.app_data, group_id, _DEFAULT_WORK_NAME)
        self._seed_default_task(w)
        self.save()
        self._refresh(select_work=w.id if w else None)   # 作った業務を選択

    # --- 右クリック「グループを分ける」 -------------------------- #
    def _show_group_menu(self, entity_id: str, x_root: int, y_root: int) -> None:
        """業務／タスク行の右クリックで小さいメニューを出す（今は「グループを分ける」だけ）。"""
        if self._busy:
            return   # タスク実行中は構成を触らせない
        menu = tk.Menu(self, tearoff=0)
        menu.add_command(
            label="グループを分ける",
            command=lambda: self.split_group(entity_id),
        )
        try:
            menu.tk_popup(x_root, y_root)
        finally:
            menu.grab_release()

    def split_group(self, entity_id: str) -> None:
        """`entity_id` とそれ以降の同グループ内の兄弟を、直後の新グループへ分ける。
        全体の並び順は保持。業務なら**分かれた側だけ**色が変わる（他グループの色は据え置き）。"""
        if self._busy:
            return
        work = hierarchy.find_work(self.app_data, entity_id)
        gi_before = (
            hierarchy.work_group_of_work(self.app_data, entity_id)[0]
            if work is not None else None
        )
        if not hierarchy.split_group_before(self.app_data, entity_id):
            return
        if gi_before is not None:
            self._pin_group_colors_after_split(gi_before)
        self.save()
        self._refresh()   # サイドバー（色）とメインパネル（区切り線）の両方に効く

    def _pin_group_colors_after_split(self, gi: int) -> None:
        """業務グループ `gi` の直後に新グループが1つ挿入された。以降のグループ色が
        位置ずれしないよう、全グループの色を明示上書きに固定し、新グループ位置へ色を1つ挿入する。"""
        n_before = len(self.app_data.work_groups) - 1   # 挿入前のグループ数
        ov = list(theme.STATE.get("group_colors") or [])
        base = [str(c) for c in theme.PALETTE["group_colors"]]
        raws = [
            (ov[k] if k < len(ov) and ov[k] else base[k % len(base)])
            for k in range(n_before)
        ]
        avoid = {raws[gi]} if gi < len(raws) else set()
        if gi + 1 < len(raws):
            avoid.add(raws[gi + 1])
        new_c = next((c for c in base if c not in avoid), base[(gi + 1) % len(base)])
        raws.insert(gi + 1, new_c)
        theme.set_group_colors(raws)

    def _seed_default_task(self, work) -> None:
        """新規業務に、動作の無い空タスクを1つ用意する（他にタスクを作る導線が無いため。2026-09-02）。"""
        if work is None:
            return
        tg = hierarchy.add_task_group(self.app_data, work.id, "")
        if tg is not None:
            hierarchy.add_task(self.app_data, tg.id, _DEFAULT_TASK_NAME)

    def add_task(self, task_group_id: str) -> None:
        t = hierarchy.add_task(self.app_data, task_group_id, _DEFAULT_TASK_NAME)
        self.save()
        self._refresh()
        if t is not None:
            self.main_panel.reselect_task(t.id)   # 作ったタスクを選択
            self._recompute_sel()
            self._ping_design_lab_edit()

    def delete_entity(self, entity_id: str, label: str) -> None:
        ok = messagebox.askyesno(
            "削除の確認",
            f"「{label}」を削除しますか？\n（中の要素もすべて削除されます）",
            parent=self,
        )
        if not ok:
            return
        # 動作を削除する場合は、削除後に選ぶ「隣の動作」を先に決めておく
        # （次の動作／無ければ前の動作。全部消えたら親タスクを選ぶ）。
        ptask = hierarchy.parent_task_of_action(self.app_data, entity_id)
        next_action = None
        if ptask is not None:
            ids = [a.id for a in ptask.actions]
            i = ids.index(entity_id)
            rest = ids[:i] + ids[i + 1:]
            if rest:
                next_action = rest[i] if i < len(rest) else rest[-1]

        secrets_before = self._referenced_secret_ids()
        hierarchy.delete(self.app_data, entity_id)
        self.save()
        self._purge_orphan_secrets(secrets_before)
        self._refresh()

        if ptask is not None:
            if next_action is not None:
                self.main_panel.select_action(ptask.id, next_action)
            else:
                self.main_panel.reselect_task(ptask.id)   # 動作が全部消えた→親タスクを選択
            self._recompute_sel()
            self._ping_design_lab_edit()

    def _referenced_secret_ids(self) -> set[str]:
        """いま階層内の暗号化コピー動作が指している `secret_id` の集合。"""
        out: set[str] = set()
        for wg in self.app_data.work_groups:
            for w in wg.works:
                for tg in w.task_groups:
                    for t in tg.tasks:
                        for a in t.actions:
                            if a.action_id == "copy" and a.args.get("encrypt"):
                                sid = a.args.get("secret_id")
                                if sid:
                                    out.add(sid)
        return out

    def _purge_orphan_secrets(self, before: set[str]) -> None:
        """削除で参照されなくなった暗号文を `secrets.json` から消す
        （動作／タスク／業務を消したらその秘密文字列も速やかに消す。2026-09-01）。"""
        for sid in before - self._referenced_secret_ids():
            try:
                self.crypto.remove_secret(sid)
            except Exception:  # noqa: BLE001
                pass

    # --- 動作の追加・編集 --------------------------------------- #
    def add_action(self, task_id: str) -> None:
        res = add_action_dialog(self)
        if res is None:
            return
        action_id, args = res
        act = hierarchy.add_action(self.app_data, task_id, action_id, args)
        self.save()
        self._refresh()
        if act is not None:
            self.main_panel.select_action(task_id, act.id)   # 作った動作を選択
            self._recompute_sel()
            self._ping_design_lab_edit()

    def apply_action_edit(self, action_id: str, res: tuple[str, dict]) -> None:
        """デザインラボの動作カード内インラインフォームの「適用」から（§16bis まとまり B 追補）。
        全再描画はせず、アコーディオンとカードだけ更新（フォームは開いたまま）。"""
        act = hierarchy.find_action(self.app_data, action_id)
        if act is None:
            return
        act.action_id, act.args = res
        self.save()
        self.main_panel.rebuild_open_accordion()
        ptask = hierarchy.parent_task_of_action(self.app_data, action_id)
        if ptask is not None:
            self.main_panel.refresh_task_icon(ptask.id)   # 先頭動作なら行アイコンも即追従
        self._ping_design_lab_edit()

    def _on_mousewheel(self, event: tk.Event) -> None:
        for widget in ancestors(event.widget):
            if isinstance(widget, ScrollableFrame):
                widget.scroll_by_wheel(event.delta)
                return

    # --- タスク実行（継ぎ目の呼び出し） --------------------------- #
    def _on_task_click(self, task_id: str) -> None:
        row = self.main_panel.row(task_id)
        # デザインラボはドック扱い（常設）。開いていてもタスク実行は妨げない。
        if self._busy:
            # ワンタイムの Ctrl+V 待ち中に他タスク押下 → シーケンス中止（§9）
            if self.onetime.is_waiting:
                self.onetime.cancel()
            elif row is not None:
                row.set_sub("実行中です")
            return

        self._busy = True
        self._run_started_at = time.monotonic()
        self._running_task_id = task_id
        self._run_lines = []
        self._run_gen[task_id] = self._run_gen.get(task_id, 0) + 1
        if row is not None:
            row.paint(str(theme.PALETTE["row_running"]))
            row.hide_badge()
            row.set_sub("")
        self.status_label.config(text="実行中…")
        self.dispatcher.dispatch(Command(task_id), self._emit)

    def _running_task_rect(self) -> tuple[int, int, int, int] | None:
        """実行中タスク行の画面上の矩形 (x, y, w, h)。メンション先ポップアップの中央合わせ用。
        取れない（headless / 行が無い / 未マップ）なら None＝呼び出し側は既定位置へ。"""
        rid = self._running_task_id
        mp = getattr(self, "main_panel", None)
        row = mp.row(rid) if (mp is not None and rid) else None
        if row is None:
            return None
        try:
            f = row.frame
            if not f.winfo_ismapped():
                return None
            return (f.winfo_rootx(), f.winfo_rooty(), f.winfo_width(), f.winfo_height())
        except tk.TclError:
            return None

    def _emit(self, event: Event) -> None:
        """ワーカースレッドから呼ばれる。queue 経由で UI スレッドへ。"""
        self._event_q.put(event)

    def run_on_ui(self, fn) -> None:
        """他スレッドから UI スレッドで fn を実行させる。"""
        self._ui_q.put(fn)

    def _drain_events(self) -> None:
        if not self._alive:
            return
        try:
            while True:
                self._ui_q.get_nowait()()
        except queue.Empty:
            pass
        try:
            while True:
                self._handle_event(self._event_q.get_nowait())
        except queue.Empty:
            pass
        self._schedule(50, self._drain_events)

    def destroy(self) -> None:  # noqa: D401
        self._alive = False
        theme.unsubscribe(self._on_theme_change)
        theme.set_save_hook(None)
        # 未書き込みのデバウンス保存を取りこぼさずに確定
        self._geom_debounce.cancel()
        for d in (self._rename_debounce, self._appearance_debounce):
            try:
                d.flush()
            except Exception:  # noqa: BLE001
                pass
        if self._persist_window:
            try:
                self._win_cfg["main"] = self.geometry()
                self.save()
            except Exception:  # noqa: BLE001
                pass
        try:
            self.onetime.shutdown()
        except Exception:  # noqa: BLE001
            pass
        try:
            self.mention_dir.shutdown()   # 宛先選択で待っている worker を解放
        except Exception:  # noqa: BLE001
            pass
        for ident in list(self._after_ids):
            try:
                self.after_cancel(ident)
            except Exception:  # noqa: BLE001
                pass
        self._after_ids.clear()
        super().destroy()

    def _handle_event(self, event: Event) -> None:
        row = self.main_panel.row(event.task_id)
        if event.kind == "task_started":
            if row is not None:
                row.hide_badge()
                row.set_sub("")
        elif event.kind == "action_done":
            if event.message:
                self._run_lines.append(f"{event.feature_name}: {event.message}")
            elif event.status == "FAILED":
                self._run_lines.append(f"{event.feature_name}: 失敗")
            if row is not None and self._run_lines:
                row.set_sub("\n".join(self._run_lines), tone="run")
        elif event.kind == "task_finished":
            self._finish(event, row)

    def _finish(self, event: Event, row) -> None:
        ok = event.outcome == "all_ok"
        color = str(theme.PALETTE["row_ok" if ok else "row_fail"])
        summary = _OUTCOME_TEXT.get(event.outcome, event.outcome)
        if row is not None:
            row.paint(color)
            if ok:
                row.show_badge(summary)                       # 「成功しました」は緑バッジ
                row.set_sub("\n".join(self._run_lines), tone="ok")
            else:
                row.hide_badge()
                row.set_sub("\n".join([summary, *self._run_lines]), tone="fail")
        self.status_label.config(text="")

        gen = self._run_gen.get(event.task_id)
        hold_ms = int(float(self.settings.get("layer2_hold_seconds", 3.0)) * 1000)
        self._schedule(hold_ms, lambda: self._revert(event.task_id, gen))

        # 連打ロック解除: max(min_lock_seconds, 完了まで)
        elapsed = time.monotonic() - self._run_started_at
        min_lock = float(self.settings.get("min_lock_seconds", 1.0))
        remaining_ms = max(0, int((min_lock - elapsed) * 1000))
        self._schedule(remaining_ms, self._unlock)

    def _revert(self, task_id: str, gen: int | None) -> None:
        if not self._alive or self._run_gen.get(task_id) != gen:
            return  # 破棄済み or その後に再実行された
        row = self.main_panel.row(task_id)
        if row is not None:
            row.paint_resting()   # 溶け込み地色（or 選択/ホバー）へ戻す
            row.hide_badge()
            row.set_sub("")

    def _unlock(self) -> None:
        if self._alive:
            self._busy = False
