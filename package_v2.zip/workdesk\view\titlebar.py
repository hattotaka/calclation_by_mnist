"""自作タイトル帯（§16 ステージ3）。

メイン窓は OS のタイトルバー（`WS_CAPTION`）だけを ctypes で外し、この帯で
アプリ名／モード表示／状況表示／最小化（－）／閉じる（✕）を担う。帯のドラッグで移動。
枠・タスクバー・スナップ・角丸はネイティブのまま残す（App 側 `_strip_titlebar`）。
（共通設定・デザインラボは対象外。OS の × を残す。）

App からは `title_bar.mode_label` / `title_bar.status_label` を従来どおり更新する。
設定モードでは `set_settings_mode(True)` で帯を暖色に。
"""

from __future__ import annotations

import tkinter as tk
from collections.abc import Callable

from . import theme

_BTN_FONT = ("Yu Gothic UI", 11)


class TitleBar(tk.Frame):
    def __init__(
        self,
        parent: tk.Misc,
        app: tk.Misc,
        *,
        on_minimize: Callable[[], None],
        on_close: Callable[[], None],
    ) -> None:
        bg = str(theme.PALETTE["titlebar_bg"])
        super().__init__(parent, bg=bg)
        self.app = app
        self._bg = bg
        self._settings = False

        self._name = tk.Label(
            self, text="WorkDesk Launcher", bg=bg, fg=str(theme.PALETTE["ink"]),
            font=theme.font("mode"), padx=10, pady=5,
        )
        self._name.pack(side="left")

        # 右端は 閉じる → 最小化 の順（side="right" は右から積まれる）
        close = self._btn(
            "✕", on_close, hover_bg=str(theme.PALETTE["close_hover"]),
            hover_fg=str(theme.PALETTE["on_accent"]),
        )
        close.pack(side="right")
        mini = self._btn(
            "－", on_minimize, hover_bg=str(theme.PALETTE["min_hover"]),
            hover_fg=str(theme.PALETTE["ink"]),
        )
        mini.pack(side="right")
        self._btns = (close, mini)

        # 通常モードでは何も出さない（帯をすっきり）。設定モードのときだけ「設定モード」。
        self.mode_label = tk.Label(
            self, text="", bg=bg, fg=str(theme.PALETTE["ink"]),
            font=theme.font("mode"),
        )
        self.mode_label.pack(side="left", padx=(12, 0))
        self.status_label = tk.Label(
            self, text="", bg=bg, fg=str(theme.PALETTE["sub"]), font=theme.font("body")
        )
        self.status_label.pack(side="right", padx=12)

        self._press = (0, 0)                        # 押下時のポインタ（しきい値判定用）
        self._off: tuple[int, int] | None = None    # 押下時の窓内オフセット
        self._dragging = False
        # OS の移動ループ（WM_NCLBUTTONDOWN）はキーボードフックのメッセージポンプと
        # 競合して落ちるため使えない。raw SetWindowPos で手動移動する。
        # 静止クリック／ダブルクリック（＝最背面）を潰さないよう 4px 動いてから発動。
        for w in (self, self._name, self.mode_label, self.status_label):
            w.bind("<Button-1>", self._move_press)
            w.bind("<B1-Motion>", self._move_motion)
            w.bind("<ButtonRelease-1>", self._move_release)

    # --- 設定モードの識別 ------------------------------------- #
    def set_settings_mode(self, on: bool) -> None:
        self._settings = on
        bg = str(
            theme.PALETTE["settings_titlebar_bg"] if on else theme.PALETTE["titlebar_bg"]
        )
        self._bg = bg
        self.configure(bg=bg)
        for w in (self._name, self.mode_label, self.status_label, *self._btns):
            w.configure(bg=bg)

    def refresh_theme(self) -> None:
        """テーマ切替（§17.7 ステージ2）。帯の地色＋文字色をトークンから読み直す。"""
        self.set_settings_mode(self._settings)   # bg 一式
        ink = str(theme.PALETTE["ink"])
        self._name.configure(fg=ink)
        self.status_label.configure(fg=str(theme.PALETTE["sub"]))
        for b in self._btns:
            b.configure(fg=ink)
        # mode_label の fg は App._set_mode / _rebuild_for_theme がモードに応じて設定する

    # --- ボタン --------------------------------------------- #
    def _btn(self, text: str, cmd, *, hover_bg: str, hover_fg: str) -> tk.Label:
        b = tk.Label(
            self, text=text, bg=self._bg, fg=str(theme.PALETTE["ink"]),
            font=_BTN_FONT, padx=14, pady=5,   # ポインタは変えない（矢印のまま）
        )
        b.bind("<Button-1>", lambda _e: cmd())
        b.bind("<Enter>", lambda _e: b.configure(bg=hover_bg, fg=hover_fg))
        # 復帰色はテーマ切替に追随できるよう都度読む
        b.bind("<Leave>", lambda _e: b.configure(bg=self._bg, fg=str(theme.PALETTE["ink"])))
        return b

    # --- 帯ドラッグで窓移動（手動・raw SetWindowPos） ------------- #
    def _move_press(self, e: tk.Event) -> None:
        # break しない＝ダブルクリック（最背面）は素通し
        self._press = (e.x_root, e.y_root)
        self._off = (e.x_root - self.app.winfo_rootx(), e.y_root - self.app.winfo_rooty())
        self._dragging = False

    def _move_motion(self, e: tk.Event) -> None:
        if self._off is None:
            return
        if not self._dragging:
            if abs(e.x_root - self._press[0]) + abs(e.y_root - self._press[1]) <= 4:
                return
            self._dragging = True
            self.app.begin_window_drag()   # ドラッグ中は位置の自動保存を止める
        self.app.drag_window_to(e.x_root - self._off[0], e.y_root - self._off[1])

    def _move_release(self, _e: tk.Event) -> None:
        off, was_drag = self._off, self._dragging
        self._off = None
        self._dragging = False
        if off is not None and was_drag:
            # 間引きで取りこぼした最終位置を確定 → 位置保存を再開して一度だけ保存
            self.app.end_window_drag(
                self.winfo_pointerx() - off[0], self.winfo_pointery() - off[1]
            )
