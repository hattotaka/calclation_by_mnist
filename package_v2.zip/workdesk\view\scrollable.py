"""スクロール可能なフレーム。

サイドバー・メインパネルの共通部品（§15「スクロールする自作行リスト」）。
`body` に中身を積む。縦スクロールのみ。マウスホイールは App 側で
`winfo_containing` により対象を判定して回す（§ App._on_mousewheel）。

スクロールバーの可視制御（§15 デザイン詰め）は `set_scrollbar_mode()`:
- ``always`` … 常時表示（従来）
- ``auto``   … 中身がビューポートに収まる間は隠す
- ``thin``   … 常時表示・細身
- ``hover``  … パネルにマウスが乗っていて、かつ溢れている間だけ表示
"""

from __future__ import annotations

import tkinter as tk

from . import theme
from .uikit import pointer_within

_NORMAL_WIDTH = 16
_THIN_WIDTH = 9


class ScrollableFrame(tk.Frame):
    def __init__(self, parent: tk.Misc, **kw) -> None:
        super().__init__(parent, **kw)

        self._mode = "always"
        self._hovering = False

        self.canvas = tk.Canvas(
            self, highlightthickness=0,
            bg=kw.get("bg", str(theme.PALETTE["row_normal"])),
        )
        self.vbar = tk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self._on_yscroll)

        self.canvas.pack(side="left", fill="both", expand=True)
        self.vbar.pack(side="right", fill="y", before=self.canvas)

        self.body = tk.Frame(self.canvas, bg=self.canvas["bg"])
        self._window = self.canvas.create_window((0, 0), window=self.body, anchor="nw")
        self._staging: tk.Frame | None = None

        self.body.bind("<Configure>", self._sync_scrollregion)
        self.canvas.bind("<Configure>", self._sync_body_width)
        # ホバー判定は枠全体で。バー上へマウスを移すと外れる問題を避けるため、
        # Leave は少し待ってからポインタ実位置で「本当に外か」を確かめる。
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)

    # --- 内部 --------------------------------------------------------- #
    def _sync_scrollregion(self, _event: tk.Event | None = None) -> None:
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _sync_body_width(self, event: tk.Event) -> None:
        # 中身フレームの幅をキャンバス幅に合わせる（行が横いっぱいに広がる）
        self.canvas.itemconfigure(self._window, width=event.width)

    def _on_yscroll(self, lo: str, hi: str) -> None:
        self.vbar.set(lo, hi)
        self._refresh_visibility(float(lo), float(hi))

    def _on_enter(self, _event: tk.Event) -> None:
        self._hovering = True
        if self._mode == "hover":
            self._refresh_visibility()

    def _on_leave(self, _event: tk.Event) -> None:
        # 子ウィジェット境界をまたいだだけの Leave を無視する
        self.after(60, self._verify_hover)

    def _verify_hover(self) -> None:
        self._hovering = pointer_within(self)
        if self._mode == "hover":
            self._refresh_visibility()

    def _refresh_visibility(self, lo: float | None = None, hi: float | None = None) -> None:
        if lo is None or hi is None:
            lo, hi = self.canvas.yview()
        fits = lo <= 0.0 and hi >= 1.0

        if self._mode in ("always", "thin"):
            show = True
        elif self._mode == "auto":
            show = not fits
        elif self._mode == "hover":
            show = self._hovering and not fits
        else:
            show = True

        mapped = bool(self.vbar.winfo_ismapped())
        if show and not mapped:
            self.vbar.pack(side="right", fill="y", before=self.canvas)
        elif not show and mapped:
            self.vbar.pack_forget()

    # --- API -------------------------------------------------------- #
    def set_bg(self, color: str) -> None:
        """地色を差し替える（設定モードのペイン着色など）。以後の
        `begin_rebuild()` も `canvas["bg"]` を引くので新しい body に反映される。"""
        self.configure(bg=color)
        self.canvas.configure(bg=color)
        self.body.configure(bg=color)

    def set_scrollbar_mode(self, mode: str) -> None:
        self._mode = mode
        self.vbar.configure(width=_THIN_WIDTH if mode == "thin" else _NORMAL_WIDTH)
        self._refresh_visibility()

    # --- アトミックな作り直し（チラつき／空白防止） ----------------- #
    def begin_rebuild(self) -> tk.Frame:
        """新しい body を作って返す。中身を積んだあと `commit_rebuild()` で差し替える。

        旧 body は差し替えの瞬間まで表示されたままなので、`clear()` → 再構築で出る
        「一瞬空白になる」感じを避けられる。
        """
        if self._staging is not None:
            self._staging.destroy()
        self._staging = tk.Frame(self.canvas, bg=self.canvas["bg"])
        return self._staging

    def commit_rebuild(self) -> None:
        if self._staging is None:
            return
        # 差し替え前にレイアウトを確定させておく（swap 直後の一瞬の空白/チラつき対策）
        self._staging.update_idletasks()
        old, self.body, self._staging = self.body, self._staging, None
        self.canvas.itemconfigure(self._window, window=self.body)
        self.canvas.itemconfigure(self._window, width=self.canvas.winfo_width())
        self.body.bind("<Configure>", self._sync_scrollregion)
        self.canvas.yview_moveto(0.0)
        old.destroy()
        self._sync_scrollregion()

    def scroll_by_wheel(self, delta: int) -> None:
        lo, hi = self.canvas.yview()
        if lo <= 0.0 and hi >= 1.0:
            return  # 中身がビューポートに収まっている：スクロールしない
        #        （収まっているのに yview_scroll すると上方向へ空白を送ってしまう Tk canvas の癖）
        self.canvas.yview_scroll(int(-delta / 120), "units")
