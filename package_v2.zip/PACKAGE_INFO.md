# WorkDeskLauncher 配布用パッケージ

このフォルダは **これ単体で完結**しています。丸ごと zip にして渡せます。

## 中身

```
package/
  main.py                    エントリポイント（python main.py で起動）
  requirements.txt           実行時の依存（cryptography, Pillow）
  README.md                  使い方（機能・画面・データファイルの説明）
  data/
    workdesk.sample.json     初期表示用のサンプル階層（上書きされない）
  workdesk/                  アプリ本体（Python パッケージ）
  build/
    build.bat                exe ビルド（onedir / 推奨）
    build_onefile.bat        exe ビルド（単一 exe）
    WorkDeskLauncher.spec            PyInstaller 設定（onedir）
    WorkDeskLauncher-onefile.spec    PyInstaller 設定（onefile）
    requirements-build.txt   ビルド時の依存（上記＋pyinstaller）
    ビルド手順.md            exe 化の手順書
```

## そのまま動かす

```
pip install -r requirements.txt
python main.py
```

- 起動フォルダに `workdesk.json` があればそれを、無ければ
  `data/workdesk.sample.json` を読み込む。
- 設定モードで編集すると起動フォルダに `workdesk.json` が作られる
  （同梱サンプルは上書きしない）。

## exe にする

`build/ビルド手順.md` を参照。要点だけ:

- ビルドの出力は **すべて `%TEMP%\wdl-build\` の下**（`package/` や OneDrive を汚さない）。
- 推奨は `build/build.bat`（onedir）。exe 一式 ＋ **配布用 `WorkDeskLauncher-onedir.zip`** ができる。
- 単一 exe は `build/build_onefile.bat` → exe ＋ `WorkDeskLauncher-onefile.zip`。
  ただし AV のヒューリスティック検知に注意（onedir 推奨の理由）。
- 各バッチは自分のモードの出力を毎回まるごと消してから再ビルド（残骸なし）。
- どちらも UPX 圧縮は無効／`numpy` は除外（誤検知・サイズ対策）。
- 配布は **zip を共有に置き、配布先でローカルへコピー→展開**（zip 1 個なので転送が速い）。

## このパッケージに含まれないもの（意図的な除外）

| 除外したもの | 理由 |
|---|---|
| `workdesk.json` | 開発端末の個人的な業務データ。サンプルのみ同梱 |
| `secrets.json` | 暗号化された秘密情報（個人）。配布しない |
| `templates/` の実データ | 開発端末で作った個人テンプレート |
| `tests/` | 実行にも exe 化にも不要（開発用） |
| `docs/`, `CLAUDE.md` | 内部の設計メモ・作業ルール |
| `__pycache__/`, `*.pyc` | ビルド生成物 |

## 動作確認済み

- Python 3.11 / Windows 11 で `python main.py` 起動、全 11 テスト緑
  （テストは本パッケージには非同梱）。
- `build/build.bat`（onedir・約 46MB）／`build/build_onefile.bat`
  （単一 exe・約 21MB）とも生成・起動を確認（PyInstaller 6.22）。
  設定ファイルは exe と同じフォルダに作られる。
