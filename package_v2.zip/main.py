"""WorkDeskLauncher エントリポイント。

- 実行フォルダ（exe と同じフォルダ / 通常実行はカレント）に ``workdesk.json``
  があればそれを、無ければ**同梱**の ``data/workdesk.sample.json`` を読み込む。
- PyInstaller で凍結した場合、同梱シードは展開先（``sys._MEIPASS``）に置かれる。
"""

from __future__ import annotations

import sys
from pathlib import Path

from workdesk import persistence
from workdesk.view.app import App


def bundle_dir() -> Path:
    """同梱リソース（data/ など）の基準フォルダ。

    PyInstaller は onefile なら一時展開先、onedir なら ``_internal`` を
    ``sys._MEIPASS`` に入れる。通常実行時はこのスクリプトの隣。
    """
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        return Path(meipass)
    return Path(__file__).resolve().parent


def resolve_data_path() -> Path:
    real = persistence.default_path()
    if real.exists():
        return real
    return bundle_dir() / "data" / "workdesk.sample.json"


def main() -> None:
    App(resolve_data_path()).mainloop()


if __name__ == "__main__":
    main()
