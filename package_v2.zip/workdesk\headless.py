"""GUI なしで Command→Event を回すドライバ（§15 補助）。

dispatcher と各機能を画面から切り離して開発・回帰テストするための土台。
`onetime=True` にすると OneTimeService をポップアップ無し（master=None）で組み込む。
"""

from __future__ import annotations

import threading

from .context import Context
from .dispatch import Command, Dispatcher, Event
from .model import AppData
from .services.clipboard import FakeClipboard
from .services.logger import NullLogger
from .services.onetime import OneTimeService
from .settings import SettingsReader


class HeadlessDriver:
    def __init__(
        self, data: AppData, *, onetime: bool = False, wait_ms: int = 0,
        crypto=None, templates=None, mention=None,
    ) -> None:
        self.settings = SettingsReader(data)
        self.clipboard = FakeClipboard()
        self.onetime: OneTimeService | None = None
        if onetime:
            self.onetime = OneTimeService(
                run_on_ui=lambda fn: fn(),      # 即時実行（UI スレッド無し）
                clipboard=self.clipboard,
                wait_ms=lambda: wait_ms,
                master=None,                    # ポップアップを作らない
                use_hook=False,
            )
        self.context = Context(
            settings=self.settings,
            clipboard=self.clipboard,
            log=NullLogger(),
            onetime=self.onetime,
            crypto=crypto,
            templates=templates,
            mention_directory=mention,
        )
        self.dispatcher = Dispatcher(self.context, self.settings)

    def run_task(self, task_id: str, timeout: float = 5.0) -> list[Event]:
        events: list[Event] = []
        done = threading.Event()

        def on_event(ev: Event) -> None:
            events.append(ev)
            if ev.kind == "task_finished":
                done.set()

        self.dispatcher.dispatch(Command(task_id), on_event)
        if not done.wait(timeout):
            raise TimeoutError(f"task {task_id} did not finish within {timeout}s")
        return events
