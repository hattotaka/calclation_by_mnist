"""本体（App）に紐づくモードレス補助窓の共通土台（§16 ステージ2）。

「設定」（`commonsettings`）と「デザインラボ」（`designlab`）は、
- `tk.Toplevel` サブクラス・`transient`・リサイズ不可
- 窓内に「閉じる」を持たない（OS の × ＋ サイドバー・フッター行のトグルで開閉）
- 位置を `settings["window"][pos_key]` にデバウンス保存し、起動時に復元
という骨格が共通。その部分だけをここに置く（中身の構築はサブクラス）。
"""

from __future__ import annotations

import tkinter as tk

from . import theme
from .uikit import Debouncer


class DockPanel(tk.Toplevel):
    pos_key: str = ""            # settings["window"] のキー（サブクラスで指定）
    _POS_DEBOUNCE_MS = 700

    def __init__(self, app) -> None:
        super().__init__(app)
        self.app = app
        self._bg = str(theme.PALETTE["row_normal"])
        self._pos_debounce = Debouncer(self)
        self.configure(bg=self._bg)
        self.resizable(False, False)
        self.transient(app)

    def install_position_persistence(self, *, extra_down: int = 0) -> None:
        """中身を組んだあとに呼ぶ。前回位置を復元、無ければ本体の右隣に置き、
        以後は移動をデバウンスで保存する（`<Destroy>` で予約をキャンセル）。"""
        self.update_idletasks()
        saved = self.app.load_win_pos(self.pos_key)
        if saved:
            self.geometry(saved)
        else:
            x = self.app.winfo_rootx() + self.app.winfo_width() + 8
            self.geometry(f"+{x}+{self.app.winfo_rooty() + extra_down}")
        self.bind("<Configure>", self._on_configure_pos, add="+")
        self.bind("<Destroy>", self._on_destroy_pos, add="+")

    def _on_configure_pos(self, e: tk.Event) -> None:
        if e.widget is self:
            self._pos_debounce.schedule(self._POS_DEBOUNCE_MS, self._save_pos)

    def _save_pos(self) -> None:
        if self.winfo_exists():
            self.app.save_win_pos(self.pos_key, self.winfo_x(), self.winfo_y())

    def _on_destroy_pos(self, e: tk.Event) -> None:
        if e.widget is self:
            self._pos_debounce.cancel()
