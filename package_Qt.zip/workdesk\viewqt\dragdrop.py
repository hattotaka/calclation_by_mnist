"""行のどこでもドラッグで並べ替え（設定モード限定）。Tk 版 `view/dragdrop.py` の Qt 版。

サイドバー（業務）とメインパネル（タスク）が共有する。動作の並べ替えは
`QListWidget` の `InternalMove` で済んでいるのでここは使わない ── あちらは
「1 本のリスト」だが、こちらは**グループに分かれた行の並び**（業務グループ /
タスクグループ）なので `QListWidget` に載らない。

`QDrag` を使わない理由: Qt は押した瞬間にマウスを暗黙グラブするので、
**押した行がそのまま move / release を受け取る**。ドロップ先はこちらで
「登録済みの行の矩形」から引けるため、`QMimeData` を作る必要が無い。
外部とデータをやり取りしないドラッグに `QDrag` を持ち出しても得が無い。

使い方（ペイン側）:

    self._drag = RowReorder(self._scroll, on_drop=self._drop)
    ...render の中で...
    self._drag.reset()
    self._drag.add_row(row_widget, item_id, group_id)   # 表示順に

`on_drop(item_id, before_id, group_id)`:
  `before_id` が None なら**そのグループの末尾**。`group_id` も None なら
  **新しいグループ**（`allow_new_container=True` のときだけ。Tk 版 `allow_new_container`
  の移植。2026-09-05 に「操作の一貫性」を理由に復活 ── 右クリックの
  「新しいグループに作る」と同じことをドラッグでもできるようにする）。
  呼び出し側（App）は `uicore.reorder_*` に渡し、順序が変わったときだけ保存・再描画する。

**新しいグループのゾーンは最終行の下、さらに `NEW_ZONE_PX` だけ余分に離れたところ**
（Tk 版の `_NEW_ZONE` と同じ考え方）。末尾グループへの追加（境界のすぐ下）と
新しいグループ（もっと下）を分けるための遊びで、当たり判定を広げすぎない。
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, QObject, Qt
from PySide6.QtWidgets import QApplication, QLabel, QVBoxLayout, QWidget

from .. import theme_tokens as T

DRAG_START_PX = 6          # これだけ動いたらドラッグ開始（クリックと区別する）
INDICATOR_H = 2
NEW_ZONE_PX = 28           # 最終行の下、このぶん余分に離れたら「新しいグループ」


class RowReorder(QObject):
    """行にイベントフィルタを掛け、押して動かしたら並べ替えにするヘルパ。"""

    def __init__(self, scroll, on_drop, parent: QWidget | None = None,
                 *, allow_new_container: bool = False) -> None:
        super().__init__(parent)
        self._scroll = scroll
        self._on_drop = on_drop
        self._allow_new = allow_new_container
        self._enabled = False
        self._rows: list[tuple[str, str, QWidget]] = []   # (item_id, group_id, widget)
        self._press_pos = None
        self._press_id: str | None = None
        self._dragging = False
        self._indicator: QWidget | None = None
        self._newbox: QWidget | None = None

    # --- ペインから呼ぶ ---------------------------------------------- #
    def set_enabled(self, on: bool) -> None:
        """設定モードのときだけ True。通常モードではクリック＝実行なので掛けない。"""
        self._enabled = bool(on)
        if not on:
            self._cancel()

    @property
    def enabled(self) -> bool:
        return self._enabled

    def reset(self) -> None:
        """`render()` の先頭で呼ぶ（行を作り直すので登録も作り直す）。"""
        self._cancel()
        self._rows = []

    def add_row(self, widget: QWidget, item_id: str, group_id: str) -> None:
        widget.installEventFilter(self)
        self._rows.append((item_id, group_id, widget))

    def is_dragging(self) -> bool:
        return self._dragging

    # --- イベント ----------------------------------------------------- #
    def eventFilter(self, obj, event) -> bool:   # noqa: N802
        if not self._enabled:
            return False
        kind = event.type()
        if kind == QEvent.MouseButtonPress and event.button() == Qt.LeftButton:
            self._press_pos = event.globalPosition().toPoint()
            self._press_id = self._id_of(obj)
            return False                        # 選択（クリック）は通す
        if kind == QEvent.MouseMove and self._press_id is not None:
            return self._on_move(event)
        if kind == QEvent.MouseButtonRelease and self._press_id is not None:
            return self._on_release(event)
        return False

    def _on_move(self, event) -> bool:
        pos = event.globalPosition().toPoint()
        if not self._dragging:
            if (pos - self._press_pos).manhattanLength() < DRAG_START_PX:
                return False
            self._dragging = True
            QApplication.setOverrideCursor(Qt.ClosedHandCursor)
        self._show_indicator(self._target(pos))
        return True

    def _on_release(self, event) -> bool:
        if not self._dragging:
            self._press_id = self._press_pos = None
            return False
        target = self._target(event.globalPosition().toPoint())
        item_id = self._press_id
        self._cancel()
        if target is not None:
            before_id, group_id = target
            if before_id != item_id:
                self._on_drop(item_id, before_id, group_id)
        return True

    # --- 位置の計算 --------------------------------------------------- #
    def _id_of(self, widget) -> str | None:
        for item_id, _gid, w in self._rows:
            if w is widget:
                return item_id
        return None

    def _target(self, global_pos):
        """落とす位置 `(before_id, group_id)`。`before_id=None` はそのグループの末尾。
        `group_id` も None なら**新しいグループ**（`allow_new_container` 時のみ）。

        行の**上半分なら手前へ / 下半分なら後ろへ**。どの行にも当たらなければ、
        いちばん近い行のグループの端に寄せる（一覧の外まで出しても破綻しない）。
        最終行の下、さらに `NEW_ZONE_PX` 離れたら新しいグループのゾーン。
        """
        if not self._rows:
            return None
        y = global_pos.y()
        last_bottom = None
        last_gid = None
        for idx, (item_id, gid, w) in enumerate(self._rows):
            top = w.mapToGlobal(w.rect().topLeft()).y()
            mid = top + w.height() // 2
            bottom = top + w.height()
            if y < mid:
                return (item_id, gid)
            if y < bottom:
                nxt = self._rows[idx + 1] if idx + 1 < len(self._rows) else None
                if nxt is not None and nxt[1] == gid:
                    return (nxt[0], gid)
                return (None, gid)              # そのグループの末尾
            last_bottom, last_gid = bottom, gid
        if self._allow_new and last_bottom is not None and y >= last_bottom + NEW_ZONE_PX:
            return (None, None)                 # 新しいグループ
        return (None, last_gid)                 # 最後の行より下＝末尾グループの末尾

    # --- 目印 ---------------------------------------------------------- #
    def _show_indicator(self, target) -> None:
        if target is None:
            return
        before_id, gid = target
        if gid is None:
            if self._indicator is not None:
                self._indicator.hide()
            self._show_newgroup_box()
            return
        if self._newbox is not None:
            self._newbox.hide()
        vp = self._scroll.viewport()
        if self._indicator is None:
            self._indicator = QWidget(vp)
            self._indicator.setObjectName("dropIndicator")
        self._indicator.setStyleSheet(
            "#dropIndicator{background:%s;border:none;border-radius:1px;}"
            % str(T.PALETTE.get("accent", "#4dd0e1")))
        y = self._edge_y(before_id, gid)
        if y is None:
            return
        self._indicator.setGeometry(2, y - INDICATOR_H // 2,
                                    max(0, vp.width() - 4), INDICATOR_H)
        self._indicator.show()
        self._indicator.raise_()

    def _show_newgroup_box(self) -> None:
        """最終行の下（空白部）に「＋ 新しいグループ」の点線枠を出す（Tk 版から移植）。"""
        if not self._rows:
            return
        vp = self._scroll.viewport()
        accent = str(T.PALETTE.get("accent", "#4dd0e1"))
        if self._newbox is None:
            self._newbox = QWidget(vp)
            self._newbox.setObjectName("dropNewGroup")
            lay = QVBoxLayout(self._newbox)
            lay.setContentsMargins(0, 0, 0, 0)
            label = QLabel("＋ 新しいグループ", self._newbox)
            label.setObjectName("dropNewGroupLabel")
            label.setAlignment(Qt.AlignCenter)
            lay.addWidget(label)
        self._newbox.setStyleSheet(
            "#dropNewGroup{background:transparent;border:2px dashed %s;border-radius:6px;}"
            "#dropNewGroupLabel{background:transparent;border:none;color:%s;}"
            % (accent, accent))
        last_w = self._rows[-1][2]
        bottom = last_w.mapTo(vp, last_w.rect().bottomLeft())
        margin, box_h = 6, 34
        self._newbox.setGeometry(
            margin, bottom.y() + 8, max(40, vp.width() - margin * 2), box_h)
        self._newbox.show()
        self._newbox.raise_()

    def _edge_y(self, before_id, group_id) -> int | None:
        """目印を出す y（ビューポート座標）。"""
        vp = self._scroll.viewport()
        rows = [r for r in self._rows if r[1] == group_id]
        if not rows:
            return None
        if before_id is None:
            w = rows[-1][2]
            pt = w.mapTo(vp, w.rect().bottomLeft())
        else:
            w = next((r[2] for r in rows if r[0] == before_id), rows[0][2])
            pt = w.mapTo(vp, w.rect().topLeft())
        return pt.y()

    def _cancel(self) -> None:
        if self._dragging:
            QApplication.restoreOverrideCursor()
        self._dragging = False
        self._press_id = self._press_pos = None
        if self._indicator is not None:
            self._indicator.hide()
        if self._newbox is not None:
            self._newbox.hide()
