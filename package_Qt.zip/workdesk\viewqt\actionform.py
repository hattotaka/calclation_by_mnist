"""動作（タスクにぶら下がる処理）の入力フォーム。Tk 版 `view/actiondialog.py` の
`ActionForm` を Qt へ移したもの（Phase 4d）。

- 種類コンボ ＋ 種類別の入力欄を組む再利用コンポーネント。
  `collect() -> (action_id, args)`（不正なら `ValueError`）。
- **「適用」ボタンは持たない**。選択が動くとき・窓を閉じるときに呼び出し側が
  `collect()` する（Tk 版と同じ「移動時の自動保存」。入力漏れなら移動をブロックする）。
  そのため `dirty`（ユーザーが1つでも触ったか）を自分で追う ── 未変更なら
  `collect()` すら呼ばない＝暗号化コピーの再暗号化を無駄に走らせない。
- コピーのオプション: ワンタイム / 書式（HTMLテンプレート）/ 暗号化 / Slackメンション。
  **書式・暗号化・メンションは三者排他**（ワンタイムはどれとも併用可）。
- 暗号化 ON: 入力＋確認再入力 → `host.ensure_crypto_ready()` → `host.crypto.encrypt()`。
  args に入るのは `secret_id` だけ（**平文は保存しない**）。登録済みの値は
  **復号して欄に流し込まない**（平文・文字数をランチャーに残さない。2026-09-01）。

**配色は親（編集ウィンドウ）の QSS が当たる**ので、ここでは色を書かない
（hex 直書き禁止に加え、QSS の二重管理も避ける）。
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QPlainTextEdit, QPushButton, QSizePolicy, QVBoxLayout, QWidget,
)

from ..model import new_id
from . import actionmeta, uikit


class ActionForm(QWidget):
    """種類選択＋種類別入力欄。`collect()` で `(action_id, args)`。"""

    kindChanged = Signal()      # 種類コンボが変わった（要約の描き直しに使う）

    def __init__(self, host, action, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        uikit.transparent(self)
        self._host = host
        self._action = action
        self.dirty = False

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(8)

        # 「種類」も種類別の入力欄と**同じ `QFormLayout`** に入れる。別立てにすると
        # 列幅がそれぞれ別に計算され、ラベルの右端が揃わない（2026-09-05 実機で発覚）。
        form_widget = uikit.transparent(QWidget())
        self._form = QFormLayout(form_widget)
        self._form.setContentsMargins(0, 0, 0, 0)
        self._form.setSpacing(8)
        # 右揃えだと項目名の文字数がまちまちで右端しか揃わず、逆に「ズレて」見える
        # （2026-09-05 実機の指摘）。左揃えにして開始位置を統一する。
        self._form.setLabelAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        v.addWidget(form_widget)

        self.type_cb = QComboBox()
        self.type_cb.addItems(actionmeta.LABELS)
        cur = actionmeta.LABEL_BY_ID.get(
            action.action_id if action is not None else "open_file", actionmeta.LABELS[0])
        self.type_cb.setCurrentText(cur)
        self.type_cb.activated.connect(self._on_kind_changed)
        self._add_row("種類", self.type_cb)

        self._v = v
        self._collect = None
        self._extra: QWidget | None = None   # フォームの外＝全幅で出す部品（コピーの文字列欄）
        self._build_body()

    def _add_row(self, label: str, widget: QWidget) -> None:
        """`QFormLayout.addRow` の薄いラッパ。

        自動生成されるラベルは既定だと行の高さいっぱいまで伸びず、フィールドより
        少し上に寄って見える（`labelAlignment` の縦センターだけでは効かなかった。
        2026-09-05 実機の指摘・実測で確認）。ラベルを縦方向に伸縮可能にして、
        行の高さいっぱいの中でテキストが縦センターされるようにする。
        """
        self._form.addRow(label, widget)
        item = self._form.itemAt(self._form.rowCount() - 1, QFormLayout.LabelRole)
        lbl = item.widget() if item is not None else None
        if isinstance(lbl, QLabel):
            lbl.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
            # 編集ウィンドウの QSS が `#rowLabel` に文字サイズを当てる
            # （"タスク名"/"説明" と同じ 14px に揃える）。
            lbl.setObjectName("rowLabel")

    # --- 種類 -------------------------------------------------------- #
    def _on_kind_changed(self, _index: int) -> None:
        self._mark_dirty()
        self._build_body()
        self.kindChanged.emit()

    def kind(self) -> str:
        return actionmeta.ID_BY_LABEL[self.type_cb.currentText()]

    def _args(self) -> dict:
        return dict(self._action.args) if self._action is not None else {}

    def _mark_dirty(self) -> None:
        self.dirty = True

    # --- 入力部品（dirty 追跡つき） ---------------------------------- #
    def _line(self, text: str = "", *, password: bool = False) -> QLineEdit:
        e = QLineEdit(str(text))
        if password:
            e.setEchoMode(QLineEdit.Password)
        e.textEdited.connect(lambda _t: self._mark_dirty())
        return e

    def _check(self, text: str, on) -> QCheckBox:
        c = QCheckBox(text)
        c.setChecked(bool(on))
        c.clicked.connect(lambda _on: self._mark_dirty())
        return c

    def _note(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("formNote")
        lbl.setWordWrap(True)
        return lbl

    def _browse(self, edit: QLineEdit, mode: str, *, exe: bool = False) -> QPushButton:
        """「参照…」。`QFileDialog` は Qt の標準機能に寄せる方針どおりそのまま使う。"""
        btn = QPushButton("参照…")
        btn.setObjectName("browseButton")

        def pick() -> None:
            if mode == "dir":
                p = QFileDialog.getExistingDirectory(self, "フォルダを選択")
            else:
                flt = "実行ファイル (*.exe);;すべて (*.*)" if exe else "すべて (*.*)"
                p, _ = QFileDialog.getOpenFileName(self, "ファイルを選択", "", flt)
            if p:
                edit.setText(p)
                self._mark_dirty()

        btn.clicked.connect(pick)
        return btn

    @staticmethod
    def _with_browse(edit: QLineEdit, btn: QPushButton) -> QWidget:
        w = uikit.transparent(QWidget())
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        h.addWidget(edit, 1)
        h.addWidget(btn)
        return w

    # --- 本体の組み立て ---------------------------------------------- #
    def _build_body(self) -> None:
        """種類別の行だけ作り直す。**「種類」の行（先頭）は残す** ── ラベル列の幅は
        フォーム全体で 1 つなので、種類だけ独立させると列幅がまた食い違う。"""
        while self._form.rowCount() > 1:
            self._form.removeRow(1)
        if self._extra is not None:
            self._v.removeWidget(self._extra)
            self._extra.setParent(None)
            self._extra.deleteLater()
            self._extra = None

        kind = self.kind()
        if kind in ("open_file", "open_folder"):
            self._collect = self._body_path(kind)
        elif kind == "open_url":
            self._collect = self._body_url()
        elif kind == "os_exec":
            self._collect = self._body_single("実行対象", "target")
        elif kind == "launch_app":
            self._collect = self._body_launch_app()
        elif kind == "copy":
            self._collect = self._body_copy()
        elif kind == "wait":
            self._collect = self._body_wait()
        else:
            self._collect = dict
        # 作り直したコンボ（書式テンプレート等）のポップアップを塗る。
        # **祖先の QSS は届かない**ので、作るたびに当て直す（2026-09-06）。
        uikit.style_combo_popups(self)

    # --- 種類別ボディ ------------------------------------------------ #
    def _body_single(self, label: str, key: str):
        ent = self._line(self._args().get(key, ""))
        self._add_row(label, ent)

        def collect() -> dict:
            v = ent.text().strip()
            if not v:
                raise ValueError("%s を入力してください" % label)
            return {key: v}

        return collect

    def _body_path(self, kind: str):
        ent = self._line(self._args().get("path", ""))
        btn = self._browse(ent, "dir" if kind == "open_folder" else "file")
        self._add_row("パス", self._with_browse(ent, btn))

        def collect() -> dict:
            v = ent.text().strip()
            if not v:
                raise ValueError("パスを入力してください")
            return {"path": v}

        return collect

    def _body_url(self):
        a = self._args()
        ent = self._line(a.get("url", ""))
        self._add_row("URL", ent)
        nw = self._check("新規ウィンドウで開く", a.get("new_window"))
        self._add_row("", nw)
        self._add_row("", self._note(
            "複数ページをまとめて開くとき、先頭の URL だけ ON にすると"
            "その新しいウィンドウに残りがタブで入ります（既存の窓を汚さない）。"))

        def collect() -> dict:
            v = ent.text().strip()
            if not v:
                raise ValueError("URL を入力してください")
            if "://" not in v:
                raise ValueError("URL の形式が不正です（scheme:// が必要）")
            out: dict = {"url": v}
            if nw.isChecked():
                out["new_window"] = True
            return out

        return collect

    def _body_wait(self):
        ent = self._line(self._args().get("seconds", "1"))
        self._add_row("待機秒数", ent)
        self._add_row("", self._note(
            "秒。この動作が終わるまで次の動作は始まりません"
            "（例: URL を開く動作の間に挟むと 1 本ずつ順に開く）。"))

        def collect() -> dict:
            raw = ent.text().strip()
            try:
                v = float(raw)
            except ValueError as e:
                raise ValueError("待機秒数は数値で入力してください") from e
            if v < 0:
                raise ValueError("待機秒数は 0 以上で入力してください")
            return {"seconds": v}

        return collect

    def _body_launch_app(self):
        """exe を直接実行（`os.startfile` で開けない業務アプリ向け）。引数・作業フォルダは任意。"""
        a = self._args()
        e_path = self._line(a.get("path", ""))
        self._add_row("exe パス", self._with_browse(
            e_path, self._browse(e_path, "file", exe=True)))
        e_args = self._line(a.get("args", ""))
        self._add_row("引数（任意）", e_args)
        e_wd = self._line(a.get("workdir", ""))
        self._add_row("作業フォルダ（任意）", self._with_browse(
            e_wd, self._browse(e_wd, "dir")))
        self._add_row("", self._note("未指定なら exe のあるフォルダで起動します。"))

        def collect() -> dict:
            p = e_path.text().strip()
            if not p:
                raise ValueError("exe パスを入力してください")
            out: dict = {"path": p}
            if e_args.text().strip():
                out["args"] = e_args.text().strip()
            if e_wd.text().strip():
                out["workdir"] = e_wd.text().strip()
            return out

        return collect

    # --- コピー ------------------------------------------------------ #
    def _body_copy(self):
        a = self._args()
        self.e_label = self._line(a.get("label", ""))
        self.e_label.setPlaceholderText("ワンタイムの窓に出す短い呼称（ID / パスワード など）")
        self._add_row("呼称（任意）", self.e_label)

        opts = uikit.transparent(QWidget())
        h = QHBoxLayout(opts)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(12)
        self.cb_onetime = self._check("ワンタイム", a.get("onetime"))
        self.cb_html = self._check("書式", a.get("format") == "html")
        self.cb_enc = self._check("暗号化", a.get("encrypt"))
        self.cb_mention = self._check("Slackメンション", a.get("mention"))
        for c in (self.cb_onetime, self.cb_html, self.cb_enc, self.cb_mention):
            h.addWidget(c)
        h.addStretch(1)
        # 書式 / 暗号化 / メンションは三者排他（ワンタイムはどれとも併用可）
        self.cb_html.clicked.connect(lambda _on: self._copy_exclusive(self.cb_html))
        self.cb_enc.clicked.connect(lambda _on: self._copy_exclusive(self.cb_enc))
        self.cb_mention.clicked.connect(lambda _on: self._copy_exclusive(self.cb_mention))
        self._add_row("オプション", opts)

        # **フォームの外**（2 列レイアウトの右列ではなく全幅）へ置く（2026-09-05 指摘）。
        # 「文字列」は複数行の入力なので、狭い右列に押し込めず左端から使えるように。
        self.copy_fields = uikit.transparent(QWidget())
        self._extra = self.copy_fields
        self._copy_v = QVBoxLayout(self.copy_fields)
        self._copy_v.setContentsMargins(0, 0, 0, 0)
        self._copy_v.setSpacing(6)
        self._v.addWidget(self.copy_fields)
        self._render_copy_fields()
        return self._collect_copy

    def _copy_exclusive(self, on_widget: QCheckBox) -> None:
        if on_widget.isChecked():
            for c in (self.cb_html, self.cb_enc, self.cb_mention):
                if c is not on_widget:
                    c.setChecked(False)
        self._render_copy_fields()

    def _has_stored_secret(self) -> bool:
        """この動作に**実際に登録済みの暗号文がある**か（`secret_id` が非空）。
        コピー＆貼り付けで複製された暗号化動作は `secret_id` が空＝未登録なので、
        『登録済み』扱いにせず入力を必須にする（2026-09-01 の指摘）。"""
        a = self._args()
        return bool(self._action is not None and a.get("encrypt") and a.get("secret_id"))

    def _check_secret_match(self) -> None:
        """暗号化の「入力」と「確認」の食い違いを入力中に出す（両方に文字があるときだけ）。"""
        warn = getattr(self, "enc_warn", None)
        if warn is None:
            return
        v1, v2 = self.e_s1.text(), self.e_s2.text()
        warn.setVisible(bool(v1) and bool(v2) and v1 != v2)

    def _clear_copy_fields(self) -> None:
        self.enc_warn = None
        while self._copy_v.count():
            item = self._copy_v.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _render_copy_fields(self) -> None:
        self._clear_copy_fields()
        a = self._args()
        self._tmpl_cb = None
        self._tmpl_id_by_name: dict[str, str] = {}

        if self.cb_enc.isChecked():
            has = self._has_stored_secret()
            self._copy_v.addWidget(self._note(
                "文字列（登録済み・変更するときだけ入力）" if has
                else "文字列（未登録。入力してください）"))
            self.e_s1 = self._line(password=True)
            self.e_s1.setPlaceholderText("入力")
            self.e_s2 = self._line(password=True)
            self.e_s2.setPlaceholderText("確認のためもう一度")
            self._copy_v.addWidget(self.e_s1)
            self._copy_v.addWidget(self.e_s2)
            # **打っている最中に知らせる**（2026-09-06 実機の指摘）。伏字なので
            # 見比べられず、確定するまで食い違いに気づけなかった。
            self.enc_warn = self._note("入力と確認が一致していません（このままでは登録されません）")
            self.enc_warn.setObjectName("formWarn")
            self.enc_warn.setVisible(False)
            self._copy_v.addWidget(self.enc_warn)
            for e in (self.e_s1, self.e_s2):
                e.textChanged.connect(self._check_secret_match)
            return

        if self.cb_html.isChecked():
            tmpls = self._host.templates.list() if self._host.templates else []
            if not tmpls:
                warn = self._note("※ テンプレートが未登録です。\n"
                                  "「設定」→ 書式付きコピー（テンプレート）で登録してください。")
                warn.setObjectName("formWarn")
                self._copy_v.addWidget(warn)
                return
            self._tmpl_id_by_name = {t.name: t.id for t in tmpls}
            self._tmpl_cb = QComboBox()
            self._tmpl_cb.addItems([t.name for t in tmpls])
            self._tmpl_cb.activated.connect(lambda _i: self._mark_dirty())
            cur_id = a.get("template_id")
            for t in tmpls:
                if t.id == cur_id:
                    self._tmpl_cb.setCurrentText(t.name)
                    break
            self._copy_v.addWidget(QLabel("テンプレート"))
            self._copy_v.addWidget(self._tmpl_cb)
            return

        self.t_text = QPlainTextEdit(str(a.get("text", "")))
        self.t_text.setFixedHeight(84)
        self.t_text.textChanged.connect(self._mark_dirty)
        self._copy_v.addWidget(QLabel("文字列"))
        self._copy_v.addWidget(self.t_text)

    def _collect_copy(self) -> dict:
        args: dict = {}
        lbl = self.e_label.text().strip()
        if lbl:
            args["label"] = lbl
        if self.cb_onetime.isChecked():
            args["onetime"] = True
        if self.cb_mention.isChecked():
            args["mention"] = True

        a = self._args()
        has_secret = self._has_stored_secret()

        if self.cb_enc.isChecked():
            v1, v2 = self.e_s1.text(), self.e_s2.text()
            if has_secret and not v1 and not v2:
                # 空のまま＝現在の登録内容を維持
                args.update({"encrypt": True, "secret_id": a["secret_id"]})
                return args
            if not v1:
                raise ValueError("暗号化する文字列を入力してください")
            if v1 != v2:
                raise ValueError("確認再入力が一致しません")
            if not self._host.ensure_crypto_ready():
                raise ValueError("パスフレーズが設定されていません")
            sid = a["secret_id"] if has_secret else new_id()
            self._host.crypto.encrypt(sid, v1)
            args.update({"encrypt": True, "secret_id": sid})
            return args

        # 非暗号化。以前 暗号化で**登録済みだった**なら暗号文を破棄する
        if has_secret:
            try:
                self._host.crypto.remove_secret(a["secret_id"])
            except Exception:  # noqa: BLE001  片付けの失敗で編集を止めない
                pass

        if self.cb_html.isChecked():
            if self._tmpl_cb is None or not self._tmpl_cb.currentText():
                raise ValueError("テンプレートを選択してください"
                                 "（未登録なら「設定」→ 書式付きコピー（テンプレート）で登録）")
            args.update({"format": "html",
                         "template_id": self._tmpl_id_by_name[self._tmpl_cb.currentText()]})
        else:
            args["text"] = self.t_text.toPlainText().rstrip("\n")
        return args

    # ----------------------------------------------------------------- #
    def collect(self) -> tuple[str, dict]:
        """`(action_id, args)` を返す。不正なら `ValueError`。"""
        return self.kind(), self._collect()
