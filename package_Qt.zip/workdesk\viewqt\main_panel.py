"""メインパネル（タスク一覧）。Tk 版 `view/main_panel.py` の置き換え（Phase 3e）。

design-notes「2026-09-05 メインパネルの形を決定（スパイク11）」で決めた **A 案**:

- 2 行（タスク名＋説明。**説明は書いたときだけ**）＋ 先頭に**色つきタイル**。
  タイルは装飾ではなく、**行の縦幅領域を自然にガイドする**機能を持つ（ユーザー評）。
- 実行フィードバック（3 層の層2）は**行の面の色**で出す。中核機能なので弱めない。
- **選択式にしない**（作業する場所なので一貫性を優先）。
- **タスクグループの仕切りは区切り線のみ・固定**（`group_style` はサイドバー専用）。

色はすべて `qtheme` が逆算したトークン／`theme_tokens.kind_tone()` から取る。
**現行の `_ICON_TINTS` 8 色のような hex 直書きはしない**（色相だけ引き継いでテーマから導出）。
"""

from __future__ import annotations

from PySide6.QtCore import QEvent, Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QScrollArea, QSizePolicy, QVBoxLayout, QWidget,
)

from .. import theme_tokens as T
from ..model import Task, Work
from . import actionmeta, icons, qtheme, uikit
from .uikit import pal as _pal
from .dragdrop import RowReorder

TILE = 30
#: 一覧の上下に空ける余白。下側は**サイドバーの外余白と同じ**＝フッターのカードの
#: 下線と同じ高さで両ペインの底が揃う（2026-09-06 要望）。
#: この帯は「まだ続きがある」ときだけ小さな `∧` `∨` を出す場所も兼ねる
#: （2026-09-06 その 2 で 14→18＝合図を見やすくするため少し広げた）。
#: 帯の高さ・合図の大きさは**サイドバーと共有**する（`uikit`。2026-09-07）。
BOTTOM_GAP = uikit.HINT_GAP
_ROW_RADIUS = 6

# 状態 → 面の色トークン。
# **「成功しました」等の要約文は出さない**（2026-09-05「実行前は主役 / 実行後は退場」）。
# 成功・中止は面も付けずに即座に通常へ戻す（app 側が state=None にする）。
# 残るのは 実行中（一時的）と 失敗（次にそのタスクを押すまで残る）だけ。
_STATE_FACE = {"running": "row_running", "all_ok": "row_ok",
               "has_failure": "row_fail", "aborted": "row_fail"}


def _thin(name: str, color: str, height: int = 1) -> QWidget:
    """細い矩形。`QFrame` を使わない（qt-material が border を当てる）。"""
    w = QWidget()
    w.setObjectName(name)
    w.setFixedHeight(height)
    w.setStyleSheet("#%s{background:%s;border:none;}" % (name, color))
    return w


class _Tile(QLabel):
    """先頭の色つきタイル（動作種別）。アイコンが出せなければ面だけで成立させる。"""

    def __init__(self, icon_name: str) -> None:
        super().__init__()
        self.setObjectName("taskTile")
        self.setFixedSize(TILE, TILE)
        self.setAlignment(Qt.AlignCenter)
        self.set_icon(icon_name)

    def set_icon(self, icon_name: str) -> None:
        """種類が変わったら塗り直す（動作の編集で先頭動作が変わったとき）。"""
        base = T.kind_tone(icon_name, "surface")
        self.setStyleSheet("#taskTile{background:%s;border:none;border-radius:7px;}" % base)
        pm = icons.pixmap(icon_name, T.tinted_ink(base), int(TILE * 0.6))
        self.setPixmap(pm if pm is not None else QPixmap())


class TaskRow(QWidget):
    """タスク 1 行。通常 / ホバー / 選択 ＋ 実行状態（層2）を持つ。"""

    clicked = Signal(str)
    rightClicked = Signal(str, int, int)
    doubleClicked = Signal(str)

    def __init__(self, task: Task, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.task_id = task.id
        self._selected = False
        self._hover = False
        self._state: str | None = None          # None / running / all_ok / …
        self.setObjectName("taskRow")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setCursor(Qt.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        pad = T.metrics()
        h = QHBoxLayout(self)
        h.setContentsMargins(pad["row_padx"], pad["row_pady"],
                             pad["row_padx"], pad["row_pady"])
        h.setSpacing(10)

        first = task.actions[0] if task.actions else None
        self._tile = _Tile(actionmeta.icon_name(first) if first is not None else "file")
        h.addWidget(self._tile)

        col = QVBoxLayout()
        col.setSpacing(1)
        col.setContentsMargins(0, 0, 0, 0)
        self._name = QLabel(task.name)
        self._name.setObjectName("taskName")
        col.addWidget(self._name)
        # 説明は**書いたときだけ**行を作る（2026-09-01 の判断を踏襲）。
        # 実行中は層3（動作ごとの詳細）でこの行を差し替えるので、元の説明を控えておく。
        self._base_desc = task.description or ""
        self._desc = QLabel(task.description or "")
        self._desc.setObjectName("taskDesc")
        self._desc.setVisible(bool(task.description))
        col.addWidget(self._desc)
        h.addLayout(col, 1)

        self._restyle()

    # --- 状態 ------------------------------------------------------- #
    def set_selected(self, on: bool) -> None:
        if self._selected != on:
            self._selected = on
            self._restyle()

    def set_state(self, state: str | None) -> None:
        """実行状態。`None` で通常へ戻す。**文言は出さない**（面の色だけ）。"""
        self._state = state
        self._restyle()

    def set_name(self, text: str) -> None:
        self._name.setText(text)

    def set_icon(self, icon_name: str) -> None:
        self._tile.set_icon(icon_name)

    def set_description(self, text: str) -> None:
        self._base_desc = text
        self._desc.setText(text)
        self._desc.setVisible(bool(text))

    def set_sub(self, text: str) -> None:
        """2 行目を一時的に差し替える（層3＝動作ごとの詳細、「実行中です」等）。

        空文字を渡すと**元の説明へ戻す**（説明が無ければ行ごと隠す）。
        """
        show = text or self._base_desc
        self._desc.setText(show)
        self._desc.setVisible(bool(show))

    @property
    def state(self) -> str | None:
        return self._state

    def enterEvent(self, _e) -> None:   # noqa: N802
        self._hover = True
        self._restyle()

    def leaveEvent(self, _e) -> None:   # noqa: N802
        self._hover = False
        self._restyle()

    def mousePressEvent(self, e) -> None:   # noqa: N802
        if e.button() == Qt.LeftButton:
            self.clicked.emit(self.task_id)
        elif e.button() == Qt.RightButton:
            p = e.globalPosition().toPoint()
            self.rightClicked.emit(self.task_id, p.x(), p.y())

    def mouseDoubleClickEvent(self, e) -> None:   # noqa: N802
        """設定モードでの改名の入口（判断は App が持つ。行はモードを知らない）。"""
        if e.button() == Qt.LeftButton:
            self.doubleClicked.emit(self.task_id)

    def begin_rename(self, on_commit) -> None:
        """タスク名ラベルの上に入力欄をかぶせる（設定モードのダブルクリック）。"""
        uikit.inline_rename(self, self._name, on_commit)

    def _restyle(self) -> None:
        """面と文字色を決める。**実行状態が選択・ホバーより優先**（結果を隠さない）。"""
        if self._state:
            face = _pal(_STATE_FACE.get(self._state, "row_fail"))
            ink = T.tinted_ink(face)
            sub = T.mix(ink, face, 0.42)
        elif self._selected:
            face, ink = _pal("accent"), _pal("on_accent")
            sub = T.mix(ink, face, 0.30)
        elif self._hover:
            face, ink = _pal("row_hover"), _pal("ink")
            sub = _pal("sub")
        else:
            face, ink = "transparent", _pal("ink")
            sub = _pal("sub")
        # フォントも自分の QSS に書く ── `setFont()` は qt-material のグローバル
        # QSS に負けて反映されない（qtheme.font_css の docstring 参照）。
        self.setStyleSheet(
            "#taskRow{background:%s;border:none;border-radius:%dpx;}"
            "#taskName{color:%s;background:transparent;border:none;font-weight:600;%s}"
            "#taskDesc{color:%s;background:transparent;border:none;%s}"
            % (face, _ROW_RADIUS, ink, qtheme.font_css(), sub, qtheme.font_css())
        )


class MainPanel(QWidget):
    """1 業務ぶんのタスク一覧。`render(work)` で作り直す。"""

    taskClicked = Signal(str)
    # タスク id（**空白部なら None**）と画面座標。`object` なのは None を運ぶため。
    taskRightClicked = Signal(object, int, int)
    # 並べ替え: (動かしたタスク, その手前に来るタスク or None, 行き先のタスクグループ。
    # 新しいグループへ出すときは行き先が None)
    reorderRequested = Signal(str, object, object)
    # タスク行の外（空白部）のダブルクリック＝最背面へ（帯と同じ挙動。2026-09-05 要望）
    emptyDoubleClicked = Signal()
    # タスク行そのもののダブルクリック＝その場で改名（設定モードのときだけ。2026-09-06）
    renameRequested = Signal(str)

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._rows: dict[str, TaskRow] = {}
        self._selected_id: str | None = None
        # **自分の地も塗る**（2026-09-06 要望）。下の余白は素の `QWidget` のままだと
        # qt-material の既定色が出て、一覧の地と違う帯に見える（既知の癖）。
        self.setObjectName("mainPanel")
        self.setAttribute(Qt.WA_StyledBackground, True)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # **業務名の見出しは固定**（一覧と一緒にスクロールさせない。2026-09-06 要望）。
        # いま何を見ているかが常に見えるうえ、下の余白が「上に続きがある」の
        # 合図（`∧`）の置き場になる。
        self._head = QLabel("")
        self._head.setObjectName("mainHead")
        self._head_box = uikit.transparent(QWidget())
        hb = QVBoxLayout(self._head_box)
        hb.setContentsMargins(T.box_margin(), T.TOP_GAP, T.box_margin(), 0)
        hb.setSpacing(0)
        hb.addWidget(self._head)
        # 見出しの帯も「空白部」として扱う（右クリック＝アンカー無しのメニュー、
        # ダブルクリック＝最背面）。一覧の外に出したぶん、ここが空白部になる。
        self._head_box.setContextMenuPolicy(Qt.CustomContextMenu)
        self._head_box.customContextMenuRequested.connect(
            lambda pos: self._blank_context(self._head_box, pos))
        self._head_box.installEventFilter(self)
        outer.addWidget(self._head_box)
        self._up = uikit.hint_band("mainUp")
        outer.addWidget(self._up)

        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setFrameShape(QFrame.NoFrame)
        self._scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(self._scroll)

        # 下の余白（2026-09-06 要望）。フッターの帯が無くなって一覧が窓の下端に
        # 貼り付いて見えたため。**サイドバーの外余白と同じ 14px** ＝ フッターの
        # カードの下線と同じ高さで両ペインの底が揃う。
        # この帯が「まだ下に項目がある」の合図（`∨`）の置き場も兼ねる
        # ── スクロールバーだけだと続きがあることに気づきにくい、という指摘。
        self._more = uikit.hint_band("mainMore")
        outer.addWidget(self._more)
        bar = self._scroll.verticalScrollBar()
        bar.valueChanged.connect(self._sync_more_hint)
        bar.rangeChanged.connect(lambda *_a: self._sync_more_hint())
        # 行のどこでもドラッグで並べ替え（設定モード限定）。
        # 最終行の下まで運べば新しいグループへ出せる（2026-09-05・操作の一貫性）。
        self._drag = RowReorder(self._scroll, self.reorderRequested.emit, self,
                                 allow_new_container=True)

    # --- 公開 API --------------------------------------------------- #
    @property
    def selected_task_id(self) -> str | None:
        return self._selected_id

    def row(self, task_id: str) -> TaskRow | None:
        return self._rows.get(task_id)

    def head_text(self) -> str:
        """いま出ている見出し（選択中の業務名。空なら案内文）。"""
        return self._head.text()

    def _sync_more_hint(self) -> None:
        """**続きがある側にだけ**小さな `∧` `∨` を出す（2026-09-06 要望）。

        置き場は 上＝見出しと一覧の間 / 下＝一覧と窓の下端の間。中身の出し分けは
        サイドバーと同じ処理なので `uikit` にある。
        """
        uikit.sync_scroll_hints(self._scroll, self._up, self._more)

    def row_ids(self) -> list[str]:
        return list(self._rows)

    def render(self, work: Work | None) -> None:
        ground = _pal("bg")
        # 自分の地と、下の余白の帯（テーマが変わるたびここを通る）
        self.setStyleSheet("#mainPanel{background:%s;border:none;}"
                           "#mainUp,#mainMore{background:%s;border:none;}"
                           % (ground, ground))
        body = QWidget()
        body.setObjectName("mainBody")
        body.setAttribute(Qt.WA_StyledBackground, True)
        body.setStyleSheet("#mainBody{background:%s;border:none;}" % ground)
        v = QVBoxLayout(body)
        v.setContentsMargins(T.box_margin(), 0, T.box_margin(), 0)
        v.setSpacing(0)

        # 「選択中の業務名」の見出し（Tk 版から移植。2026-08-31 のユーザー要望）は
        # **スクロールの外**（`_head_box`）に常設してある。ここでは中身だけ替える。
        self._head.setText(work.name if work is not None else "（業務を選択してください）")
        self._head.setObjectName("mainHead" if work is not None else "mainEmpty")
        self.refresh_font()

        self._rows = {}
        self._drag.reset()
        first = True
        for tg in (work.task_groups if work is not None else []):
            if not tg.tasks:
                continue
            if not first:
                # タスクグループの仕切りは**区切り線のみ・固定**（サイドバーと違い選択式にしない）
                v.addSpacing(9)
                v.addWidget(_thin("taskGroupLine", _pal("divider")))
                v.addSpacing(9)
            for t in tg.tasks:
                row = TaskRow(t)
                row.clicked.connect(self._on_row_clicked)
                row.rightClicked.connect(self.taskRightClicked.emit)
                row.doubleClicked.connect(self.renameRequested.emit)
                self._rows[t.id] = row
                self._drag.add_row(row, t.id, tg.id)
                v.addWidget(row)
            first = False
        v.addStretch(1)

        # タスク行の外（空白部）で右クリック＝アンカー無しのメニュー（Tk 版から移植）
        body.setContextMenuPolicy(Qt.CustomContextMenu)
        body.customContextMenuRequested.connect(
            lambda pos, w=body: self._blank_context(w, pos))
        # 同じ空白部のダブルクリック＝最背面（帯のダブルクリックと同じ挙動）
        body.installEventFilter(self)

        self._scroll.setWidget(body)
        self._sync_more_hint()
        vp = self._scroll.viewport()
        vp.setObjectName("mainViewport")
        vp.setStyleSheet("#mainViewport{background:%s;border:none;}" % ground)
        vp.setContextMenuPolicy(Qt.CustomContextMenu)
        vp.customContextMenuRequested.connect(
            lambda pos, w=vp: self._blank_context(w, pos))
        vp.installEventFilter(self)
        uikit.apply_scrollbar_mode(self._scroll)
        if self._selected_id not in self._rows:
            self._selected_id = None

    def _blank_context(self, widget, pos) -> None:
        g = widget.mapToGlobal(pos)
        self.taskRightClicked.emit(None, g.x(), g.y())

    def eventFilter(self, obj, event) -> bool:   # noqa: N802
        """一覧の地（`body` / ビューポート）そのもののダブルクリックだけ拾う。

        タスク行は自分の `mousePressEvent` を先に受けるので、行の上では
        ここまで来ない（＝当てても実行の邪魔をしない）。
        """
        if (event.type() == QEvent.MouseButtonDblClick
                and event.button() == Qt.LeftButton
                and T.STATE.get("send_to_back_dblclick", True)):
            self.emptyDoubleClicked.emit()
            return True
        return False

    def set_drag_enabled(self, on: bool) -> None:
        """設定モードのときだけ並べ替えを有効にする（通常モードはクリック＝実行）。"""
        self._drag.set_enabled(on)

    def refresh_font(self) -> None:
        """フォント設定が変わったとき、**行を作り直さずに**塗り直す。"""
        if self._head is not None:
            self._head.setStyleSheet(
                "#mainHead{color:%s;background:transparent;border:none;"
                "font-weight:600;%s}"
                "#mainEmpty{color:%s;background:transparent;border:none;%s}"
                % (_pal("ink"), qtheme.font_css(), _pal("faint"), qtheme.font_css()))
        for row in self._rows.values():
            row._restyle()

    def select_task(self, task_id: str | None) -> None:
        if task_id is not None and task_id not in self._rows:
            return
        if self._selected_id in self._rows:
            self._rows[self._selected_id].set_selected(False)
        self._selected_id = task_id
        if task_id is not None:
            self._rows[task_id].set_selected(True)

    def clear_selection(self) -> None:
        self.select_task(None)

    def set_task_state(self, task_id: str, state: str | None) -> None:
        """層2 のフィードバックを行に反映する（`None` で通常へ）。"""
        row = self._rows.get(task_id)
        if row is not None:
            row.set_state(state)

    def update_row_label(self, task_id: str, text: str) -> None:
        row = self._rows.get(task_id)
        if row is not None:
            row.set_name(text)

    def update_task_description(self, task_id: str, text: str) -> None:
        row = self._rows.get(task_id)
        if row is not None:
            row.set_description(text)

    def update_task_icon(self, task_id: str, icon_name: str) -> None:
        """先頭動作の種類が変わったときのタイル塗り直し（行だけの最小再描画）。"""
        row = self._rows.get(task_id)
        if row is not None:
            row.set_icon(icon_name)

    # --- 内部 ------------------------------------------------------- #
    def _on_row_clicked(self, task_id: str) -> None:
        self.taskClicked.emit(task_id)
