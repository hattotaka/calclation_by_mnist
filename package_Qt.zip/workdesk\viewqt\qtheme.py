"""qt-material のテーマ → `theme_tokens.PALETTE` の橋渡し（Phase 3c）。

design-notes「2026-09-04 PySide6 + qt-material への UI 移行」の決めたこと 5:

    qt-material が持つグローバル QSS と `theme.PALETTE` を二重管理すると必ず食い違う。
    **qt-material の active テーマ → PALETTE トークン**の**一方向**にする。

qt-material は `apply_stylesheet()` のたびに `QTMATERIAL_*` 環境変数へ 7 色を出す。
それを入力に、`theme_tokens` の色の理屈（`contrast_step` / `elevated_face` / `tone`）で
残りのトークンを**すべて逆算**する。**ここに hex を直書きしない。**

qt-material の既知の癖（スパイク3・9 で実際に踏んだもの）:
  - `qt_material` は **PySide6 の後に** import する（先だとフォント関連が壊れる）
  - ライト系テーマは `invert_secondary=True` が要る
  - `apply_stylesheet()` は**フォントも上書きする**ので毎回 和文フォントへ戻す

Qt 側のスタイリングでの注意（同じくスパイク9 で踏んだもの。ウィジェットを書くとき）:
  - `QFrame` には border が当たる → 細い矩形は `QWidget` で作る
  - ウィジェット側 QSS はセレクタ無しだと詳細度で負ける → `QLabel{...}` / `#id{...}`
  - `QScrollArea` の地色は palette では塗れない → ID セレクタ ＋ `WA_StyledBackground`
"""

from __future__ import annotations

import os

from .. import theme_tokens as T

# 目標コントラスト（地色に対して）。**この表が「濃さ」の唯一の情報源**。
# 値の根拠はスパイク10（テーマ既定の secondarylightcolor は 1.14〜2.18 とばらつき、
# ライトではほぼ見えなかった）。
CR: dict[str, float] = {
    "divider": 2.60,      # グループの区切り線（サイドバー・タスクグループ。2026-09-05 濃く）
    "rail": 2.40,         # グループのレール（無彩色スタイル E）
    "card_edge": 2.90,    # グループカード（スタイル D）の枠。サイドバー全体の外枠も同じトークン
    "card_face": 1.35,    # グループカードの面
    "row_hover": 1.14,    # 行のマウスオーバー（ごく薄く）
    "input_border": 2.00,  # 入力欄などの枠
    "sub_ink": 4.60,      # 二次テキスト（AA 4.5 をわずかに超える）
    "faint_ink": 3.00,    # プレースホルダ・OFF 状態（AA 未満は承知の上）
}

_KEYS = ("primaryColor", "primaryLightColor", "secondaryColor",
         "secondaryLightColor", "secondaryDarkColor", "primaryTextColor",
         "secondaryTextColor")


def read_env() -> dict[str, str]:
    """`apply_stylesheet()` が立てた `QTMATERIAL_*` を読む。"""
    return {k: os.environ.get("QTMATERIAL_" + k.upper(), "") for k in _KEYS}


def is_dark(theme_name: str | None = None) -> bool:
    name = theme_name or os.environ.get("QTMATERIAL_THEME", "")
    return "dark" in name


def derive_tokens(src: dict[str, str], *, dark: bool) -> dict[str, str]:
    """qt-material の 7 色から画面が使う色トークン一式を作る。

    **純粋関数**（Qt に触れない）ので、全 26 テーマぶんの値を流し込んでテストできる。
    """
    ground = src.get("secondaryColor") or ("#232629" if dark else "#f5f5f5")
    accent = src.get("primaryColor") or "#4dd0e1"

    step = T.contrast_step
    ink = T.readable_ink(ground)

    tokens: dict[str, str] = {
        # --- 面 ------------------------------------------------------ #
        "bg": ground,                                   # 窓・ペインの地
        "sidebar_bg": ground,                           # サイドバーも同じ地（帯で分けない）
        "row_normal": ground,                           # 行は地に溶け込む（フラット）
        "row_hover": step(ground, CR["row_hover"]),
        "card_face": T.elevated_face(ground, CR["card_face"]),
        "card_edge": step(ground, CR["card_edge"]),
        # --- 線 ------------------------------------------------------ #
        "divider": step(ground, CR["divider"]),
        "rail": step(ground, CR["rail"]),
        "input_border": step(ground, CR["input_border"]),
        # --- 文字 ---------------------------------------------------- #
        "ink": ink,
        "sub": step(ground, CR["sub_ink"]),
        "faint": step(ground, CR["faint_ink"]),
        # --- アクセント（選択・フォーカス。**色はここに予約されている**） --- #
        "accent": accent,
        # アクセントは彩度が高く中間輝度のものがある。2 極では AA に届かないので
        # 純黒・純白までエスカレートする `on_color` を使う（実測: #2979ff / #ff4081）。
        "on_accent": T.on_color(accent),
        "accent_soft": T.mix(accent, ground, 0.82),
        # --- 実行フィードバック（3 層の層2）。色相だけ意味に固定 ------- #
        "row_running": T.state_tone("running", "surface", dark=dark),
        "row_ok": T.state_tone("ok", "surface", dark=dark),
        "row_fail": T.state_tone("fail", "surface", dark=dark),
    }
    # 状態面の上に載る要約文字は**その面**から決める（地から決めると読めない）
    for state in ("running", "ok", "fail"):
        tokens[state + "_ink"] = T.tinted_ink(tokens["row_" + state])
    tokens["run_ink"] = tokens.pop("running_ink")   # 既存の呼び名に合わせる
    return tokens


def apply(app, theme_name: str, *, font_family: str | None = None) -> dict[str, str]:
    """テーマを当てて `PALETTE` を差し替える。戻り値は作ったトークン。

    `app` は `QApplication`。この関数だけが qt-material に触る。
    """
    import qt_material                      # PySide6 の後に import する（既知の癖）

    qt_material.apply_stylesheet(
        app, theme=theme_name, invert_secondary=theme_name.startswith("light"))
    _restore_font(app, font_family)

    dark = is_dark(theme_name)
    tokens = derive_tokens(read_env(), dark=dark)
    T.set_palette(tokens, dark=dark)
    T.STATE["qt_theme"] = theme_name      # 永続化（PERSIST_KEYS に入っている）
    return tokens


def current_theme() -> str:
    return str(T.STATE.get("qt_theme", "dark_cyan.xml"))


def list_themes() -> list[str]:
    import qt_material

    return list(qt_material.list_themes())


def _restore_font(app, family: str | None) -> None:
    """`apply_stylesheet()` がフォントを上書きするので和文フォントへ戻す（既知の癖）。"""
    from PySide6.QtGui import QFont, QFontDatabase

    fams = set(QFontDatabase.families())
    want = family or str(T.STATE.get("font_family", "Yu Gothic UI"))
    pick = next((f for f in (want, "Yu Gothic UI", "Meiryo UI", "Meiryo", "MS UI Gothic")
                 if f in fams), None)
    if pick:
        app.setFont(QFont(pick, int(T.STATE.get("font_size", 10))))


def font_css(delta: int = 0) -> str:
    """`T.STATE` のフォント設定を QSS の宣言片に変換する。

    `delta` は文字の大きさの差分（`-1` で 1pt 小さく）。**場所の名前**として
    弱く出したい見出し（サイドバーの `Menu` / `Tools`）に使う。

    **メイン画面の行の文字は `QApplication.setFont()` だけでは変わらない**
    （qt-material がグローバル QSS で `font-family` を指定しており、QSS が
    ウィジェット自身の `setFont()` より強い。2026-09-05 実機で発覚）。
    行を作り直さずに反映するには、**自分の QSS にも同じ値を書く**しかない
    （`_WorkRow` / `TaskRow` の `_restyle()` が使う）。
    """
    fam = str(T.STATE.get("font_family", "Yu Gothic UI")).replace("'", "")
    size = max(6, int(T.STATE.get("font_size", 10)) + delta)
    return "font-family:'%s';font-size:%dpt;" % (fam, size)
