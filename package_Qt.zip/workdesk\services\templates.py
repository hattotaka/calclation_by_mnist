"""HTML テンプレートの保管庫。

- 「登録したい書式付きコンテンツをコピー」→ 共通設定画面で登録 → クリップボードの
  CF_HTML（HTML断片）＋ 平文を取り出して `templates/<id>.json` に保存。
- 動作（コピー）の `format=="html"` は `template_id` でここを引く。
- 暗号化はしない（大きな本文を暗号化するのは非現実的、というユーザー判断）。

templates/<id>.json = {"id":..., "name":..., "html":..., "text":..., "created":...}
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path

from ..model import new_id


@dataclass
class Template:
    id: str
    name: str
    html: str = ""
    text: str = ""


class TemplateStore:
    def __init__(self, directory: str | os.PathLike[str], clipboard) -> None:
        self._dir = Path(directory)
        self._clipboard = clipboard
        # names() 用のキャッシュ: ファイル名 -> ((mtime_ns, size), template_id, 名前)
        self._name_cache: dict[str, tuple[tuple[int, int], str, str]] = {}

    def _path(self, template_id: str) -> Path:
        return self._dir / f"{template_id}.json"

    def list(self) -> list[Template]:
        """全テンプレートを本文（html / text）込みで読む。

        本文は「メール本文をまるごと」の想定で大きくなりうるので、**名前しか要らない
        呼び出しでは `names()` を使う**（一覧表示・要約表示はすべて名前だけ）。
        """
        if not self._dir.is_dir():
            return []
        out: list[Template] = []
        for p in self._dir.glob("*.json"):
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                out.append(Template(d["id"], d.get("name", p.stem), d.get("html", ""), d.get("text", "")))
            except (OSError, ValueError, KeyError):
                continue
        out.sort(key=lambda t: t.name)
        return out

    def names(self) -> dict[str, str]:
        """`{template_id: 名前}` を返す（本文は読み込まない・変化していなければ読み直さない）。

        業務を選ぶたびに動作の要約へテンプレート名を埋める＝**頻繁に呼ばれる経路**。
        以前はここで `list()` を呼んでいたため、選択のたびに全テンプレートの html / text
        （メール本文まるごと）をディスクから読んで捨てていた（2026-09-02 に分離）。

        キャッシュはファイルごとに `(mtime_ns, size)` で検証するので、マイドライブ同期など
        **外部からの書き換えにも追従する**（読み直すのは変わったファイルだけ）。
        """
        if not self._dir.is_dir():
            self._name_cache.clear()
            return {}
        out: dict[str, str] = {}
        fresh: dict[str, tuple[tuple[int, int], str, str]] = {}
        for p in self._dir.glob("*.json"):
            try:
                st = p.stat()
                stamp = (st.st_mtime_ns, st.st_size)
                hit = self._name_cache.get(p.name)
                if hit is not None and hit[0] == stamp:
                    fresh[p.name] = hit
                    out[hit[1]] = hit[2]
                    continue
                d = json.loads(p.read_text(encoding="utf-8"))
                tid, name = d["id"], d.get("name", p.stem)
                fresh[p.name] = (stamp, tid, name)
                out[tid] = name
            except (OSError, ValueError, KeyError):
                continue
        self._name_cache = fresh   # 消えたファイルはここで落ちる
        return out

    def get(self, template_id: str) -> Template | None:
        p = self._path(template_id)
        if not p.exists():
            return None
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        return Template(d["id"], d.get("name", ""), d.get("html", ""), d.get("text", ""))

    def add_from_clipboard(self, name: str) -> Template:
        res = self._clipboard.get_html()
        if res is None:
            raise ValueError("クリップボードに書式付き(HTML)データがありません")
        html, text = res
        tmpl = Template(id=new_id(), name=name.strip() or "無題", html=html, text=text)
        self._write(tmpl)
        return tmpl

    def rename(self, template_id: str, name: str) -> bool:
        t = self.get(template_id)
        if t is None:
            return False
        t.name = name.strip() or t.name
        self._write(t)
        return True

    def delete(self, template_id: str) -> bool:
        p = self._path(template_id)
        if p.exists():
            p.unlink()
            return True
        return False

    def _write(self, t: Template) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        p = self._path(t.id)
        tmp = p.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps(
                {"id": t.id, "name": t.name, "html": t.html, "text": t.text, "created": int(time.time())},
                ensure_ascii=False, indent=2,
            ),
            encoding="utf-8",
        )
        os.replace(tmp, p)


class FakeTemplateStore:
    """テスト・ヘッドレス用。"""

    def __init__(self, clipboard=None) -> None:
        self._items: dict[str, Template] = {}
        self._clipboard = clipboard

    def add(self, name: str, html: str, text: str = "") -> Template:
        t = Template(id=new_id(), name=name, html=html, text=text)
        self._items[t.id] = t
        return t

    def add_from_clipboard(self, name: str) -> Template:
        """本物と同じ契約（クリップボードに書式付きが無ければ ValueError）。

        `clipboard=` を渡さなければ「常に空」＝必ず ValueError になる。
        """
        res = self._clipboard.get_html() if self._clipboard is not None else None
        if res is None:
            raise ValueError("クリップボードに書式付き(HTML)データがありません")
        html, text = res
        return self.add(name.strip() or "無題", html, text)

    def list(self) -> list[Template]:
        return sorted(self._items.values(), key=lambda t: t.name)

    def names(self) -> dict[str, str]:
        return {t.id: t.name for t in self._items.values()}

    def get(self, template_id: str) -> Template | None:
        return self._items.get(template_id)

    def rename(self, template_id: str, name: str) -> bool:
        t = self._items.get(template_id)
        if t is None:
            return False
        t.name = name
        return True

    def delete(self, template_id: str) -> bool:
        return self._items.pop(template_id, None) is not None
