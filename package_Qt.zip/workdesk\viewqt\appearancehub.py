"""デザインラボ・設定を 1 つの窓にタブでまとめる（2026-09-06 要望）。

以前は「デザインラボ」「設定」は別々のモードレス窓で、導線はタイトル帯にあった。
ユーザー要望で **1 つの窓・タブで切り替え**にまとめ、導線は**サイドバー最下部の
フッター**へ移した（Tk 版で元々あった位置）。

`DesignLab` / `SettingsPanel` はどちらも「窓」ではなく `QWidget` へ変えてあり
（`designlab.py` / `settingspanel.py`）、ここがその 2 つを `QTabWidget` に載せる
唯一の「窓」。位置の永続化・タイトルバーのダークモード対応はここに一本化する
（各タブは自分がどんな入れ物に載っているか知らない）。
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QFrame, QScrollArea, QTabWidget, QVBoxLayout, QWidget,
)

from .. import theme_tokens as T
from . import qtheme, uikit
from .uikit import pal as _pal
from .designlab import DesignLab
from .settingspanel import SettingsPanel
from .titlebar import set_titlebar_dark_mode

_TABS = ("design", "settings")


class AppearanceHub(QDialog):
    """デザインラボ／設定のタブ窓（モードレス）。開いていてもタスクは実行できる。"""

    def __init__(self, host, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._host = host
        self.setWindowTitle("デザインラボ・設定")
        self.setModal(False)
        self.setMinimumWidth(460)
        # QSS の背景・文字色を確実に適用させる（qt-material のグローバル QSS が
        # 既定であてる灰色・黒い文字が透けて見えることがある。2026-09-05 実機で発覚）。
        self.setAttribute(Qt.WA_StyledBackground, True)

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)

        self.tabs = QTabWidget()
        self.tabs.setObjectName("hubTabs")
        self.design_lab = DesignLab(host)
        self.settings_panel = SettingsPanel(host)
        # **中身はスクロール領域に載せる。** 設定タブは 4 セクションで縦に長く、
        # 窓を縮めたり行の高さを「ゆったり」にしたりすると下が切れていた
        # （2026-09-06 整理）。ついでにここが地色を持つので、下の
        # `QStackedWidget` に qt-material の既定色が残る問題も塞がる。
        self._scrolls = [self._wrap(self.design_lab, "hubDesignScroll"),
                         self._wrap(self.settings_panel, "hubSettingsScroll")]
        self.tabs.addTab(self._scrolls[0], "デザインラボ")
        self.tabs.addTab(self._scrolls[1], "設定")
        v.addWidget(self.tabs)

        self._sized = False
        self._restyle()

    @staticmethod
    def _wrap(panel: QWidget, name: str) -> QScrollArea:
        sa = QScrollArea()
        sa.setObjectName(name)
        sa.setWidgetResizable(True)
        sa.setFrameShape(QFrame.NoFrame)
        sa.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sa.setWidget(panel)
        # ビューポートの地色は palette では塗れない（ID セレクタで塗る。既知の癖）
        sa.viewport().setObjectName(name + "Viewport")
        return sa

    # --- 導線 ---------------------------------------------------------- #
    def show_tab(self, tab: str) -> None:
        """`tab` は `"design"` / `"settings"`。すでに開いていれば前面へ。"""
        self.tabs.setCurrentIndex(_TABS.index(tab))
        self.show()
        self.raise_()
        self.activateWindow()

    def current_tab(self) -> str:
        return _TABS[self.tabs.currentIndex()]

    # --- 見た目 ---------------------------------------------------------- #
    def refresh_scrollbars(self) -> None:
        """`scrollbar_mode` の変更に追随する（塗り直しまではしない）。"""
        for sa in self._scrolls:
            uikit.apply_scrollbar_mode(sa)

    def apply_theme(self) -> None:
        """テーマが変わったら塗り直す（別窓なのでメイン窓の再描画に乗らない）。"""
        set_titlebar_dark_mode(self, qtheme.is_dark())
        self._restyle()
        self.design_lab.apply_theme()
        self.settings_panel.apply_theme()

    def _restyle(self) -> None:
        """**操作要素は qt-material の既定に任せない**（恒久ルール）。

        `QTabBar` は特にクセが強い（既定のタブ色は 18/26 テーマで AA 未満になり得る）
        ので、選択タブはアクセント、非選択はフラットに、自分のトークンで塗る。
        """
        self.setStyleSheet(
            "QDialog{background:%(bg)s;}"
            "#hubTabs::pane{background:%(bg)s;border:none;border-top:1px solid %(divider)s;}"
            "QTabBar{background:transparent;}"
            "QTabBar::tab{background:transparent;color:%(sub)s;border:none;"
            "padding:10px 18px;font-size:15px;}"
            "QTabBar::tab:selected{color:%(ink)s;font-weight:600;"
            "border-bottom:2px solid %(accent)s;}"
            "QTabBar::tab:hover:!selected{color:%(ink)s;}"
            # タブの中身（スクロール領域とそのビューポート）。**書かないと
            # qt-material の `QWidget` 型セレクタ（#31363b）が残る** ── パネル側は
            # `background:transparent` なので、その下がそのまま見えていた。
            "#hubDesignScroll,#hubSettingsScroll{background:%(bg)s;border:none;}"
            "#hubDesignScrollViewport,#hubSettingsScrollViewport{background:%(bg)s;}"
            % {"bg": _pal("bg"), "divider": _pal("divider"), "sub": _pal("sub"),
               "ink": _pal("ink"), "accent": _pal("accent")}
        )
        for sa in getattr(self, "_scrolls", ()):
            uikit.apply_scrollbar_mode(sa)

    # --- 位置の永続化 ------------------------------------------------- #
    def showEvent(self, e) -> None:   # noqa: N802
        super().showEvent(e)
        # `round_corners` と同じ順序（ネイティブのウィンドウハンドルが実体化する
        # 前に `winId()` を読むと効かない。2026-09-05 実機で発覚）。
        set_titlebar_dark_mode(self, qtheme.is_dark())
        geo = (self._host.app_data.settings.get("window", {}) or {}).get("appearance_hub")
        if geo and len(geo) >= 2:
            self.move(int(geo[0]), int(geo[1]))
        if not self._sized:
            self._sized = True
            if geo and len(geo) >= 4:
                self.resize(int(geo[2]), int(geo[3]))
            else:
                self.resize(self._initial_size())

    def _initial_size(self):
        """**中身が収まる高さ**で開く。ただし画面からはみ出さない。

        スクロール領域に載せたので `sizeHint()` は中身の高さを返さない
        （スクロールできる＝小さくてよい、になる）。パネル自身に聞く。
        """
        from PySide6.QtCore import QSize

        need = max(self.design_lab.sizeHint().height(),
                   self.settings_panel.sizeHint().height())
        need += self.tabs.tabBar().sizeHint().height() + 8
        scr = self.screen()
        if scr is not None:
            need = min(need, int(scr.availableGeometry().height() * 0.9))
        return QSize(max(self.width(), self.minimumWidth()), need)

    def closeEvent(self, e) -> None:   # noqa: N802
        self.settings_panel.wait_commit()   # 入力途中のまま閉じても取りこぼさない
        win = self._host.app_data.settings.setdefault("window", {})
        win["appearance_hub"] = [self.x(), self.y(), self.width(), self.height()]
        self._host.save()
        super().closeEvent(e)
