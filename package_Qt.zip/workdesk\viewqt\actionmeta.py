"""動作の「種類ごとの見せ方」を 1 か所に集めたテーブル（design-notes §17 / 2026-09-02 整理）。

以前は 表示名（`main_panel._KIND_JA`）・アイコン（`main_panel._ICON_FOR_ACTION`）・
要約文（`main_panel._action_summary`）・エディタの選択肢（`actiondialog._TYPES`）が
別々の場所に散っていて、動作を 1 つ足すたびに 4 か所を触る必要があった。
それらを `_KINDS` の 1 テーブルに統合し、view のどこからでも参照できるようにする。

- 表示に関わる知識だけを持つ（実行の知識は `features/` 側）。
- ここは view のどのモジュールからも import してよい（他の view モジュールに依存しない）。
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ActionKind:
    """1 動作種別ぶんの表示情報。"""

    action_id: str
    label: str        # 動作エディタの種類コンボに出す文言
    short: str        # 要約文の頭に出す短い呼称
    icon: str         # icons.py のアイコン名


# 並び順は動作エディタの種類コンボの並び順でもある。
_KINDS: tuple[ActionKind, ...] = (
    ActionKind("open_file", "ファイルを開く", "ファイル", "file"),
    ActionKind("open_folder", "フォルダを開く", "フォルダ", "folder"),
    ActionKind("open_url", "URLを開く", "URL", "link"),
    ActionKind("os_exec", "OS実行（claude:// など）", "OS実行", "terminal"),
    ActionKind("launch_app", "アプリ起動（exe を直接実行）", "アプリ起動", "terminal"),
    ActionKind("copy", "文字列コピー", "コピー", "copy"),
    ActionKind("wait", "待機する", "待機", "clock"),
)

BY_ID: dict[str, ActionKind] = {k.action_id: k for k in _KINDS}
LABELS: list[str] = [k.label for k in _KINDS]
ID_BY_LABEL: dict[str, str] = {k.label: k.action_id for k in _KINDS}
LABEL_BY_ID: dict[str, str] = {k.action_id: k.label for k in _KINDS}

_FALLBACK = ActionKind("", "", "", "doc")


def kind_of(action_id: str) -> ActionKind:
    """未知の `action_id` でも落ちない（汎用アイコン・空の呼称）。"""
    return BY_ID.get(action_id, _FALLBACK)


def icon_name(action) -> str:
    """1 動作に対応する `icons.py` のアイコン名（暗号化コピーだけ錠前）。"""
    if action.action_id == "copy" and action.args.get("encrypt"):
        return "lock"
    return kind_of(action.action_id).icon


def _short(s: str, n: int = 32) -> str:
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[:n] + "…"


def summary(action, template_names: dict[str, str] | None = None) -> str:
    """設定モードの動作行・削除確認に出す 1 行要約（「種別 — 詳細」）。

    種別の頭は**「種類」コンボと同じ表記**（`label`）で揃える（2026-09-05 要望）。
    ただし `os_exec` / `launch_app` は `label` が長い注釈付き
    （「OS実行（claude:// など）」等）で行の頭には冗長なので、従来どおり `short` のまま。
    """
    args = action.args
    aid = action.action_id
    if aid == "copy":
        tags = []
        if args.get("encrypt"):
            tags.append("暗号")
        if args.get("onetime"):
            tags.append("ワンタイム")
        if args.get("format") == "html":
            tags.append("書式")
        if args.get("mention"):
            tags.append("メンション")
        head = kind_of(aid).label + (f" {args['label']}" if args.get("label") else "")
        if tags:
            head += " [" + "/".join(tags) + "]"
        if args.get("encrypt"):
            body = "●●●"
        elif args.get("format") == "html":
            body = (template_names or {}).get(
                args.get("template_id", ""), "(テンプレート未選択)"
            )
        else:
            body = _short(args.get("text", ""))
        return f"{head} — {body}" if body else head
    if aid in ("open_file", "open_folder"):
        return f"{kind_of(aid).label} — {_short(args.get('path', ''), 44)}"
    if aid == "open_url":
        tag = " [新規窓]" if args.get("new_window") else ""
        return f"{kind_of(aid).label}{tag} — {_short(args.get('url', ''), 44)}"
    if aid == "os_exec":
        return f"{kind_of(aid).short} — {_short(args.get('target', ''), 44)}"
    if aid == "launch_app":
        extra = f" {args['args']}" if args.get("args") else ""
        return f"{kind_of(aid).short} — {_short(args.get('path', '') + extra, 44)}"
    if aid == "wait":
        try:
            secs = float(args.get("seconds", 0))
        except (TypeError, ValueError):
            secs = 0
        return f"{kind_of(aid).label} — {secs:g} 秒"
    return kind_of(aid).label or aid
