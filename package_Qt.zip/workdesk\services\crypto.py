"""暗号化サービス（AES-GCM / PBKDF2-HMAC-SHA256）。

- パスフレーズ → PBKDF2 で 32byte 鍵を導出。鍵は資格情報マネージャーに保存（credstore）。
- salt / 検証子 / 「動作の secret_id → 暗号文」は単一ファイル secrets.json に保持。
- 検証子 = 固定平文を鍵で AES-GCM 暗号化したもの。復号できればパスフレーズ正しい。
- コピー機能は `decrypt(secret_id)` で平文を取り出す（失敗は待ちに入る前に FAILED）。

secrets.json:
{
  "kdf": {"algo": "pbkdf2-sha256", "iterations": N, "salt": "<b64>"},
  "verifier": {"nonce": "<b64>", "ct": "<b64>"},
  "secrets": {"<secret_id>": {"nonce": "<b64>", "ct": "<b64>"}}
}
"""

from __future__ import annotations

import base64
import json
import os
from pathlib import Path

from . import credstore

_VERIFIER_PLAINTEXT = b"workdesk-verifier-v1"
_KDF_ITERATIONS = 600_000
_CRED_TARGET = "WorkDeskLauncher"


class CryptoError(Exception):
    pass


def _b64e(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))


class CryptoService:
    def __init__(self, secrets_path: str | os.PathLike[str], cred_target: str = _CRED_TARGET) -> None:
        self._path = Path(secrets_path)
        self._cred_target = cred_target
        self._key: bytes | None = None
        self._data = self._load()

    # --- ファイル ------------------------------------------------- #
    def _load(self) -> dict:
        if self._path.exists():
            return json.loads(self._path.read_text(encoding="utf-8"))
        return {"kdf": None, "verifier": None, "secrets": {}}

    def _save(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self._path.with_suffix(self._path.suffix + ".tmp")
        tmp.write_text(json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(tmp, self._path)

    # --- 状態 --------------------------------------------------- #
    def is_configured(self) -> bool:
        return bool(self._data.get("verifier"))

    @property
    def unlocked(self) -> bool:
        return self._key is not None

    def lock(self) -> None:
        """メモリ上の鍵を捨てる。**テスト専用**（製品コードに施錠の動線は無い＝
        鍵はプロセス終了まで保持し、別端末では起動時に解錠を促す）。"""
        self._key = None

    # --- 暗号プリミティブ -------------------------------------- #
    @staticmethod
    def _derive(passphrase: str, salt: bytes, iterations: int) -> bytes:
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

        return PBKDF2HMAC(
            algorithm=hashes.SHA256(), length=32, salt=salt, iterations=iterations
        ).derive(passphrase.encode("utf-8"))

    @staticmethod
    def _enc(key: bytes, plaintext: bytes) -> dict:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        nonce = os.urandom(12)
        ct = AESGCM(key).encrypt(nonce, plaintext, None)
        return {"nonce": _b64e(nonce), "ct": _b64e(ct)}

    @staticmethod
    def _dec(key: bytes, blob: dict) -> bytes:
        from cryptography.exceptions import InvalidTag
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM

        try:
            return AESGCM(key).decrypt(_b64d(blob["nonce"]), _b64d(blob["ct"]), None)
        except InvalidTag as e:
            raise CryptoError("復号に失敗しました（パスフレーズ不一致または破損）") from e

    # --- 初期化 / 解錠 -------------------------------------- #
    def setup(self, passphrase: str) -> None:
        if self.is_configured():
            raise CryptoError("すでに初期化済みです")
        salt = os.urandom(16)
        key = self._derive(passphrase, salt, _KDF_ITERATIONS)
        self._data["kdf"] = {
            "algo": "pbkdf2-sha256", "iterations": _KDF_ITERATIONS, "salt": _b64e(salt),
        }
        self._data["verifier"] = self._enc(key, _VERIFIER_PLAINTEXT)
        self._data.setdefault("secrets", {})
        self._save()
        self._key = key
        credstore.set_secret(self._cred_target, key)

    def unlock(self, passphrase: str) -> bool:
        if not self.is_configured():
            return False
        kdf = self._data["kdf"]
        key = self._derive(passphrase, _b64d(kdf["salt"]), int(kdf["iterations"]))
        try:
            self._dec(key, self._data["verifier"])
        except CryptoError:
            return False
        self._key = key
        credstore.set_secret(self._cred_target, key)
        return True

    def load_from_store(self) -> bool:
        if not self.is_configured():
            return False
        blob = credstore.get_secret(self._cred_target)
        if not blob:
            return False
        try:
            self._dec(blob, self._data["verifier"])
        except CryptoError:
            return False
        self._key = blob
        return True

    # --- 暗号文 ---------------------------------------------- #
    def has_secret(self, secret_id: str) -> bool:
        return secret_id in self._data.get("secrets", {})

    def encrypt(self, secret_id: str, plaintext: str) -> None:
        if not self.unlocked:
            raise CryptoError("暗号鍵がロックされています")
        self._data.setdefault("secrets", {})[secret_id] = self._enc(
            self._key, plaintext.encode("utf-8")
        )
        self._save()

    def decrypt(self, secret_id: str) -> str:
        if not self.unlocked:
            raise CryptoError("暗号鍵がロックされています")
        blob = self._data.get("secrets", {}).get(secret_id)
        if blob is None:
            raise CryptoError("暗号文が見つかりません")
        return self._dec(self._key, blob).decode("utf-8")

    def remove_secret(self, secret_id: str) -> None:
        if self._data.get("secrets", {}).pop(secret_id, None) is not None:
            self._save()

    # --- パスフレーズ変更（UI は後日 / 共通設定） ------------ #
    def change_passphrase(self, current: str, new: str) -> bool:
        if not self.unlock(current):
            return False
        old_key = self._key
        salt = os.urandom(16)
        new_key = self._derive(new, salt, _KDF_ITERATIONS)
        new_secrets = {
            sid: self._enc(new_key, self._dec(old_key, blob))
            for sid, blob in self._data.get("secrets", {}).items()
        }
        self._data["kdf"] = {
            "algo": "pbkdf2-sha256", "iterations": _KDF_ITERATIONS, "salt": _b64e(salt),
        }
        self._data["verifier"] = self._enc(new_key, _VERIFIER_PLAINTEXT)
        self._data["secrets"] = new_secrets
        self._save()
        self._key = new_key
        credstore.set_secret(self._cred_target, new_key)
        return True


class FakeCrypto:
    """テスト・ヘッドレス用。cryptography も資格情報マネージャーも使わない。"""

    def __init__(self) -> None:
        self._configured = False
        self._pass: str | None = None
        self._key: str | None = None
        self._secrets: dict[str, tuple[str, str]] = {}

    def is_configured(self) -> bool:
        return self._configured

    @property
    def unlocked(self) -> bool:
        return self._key is not None

    def lock(self) -> None:
        self._key = None

    def setup(self, passphrase: str) -> None:
        if self._configured:
            raise CryptoError("すでに初期化済みです")
        self._configured = True
        self._pass = passphrase
        self._key = passphrase

    def unlock(self, passphrase: str) -> bool:
        if self._configured and passphrase == self._pass:
            self._key = passphrase
            return True
        return False

    def load_from_store(self) -> bool:
        return False

    def has_secret(self, secret_id: str) -> bool:
        return secret_id in self._secrets

    def encrypt(self, secret_id: str, plaintext: str) -> None:
        if not self.unlocked:
            raise CryptoError("暗号鍵がロックされています")
        self._secrets[secret_id] = (self._key, plaintext)

    def decrypt(self, secret_id: str) -> str:
        if not self.unlocked:
            raise CryptoError("暗号鍵がロックされています")
        entry = self._secrets.get(secret_id)
        if entry is None:
            raise CryptoError("暗号文が見つかりません")
        key, pt = entry
        if key != self._key:
            raise CryptoError("復号に失敗しました")
        return pt

    def remove_secret(self, secret_id: str) -> None:
        self._secrets.pop(secret_id, None)

    def change_passphrase(self, current: str, new: str) -> bool:
        if not self.unlock(current):
            return False
        self._secrets = {sid: (new, pt) for sid, (_k, pt) in self._secrets.items()}
        self._pass = new
        self._key = new
        return True
