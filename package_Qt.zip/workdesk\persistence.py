"""階層データ（AppData）の JSON ロード / セーブ。

- 単一ファイル。第1版では階層＋共通設定をまとめて保持する。
- 保存は「一時ファイルへ書いて置換」で原子的に行う（マイドライブ同期中の破損を避ける）。
- 想定パス: exe（またはエントリスクリプト）と同じフォルダの ``workdesk.json``。
"""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path

from .model import AppData

DEFAULT_FILENAME = "workdesk.json"


def base_dir() -> Path:
    """データファイル（workdesk.json / secrets.json / templates/）を置く基準フォルダ。

    - 通常実行（``python main.py``）: カレントフォルダ（従来どおり）。
    - PyInstaller で凍結（exe）: **exe と同じフォルダ**。
      ショートカットの「作業フォルダ」設定や二重起動でカレントが変わっても
      データの置き場所がぶれないよう、``sys.executable`` を基準にする
      （design-notes「2026-08-31 exe 化のためのパッケージング」）。
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path.cwd()


def default_path() -> Path:
    """基準フォルダ（:func:`base_dir`）の workdesk.json。"""
    return base_dir() / DEFAULT_FILENAME


def load(path: str | os.PathLike[str]) -> AppData:
    """存在しなければ空の AppData（既定設定つき）を返す。"""
    p = Path(path)
    if not p.exists():
        return AppData()
    with p.open(encoding="utf-8") as f:
        return AppData.from_dict(json.load(f))


# 置換のやり直し。OneDrive / Defender / エクスプローラのプレビューが保存先を
# 一瞬掴んでいると `os.replace` が PermissionError (WinError 5) で落ちる。
# **同期フォルダに置く前提のアプリなので一度で諦めない**
# （2026-09-05 実機で「グループを分ける」の保存が飛んだ）。
# 待ち時間は 0.05 → 0.25 秒と伸ばし、合計 0.75 秒まで粘る。
_REPLACE_RETRIES = 6
_REPLACE_WAIT_S = 0.05


def _replace_with_retry(tmp: Path, dest: Path) -> None:
    """`os.replace`（原子的置換）を数回やり直す。最後まで駄目なら送出する。"""
    for i in range(_REPLACE_RETRIES):
        try:
            os.replace(tmp, dest)
            return
        except PermissionError:
            if i == _REPLACE_RETRIES - 1:
                raise           # 呼び出し側（view）が知らせる。**握り潰さない**
            time.sleep(_REPLACE_WAIT_S * (i + 1))


def save(path: str | os.PathLike[str], data: AppData) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(data.to_dict(), f, ensure_ascii=False, indent=2)
        f.write("\n")
    # 同一ボリューム内の原子的置換（失敗したら .tmp は残す＝新しい内容の唯一の控え）
    _replace_with_retry(tmp, p)
