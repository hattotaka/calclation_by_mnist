"""枠なし窓の自作タイトル帯とリサイズ枠。Tk 版 `view/titlebar.py` の Qt 版（Phase 4g）。

帯に載るもの（2026-09-05「デザインラボ・設定ボタンをサイドバー最下部へ」で更新）:

    [ WorkDesk Launcher ] [Customize(スイッチ)]  …  [－] [✕]

**設定モードのスイッチが帯にある**のがこの設計の要。スイッチ ON ＝ 編集ウィンドウが開き、
タスクは実行しない。**デザインラボ／設定への導線はサイドバー最下部のフッター**
（`sidebar.py`）── 以前は帯にあったが、Tk 版と同じ位置に戻した。

## OS のモーダルループを使わない（恒久ルール。CLAUDE.md §3）

窓の移動もリサイズも**自前のマウスイベントで行う**。`QWindow.startSystemMove()` /
`startSystemResize()` は OS の移動／リサイズループに入るが、これは Tk 版で
`SendMessage(WM_NCLBUTTONDOWN, …)` を使って踏んだのと同じ形 ── `WH_KEYBOARD_LL` の
フックスレッドのポンプと再入して `PyEval_RestoreThread: GIL not held` で即クラッシュした。
Qt なら安全かもしれないが**確かめていない**ので、確実な側に倒す。

リサイズは窓の四辺・四隅に置いた 6px の透明なつまみ（`_Grip`）で行う。
`QSizeGrip` を使わないのも同じ理由（Qt6 の実装は `startSystemResize` を呼ぶ）。
"""

from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QPoint, QSize, Qt, Signal
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget

from .. import theme_tokens as T
from . import icons
from .uikit import pal as _pal

# 帯のスイッチの名前。サイドバーの見出し（`Menu` / `Tools`）と同じ層＝
# **英語＝場所やモードの名前**（2026-09-07 ユーザー判断）。「設定」ではなく
# 「自分用に作り替える」モードなので `Customize`（設定＝`Tools` の中身は別物）。
MODE_TEXT = "Customize"
BAR_HEIGHT = 34
BAR_ICON = 12               # 帯の最小化 / 閉じるアイコンの大きさ
GRIP = 6                    # 辺のリサイズつまみの太さ（見えない）
CORNER = 22                 # 右下だけ大きく、**見える**つまみにする（2026-09-05 要望。
                            # 2026-09-06 に 16→22＝フッターが消えて掴みにくくなったため）
_DOT_SIZE = 2               # つまみの点の大きさ（px）
_DOT_STEP = 4               # 点の間隔（px）
_DOT_MARGIN = 3             # 右下の角から点までの余白（px）
MIN_W, MIN_H = 560, 380


class _BarButton(QPushButton):
    """帯の右端のボタン（最小化 / 閉じる）。**アイコンは `QPainter` で描く**。

    以前は文字の `－` `✕` だった（2026-09-06 に変更）。文字だと他のアイコンと
    線の太さが揃わず、縦位置もフォント依存でずれる。

    ホバーで面の色が変わるので、**アイコンの色もそのとき描き直す**
    ── QSS の `color` は `QIcon` には効かない。
    """

    def __init__(self, icon_name: str, hover_ink: Callable[[], str],
                 parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._icon_name = icon_name
        self._hover_ink = hover_ink
        self._hover = False
        self.setIconSize(QSize(BAR_ICON, BAR_ICON))

    def enterEvent(self, _e) -> None:   # noqa: N802
        self._hover = True
        self.restyle()

    def leaveEvent(self, _e) -> None:   # noqa: N802
        self._hover = False
        self.restyle()

    def restyle(self) -> None:
        """テーマ切替とホバーの両方から呼ぶ（色を焼き込んであるので取り直す）。"""
        color = self._hover_ink() if self._hover else _pal("sub")
        pm = icons.pixmap(self._icon_name, color, BAR_ICON)
        self.setIcon(QIcon(pm) if pm is not None else QIcon())


class TitleBar(QWidget):
    """アプリ名 ＋ 設定モードのスイッチ ＋ パネルの導線 ＋ 最小化 / 閉じる。"""

    modeToggled = Signal(bool)
    sendToBackRequested = Signal()
    minimizeRequested = Signal()
    closeRequested = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("titleBar")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedHeight(BAR_HEIGHT)

        h = QHBoxLayout(self)
        h.setContentsMargins(12, 0, 6, 0)
        h.setSpacing(8)

        self.title = QLabel("WorkDesk Launcher")
        self.title.setObjectName("barTitle")
        h.addWidget(self.title)

        self.mode_switch = QPushButton(MODE_TEXT)
        self.mode_switch.setObjectName("modeSwitch")
        self.mode_switch.setCheckable(True)
        self.mode_switch.setCursor(Qt.PointingHandCursor)
        self.mode_switch.setFocusPolicy(Qt.NoFocus)
        self.mode_switch.toggled.connect(self.modeToggled.emit)
        h.addWidget(self.mode_switch)

        # デザインラボ／設定への導線は**サイドバー最下部のフッター**へ移した
        # （2026-09-05 要望。Tk 版と同じ位置に戻す）。帯にはモードスイッチだけ残す。
        h.addStretch(1)

        self.min_button = _BarButton("minimize", lambda: _pal("ink"))
        self.min_button.setObjectName("barButton")
        # 閉じるはホバーで赤い面になる（Windows の作法）。その上に乗る色にする。
        self.close_button = _BarButton("close", lambda: T.tinted_ink(_pal("row_fail")))
        self.close_button.setObjectName("closeButton")
        for b, sig in ((self.min_button, self.minimizeRequested),
                       (self.close_button, self.closeRequested)):
            b.setFixedWidth(38)
            b.setCursor(Qt.PointingHandCursor)
            b.setFocusPolicy(Qt.NoFocus)
            b.clicked.connect(sig.emit)
            h.addWidget(b)

        self._press: QPoint | None = None
        self.apply_theme()

    # --- 帯のドラッグ（**OS の移動ループは使わない**） ---------------- #
    def mousePressEvent(self, e) -> None:   # noqa: N802
        if e.button() == Qt.LeftButton:
            win = self.window()
            self._press = e.globalPosition().toPoint() - win.frameGeometry().topLeft()

    def mouseMoveEvent(self, e) -> None:   # noqa: N802
        if self._press is not None and e.buttons() & Qt.LeftButton:
            self.window().move(e.globalPosition().toPoint() - self._press)

    def mouseReleaseEvent(self, _e) -> None:   # noqa: N802
        self._press = None

    def mouseDoubleClickEvent(self, e) -> None:   # noqa: N802
        """帯（＝死んだ面）のダブルクリックで最背面へ（Tk 版からの移植）。

        対話要素の上では起きない（ボタンが先に受ける）。判定間隔は OS 設定に従う。
        """
        if e.button() == Qt.LeftButton and T.STATE.get("send_to_back_dblclick", True):
            self.sendToBackRequested.emit()

    # --- 状態 ---------------------------------------------------------- #
    def set_mode(self, on: bool) -> None:
        """スイッチと窓の状態は**同じもののふたつの見え方**（信号は出さない）。"""
        if self.mode_switch.isChecked() != on:
            self.mode_switch.blockSignals(True)
            self.mode_switch.setChecked(on)
            self.mode_switch.blockSignals(False)
        self.apply_theme()

    def apply_theme(self) -> None:
        """**自分のトークンで塗る**（qt-material の既定は 18/26 テーマで AA 未満）。"""
        on = self.mode_switch.isChecked()
        switch = (("background:%s;color:%s;border:1px solid %s;"
                   % (_pal("accent"), _pal("on_accent"), _pal("accent"))) if on
                  else ("background:transparent;color:%s;border:1px solid %s;"
                        % (_pal("sub"), _pal("input_border"))))
        fail = _pal("row_fail")
        self.setStyleSheet(
            "#titleBar{background:%(bg)s;border:none;border-bottom:1px solid %(div)s;}"
            "#barTitle{color:%(ink)s;background:transparent;border:none;font-weight:600;}"
            # qt-material の `QPushButton` は `text-transform:uppercase` を持つ。
            # 日本語のときは効かなかったが、英語にすると `CUSTOMIZE` と叫ぶ形になる
            # ── サイドバーの見出し（`Menu` / `Tools`）と同じ静かさに揃える
            # （2026-09-07）。
            "#modeSwitch{%(switch)s border-radius:5px;padding:3px 10px;"
            "text-transform:none;}"
            "#barButton{background:transparent;color:%(sub)s;border:none;"
            "border-radius:5px;padding:3px 10px;}"
            "#barButton:hover{background:%(hover)s;color:%(ink)s;}"
            "#closeButton{background:transparent;color:%(sub)s;border:none;"
            "border-radius:5px;padding:3px 10px;}"
            "#closeButton:hover{background:%(fail)s;color:%(fail_ink)s;}"
            % {"bg": _pal("bg"), "div": _pal("divider"), "ink": _pal("ink"),
               "sub": _pal("sub"), "hover": _pal("row_hover"), "switch": switch,
               "fail": fail, "fail_ink": T.tinted_ink(fail)})
        self.min_button.restyle()           # アイコンは色を焼き込んである
        self.close_button.restyle()


class _Grip(QWidget):
    """窓の縁のつまみ。**自前でジオメトリを更新する**（OS ループを使わない）。

    右下だけ `visible_mark=True` で**点の三角**を描く（掴める場所が見えるように。
    2026-09-05 要望 → 2026-09-06 に斜線から点のグリッドへ。線だと 3 本の向きが
    強く出るが、点は「ざらついた面」に見えるので主張が弱く、掴み代の広さは
    かえって伝わる）。`QSizeGrip` は使わない ── Qt6 の実装は `startSystemResize()` を
    呼ぶので、この窓では踏んではいけない道（モジュール冒頭の説明）。
    """

    def __init__(self, window, edges: str, *, visible_mark: bool = False) -> None:
        super().__init__(window)
        self._win = window
        self._edges = edges                 # "l" / "r" / "t" / "b" の組み合わせ
        self._visible_mark = visible_mark
        self.setCursor(self._cursor())
        self._start = None
        self._geo = None

    def paintEvent(self, _e) -> None:   # noqa: N802
        """点を三角に並べる（右下の角に向かって密になる）。

        点は 2x2 px・間隔 `_DOT_STEP`。**掴める領域いっぱい**に敷くので、
        つまみを大きくしたぶんが見た目にも出る（2026-09-06 要望）。
        """
        if not self._visible_mark:
            return
        from PySide6.QtGui import QColor, QPainter

        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, False)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(_pal("rail")))
        w, h = self.width(), self.height()
        rows = max(1, (min(w, h) - _DOT_MARGIN) // _DOT_STEP)
        for r in range(rows):                      # 下から上へ
            y = h - _DOT_MARGIN - r * _DOT_STEP
            for c in range(rows - r):              # 右から左へ（三角に減らす）
                x = w - _DOT_MARGIN - c * _DOT_STEP
                p.drawRect(x, y, _DOT_SIZE, _DOT_SIZE)
        p.end()

    def _cursor(self):
        if self._edges in ("lt", "rb"):
            return Qt.SizeFDiagCursor
        if self._edges in ("rt", "lb"):
            return Qt.SizeBDiagCursor
        return Qt.SizeHorCursor if self._edges in ("l", "r") else Qt.SizeVerCursor

    def mousePressEvent(self, e) -> None:   # noqa: N802
        if e.button() == Qt.LeftButton:
            self._start = e.globalPosition().toPoint()
            self._geo = self._win.geometry()

    def mouseMoveEvent(self, e) -> None:   # noqa: N802
        if self._start is None:
            return
        d = e.globalPosition().toPoint() - self._start
        g = self._geo
        left, top, right, bottom = g.left(), g.top(), g.right(), g.bottom()
        if "l" in self._edges:
            left = min(left + d.x(), right - MIN_W)
        if "r" in self._edges:
            right = max(right + d.x(), left + MIN_W)
        if "t" in self._edges:
            top = min(top + d.y(), bottom - MIN_H)
        if "b" in self._edges:
            bottom = max(bottom + d.y(), top + MIN_H)
        self._win.setGeometry(left, top, right - left + 1, bottom - top + 1)

    def mouseReleaseEvent(self, _e) -> None:   # noqa: N802
        self._start = self._geo = None

    def restyle(self) -> None:
        if self._visible_mark:
            self.update()


class ResizeGrips:
    """窓の四辺・四隅に `_Grip` を配置する。`relayout()` を `resizeEvent` から呼ぶ。"""

    EDGES = ("l", "r", "t", "b", "lt", "rt", "lb", "rb")

    def __init__(self, window) -> None:
        self._win = window
        self._grips = {e: _Grip(window, e, visible_mark=(e == "rb"))
                       for e in self.EDGES}
        self.relayout()

    def relayout(self) -> None:
        """つまみを窓の縁へ置き直す。**右下だけ大きい**（見えるつまみ）。"""
        w, h, g, c = self._win.width(), self._win.height(), GRIP, CORNER
        rects = {
            "l": (0, g, g, h - g - c), "r": (w - g, g, g, h - g - c),
            "t": (g, 0, w - 2 * g, g), "b": (g, h - g, w - g - c, g),
            "lt": (0, 0, g, g), "rt": (w - g, 0, g, g),
            "lb": (0, h - g, g, g), "rb": (w - c, h - c, c, c),
        }
        for e, grip in self._grips.items():
            grip.setGeometry(*rects[e])
            grip.raise_()

    def restyle(self) -> None:
        """テーマが変わったら見えるつまみを描き直す。"""
        for grip in self._grips.values():
            grip.restyle()


def round_corners(window) -> None:
    """Win11 の角丸を明示要求する（対応していない OS では黙って何もしない）。"""
    try:
        import ctypes

        hwnd = int(window.winId())
        # DWMWA_WINDOW_CORNER_PREFERENCE = 33 / DWMWCP_ROUND = 2
        value = ctypes.c_int(2)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            ctypes.c_void_p(hwnd), 33, ctypes.byref(value), ctypes.sizeof(value))
    except Exception:  # noqa: BLE001  見た目の付加なので失敗しても続行する
        pass


def set_titlebar_dark_mode(window, dark: bool) -> None:
    """編集ウィンドウ・デザインラボ・設定パネルは**枠なし窓ではない**ので
    タイトルバー・枠は OS が描く。Windows は既定でこれを明るいまま描くため、
    ダークテーマ中は「窓枠のすぐ内側だけ明るい」帯に見える（2026-09-05 実機の指摘）。
    ライトテーマでは呼ばない側の責任（暗くしっぱなしにしない）。

    **表示中に呼ぶ（テーマの生切替え）ときは属性を変えるだけでは帯が塗り直されない**
    ── DWM は非クライアント領域（タイトルバー）を必要になるまで再描画しないため。
    `SetWindowPos` に `SWP_FRAMECHANGED` を立てて明示的に再計算・再描画させる
    （2026-09-05 実機で発覚。ダーク→ライトへ切り替えても帯だけ黒いままだった）。

    **前面に無い窓は `SWP_FRAMECHANGED` だけでは塗り替わらないことがある**
    （2026-09-06 実機の指摘＝デザインラボと編集ウィンドウを両方開いた状態で
    ダーク⇔ライトを切り替えると、非アクティブな方の帯が中途半端な色で残る）。
    非クライアント領域を明示的に無効化して**その場で**描き直させる
    （`RedrawWindow` に `RDW_FRAME | RDW_INVALIDATE | RDW_UPDATENOW`）。
    """
    try:
        import ctypes

        hwnd = int(window.winId())
        value = ctypes.c_int(1 if dark else 0)
        size = ctypes.sizeof(value)
        for attr in (20, 19):       # 20=DWMWA_USE_IMMERSIVE_DARK_MODE
            # 19 は Windows 10 の古いビルドでの旧番号。新しい OS では
            # 失敗するだけなので両方投げる（戻り値は見ない）。
            ctypes.windll.dwmapi.DwmSetWindowAttribute(
                ctypes.c_void_p(hwnd), attr, ctypes.byref(value), size)
        # SWP_NOSIZE=0x1, SWP_NOMOVE=0x2, SWP_NOZORDER=0x4,
        # SWP_NOACTIVATE=0x10, SWP_FRAMECHANGED=0x20
        flags = 0x1 | 0x2 | 0x4 | 0x10 | 0x20
        ctypes.windll.user32.SetWindowPos(
            ctypes.c_void_p(hwnd), None, 0, 0, 0, 0, flags)
        # RDW_INVALIDATE=0x1, RDW_UPDATENOW=0x100, RDW_FRAME=0x400
        ctypes.windll.user32.RedrawWindow(
            ctypes.c_void_p(hwnd), None, None, 0x1 | 0x100 | 0x400)
    except Exception:  # noqa: BLE001  見た目の付加なので失敗しても続行する
        pass
