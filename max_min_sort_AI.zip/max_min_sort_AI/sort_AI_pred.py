import numpy as np
import chainer.functions as F
import chainer.links as L
from chainer import Variable, Chain, serializers
import copy

INPUT_STRING = '0123456789+'
OUTPUT_STRING = '0123456789+'

def encode_in(a, args):
    alphabet = np.array(list(INPUT_STRING))
    texts = np.array(['{}+{}+{}+{}'.format(str(a_[0]).rjust(args.numbersize, '0'), 
                                           str(a_[1]).rjust(args.numbersize, '0'), 
                                           str(a_[2]).rjust(args.numbersize, '0'), 
                                           str(a_[3]).rjust(args.numbersize, '0')) for a_ in a ])
    return np.array([[alphabet == c for c in s] for s in texts]).astype(np.float32)

def encode_out(b, args):
    texts = np.array(['{}{}{}{}'.format(str(b_[0]).rjust(args.numbersize, '0'), 
                                        str(b_[1]).rjust(args.numbersize, '0'), 
                                        str(b_[2]).rjust(args.numbersize, '0'), 
                                        str(b_[3]).rjust(args.numbersize, '0')) for b_ in b ])
    return np.array([[OUTPUT_STRING.index(c) for c in s] for s in texts]).astype(np.int32)
 
class Model(Chain):
    def __init__(self, unit):
        super(Model, self).__init__(
            l1=L.Linear(len(INPUT_STRING), unit),
            l2=L.LSTM(unit, unit),
            l3=L.Linear(unit, len(OUTPUT_STRING)),
        )
    def forward(self, x, k):
        self.l2.reset_state()
        for i in range(x.shape[1]):
            h = F.relu(self.l1( Variable(x[:, i, :]) ))
            h = self.l2(h)
        result = []
        for i in range(k):
            h = F.relu(h)
            h = self.l2(h)
            result += [ self.l3(h) ]
        return result
 
def init(args, filename, model_load_flg):
    model = Model(args.unit)
    if model_load_flg == True:
        serializers.load_npz(filename, model)
    return model

def pred(model, args, a, b):
    x = np.array(encode_in(a, args))
    y = model.forward(x, args.numbersize * args.numbercnt)
    str_a = ''
    str_b = ''
    for i in range(len(a[0])):
        str_a = str(str_a) + str(a[0][i]).rjust(args.numbersize, '0')
        str_b = str(str_b) + str(b[0][i]).rjust(args.numbersize, '0')
        c = ''.join([OUTPUT_STRING[int(y_.data[0].argmax())] for y_ in y])
    print(a, ', ', str_b, ', ' , c, str_b == c)

def main(args):
    for i in range(30):
        d = 1
        c = np.random.randint(100-d)
        a = [[np.random.randint(d) + c, np.random.randint(d) + c, np.random.randint(d) + c, np.random.randint(d) + c]]
    #    a = [[31,30,32,33]]
        b = copy.deepcopy(a)
        b[0].sort()
        
        filename = r'model\model_sort_AI_2_590.npz'
        model = init(args, filename, True)
        pred(model, args, a, b)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--unit', type=int, default=200)
    parser.add_argument('--numbersize', type=int, default=2)
    parser.add_argument('--numbercnt', type=int, default=4)
    args = parser.parse_args()
    main(args)