#from __future__ import print_function
import numpy as np
import chainer
import chainer.functions as F
import chainer.links as L
from chainer import Variable, optimizers, Chain, serializers
import sys
import csv
INPUT_STRING = '0123456789+'
OUTPUT_STRING = '0123456789+'

def generate(numbersize, datasize, numbercnt):
    a = []
    b = []
    a_tmp = ''
    
    #全体から乱数取得
    for i in range(10000):
        a_tmp = [int(np.random.uniform(0, pow(10, numbersize) - 1)) for j in range(numbercnt)]
        a.append(a_tmp)

    for i in range(100):
        for j in range(100):
            a_tmp = [int(np.random.uniform(0, 9) + i * 10) for k in range(numbercnt)]
            a.append(a_tmp)

    for i in range(20):
        for j in range(500):
            a_tmp = [int(np.random.uniform(0, 49) + i * 50) for k in range(numbercnt)]
            a.append(a_tmp)

    for i in range(10):
        for j in range(1000):
            a_tmp = [int(np.random.uniform(0, 99) + i * 100) for k in range(numbercnt)]
            a.append(a_tmp)

    for i in range(5):
        for j in range(2000):
            a_tmp = [int(np.random.uniform(0, 199) + i * 200) for k in range(numbercnt)]
            a.append(a_tmp)

    for i in range(2):
        for j in range(5000):
            a_tmp = [int(np.random.uniform(0, 499) + i * 500) for k in range(numbercnt)]
            a.append(a_tmp)

    for a_ in a:
        b.append([max(a_)])
    return a, b

def generate_for_test(numbersize, datasize, numbercnt):
    a = [[int(np.random.uniform(0, pow(10, numbersize) - 1)) for i in range(numbercnt)] for j in range(datasize)]
    b = []
    for a_ in a:
        b.append([max(a_)])
    return a, b

def encode_in(a, args):
    alphabet = np.array(list(INPUT_STRING))
    texts = np.array(['{}+{}+{}+{}'.format(str(a_[0]).rjust(args.numbersize, '0'), 
                                           str(a_[1]).rjust(args.numbersize, '0'), 
                                           str(a_[2]).rjust(args.numbersize, '0'), 
                                           str(a_[3]).rjust(args.numbersize, '0')) for a_ in a ])
    return np.array([[alphabet == c for c in s] for s in texts]).astype(np.float32)

def encode_out(b, args):
    texts = np.array(['{}'.format(str(b_[0]).rjust(args.numbersize, '0')) for b_ in b ])
    return np.array([[OUTPUT_STRING.index(c) for c in s] for s in texts]).astype(np.int32)
 
class Model(Chain):
    def __init__(self, unit):
        super(Model, self).__init__(
            l1=L.Linear(len(INPUT_STRING), unit),
            l2=L.LSTM(unit, unit),
            l3=L.Linear(unit, len(OUTPUT_STRING)),
        )
    def forward(self, x, k):
        self.l2.reset_state()
        for i in range(x.shape[1]):
            h = F.relu(self.l1( Variable(x[:, i, :]) ))
            h = self.l2(h)
        result = []
        for i in range(k):
            h = F.relu(h)
            h = self.l2(h)
            result += [ self.l3(h) ]
        return result
 
def init(args, filename, model_load_flg):
    model = Model(args.unit)
    if model_load_flg == True:
        serializers.load_npz(filename, model)

    optimizer = optimizers.Adam()
    optimizer.setup(model)
    optimizer.add_hook(chainer.optimizer.WeightDecay(0.0001))
    optimizer.add_hook(chainer.optimizer.GradientClipping(5.0))
    return model, optimizer

def train(model, optimizer, args):
    f = open(r"log/log_max_AI.csv", 'a')
    writer = csv.writer(f, lineterminator='\n')
    csvlist = []
    csvlist.append('epoch')
    csvlist.append('train accuracy')
    csvlist.append('test accuracy')
    csvlist.append('train loss')
    csvlist.append('test loss')
    writer.writerow(csvlist)
    f.close()

    train_a, train_b = generate(args.numbersize, args.datasize, args.numbercnt)
    x_train = encode_in(train_a, args)
    t_train = encode_out(train_b, args)
    test_a, test_b = generate_for_test(args.numbersize, args.testdatasize, args.numbercnt)
    x_test = np.array(encode_in(test_a, args))
    t_test = np.array(encode_out(test_b, args))


    for epoch in range(args.epochsize):
        f = open(r"log/log_max_AI.csv", 'a')
        writer = csv.writer(f, lineterminator='\n')
        csvlist = []
        csvlist.append(epoch + 1)
        print('epoch: %d' % (epoch + 1))

        #train
        sum_accu, sum_loss, sum_loss_train, sum_loss_test = 0, 0, 0, 0
        perm = np.random.permutation(args.datasize)
        for i in range(0, args.datasize, args.batchsize):
            indices = perm[i : i + args.batchsize]
            x = np.array(x_train[indices])
            t = np.array(t_train[indices])
            y = model.forward(x, args.numbersize)
            accu, loss = 0, 0
            for i in range(len(y)):
                ti = Variable(t[:, i])
                accu += F.accuracy(y[i], ti)
                loss += F.softmax_cross_entropy(y[i], ti)
            model.zerograds()
            loss.backward()
            loss.unchain_backward()
            optimizer.update()
 
            sum_accu += float(accu.data) * len(indices)
            sum_loss += float(loss.data) * len(indices)
 
        sum_accuracy_train = sum_accu / args.datasize
        sum_loss_train = sum_loss / args.datasize
        print('train accuracy: %0.3f'   % (sum_accuracy_train))
        print('train loss: %0.3f' % (sum_loss_train))

        for j in range(3):
            k = indices[j]
            str_train_a = ''
            str_train_b = ''
            for i in range(len(train_a[0])):
                str_train_a = str(str_train_a) + str(train_a[k][i]).rjust(args.numbersize, '0')
            for i in range(len(train_b[0])):
                str_train_b = str(str_train_b) + str(train_b[k][i]).rjust(args.numbersize, '0')            
            print(str_train_a, ', ', str_train_b, ', ' , ''.join([OUTPUT_STRING[int(y_.data[j].argmax())] for y_ in y]))
        sys.stdout.flush()

        #test
        sum_accu, sum_loss, sum_loss_test, sum_loss_test = 0, 0, 0, 0
        perm = np.random.permutation(args.testdatasize)
        for i in range(0, args.testdatasize, args.testbatchsize):
            indices = perm[i : i + args.testbatchsize]
            x = np.array(x_test[indices])
            t = np.array(t_test[indices])
            y = model.forward(x, args.numbersize)
            accu, loss = 0, 0
            for i in range(len(y)):
                ti = Variable(t[:, i])
                accu += F.accuracy(y[i], ti)
                loss += F.softmax_cross_entropy(y[i], ti)

            sum_accu += float(accu.data) * len(indices)
            sum_loss += float(loss.data) * len(indices)
            
        sum_accuracy_test = sum_accu / args.testdatasize
        sum_loss_test = sum_loss / args.testdatasize
        print('test accuracy: %0.3f'   % (sum_accuracy_test))
        print('test loss: %0.3f' % (sum_loss_test))

        for j in range(3):
            k = indices[j]
            str_test_a = ''
            str_test_b = ''
            for i in range(len(test_a[0])):
                str_test_a = str(str_test_a) + str(test_a[k][i]).rjust(args.numbersize, '0')
            for i in range(len(test_b[0])):
                str_test_b = str(str_test_b) + str(test_b[k][i]).rjust(args.numbersize, '0')                
            print(str_test_a, ', ', str_test_b, ', ' , ''.join([OUTPUT_STRING[int(y_.data[j].argmax())] for y_ in y]))
        sys.stdout.flush()

        csvlist.append(sum_accuracy_train)
        csvlist.append(sum_accuracy_test)
        csvlist.append(sum_loss_train)
        csvlist.append(sum_loss_test)
        writer.writerow(csvlist)
        f.close()

        serializers.save_npz(r"model/model_max_AI_" + str(epoch + 1) + ".npz", model)

def main(args):
    filename = r'model/model_max_AI.npz'
    filename = ''
    model, optimizer = init(args, filename, False)
    train(model, optimizer, args)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--unit', type=int, default=200)
    parser.add_argument('--datasize', type=int, default=60000)
    parser.add_argument('--testdatasize', type=int, default=10000)
    parser.add_argument('--batchsize', type=int, default=100)
    parser.add_argument('--testbatchsize', type=int, default=100)
    parser.add_argument('--epochsize', type=int, default=1000)
    parser.add_argument('--numbersize', type=int, default=3)
    parser.add_argument('--numbercnt', type=int, default=4)
    args = parser.parse_args()
    main(args)