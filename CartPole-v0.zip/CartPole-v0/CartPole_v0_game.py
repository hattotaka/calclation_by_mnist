import CartPole_v0_setting as C
from time import sleep

#setting
env, obs, agent = C.QSetting(r'CartPole-v0\step' + str(150), True)
obs = env.reset()

#game start
for t in range(1000):
    env.render()
    if t == 0:
        sleep(5)
    else:
        sleep(0.1)

    action = action = agent.act(obs)
    obs, reward, done, info = env.step(action)
    if done:
        break

#game end
sleep(3)
env.render(close=True)