import CartPole_v0_setting as C

#setting
env, obs, agent = C.QSetting('', False)

#train
import time
n_episodes = 200
max_episode_len = 200
start = time.time()
for i in range(1, n_episodes + 1):
    obs = env.reset()
    reward = 0
    done = False
    R = 0  # return (sum of rewards)
    t = 0  # time step
    while not done and t < max_episode_len:
        action = agent.act_and_train(obs, reward)
        obs, reward, done, _ = env.step(action)
        R += reward
        t += 1
    if i % 10 == 0:
        print('episode:', i,
              'R:', R,
              'statistics:', agent.get_statistics())
        agent.save(r'CartPole-v0\step' + str(i))
    agent.stop_episode_and_train(obs, reward, done)

    if i % 10 == 0:
        #test
        obs = env.reset()
        done = False
        R = 0
        t = 0
        while not done and t < 200:
            action = agent.act(obs)
            obs, r, done, _ = env.step(action)
            R += r
            t += 1
        print('test episode:', i, 'R:', R)
        agent.stop_episode()

print('Finished, elapsed time : {}'.format(time.time()-start))