"""見た目の「値」と色の理屈だけを持つモジュール（**GUI ツールキット非依存**）。

`view/theme.py` から純粋な部分を切り出したもの（design-notes「2026-09-04 …」Phase 2b/2d）。
Tkinter でも PySide6 でもそのまま使える:

- `STATE` / `PERSIST_KEYS` … ユーザーが変えられる外観の値（`settings.appearance` に永続化）
- `THEMES` / `PALETTE` … テーマ別の色トークン。**`PALETTE` は都度読む**（モジュール定数へ
  束縛するとテーマ切替で凍結する）
- 密度・チップ寸法・グループ色プリセット
- 色の理屈 … `lighten` / `mix` / `contrast` / `elevation_tint` / `tinted_ink` /
  `readable_ink` / `fit_tint` / `group_color`
- 変更の通知 … `subscribe` / `set_theme` / `set_option` / `set_group_color*`

**フォント・ttk スタイル・アイコン画像は持たない**（それらは `view/theme.py` 側）。
`_apply_theme` はツールキット側の後始末（アイコンキャッシュ破棄など）を
`on_palette_changed` のフックで呼ぶ。
"""

from __future__ import annotations

import colorsys
import math
from collections.abc import Callable

# PALETTE が差し替わった直後に呼ぶ後始末（ツールキット側が登録する）。
# 例: `view/theme.py` が `_icon_cache.clear` を入れる（色が変わるので作り直す）。
on_palette_changed: list[Callable[[], None]] = []

# --- 変更しうる状態（画面調整パネルが書き換える。settings に永続化） ---- #
STATE: dict[str, object] = {
    "theme": "light",                # light | dark（Tk 版の 2 テーマ。Qt 版は下の qt_theme を使う）
    # Qt 版のテーマ（qt-material のファイル名）。26 種から選ぶ。
    "qt_theme": "dark_cyan.xml",
    "font_family": "Yu Gothic UI",   # 未インストールなら init 時に実在候補へ寄せる
    "font_size": 12,                 # 基準サイズ
    "scrollbar_mode": "auto",        # always | auto | thin | hover
    "click_density": "normal",       # compact | normal | roomy
    # 業務グループの見せ方（Qt 版。design-notes 2026-09-04/05）。
    #   A=区切り線（既定。グループ間ドラッグの分かりやすさを優先）/ D=カード /
    #   E=レール(無彩色) / F=レール(グループ色)
    # **サイドバー専用**。メインパネルのタスクグループは常に区切り線。
    "group_style": "A",
    # 業務グループの色相の上書き（度。None or 範囲外は DEFAULT_GROUP_HUES へ）。
    # 旧 `group_colors`（hex の配列）の置き換え＝色相はユーザー / 明度彩度はテーマ。
    "group_hues": [],
    "box_margin": 14,              # 業務の色帯／タスクカードの左右マージン（枠・サイドバーとの距離）
}
# workdesk.json の settings に保存/復元するキー
PERSIST_KEYS: tuple[str, ...] = tuple(STATE)

# --- 色（テーマ別。§17 Fluent リスタイル） ------------------------- #
# `THEMES` は「テーマ名 → 色 dict」。3 種目（ネオン等）はキーを足すだけ。
# `PALETTE` は「現在テーマの色 dict」を指す名前として維持する
# （既存の `theme.PALETTE["x"]` 参照を壊さないよう、差し替えは
#  同じ dict オブジェクトの clear()+update() で行う＝再代入しない）。
# §17.7 ステージ3: 面を3段化（`bg` < `sidebar_bg` / `surface`(=row_normal)）＋淡い選択面
# `accent_soft`。実 hex は `THEMES` が正（design-notes §17.3 の表は当時の目安）。
THEMES: dict[str, dict[str, object]] = {
    "light": {
        "bg": "#f4f6f8",                # 窓／メインパネルの地色（面の最下段。行はこの上に浮く）
        "accent": "#2e6fa8",             # 選択／有効時の縦バー・枠色（フル・アクセント）
        # サイドバー最下部フッター（設定モード切替 / 共通設定）。枠色ではなく地色で状態を示す。
        "row_hover": "#e9edf2",         # タスク行のマウスオーバー地色（普段は地に溶け込む）
        # 層2（§7）の面＋文字（§17.7 ステージ6 で retune＋文字色トークンを新設）
        "row_fail": "#f6e3e7",          # 失敗 / 中止
        "divider": "#d3d9e0",           # 1px 罫（グループ区切りが見える濃さに）
        # 文字 3 段（§17.3）。現行は個別 fg 直書きだったのを集約。
        "ink": "#1a222b",               # 主要テキスト（旧 #333 / #333333 / #444）
        "sub": "#5b6672",               # 二次テキスト・要約・ヒント（旧 #555〜#888）
        "faint": "#8b95a1",             # プレースホルダ・OFF 状態・空メッセージ（旧 #999）
        "on_accent": "#ffffff",         # accent 塗りの上に載る文字・前景
        "input_border": "#cccccc",      # Entry / Listbox の resting 枠
        # 枠なしメイン窓（§16 ステージ3）
        # 設定モードの識別（帯・窓の縁取り・ペイン地色を暖色に）
    },
    "dark": {
        # 「真っ黒＝昔の PC」印象を避け、デザインラボ相当のスレート系に寄せた（§17 ユーザー指摘）。
        # VS Code / GitHub 等の現代的ダークは #1e1e1e〜#282c34 帯＝near-black は使わない。
        # 面3段は保つ：bg < sidebar_bg / surface、divider が 1px 枠に効く濃さ。
        "bg": "#262d37",               # 窓／メインパネル地色（デザインラボ相当のスレート。2026-08-31）
        # 業務グループ色の raw hue はライトと同じ＝`fit_tint()` がテーマ別に正規化する。
        "accent": "#74aee0",
        "row_hover": "#313a46",         # タスク行のマウスオーバー地色（bg より一段明るく）
        "row_fail": "#3b2a34",
        "divider": "#3d4653",          # 1px カード枠がちゃんと見える濃さ
        "ink": "#e9ecef",
        "sub": "#9aa4af",
        "faint": "#727c88",
        "on_accent": "#12161b",
        "input_border": "#4a5563",
    },
}

PALETTE: dict[str, object] = dict(THEMES["light"])

# クリック領域（行の内側余白）。side_* はサイドバー、row_* はメインパネル。
# §17.7 ステージ3: 「詰まって見える」対策で行内 pady を一段広げた（normal ≒10）。
_DENSITY: dict[str, dict[str, int]] = {
    "compact": {"row_padx": 10, "row_pady": 6, "side_padx": 9, "side_pady": 6},
    "normal": {"row_padx": 13, "row_pady": 10, "side_padx": 11, "side_pady": 9},
    "roomy": {"row_padx": 16, "row_pady": 14, "side_padx": 14, "side_pady": 12},
}

TOP_GAP = 10           # 帯（タイトルバー）と先頭の業務行／タスクカードの間の固定余白
# 「箱の左右マージン」`STATE["box_margin"]` はデザインラボから可変（§17 ユーザー要望）。
# 参照は `box_margin()`（下）。
# 帯からの隙間は固定値 `TOP_GAP`（下）── 以前はここも可変だったが、サイドバー
# 「業務」見出し／メインパネルの業務名見出しが既に同じ役目（先頭行の呼吸感）を
# 果たしているため冗長と判断し撤去した（2026-09-05）。

_subscribers: list[Callable[[str], None]] = []   # fn(changed_key)
_save_hook: Callable[[dict], None] | None = None


# --- 起動時 --------------------------------------------------------- #
def load_state(saved: dict) -> None:
    """workdesk.json の settings から復元（init より前に呼ぶ）。"""
    for k in PERSIST_KEYS:
        if k in saved:
            STATE[k] = saved[k]
    _apply_theme(str(STATE["theme"]))   # 復元したテーマ名を PALETTE へ反映（通知なし）


def set_save_hook(fn: Callable[[dict], None] | None) -> None:
    global _save_hook
    _save_hook = fn

def metrics() -> dict[str, int]:
    return _DENSITY[str(STATE["click_density"])]


def box_margin() -> int:
    """業務の色帯／タスクカードの左右マージン。

    `STATE["box_margin"]` に持つが**変更する UI は無い**。値を変えたいときは
    settings を直接編集する。
    """
    return int(STATE["box_margin"])


# --- 色ユーティリティ（ライト⇄ダークの色使いを1本の理屈で扱う） ------- #
def _hex_to_rgb(hx: str) -> tuple[float, float, float]:
    hx = hx.strip().lstrip("#")
    if len(hx) == 3:
        hx = "".join(c * 2 for c in hx)
    return (int(hx[0:2], 16) / 255, int(hx[2:4], 16) / 255, int(hx[4:6], 16) / 255)


def _rgb_to_hex(r: float, g: float, b: float) -> str:
    f = lambda v: max(0, min(255, round(v * 255)))  # noqa: E731
    return f"#{f(r):02x}{f(g):02x}{f(b):02x}"


# 背景色から導く「読める文字色」。テーマ既定の ink ではなく **実際に乗る地色** で決める
# （§17 ユーザー指摘: 文字色は背景色に合わせるべき＝全体の問題）。
_INK_ON_LIGHT = "#1e2733"
_INK_ON_DARK = "#e9ecef"


def lighten(hex_color: str, f: float) -> str:
    """`hex_color` を白へ f（0..1）だけ寄せる（業務チップのホバー面など）。"""
    try:
        r, g, b = _hex_to_rgb(hex_color)
    except Exception:  # noqa: BLE001
        return hex_color
    f = max(0.0, min(1.0, f))
    return _rgb_to_hex(r + (1 - r) * f, g + (1 - g) * f, b + (1 - b) * f)


def mix(a_hex: str, b_hex: str, t: float) -> str:
    """`a_hex` を `b_hex` へ t（0..1）だけ寄せた色。t=0 で a、t=1 で b。

    「地色から作った読める色」をそのまま線に使うと硬いので、地色側へ少し戻して
    和らげる用途（`lighten` は白へ寄せるだけなのでダークで使えない）。
    """
    try:
        ar, ag, ab = _hex_to_rgb(a_hex)
        br, bg, bb = _hex_to_rgb(b_hex)
    except Exception:  # noqa: BLE001
        return a_hex
    t = max(0.0, min(1.0, t))
    return _rgb_to_hex(ar + (br - ar) * t, ag + (bg - ag) * t, ab + (bb - ab) * t)


def _rel_lum(hex_color: str) -> float:
    """WCAG の相対輝度（コントラスト比の計算用）。"""
    def ch(v: float) -> float:
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4

    r, g, b = _hex_to_rgb(hex_color)
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)


def contrast(a_hex: str, b_hex: str) -> float:
    """2 色のコントラスト比（1.0〜21.0）。WCAG AA の通常文字は 4.5 以上。"""
    try:
        la, lb = _rel_lum(a_hex), _rel_lum(b_hex)
    except Exception:  # noqa: BLE001
        return 21.0
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


_INK_MIN_CONTRAST = 4.5   # WCAG AA（通常サイズの文字）


def tinted_ink(bg_hex: str) -> str:
    """`bg_hex` と **同じ色相**で、その上に載せて読める文字色。

    グループ色のチップに載る業務名のように「地色に色みがある面」向け
    （淡い青の上なら濃い青、淡い緑なら濃い緑）。明暗はテーマではなく
    **実際の地色の明るさ**で決めるので、ライト/ダークどちらでも同じ理屈で効く。
    無彩色に近い地色なら自然とグレーになる（色相が無いので）。

    明度は「まず狙いの値を置き、コントラスト比が `_INK_MIN_CONTRAST` に届かなければ
    届くまで地色から離す」＝どのグループ色を選んでも読めることを保証する
    （`fit_tint` のクランプで地色が中間の明るさに寄ることがあるため）。
    """
    try:
        r, g, b = _hex_to_rgb(bg_hex)
    except Exception:  # noqa: BLE001
        return readable_ink(bg_hex)
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    if l < 0.5:
        # 暗い地 → 明るい同系色（彩度は抑えないと目に刺さる）
        target, limit, step = min(0.90, l + 0.58), 1.0, +0.02
        s2 = min(max(s, 0.18), 0.42)
    else:
        # 明るい地 → 濃い同系色（彩度は少し上げると「同系統」がはっきりする）
        target, limit, step = max(0.17, l - 0.58), 0.0, -0.02
        s2 = min(max(s * 1.25, 0.22), 0.62)

    if s < 0.04:
        s2 = 0.0   # 無彩色の地には色相が無い＝グレーのまま濃く／淡くする
    ink = _rgb_to_hex(*colorsys.hls_to_rgb(h, target, s2))
    while contrast(bg_hex, ink) < _INK_MIN_CONTRAST:
        nxt = target + step
        if not (0.0 <= nxt <= 1.0) or abs(nxt - limit) < 1e-9:
            break
        target = nxt
        ink = _rgb_to_hex(*colorsys.hls_to_rgb(h, target, s2))
    return ink


def readable_ink(bg_hex: str) -> str:
    """`bg_hex` の上で読める文字色。**2 つの ink 極のうちコントラストが高い方**を返す。

    色相を持たない汎用の ink。**地色に色みがある面では `tinted_ink()`** を使う。

    旧実装は「ガンマ補正前の RGB で相対輝度を出し、0.5 のしきい値で選ぶ」だったが、
    中間輝度の色で誤る。Tk 版は固定 2 テーマ＋制御された面しか無かったので露見しなかったが、
    qt-material の 26 テーマのアクセント色では破綻した（2026-09-05 に発見）:
        #ff4081（dark_pink）… 暗い ink 4.52 / 明るい ink 2.81 なのに明るい方を選んでいた
    """
    try:
        _hex_to_rgb(bg_hex)
    except Exception:  # noqa: BLE001
        return str(PALETTE.get("ink", _INK_ON_LIGHT))
    dark_ink, light_ink = _INK_ON_LIGHT, _INK_ON_DARK
    return (dark_ink if contrast(dark_ink, bg_hex) >= contrast(light_ink, bg_hex)
            else light_ink)


def on_color(bg_hex: str, minimum: float = 4.5) -> str:
    """`bg_hex` を塗った上に載せる文字色。**`minimum` を必ず満たす**。

    `readable_ink` の 2 極（柔らかい濃紺 / 淡いグレー）で足りないときは純黒・純白まで
    エスカレートする。アクセント色は彩度が高く中間輝度のものがあり、2 極では届かない
    ことがある（実測: `#2979ff`（light_blue）は暗い ink 3.78 / 明るい ink 3.36 で、
    どちらも AA 4.5 に届かない。純黒なら 5.27）。
    """
    best = readable_ink(bg_hex)
    if contrast(best, bg_hex) >= minimum:
        return best
    for cand in ("#000000", "#ffffff"):
        if contrast(cand, bg_hex) >= minimum:
            return cand
    # どちらも届かない色（中間輝度の極彩色）＝ 取れる最大を返す
    return max(("#000000", "#ffffff", best), key=lambda c: contrast(c, bg_hex))


# --- 変更 --------------------------------------------------------- #
def subscribe(fn: Callable[[str], None]) -> None:
    """外観 STATE が変わったら `fn(changed_key)` を呼ぶ（App が最小再描画を選ぶ）。"""
    _subscribers.append(fn)


def unsubscribe(fn: Callable[[str], None]) -> None:
    try:
        _subscribers.remove(fn)
    except ValueError:
        pass


def _apply_theme(name: str) -> None:
    """`name` のテーマ色を `PALETTE`（同一 dict）へその場反映する（通知しない）。"""
    src = THEMES.get(name) or THEMES["light"]
    PALETTE.clear()
    PALETTE.update(src)
    for fn in list(on_palette_changed):   # ツールキット側の後始末（アイコン再生成など）
        try:
            fn()
        except Exception:  # noqa: BLE001
            pass


def set_palette(tokens: dict[str, object], *, dark: bool) -> None:
    """外部（Qt 版のテーマ橋渡し）が作った色トークンを `PALETTE` へ流し込む。

    Qt 版では色は `THEMES`（Tk 版の固定 2 テーマ）ではなく **qt-material の active テーマ
    から導出**する（design-notes「決めたこと」5）。この関数がその受け口。
    `PALETTE` は同じ dict オブジェクトのまま差し替える（参照側を壊さない）。
    `dark` は `tone()` が明度・彩度の目標を選ぶのに使う。
    """
    STATE["is_dark"] = bool(dark)
    PALETTE.clear()
    PALETTE.update(tokens)
    for fn in list(on_palette_changed):
        try:
            fn()
        except Exception:  # noqa: BLE001
            pass


def notify(changed: str) -> None:
    """`STATE` を直接書き換えたあとに、購読者と保存フックへ知らせる公開の口。

    `set_option()` を通せないもの（Qt のテーマ名は `qtheme.apply()` が
    副作用として書く）でも、これを呼べば永続化される。
    """
    _notify(changed)


def set_option(key: str, value: object) -> None:
    STATE[key] = value
    _notify(key)


def _notify(changed: str) -> None:
    """`changed` は変更されたキー。購読側（App）が必要最小限の再描画を選べる。"""
    for fn in list(_subscribers):
        try:
            fn(changed)
        except Exception:  # noqa: BLE001  パネル操作でアプリを落とさない
            pass
    if _save_hook is not None:
        try:
            _save_hook({k: STATE[k] for k in PERSIST_KEYS})
        except Exception:  # noqa: BLE001
            pass


# ==================================================================== #
# Qt 版で追加した色の理屈（design-notes「2026-09-04/05 …」スパイク6〜11）
#
# 決めごと: **色は必ず「目標から逆算」して作る。hex を直書きしない。**
#   面（カード・行の状態）      elevated_face(地, 目標CR)   … 常に白の方向へ
#   線・レール・枠              contrast_step(地, 目標CR)   … 文字色の方向へ
#   文字                        tinted_ink / readable_ink   … 既存
#   色みのある面（グループ色・
#   動作種別・実行状態）        tone(色相, ...)             … 色相が意味・明度彩度はテーマ
#
# これで qt-material の 26 テーマすべてで同じ見え方になる。
# ==================================================================== #

# --- OKLab / OKLCH（知覚均等な色空間。sRGB の HSL では代用できない） --- #
def _srgb_to_lin(c: float) -> float:
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _lin_to_srgb(c: float) -> float:
    return 12.92 * c if c <= 0.0031308 else 1.055 * (c ** (1 / 2.4)) - 0.055


def to_oklab(hex_color: str) -> tuple[float, float, float]:
    """sRGB の hex を OKLab (L, a, b) へ。"""
    r, g, b = (_srgb_to_lin(c) for c in _hex_to_rgb(hex_color))
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    l_, m_, s_ = l ** (1 / 3), m ** (1 / 3), s ** (1 / 3)
    return (
        0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_,
        1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_,
        0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_,
    )


def _oklab_to_linear(L: float, a: float, b: float) -> tuple[float, float, float]:
    """OKLab から**クランプ前**の線形 RGB。ガモット判定はこの生の値で行う。"""
    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    return (
        +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
        -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
        -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s,
    )


def from_oklab(L: float, a: float, b: float) -> str:
    """OKLab から sRGB の hex へ（範囲外はクランプ）。"""
    lin = _oklab_to_linear(L, a, b)
    return _rgb_to_hex(*(_lin_to_srgb(max(0.0, min(1.0, c))) for c in lin))


def oklch(hex_color: str) -> tuple[float, float, float]:
    """hex から (L, C, h)。h はラジアン。"""
    L, a, b = to_oklab(hex_color)
    return L, math.hypot(a, b), math.atan2(b, a)


def from_oklch(L: float, C: float, h_rad: float) -> str:
    return from_oklab(L, C * math.cos(h_rad), C * math.sin(h_rad))


def _in_gamut(L: float, C: float, h_rad: float) -> bool:
    """(L, C, h) が sRGB に収まるか。**クランプ前**の線形 RGB が [0,1] に入るかで判定する
    （hex にしてから往復で見ると 8bit 丸めと区別が付かず、判定が甘くなる）。"""
    lin = _oklab_to_linear(L, C * math.cos(h_rad), C * math.sin(h_rad))
    return all(-1e-6 <= c <= 1.0 + 1e-6 for c in lin)


def fit_chroma(L: float, C: float, h_rad: float) -> float:
    """`C` を sRGB のガモットに収まる最大値まで下げる（収まっていればそのまま）。

    **これを通さないと色相が勝手にずれる。** 実測では L=0.58 / C=0.150（レール・
    ライト）の青系（h≈220度）で最大 8.7 度ずれた ── sRGB の外に出た色が丸められる
    ため。色相はユーザーが選ぶもの（グループ色）なので、ずらさずに彩度を譲る。
    """
    if _in_gamut(L, C, h_rad):
        return C
    lo, hi = 0.0, C
    for _ in range(20):
        mid = (lo + hi) / 2
        if _in_gamut(L, mid, h_rad):
            lo = mid
        else:
            hi = mid
    return lo


def hue_of(hex_color: str) -> float:
    """hex から色相（度）だけ取り出す。既存 hex 設定の移行に使う。"""
    return math.degrees(oklch(hex_color)[2]) % 360.0


# --- 目標コントラストから色を逆算する ------------------------------- #
def contrast_step(ground_hex: str, target: float) -> str:
    """地色に対しコントラスト比が `target` になる色（**文字色の方向**へ寄せる）。

    区切り線・レール・枠のように「読む」わけではない要素に使う。
    テーマが持つ `secondarylightcolor` 等をそのまま使うと、テーマ間で
    コントラストが 1.14〜2.18 と 1.9 倍ばらつく（ライトではほぼ見えない）。
    """
    ink = readable_ink(ground_hex)
    # mix(ink, ground, t) は t=0 で ink（最大）、t=1 で地（=1.0）＝ t について単調減少。
    lo, hi = 0.0, 1.0
    for _ in range(30):
        mid = (lo + hi) / 2
        if contrast(mix(ink, ground_hex, mid), ground_hex) > target:
            lo = mid
        else:
            hi = mid
    return mix(ink, ground_hex, (lo + hi) / 2)


def elevated_face(ground_hex: str, target: float) -> str:
    """「浮いている面」の色（**常に白の方向**へ寄せる）。

    `contrast_step` は文字色の側へ寄せるので、ライトでは地より暗くなり
    「凹んで」見える。面にはこちらを使う（Material の慣習＝浮いた面は明るい）。
    ダークでは白方向＝明るくなるので同じ式で両対応できる。ライトは地が既に
    白に近く目標へ届かないことがあり、その場合は白で頭打ち（境界は枠が担う）。
    """
    if contrast("#ffffff", ground_hex) <= target:
        return "#ffffff"
    lo, hi = 0.0, 1.0        # mix(ground, white, t) は t について単調増加
    for _ in range(30):
        mid = (lo + hi) / 2
        if contrast(mix(ground_hex, "#ffffff", mid), ground_hex) < target:
            lo = mid
        else:
            hi = mid
    return mix(ground_hex, "#ffffff", (lo + hi) / 2)


# --- 色みのある面（色相が意味・明度彩度はテーマ） -------------------- #
# 用途別の (明度, 彩度)。`dark` はテーマが暗いときの値。
TONE_TARGETS: dict[str, dict[str, tuple[float, float]]] = {
    # 行やタイルの「面」＝控えめ（文字が乗るので彩度は低く）
    "surface": {"light": (0.90, 0.045), "dark": (0.36, 0.045)},
    # レール・バー＝細いのではっきりさせてよい
    "bar": {"light": (0.58, 0.150), "dark": (0.70, 0.135)},
}

# 意味に固定する色相（度）。値ではなく**色相だけ**を決める。
STATE_HUES: dict[str, float] = {"running": 95.0, "ok": 145.0, "fail": 25.0}

# 動作種別の色相。現行 `view/theme._ICON_TINTS` から色相を取り出したもの。
# **彩度倍率**を併せて持つ ── `clock` は現行ほぼ無彩色（#6b7280）で、彩度でほかと
# 区別している。倍率を持たせないと `file`（264.5度）と同化して見分けが付かない。
KIND_TONES: dict[str, tuple[float, float]] = {
    "link": (251.5, 1.0),
    "file": (264.5, 1.0),
    "doc": (264.5, 1.0),
    "folder": (72.0, 1.0),
    "terminal": (154.7, 1.0),
    "copy": (186.2, 1.0),
    "lock": (45.0, 1.0),
    "clock": (264.4, 0.25),    # ほぼ無彩色（待機）
}

# グループ色の既定の色相（8 グループぶん）。ユーザーは**色相だけ**を上書きできる。
DEFAULT_GROUP_HUES: list[float] = [251.5, 151.3, 87.4, 305.0, 6.3, 189.2, 220.0, 62.7]


def tone(hue_deg: float, role: str = "surface", *, chroma_scale: float = 1.0,
         dark: bool | None = None) -> str:
    """色相から「テーマに馴染む色」を作る。明度・彩度は `role` とテーマが決める。"""
    if dark is None:
        dark = bool(STATE.get("is_dark", False))
    spec = TONE_TARGETS.get(role, TONE_TARGETS["surface"])
    L, C = spec["dark" if dark else "light"]
    h = math.radians(hue_deg)
    # ガモットに収まる範囲まで彩度を下げる＝**色相はずらさない**（上の fit_chroma 参照）。
    return from_oklch(L, fit_chroma(L, C * max(0.0, chroma_scale), h), h)


def state_tone(state: str, role: str = "surface", *, dark: bool | None = None) -> str:
    """実行状態（running / ok / fail）の色。色相だけ意味に固定し値はテーマから。"""
    return tone(STATE_HUES[state], role, dark=dark)


def kind_tone(icon_name: str, role: str = "surface", *, dark: bool | None = None) -> str:
    """動作種別（アイコン名）の色。"""
    hue, scale = KIND_TONES.get(icon_name, (264.5, 1.0))
    return tone(hue, role, chroma_scale=scale, dark=dark)


def group_hue(index: int) -> float:
    """業務グループ `index` の色相。STATE の上書きが無ければ既定を循環。"""
    ov = STATE.get("group_hues") or []
    if 0 <= index < len(ov) and ov[index] is not None:
        return float(ov[index])
    return DEFAULT_GROUP_HUES[index % len(DEFAULT_GROUP_HUES)]


def group_tone(index: int, role: str = "bar", *, dark: bool | None = None) -> str:
    """業務グループ `index` の色（既定はレール用）。"""
    return tone(group_hue(index), role, dark=dark)


#: グループ色相が**実際に画面へ出る**「グループの分け方」（今は「レール（色）」だけ）。
#: 区切り線 A / カード D / レール(無彩色) E はグループ色を使わない。
GROUP_HUE_STYLES = ("F",)


def group_hue_visible(style: str | None = None) -> bool:
    """そのスタイルでグループ色が使われるか（`style` 省略なら今の設定）。

    使われないスタイルでは編集ウィンドウにグループ色の欄を出さない
    （2026-09-06 要望＝効かない設定を並べない）。サイドバーのレールの色分けと
    **同じ判断をここ 1 か所に置く**。
    """
    now = STATE.get("group_style", "A") if style is None else style
    return str(now) in GROUP_HUE_STYLES
