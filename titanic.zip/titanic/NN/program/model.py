import chainer
from chainer import functions as F, links as L

''''''''''''''''''''''''''''''''''''
'　ニューラルネットワーク                 '
''''''''''''''''''''''''''''''''''''
class Model(chainer.Chain):
    def __init__(self, f1=5, f2=256, fout=2):
        super(Model, self).__init__(
            l1 = L.Linear(f1, f2),
            l2 = L.Linear(f2, fout)
        )

    def forward(self, x):
        h = F.dropout(F.relu(self.l1(x)))
        y = self.l2(h)
        return y