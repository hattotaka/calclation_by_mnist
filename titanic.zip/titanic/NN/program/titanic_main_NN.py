import model as m
import train as t
import csv
import numpy as np
import math
import chainer
import argparse

USE_EPOCH = 0
COUNTINUE_FLG = False

def get_csv_data(path, header_skip_flg):
    with open(path, 'r') as f:
        reader = csv.reader(f)
        if header_skip_flg == True:
            next(reader)

        data = []
        for row in reader:
            data.append(row)

    return data

def read_data(path):
    raw_data = get_csv_data(path, True)
    
    data = []
    label = []
    for row in raw_data:
        add_flg = True
        col_cnt = 0
        tmp_data = []
        for col in row:
            if col_cnt == 1:                # Survived
                tmp_label = int(col)
            elif col_cnt == 2:              # Pclass
                tmp_data.append(int(col))
            elif col_cnt == 4:              # Sex
                if col == 'male':
                    tmp_data.append(0)
                elif col == 'female':
                    tmp_data.append(1)
                else:
                    add_flg = False
            elif col_cnt == 5:              # Age
                if col != '':
                    tmp_data.append(float(col))
                else:
                    add_flg = False
#            elif col_cnt == 6:              # SibSp
#                tmp_data.append(int(col))
#            elif col_cnt == 7:              # Parch
#                tmp_data.append(int(col))
            elif col_cnt == 9:              # Fare
                tmp_data.append(float(col))
            elif col_cnt == 11:             # Embarked
                if col == 'C':
                    tmp_data.append(0)
                elif col == 'Q':
                    tmp_data.append(1)
                elif col == 'S':
                    tmp_data.append(2)
                else:
                    add_flg = False

            col_cnt += 1

        if add_flg == True:
            np.array(tmp_data).astype(np.float32).reshape(1, 5)
            data.append(tmp_data)
            label.append(tmp_label)

    return data, label

def make_train_and_test_data(data, label):
    perm = np.random.permutation(len(data))
    berak_point = math.ceil(len(data) * 0.7)
    train_data = np.asarray(data).astype(np.float32)[perm[0:berak_point]]
    train_label = np.asarray(label).astype(np.int32)[perm[0:berak_point]]
    test_data = np.asarray(data).astype(np.float32)[perm[berak_point:len(data)]]
    test_label = np.asarray(label).astype(np.int32)[perm[berak_point:len(data)]]

    return train_data, train_label, test_data, test_label

def set_model(model_path=''):
    model = m.Model()
    if COUNTINUE_FLG == True:
        chainer.serializers.load_npz(model_path, model)
        lasttime_end_epoch = USE_EPOCH
    else:
        lasttime_end_epoch = 0

    return model, lasttime_end_epoch

def set_optimizer(model):
    optimizer = chainer.optimizers.Adam()
    optimizer.setup(model)
    optimizer.add_hook(chainer.optimizer.WeightDecay(0.0001))
    optimizer.add_hook(chainer.optimizer.GradientClipping(5.0))
    
    return optimizer

def write_log(log_path, log):
    f = open(log_path, 'a')
    writer = csv.writer(f, lineterminator='\n')
    writer.writerow(log)
    f.close()

parser = argparse.ArgumentParser()
parser.add_argument('--gpu', type=int)
parser.add_argument('--train_batch_size', type=int, default=100)
parser.add_argument('--test_batch_size', type=int, default=100)
parser.add_argument('--epoch_size', type=int, default=5000)
parser.add_argument('--epoch', type=int, default=0)
parser.add_argument('--log_path', type=str, default=r'..\log\log.csv')
parser.add_argument('--input_model_path', type=str, default='')
parser.add_argument('--output_model_path', type=str, default=r'..\model\model_epochcnt_epoch.npz')
parser.add_argument('--train_data_path', type=str, default=r'..\data\train.csv')
parser.add_argument('--test_data_path', type=str, default=r'..\data\test.csv')
parser.add_argument('--output_data_path', type=str, default=r'..\output\result.csv')
args = parser.parse_args()

data, label = read_data(args.train_data_path)
train_data, train_label, test_data, test_label = make_train_and_test_data(data, label)
model, lasttime_end_epoch = set_model(args.input_model_path)
optimizer = set_optimizer(model)
write_log(args.log_path, ['epoch', 'train_accuracy', 'test_accuracy', 'train_loss', 'test_loss'])
for epoch in range(args.epoch_size):
    # train
    train_accuracy, train_loss = t.calc_loss_and_accuracy(model, 
                                                          optimizer, 
                                                          train_data, 
                                                          train_label, 
                                                          epoch, 
                                                          len(train_data), 
                                                          len(train_data), 
                                                          True)

    print('train_accuracy:', train_accuracy)
    print('train_loss:', train_loss)

    # train
    test_accuracy, test_loss = t.calc_loss_and_accuracy(model, 
                                                        optimizer, 
                                                        test_data, 
                                                        test_label, 
                                                        epoch, 
                                                        len(test_data), 
                                                        len(test_data), 
                                                        False)

    print('test_accuracy:', test_accuracy)
    print('test_loss:', test_loss)

    write_log(args.log_path, [epoch, train_accuracy, test_accuracy, train_loss, test_loss])

    chainer.serializers.save_npz(args.output_model_path.replace('epochcnt', str(epoch + 1)), model)
    
    pred = model.forward(x)