import math
import numpy as np
from chainer import functions as F

''''''''''''''''''''''''''''''''''''
'　loss, accuracy計算               '
''''''''''''''''''''''''''''''''''''
def calc_loss_and_accuracy(model, optimizer, x, t, epoch, batch_size, log_freq, update_model_flg):
    perm = np.random.permutation(len(x))
    sum_accuracy = 0
    sum_loss = 0
    cnt = 0
    for i in range(0, len(x), batch_size):
        # count up counter
        cnt += 1

        #output learning and batch times
        if cnt % log_freq == 0:
            print('epoch:', epoch + 1, ', batch:', cnt, '/', math.ceil(len(x)/batch_size))

        # make batch data
        indices = perm[i:i+batch_size]
        x_batch = np.array(x).astype(np.float32)[indices]
        t_batch = np.array(t).astype(np.int32)[indices]

        # init model grad
        model.zerograds()

        # propagation
        y = model.forward(x_batch)

        # accuracy
        accuracy = F.accuracy(y, t_batch)

        # loss
        loss = F.softmax_cross_entropy(y, t_batch)        

        if update_model_flg == True:
            # back propagation
            loss.backward()

            # update opatimizer
            optimizer.update()

        # sum accuracy and loss
        sum_accuracy += float(accuracy.data) * len(t_batch)
        sum_loss += float(loss.data) * len(t_batch)

    sum_accuracy /= len(t)
    sum_loss /= len(t)

    return sum_accuracy, sum_loss