"""設定モードの編集アクションの配線に使う型。

改名・削除・追加・コピー＆貼り付けは **デザインラボの種類別カード**（`view/designlab.py`）で行う。
並べ替え／グループ移動は「行のどこでもドラッグ」（`view/dragdrop.py`）。
旧「行ホバーで出る `✎ ✕ ⧉ ▽` / `▲▼` / `⠿`」のオーバーレイは廃止した（§16bis まとまり B 追補）。
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass


@dataclass
class HierarchyCallbacks:
    """App（コントローラ）が提供する編集アクション。デザインラボのカード／メインパネルから呼ぶ。

    改名はインライン（`app.rename_live`）、動作編集はインライン `_ActionForm`（`app.apply_action_edit`）、
    並べ替え・グループ移動はドラッグ（§16bis Phase D）に移行済みなので、ここには残らない。
    グループの新規作成は「＋ 新規グループ」＝`app.add_work_in_new_group` / `add_task_in_new_group`。
    """

    add_work: Callable[[str], None]              # group_id（＝＋同じグループ）
    add_task: Callable[[str], None]              # task_group_id
    add_action: Callable[[str], None]            # task_id
    delete: Callable[[str, str], None]           # entity_id, label
