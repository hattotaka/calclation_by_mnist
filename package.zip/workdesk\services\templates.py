"""HTML テンプレートの保管庫。

- 「登録したい書式付きコンテンツをコピー」→ 共通設定画面で登録 → クリップボードの
  CF_HTML（HTML断片）＋ 平文を取り出して `templates/<id>.json` に保存。
- 動作（コピー）の `format=="html"` は `template_id` でここを引く。
- 暗号化はしない（大きな本文を暗号化するのは非現実的、というユーザー判断）。

templates/<id>.json = {"id":..., "name":..., "html":..., "text":..., "created":...}
"""

from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from pathlib import Path

from ..model import new_id


@dataclass
class Template:
    id: str
    name: str
    html: str = ""
    text: str = ""


class TemplateStore:
    def __init__(self, directory: str | os.PathLike[str], clipboard) -> None:
        self._dir = Path(directory)
        self._clipboard = clipboard

    def _path(self, template_id: str) -> Path:
        return self._dir / f"{template_id}.json"

    def list(self) -> list[Template]:
        if not self._dir.is_dir():
            return []
        out: list[Template] = []
        for p in self._dir.glob("*.json"):
            try:
                d = json.loads(p.read_text(encoding="utf-8"))
                out.append(Template(d["id"], d.get("name", p.stem), d.get("html", ""), d.get("text", "")))
            except (OSError, ValueError, KeyError):
                continue
        out.sort(key=lambda t: t.name)
        return out

    def get(self, template_id: str) -> Template | None:
        p = self._path(template_id)
        if not p.exists():
            return None
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        return Template(d["id"], d.get("name", ""), d.get("html", ""), d.get("text", ""))

    def add_from_clipboard(self, name: str) -> Template:
        res = self._clipboard.get_html()
        if res is None:
            raise ValueError("クリップボードに書式付き(HTML)データがありません")
        html, text = res
        tmpl = Template(id=new_id(), name=name.strip() or "無題", html=html, text=text)
        self._write(tmpl)
        return tmpl

    def rename(self, template_id: str, name: str) -> bool:
        t = self.get(template_id)
        if t is None:
            return False
        t.name = name.strip() or t.name
        self._write(t)
        return True

    def delete(self, template_id: str) -> bool:
        p = self._path(template_id)
        if p.exists():
            p.unlink()
            return True
        return False

    def _write(self, t: Template) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        p = self._path(t.id)
        tmp = p.with_suffix(".json.tmp")
        tmp.write_text(
            json.dumps(
                {"id": t.id, "name": t.name, "html": t.html, "text": t.text, "created": int(time.time())},
                ensure_ascii=False, indent=2,
            ),
            encoding="utf-8",
        )
        os.replace(tmp, p)


class FakeTemplateStore:
    """テスト・ヘッドレス用。"""

    def __init__(self) -> None:
        self._items: dict[str, Template] = {}

    def add(self, name: str, html: str, text: str = "") -> Template:
        t = Template(id=new_id(), name=name, html=html, text=text)
        self._items[t.id] = t
        return t

    def list(self) -> list[Template]:
        return sorted(self._items.values(), key=lambda t: t.name)

    def get(self, template_id: str) -> Template | None:
        return self._items.get(template_id)

    def rename(self, template_id: str, name: str) -> bool:
        t = self._items.get(template_id)
        if t is None:
            return False
        t.name = name
        return True

    def delete(self, template_id: str) -> bool:
        return self._items.pop(template_id, None) is not None
