"""動作（タスクにぶら下がる処理）の追加・編集フォーム。

- `_ActionForm(parent_frame, app, action)` … 種類選択＋種類別の入力欄を `parent_frame` に組む
  再利用コンポーネント。`.collect() -> (action_id, args)`（不正なら ValueError）。
  デザインラボの動作カードにインライン表示するのと、追加ダイアログの両方で使う（§16bis まとまり B 追補）。
- `edit_action_dialog(parent, app, action) -> (action_id, args) | None` … 追加時に開くモーダル。
- コピーのオプション: ワンタイム / 書式（HTMLテンプレート）/ 暗号化 / Slackメンション。
  書式・暗号化・Slackメンションは三者排他（ワンタイムはどれとも併用可）。
  Slackメンション ON = 実行時に宛先名一覧を出し、選んだ "@xxx" を定型文の先頭に付ける。
- 暗号化ON時: 2フォーム（入力＋確認再入力）→ app.ensure_crypto_ready() →
  app.crypto.encrypt(secret_id, 値) して args には secret_id のみ入れる（平文は保存しない）。

見た目はデザインラボ／共通設定と揃える（Yu Gothic UI 固定・基準フォントに追従しない）。
"""

from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from ..model import Action, new_id
from . import theme

_UI = ("Yu Gothic UI", 12)
_INPUT = ("Yu Gothic UI", 12)

# (action_id, 表示名)
_TYPES: list[tuple[str, str]] = [
    ("open_file", "ファイルを開く"),
    ("open_folder", "フォルダを開く"),
    ("open_url", "URLを開く"),
    ("os_exec", "OS実行（claude:// など）"),
    ("copy", "文字列コピー"),
    ("wait", "待機する"),
]
_LABEL_TO_ID = {label: aid for aid, label in _TYPES}
_ID_TO_LABEL = {aid: label for aid, label in _TYPES}


def edit_action_dialog(parent: tk.Misc, app, action: Action | None = None):
    dlg = _ActionDialog(parent, app, action)
    parent.wait_window(dlg)
    return dlg.result


class _ActionForm:
    """種類選択＋種類別入力欄を `parent` に組む。`collect()` で `(action_id, args)`。"""

    def __init__(self, parent: tk.Misc, app, action: Action | None) -> None:
        self.app = app
        self.action = action
        self.frame = tk.Frame(parent, bg=parent["bg"])
        self._bg = parent["bg"]
        self._fg = str(theme.PALETTE["ink"])

        top = tk.Frame(self.frame, bg=self._bg)
        top.pack(fill="x")
        tk.Label(top, text="種類:", bg=self._bg, fg=self._fg, font=_UI).pack(side="left")
        self.type_var = tk.StringVar(
            value=_ID_TO_LABEL.get(action.action_id if action else "open_file", "ファイルを開く")
        )
        self.type_cb = ttk.Combobox(
            top, textvariable=self.type_var, state="readonly",
            values=[label for _, label in _TYPES], width=26, font=_UI,
        )
        self.type_cb.pack(side="left", padx=(6, 0))
        self.type_cb.bind("<<ComboboxSelected>>", lambda _e: self._build_body())

        self.body = tk.Frame(self.frame, bg=self._bg)
        self.body.pack(fill="x", pady=(6, 0))
        self._collect = None
        self._build_body()

    # --------------------------------------------------------------- #
    def _cur_type(self) -> str:
        return _LABEL_TO_ID[self.type_var.get()]

    def _args(self) -> dict:
        return dict(self.action.args) if self.action else {}

    def _toplevel(self) -> tk.Misc:
        return self.frame.winfo_toplevel()

    def _build_body(self) -> None:
        for w in self.body.winfo_children():
            w.destroy()
        kind = self._cur_type()
        if kind in ("open_file", "open_folder"):
            self._collect = self._body_path(kind)
        elif kind == "open_url":
            self._collect = self._body_url()
        elif kind == "os_exec":
            self._collect = self._body_single("実行対象", "target")
        elif kind == "copy":
            self._collect = self._body_copy()
        elif kind == "wait":
            self._collect = self._body_wait()

    # --- 種類別ボディ ------------------------------------------------ #
    def _lbl(self, parent: tk.Misc, text: str, **grid) -> None:
        tk.Label(parent, text=text, bg=self._bg, fg=self._fg, font=_UI).grid(**grid)

    def _entry(self, parent: tk.Misc, **kw) -> tk.Entry:
        kw.setdefault("bg", str(theme.PALETTE["row_normal"]))
        kw.setdefault("fg", self._fg)
        kw.setdefault("insertbackground", self._fg)
        return tk.Entry(parent, font=_INPUT, relief="solid", bd=1, **kw)

    def _body_single(self, label: str, key: str):
        self._lbl(self.body, label + ":", row=0, column=0, sticky="w")
        ent = self._entry(self.body, width=44)
        ent.grid(row=0, column=1, sticky="we", pady=4, padx=(6, 0))
        ent.insert(0, str(self._args().get(key, "")))

        def collect() -> dict:
            v = ent.get().strip()
            if not v:
                raise ValueError(f"{label} を入力してください")
            if key == "url" and "://" not in v:
                raise ValueError("URL の形式が不正です（scheme:// が必要）")
            return {key: v}

        return collect

    def _body_url(self):
        a = self._args()
        self._lbl(self.body, "URL:", row=0, column=0, sticky="w")
        ent = self._entry(self.body, width=44)
        ent.grid(row=0, column=1, sticky="we", pady=4, padx=(6, 0))
        ent.insert(0, str(a.get("url", "")))
        nw = tk.IntVar(value=1 if a.get("new_window") else 0)
        tk.Checkbutton(
            self.body, text="新規ウィンドウで開く", variable=nw,
            bg=self._bg, fg=self._fg, font=_UI, activebackground=self._bg,
            activeforeground=self._fg, selectcolor=self._bg,
        ).grid(row=1, column=1, sticky="w", padx=(6, 0), pady=(2, 0))
        tk.Label(
            self.body,
            text="複数ページをまとめて開くとき、先頭の URL だけ ON にすると\n"
                 "その新しいウィンドウに残りがタブで入る（既存の窓を汚さない）",
            bg=self._bg, fg=str(theme.PALETTE["sub"]), font=_UI, justify="left",
        ).grid(row=2, column=1, sticky="w", padx=(6, 0), pady=(2, 0))

        def collect() -> dict:
            v = ent.get().strip()
            if not v:
                raise ValueError("URL を入力してください")
            if "://" not in v:
                raise ValueError("URL の形式が不正です（scheme:// が必要）")
            out: dict = {"url": v}
            if nw.get():
                out["new_window"] = True
            return out

        return collect

    def _body_wait(self):
        self._lbl(self.body, "待機秒数:", row=0, column=0, sticky="w")
        ent = self._entry(self.body, width=10)
        ent.grid(row=0, column=1, sticky="w", pady=4, padx=(6, 0))
        ent.insert(0, str(self._args().get("seconds", "1")))
        tk.Label(
            self.body,
            text="秒。この動作が終わるまで次の動作は始まりません\n"
                 "（例: URL を開く動作の間に挟むと 1 本ずつ順に開く）",
            bg=self._bg, fg=str(theme.PALETTE["sub"]), font=_UI, justify="left",
        ).grid(row=1, column=1, sticky="w", padx=(6, 0), pady=(2, 0))

        def collect() -> dict:
            raw = ent.get().strip()
            try:
                v = float(raw)
            except ValueError as e:
                raise ValueError("待機秒数は数値で入力してください") from e
            if v < 0:
                raise ValueError("待機秒数は 0 以上で入力してください")
            return {"seconds": v}

        return collect

    def _body_path(self, kind: str):
        self._lbl(self.body, "パス:", row=0, column=0, sticky="w")
        ent = self._entry(self.body, width=38)
        ent.grid(row=0, column=1, sticky="we", pady=4, padx=(6, 0))
        ent.insert(0, str(self._args().get("path", "")))

        def browse() -> None:
            top = self._toplevel()
            p = (
                filedialog.askdirectory(parent=top)
                if kind == "open_folder"
                else filedialog.askopenfilename(parent=top)
            )
            if p:
                ent.delete(0, "end")
                ent.insert(0, p)

        tk.Button(
            self.body, text="参照…", command=browse, font=_UI, relief="solid", bd=1,
        ).grid(row=0, column=2, padx=4)

        def collect() -> dict:
            v = ent.get().strip()
            if not v:
                raise ValueError("パスを入力してください")
            return {"path": v}

        return collect

    def _body_copy(self):
        a = self._args()
        self.v_onetime = tk.IntVar(value=1 if a.get("onetime") else 0)
        self.v_html = tk.IntVar(value=1 if a.get("format") == "html" else 0)
        self.v_enc = tk.IntVar(value=1 if a.get("encrypt") else 0)
        self.v_mention = tk.IntVar(value=1 if a.get("mention") else 0)

        self._lbl(self.body, "呼称（任意）:", row=0, column=0, sticky="w")
        self.e_label = self._entry(self.body, width=28)
        self.e_label.grid(row=0, column=1, sticky="w", pady=4, padx=(6, 0))
        self.e_label.insert(0, str(a.get("label", "")))

        opt = tk.Frame(self.body, bg=self._bg)
        opt.grid(row=1, column=0, columnspan=3, sticky="w", pady=(2, 6))
        ckw = dict(
            bg=self._bg, fg=self._fg, font=_UI, activebackground=self._bg,
            activeforeground=self._fg, selectcolor=self._bg,
        )
        tk.Checkbutton(
            opt, text="ワンタイム", variable=self.v_onetime, **ckw,
        ).pack(side="left")
        self.cb_html = tk.Checkbutton(
            opt, text="書式", variable=self.v_html, command=self._copy_excl_html,
            **ckw,
        )
        self.cb_html.pack(side="left", padx=8)
        self.cb_enc = tk.Checkbutton(
            opt, text="暗号化", variable=self.v_enc, command=self._copy_excl_enc, **ckw,
        )
        self.cb_enc.pack(side="left")
        self.cb_mention = tk.Checkbutton(
            opt, text="Slackメンション", variable=self.v_mention,
            command=self._copy_excl_mention, **ckw,
        )
        self.cb_mention.pack(side="left", padx=8)

        self.copy_fields = tk.Frame(self.body, bg=self._bg)
        self.copy_fields.grid(row=2, column=0, columnspan=3, sticky="we")
        self._render_copy_fields()
        return self._collect_copy

    def _copy_excl_html(self) -> None:
        if self.v_html.get():
            self.v_enc.set(0)
            self.v_mention.set(0)
        self._render_copy_fields()

    def _copy_excl_enc(self) -> None:
        if self.v_enc.get():
            self.v_html.set(0)
            self.v_mention.set(0)
        self._render_copy_fields()

    def _copy_excl_mention(self) -> None:
        # Slack メンションは平文の定型文にだけ効く（暗号化 / HTML とは排他）。
        if self.v_mention.get():
            self.v_html.set(0)
            self.v_enc.set(0)
        self._render_copy_fields()

    def _render_copy_fields(self) -> None:
        for w in self.copy_fields.winfo_children():
            w.destroy()
        a = self._args()
        editing_enc = bool(self.action and a.get("encrypt"))
        self._tmpl_var = None
        self._tmpl_id_by_name = {}

        if self.v_enc.get():
            head = "文字列（登録済み）:" if editing_enc else "文字列:"
            self._lbl(self.copy_fields, head, row=0, column=0, columnspan=2, sticky="w")
            self._lbl(self.copy_fields, "入力:", row=1, column=0, sticky="e")
            self.e_s1 = self._entry(self.copy_fields, width=36, show="*")
            self.e_s1.grid(row=1, column=1, pady=3, padx=(6, 0))
            self._lbl(self.copy_fields, "再入力:", row=2, column=0, sticky="e")
            self.e_s2 = self._entry(self.copy_fields, width=36, show="*")
            self.e_s2.grid(row=2, column=1, pady=3, padx=(6, 0))
            if editing_enc and self.app.crypto.unlocked:
                try:
                    cur = self.app.crypto.decrypt(a["secret_id"])
                    self.e_s1.insert(0, cur)
                    self.e_s2.insert(0, cur)
                except Exception:  # noqa: BLE001
                    pass
        elif self.v_html.get():
            tmpls = self.app.templates.list()
            if not tmpls:
                tk.Label(
                    self.copy_fields, fg=str(theme.PALETTE["danger_ink"]), bg=self._bg,
                    font=_UI, justify="left",
                    text="※ HTMLテンプレートが未登録です。\n  「設定」→ HTMLテンプレート で登録してください。",
                ).grid(row=0, column=0, columnspan=2, sticky="w")
                return
            self._tmpl_id_by_name = {t.name: t.id for t in tmpls}
            self._lbl(self.copy_fields, "テンプレート:", row=0, column=0, sticky="w")
            self._tmpl_var = tk.StringVar()
            ttk.Combobox(
                self.copy_fields, textvariable=self._tmpl_var, state="readonly",
                values=[t.name for t in tmpls], width=34, font=_UI,
            ).grid(row=0, column=1, pady=3, padx=(6, 0))
            cur_id = a.get("template_id")
            for t in tmpls:
                if t.id == cur_id:
                    self._tmpl_var.set(t.name)
                    break
        else:
            self._lbl(self.copy_fields, "文字列:", row=0, column=0, sticky="nw")
            self.t_text = tk.Text(
                self.copy_fields, width=42, height=3, font=_INPUT, relief="solid", bd=1,
                bg=str(theme.PALETTE["row_normal"]), fg=self._fg,
                insertbackground=self._fg,
            )
            self.t_text.grid(row=0, column=1, pady=3, padx=(6, 0))
            self.t_text.insert("1.0", str(a.get("text", "")))

    def _collect_copy(self) -> dict:
        args: dict = {}
        lbl = self.e_label.get().strip()
        if lbl:
            args["label"] = lbl
        if self.v_onetime.get():
            args["onetime"] = True
        if self.v_mention.get():
            args["mention"] = True

        a = self._args()
        editing_enc = bool(self.action and a.get("encrypt"))

        if self.v_enc.get():
            v1, v2 = self.e_s1.get(), self.e_s2.get()
            if editing_enc and not v1 and not v2:
                args.update({"encrypt": True, "secret_id": a["secret_id"]})
                return args
            if not v1:
                raise ValueError("暗号化する文字列を入力してください")
            if v1 != v2:
                raise ValueError("確認再入力が一致しません")
            if not self.app.ensure_crypto_ready():
                raise ValueError("パスフレーズが設定されていません")
            sid = a.get("secret_id") if editing_enc else new_id()
            self.app.crypto.encrypt(sid, v1)
            args.update({"encrypt": True, "secret_id": sid})
            return args

        # 非暗号化。以前 暗号化だったなら暗号文を破棄
        if editing_enc:
            try:
                self.app.crypto.remove_secret(a["secret_id"])
            except Exception:  # noqa: BLE001
                pass

        if self.v_html.get():
            if not self._tmpl_var or not self._tmpl_var.get():
                raise ValueError("HTMLテンプレートを選択してください（未登録なら「設定」で登録）")
            args.update({
                "format": "html",
                "template_id": self._tmpl_id_by_name[self._tmpl_var.get()],
            })
        else:
            args["text"] = self.t_text.get("1.0", "end").rstrip("\n")
        return args

    # --------------------------------------------------------------- #
    def collect(self) -> tuple[str, dict]:
        """`(action_id, args)` を返す。不正なら ValueError。"""
        return self._cur_type(), self._collect()


class _ActionDialog(tk.Toplevel):
    """動作の追加時に開くモーダル（`_ActionForm` ＋ OK / キャンセル）。"""

    def __init__(self, parent: tk.Misc, app, action: Action | None) -> None:
        super().__init__(parent)
        self.result: tuple[str, dict] | None = None
        self.configure(bg=str(theme.PALETTE["row_normal"]))
        self.title("動作の編集" if action else "動作の追加")
        self.resizable(False, False)
        self.transient(parent)

        self.form = _ActionForm(self, app, action)
        self.form.frame.pack(fill="both", expand=True, padx=12, pady=10)

        btns = tk.Frame(self, bg=self["bg"])
        btns.pack(fill="x", padx=12, pady=(0, 10))
        tk.Button(
            btns, text="キャンセル", width=10, command=self.destroy, font=_UI,
        ).pack(side="right", padx=4)
        tk.Button(
            btns, text="OK", width=10, command=self._on_ok, font=_UI,
        ).pack(side="right")

        self.grab_set()
        self.update_idletasks()
        px, py = parent.winfo_rootx(), parent.winfo_rooty()
        self.geometry(f"+{px + 60}+{py + 60}")

    def _on_ok(self) -> None:
        try:
            action_id, args = self.form.collect()
        except ValueError as e:
            messagebox.showerror("入力エラー", str(e), parent=self)
            return
        self.result = (action_id, args)
        self.destroy()
