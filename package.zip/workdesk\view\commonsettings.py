"""共通設定パネル（画面を要さない設定）。

4 セクション:
  1. HTMLテンプレート    … 現在のクリップボードから登録 / 改名 / 削除
  2. Slackメンション宛先 … 名前＋メンション文字列（@xxx）を登録 / 編集 / 削除。
                          `settings["mention_directory"]` に配列で保存。動作の「Slackメンション」
                          ON 時、タスク実行中にここの名前一覧から宛先を選ぶ。
  3. ワンタイム待機(ms)  … 直接入力（入力すると自動反映。閉じても有効）
  4. パスフレーズ         … 未設定なら「設定」、設定済みなら「変更」（現在のパスフレーズ必須＋再暗号化）

テーマ（ライト/ダーク）はここではなく **デザインラボ「スタイル」タブ**（＝画面の見た目を
まとめて調整する場所。§17.7）。

位置づけ（§16 ステージ2）: デザインラボと同じく **モードレス・単一・トグル**（サイドバー
最下部の「設定」行をもう一度押すと閉じる）。窓内に「閉じる」ボタンは持たない
（開いている間はフッター行がグレーで「開」を示す）。デザインラボと違い、開いていても
本体のタスク実行は止めない。

保存の考え方:
- **ドックへ直接入力する項目（待機ms）は入力した時点で反映**（デバウンスで保存）。
  無効な中間入力は黙って無視し、フォーカスアウトで直近の有効値へ戻す。
- **別ダイアログでの登録が要る項目（テンプレート／パスフレーズ）は、その処理で確定**。

見た目: Windows 素の LabelFrame/Button をやめ、自作パーツ（アクセント縦バー付き見出し＋
区切り線、Label ベースのボタン＝ホバーでアクセント反転）。パネル文字はデザインラボと
同じく固定フォント（Yu Gothic UI。基準フォントの変更には追従しない）。
名前入力は `ask_text`（大きめの入力欄）。エラー通知だけ messagebox。
"""

from __future__ import annotations

import tkinter as tk
from tkinter import messagebox

from ..model import new_id
from . import theme
from .dockpanel import DockPanel
from .passdialog import ask_change_passphrase, ask_new_passphrase
from .uikit import Debouncer
from .uikit import accent_button as _button
from .uikit import ask_fields, ask_text

_HEAD = ("Yu Gothic UI", 12, "bold")
_UI = ("Yu Gothic UI", 12)
_INPUT = ("Yu Gothic UI", 13)


class CommonSettingsWindow(DockPanel):
    pos_key = "common_settings"

    def __init__(self, app) -> None:
        super().__init__(app)
        self._wait_debounce = Debouncer(self)   # 待機ms 入力 → settings 保存
        self.title("設定")

        self._build_ui()

        # 両パネルが開いているときは少し下へずらす（重なり回避）
        other = self.app._design_lab
        down = 44 if (other is not None and other.winfo_exists()) else 0
        self.install_position_persistence(extra_down=down)

    def _build_ui(self) -> None:
        """パネル中身を組む。`reskin()`（テーマ切替）から再実行される。"""
        self.content = tk.Frame(self, bg=self._bg, padx=16, pady=12)
        self.content.pack(fill="both", expand=True)

        self._build_templates()
        self._divider()
        self._build_mentions()
        self._divider()
        self._build_wait_ms()
        self._divider()
        self._build_passphrase()

    def reskin(self) -> None:
        """テーマ切替（§17.7）。色が直書きのため中身を作り直す（App が after(0) で呼ぶ）。
        テーマの切替 UI 自体はデザインラボ「スタイル」タブへ移設済み。"""
        if not self.winfo_exists():
            return
        self._bg = str(theme.PALETTE["row_normal"])
        self.configure(bg=self._bg)
        self._wait_debounce.cancel()
        self.content.destroy()
        self._build_ui()

    # --- 共通パーツ ----------------------------------------- #
    def _section(self, text: str) -> None:
        row = tk.Frame(self.content, bg=self._bg)
        row.pack(fill="x", pady=(10, 4))
        tk.Frame(row, bg=str(theme.PALETTE["accent"]), width=3).pack(side="left", fill="y")
        tk.Label(
            row, text=text, bg=self._bg, fg=str(theme.PALETTE["ink"]), font=_HEAD,
            anchor="w",
        ).pack(side="left", padx=(7, 0))

    def _divider(self) -> None:
        tk.Frame(self.content, height=1, bg=str(theme.PALETTE["divider"])).pack(
            fill="x", pady=(12, 0)
        )

    # --- 1. テンプレート ----------------------------------- #
    def _build_templates(self) -> None:
        self._section("HTMLテンプレート")
        box = tk.Frame(self.content, bg=self._bg)
        box.pack(fill="x")

        self.tmpl_list = tk.Listbox(
            box, height=6, width=32, exportselection=False,
            font=_INPUT, bd=1, relief="solid",
            bg=str(theme.PALETTE["row_normal"]), fg=str(theme.PALETTE["ink"]),
            highlightthickness=1, highlightbackground=str(theme.PALETTE["input_border"]),
            highlightcolor=str(theme.PALETTE["accent"]), activestyle="none",
            selectbackground=str(theme.PALETTE["accent"]),
            selectforeground=str(theme.PALETTE["on_accent"]),
        )
        self.tmpl_list.pack(side="left", fill="x", expand=True)
        self._tmpl_ids: list[str] = []

        col = tk.Frame(box, bg=self._bg)
        col.pack(side="left", fill="y", padx=(8, 0))
        _button(col, "クリップボードから登録", self._tmpl_add).pack(fill="x")
        _button(col, "改名", self._tmpl_rename).pack(fill="x", pady=(6, 0))
        _button(col, "削除", self._tmpl_delete).pack(fill="x", pady=(6, 0))
        self._reload_templates()

    def _reload_templates(self) -> None:
        self.tmpl_list.delete(0, "end")
        self._tmpl_ids = []
        for t in self.app.templates.list():
            self.tmpl_list.insert("end", t.name)
            self._tmpl_ids.append(t.id)

    def _selected_index(self) -> int | None:
        sel = self.tmpl_list.curselection()
        return sel[0] if sel else None

    def _tmpl_add(self) -> None:
        name = ask_text(self, "テンプレート登録", "テンプレート名:")
        if not name:
            return
        try:
            self.app.templates.add_from_clipboard(name)
        except ValueError as e:
            messagebox.showerror("テンプレート登録", str(e), parent=self)
            return
        self._reload_templates()

    def _tmpl_rename(self) -> None:
        i = self._selected_index()
        if i is None:
            return
        name = ask_text(self, "改名", "新しい名前:", initial=self.tmpl_list.get(i))
        if not name:
            return
        self.app.templates.rename(self._tmpl_ids[i], name)
        self._reload_templates()

    def _tmpl_delete(self) -> None:
        i = self._selected_index()
        if i is None:
            return
        if messagebox.askyesno("削除の確認", "選択したテンプレートを削除しますか？", parent=self):
            self.app.templates.delete(self._tmpl_ids[i])
            self._reload_templates()

    # --- 2. Slackメンション宛先 --------------------------- #
    def _build_mentions(self) -> None:
        self._section("Slackメンション宛先")
        box = tk.Frame(self.content, bg=self._bg)
        box.pack(fill="x")

        self.mention_list = tk.Listbox(
            box, height=6, width=32, exportselection=False,
            font=_INPUT, bd=1, relief="solid",
            bg=str(theme.PALETTE["row_normal"]), fg=str(theme.PALETTE["ink"]),
            highlightthickness=1, highlightbackground=str(theme.PALETTE["input_border"]),
            highlightcolor=str(theme.PALETTE["accent"]), activestyle="none",
            selectbackground=str(theme.PALETTE["accent"]),
            selectforeground=str(theme.PALETTE["on_accent"]),
        )
        self.mention_list.pack(side="left", fill="x", expand=True)

        col = tk.Frame(box, bg=self._bg)
        col.pack(side="left", fill="y", padx=(8, 0))
        _button(col, "追加", self._mention_add).pack(fill="x")
        _button(col, "編集", self._mention_edit).pack(fill="x", pady=(6, 0))
        _button(col, "削除", self._mention_delete).pack(fill="x", pady=(6, 0))
        self._reload_mentions()

    def _mentions(self) -> list[dict]:
        return self.app.app_data.settings.setdefault("mention_directory", [])

    def _reload_mentions(self) -> None:
        self.mention_list.delete(0, "end")
        for e in self._mentions():
            name = str(e.get("name", "")) or str(e.get("mention", ""))
            self.mention_list.insert("end", f"{name}   {e.get('mention', '')}")

    def _mention_selected_index(self) -> int | None:
        sel = self.mention_list.curselection()
        return sel[0] if sel else None

    def _mention_add(self) -> None:
        res = ask_fields(
            self, "メンション宛先の登録",
            [("name", "名前:"), ("mention", "メンション文字列（@xxx）:")],
        )
        if not res:
            return
        name, mention = res["name"].strip(), res["mention"].strip()
        if not name or not mention:
            messagebox.showerror("メンション宛先", "名前とメンション文字列の両方を入力してください。", parent=self)
            return
        self._mentions().append({"id": new_id(), "name": name, "mention": mention})
        self.app._save()  # noqa: SLF001
        self._reload_mentions()

    def _mention_edit(self) -> None:
        i = self._mention_selected_index()
        if i is None:
            return
        cur = self._mentions()[i]
        res = ask_fields(
            self, "メンション宛先の編集",
            [("name", "名前:", cur.get("name", "")),
             ("mention", "メンション文字列（@xxx）:", cur.get("mention", ""))],
        )
        if not res:
            return
        name, mention = res["name"].strip(), res["mention"].strip()
        if not name or not mention:
            messagebox.showerror("メンション宛先", "名前とメンション文字列の両方を入力してください。", parent=self)
            return
        cur["name"], cur["mention"] = name, mention
        self.app._save()  # noqa: SLF001
        self._reload_mentions()

    def _mention_delete(self) -> None:
        i = self._mention_selected_index()
        if i is None:
            return
        if messagebox.askyesno("削除の確認", "選択したメンション宛先を削除しますか？", parent=self):
            del self._mentions()[i]
            self.app._save()  # noqa: SLF001
            self._reload_mentions()

    # --- 3. 待機 ms（直接入力＝自動反映） ----------------- #
    def _build_wait_ms(self) -> None:
        self._section("ワンタイム待機 (ms)")
        row = tk.Frame(self.content, bg=self._bg)
        row.pack(fill="x")
        cur = str(self.app.settings.get("onetime_wait_ms", 300))
        self.wait_var = tk.StringVar(value=cur)
        self._wait_last_valid = cur
        entry = tk.Entry(
            row, textvariable=self.wait_var, width=8, font=_INPUT,
            bd=1, relief="solid", highlightthickness=1,
            bg=str(theme.PALETTE["row_normal"]), fg=str(theme.PALETTE["ink"]),
            insertbackground=str(theme.PALETTE["ink"]),
            highlightbackground=str(theme.PALETTE["input_border"]),
            highlightcolor=str(theme.PALETTE["accent"]),
        )
        entry.pack(side="left", ipady=3)
        entry.bind("<FocusOut>", lambda _e: self._wait_commit())
        entry.bind("<Return>", lambda _e: self._wait_commit())
        self.wait_var.trace_add("write", self._wait_changed)
        tk.Label(
            row, text="貼り付け後にクリップボードを消すまでの待ち。入力すると自動で反映されます。",
            bg=self._bg, fg=str(theme.PALETTE["sub"]), font=_UI,
        ).pack(side="left", padx=(8, 0))

    def _wait_changed(self, *_a) -> None:
        self._wait_debounce.schedule(400, self._wait_debounced)

    def _wait_debounced(self) -> None:
        if not self.winfo_exists():
            return
        v = self.wait_var.get().strip()
        if v.isdigit():
            self._persist_wait(int(v))

    def _wait_commit(self) -> None:
        """FocusOut / Return で即確定（予約は破棄）。無効値は直近の有効値へ戻す。"""
        self._wait_debounce.cancel()
        v = self.wait_var.get().strip()
        if v.isdigit():
            self._persist_wait(int(v))
        else:
            self.wait_var.set(self._wait_last_valid)

    def _persist_wait(self, n: int) -> None:
        self._wait_last_valid = str(n)
        self.app.app_data.settings["onetime_wait_ms"] = n
        self.app._save()  # noqa: SLF001

    # --- 4. パスフレーズ --------------------------------- #
    def _build_passphrase(self) -> None:
        self._section("暗号化パスフレーズ")
        row = tk.Frame(self.content, bg=self._bg)
        row.pack(fill="x")
        self._pp_status = tk.Label(row, bg=self._bg, fg=str(theme.PALETTE["ink"]), font=_UI)
        self._pp_status.pack(side="left")
        self._pp_btn = _button(row, "", self._passphrase_action)
        self._pp_btn.pack(side="left", padx=8)
        self._refresh_passphrase()

    def _refresh_passphrase(self) -> None:
        configured = self.app.crypto.is_configured()
        self._pp_status.configure(text="設定済み" if configured else "未設定")
        self._pp_btn.configure(text="変更" if configured else "設定")

    def _passphrase_action(self) -> None:
        if self.app.crypto.is_configured():
            res = ask_change_passphrase(self)
            if res is None:
                return
            cur, new = res
            if self.app.crypto.change_passphrase(cur, new):
                messagebox.showinfo("パスフレーズ", "変更しました。", parent=self)
            else:
                messagebox.showerror("パスフレーズ", "現在のパスフレーズが違います。", parent=self)
        else:
            pp = ask_new_passphrase(self)
            if not pp:
                return
            try:
                self.app.crypto.setup(pp)
                messagebox.showinfo("パスフレーズ", "設定しました。", parent=self)
            except Exception as e:  # noqa: BLE001
                messagebox.showerror("パスフレーズ", f"設定に失敗しました:\n{e}", parent=self)
        self._refresh_passphrase()
