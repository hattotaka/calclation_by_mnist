"""Slack メンションの宛先辞書と、実行時の宛先選択（design-notes §5 / §10.6）。

役割:
- **宛先辞書** = `settings["mention_directory"]` = `[{"id","name","mention"}]`。
  設定パネルから CRUD する。`id` は UUID で辞書エントリ内部用（改名・削除しても
  動作は壊れない＝**動作 args は id を参照しない**。動作側は `mention: true/false` だけ）。
- `pick()` … コピー機能がワーカースレッドから呼ぶ。宛先名の一覧ウィンドウを出し、
  ユーザーが 1 つ選ぶ or「メンション無し」を選ぶまで **ワーカースレッドをブロック**する。
  戻り値は選ばれたメンション文字列（"@xxx"）。「メンション無し」/ 候補 0 件 は "" を返す。
  **タイトルバーの 最小化 / 最大化 / × は表示しない・Esc も無い**（必ず選ばせる。
  `_strip_caption_buttons` で `WS_SYSMENU` 等を除去）。アプリ終了時のみ `shutdown()` で待ちを解放する。
  行はマウス位置に追従してハイライト（フォーカス位置が一目で分かる）。既定で先頭行を選択。

スレッド: OneTimeService と同じ考え方。UI 生成は `run_on_ui` 経由、ワーカーは
`queue.Queue.get()` で待つ（`wait_window` は使わない＝キーボードフックのポンプと
再入しての GIL クラッシュを避ける。CLAUDE.md §3）。
"""

from __future__ import annotations

import queue
import tkinter as tk
from collections.abc import Callable

_UI = ("Yu Gothic UI", 13)
_HEAD = ("Yu Gothic UI", 13, "bold")
_PREVIEW = ("Yu Gothic UI", 10)
_NO_MENTION = "（メンション無し）"
_ACCENT = "#3b7dd8"


def _strip_caption_buttons(win: tk.Misc) -> None:
    """Toplevel のタイトルバーから 最小化 / 最大化 / × / システムメニューを消す
    （キャプション文字とドラッグは残す）。Windows 専用・失敗は握り潰す（§4）。"""
    try:
        import ctypes

        GWL_STYLE = -16
        WS_SYSMENU, WS_MINIMIZEBOX, WS_MAXIMIZEBOX = 0x00080000, 0x00020000, 0x00010000
        SWP = 0x1 | 0x2 | 0x4 | 0x20  # NOSIZE | NOMOVE | NOZORDER | FRAMECHANGED
        u = ctypes.windll.user32
        hwnd = u.GetAncestor(win.winfo_id(), 2) or win.winfo_id()  # GA_ROOT
        style = u.GetWindowLongW(hwnd, GWL_STYLE)
        u.SetWindowLongW(
            hwnd, GWL_STYLE, style & ~(WS_SYSMENU | WS_MINIMIZEBOX | WS_MAXIMIZEBOX)
        )
        u.SetWindowPos(hwnd, 0, 0, 0, 0, 0, SWP)
    except Exception:  # noqa: BLE001
        pass


class MentionDirectory:
    def __init__(
        self,
        run_on_ui: Callable[[Callable[[], None]], None],
        *,
        entries: Callable[[], list[dict]],
        master: tk.Misc | None = None,
    ) -> None:
        self._run_on_ui = run_on_ui
        self._entries = entries          # live な settings["mention_directory"] を返す callable
        self._master = master
        self._result: queue.Queue = queue.Queue(maxsize=1)
        self._shutdown = False
        self._popup: tk.Toplevel | None = None

    # ------------------------------------------------------------- #
    # コピー機能が呼ぶ（ワーカースレッド）
    # ------------------------------------------------------------- #
    def pick(self, preview: str = "", label: str = "") -> str:
        """宛先名一覧を出し、選ばれたメンション文字列を返す。

        「メンション無し」を選んだ / 候補が 0 件 / headless（master=None）/ 終了中 は "".
        """
        if self._shutdown or self._master is None:
            return ""
        rows = [
            (str(e.get("name", "")), str(e.get("mention", "")))
            for e in (self._entries() or [])
            if e.get("mention")
        ]
        # 取り残しのドレイン（前回 shutdown 等）
        while not self._result.empty():
            try:
                self._result.get_nowait()
            except queue.Empty:
                break
        self._run_on_ui(lambda: self._ui_open(rows, preview, label))
        chosen = self._result.get()          # ← ここでブロック
        return "" if chosen is None else str(chosen)

    def shutdown(self) -> None:
        self._shutdown = True
        try:
            self._result.put_nowait(None)
        except queue.Full:
            pass

    # ------------------------------------------------------------- #
    # UI（UI スレッドでのみ実行）
    # ------------------------------------------------------------- #
    def _ui_open(self, rows: list[tuple[str, str]], preview: str, label: str) -> None:
        if self._master is None:
            self._finish(None)
            return
        top = tk.Toplevel(self._master)
        self._popup = top
        top.title("メンション先を選択")
        top.resizable(False, False)
        top.attributes("-topmost", True)
        top.configure(bg="#ffffff")
        top.protocol("WM_DELETE_WINDOW", lambda: None)   # × では閉じない（必ず選ばせる）

        head = label or "コピー"
        tk.Label(
            top, text=f"「{head}」のメンション先を選択", bg="#ffffff", fg="#333",
            font=_HEAD, anchor="w",
        ).pack(fill="x", padx=22, pady=(18, 2))
        tk.Label(
            top, text="名前をクリック（↑↓ で移動 → Enter でも可）", bg="#ffffff", fg="#999",
            font=_PREVIEW, anchor="w",
        ).pack(fill="x", padx=22, pady=(0, 6))
        if preview:
            snippet = preview.strip().splitlines()
            text = "  ".join(snippet[:2])
            if len(text) > 72:
                text = text[:72] + "…"
            tk.Label(
                top, text=text, bg="#f4f4f4", fg="#666", font=_PREVIEW,
                anchor="w", justify="left", padx=8, pady=4,
            ).pack(fill="x", padx=22, pady=(0, 10))

        box = tk.Frame(top, bg="#ffffff")
        box.pack(fill="both", expand=True, padx=22, pady=(0, 18))
        lb = tk.Listbox(
            box, height=min(14, max(6, len(rows) + 1)), width=40, activestyle="dotbox",
            font=_UI, bd=1, relief="solid", exportselection=False, selectmode="browse",
            highlightthickness=2, highlightbackground="#cccccc", highlightcolor=_ACCENT,
            selectbackground=_ACCENT, selectforeground="#ffffff",
        )
        sb = tk.Scrollbar(box, orient="vertical", command=lb.yview)
        lb.configure(yscrollcommand=sb.set)
        lb.pack(side="left", fill="both", expand=True)
        sb.pack(side="left", fill="y")

        mentions: list[str] = []
        for name, mention in rows:
            lb.insert("end", f"  {name or mention}")
            mentions.append(mention)
        lb.insert("end", f"  {_NO_MENTION}")
        mentions.append("")   # 末尾＝「メンション無し」

        # 最初の行を選択状態にしておく（＝どこにフォーカスがあるか一目で分かる）
        lb.selection_set(0)
        lb.activate(0)
        lb.focus_set()

        def _row_at(y: int) -> int:
            idx = lb.nearest(y)
            return idx if (idx >= 0 and lb.bbox(idx)) else -1

        def on_motion(e: tk.Event) -> None:
            idx = _row_at(e.y)
            if idx >= 0 and idx not in lb.curselection():
                lb.selection_clear(0, "end")
                lb.selection_set(idx)
                lb.activate(idx)

        def confirm_click(e: tk.Event) -> None:
            idx = _row_at(e.y)
            if idx >= 0:
                self._finish(mentions[idx])

        def confirm_active(_e: tk.Event) -> None:
            self._finish(mentions[lb.index("active")])

        lb.bind("<Motion>", on_motion)               # マウス位置の行をハイライト
        lb.bind("<ButtonRelease-1>", confirm_click)  # クリックで確定（OK ボタンは無し）
        lb.bind("<Return>", confirm_active)
        lb.bind("<KP_Enter>", confirm_active)

        top.update_idletasks()
        _strip_caption_buttons(top)                  # 最小化 / 最大化 / × を消す
        x = self._master.winfo_rootx() + (self._master.winfo_width() - top.winfo_width()) // 2
        y = self._master.winfo_rooty() + 80
        top.geometry(f"+{max(0, x)}+{max(0, y)}")

    def _finish(self, mention: str | None) -> None:
        if self._popup is not None:
            try:
                self._popup.destroy()
            except tk.TclError:
                pass
            self._popup = None
        try:
            self._result.put_nowait(mention)
        except queue.Full:
            pass


class FakeMentionDirectory:
    """headless / テスト用。`pick()` は事前設定した戻り値を即返す（ブロックしない）。"""

    def __init__(self, chosen: str = "") -> None:
        self.chosen = chosen
        self.calls: list[tuple[str, str]] = []

    def pick(self, preview: str = "", label: str = "") -> str:
        self.calls.append((preview, label))
        return self.chosen

    def shutdown(self) -> None:
        pass
