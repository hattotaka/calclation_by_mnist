"""ワンタイム（順次貼り付け）サービス。

役割分担（§9）:
    コピー機能      … 何を載せるか（ClipboardPayload を作る）。失敗は待ちに入る前に。
    OneTimeService  … いつ載せるか。clear → Ctrl+V待ち → セット → wait(ms) → clear。
                      中止（中止ボタン / 他タスク押下）なら SequenceAbort。

Ctrl+V 検知はグローバルキーボードフック（services/keyhook.py）。
`_pending`（gate が待機中）のときだけフックが反応する。
headless（master=None）ではフックを張らず、`notify_paste()` を直接叩いてテストする。

スレッド: dispatcher / コピー機能はワーカースレッドから begin_sequence / gate_paste /
end_sequence を呼ぶ。UI 操作は `run_on_ui(fn)` 経由で UI スレッドへ回す。
`gate_paste` は Ctrl+V か中止まで **ワーカースレッドをブロック**する。
"""

from __future__ import annotations

import threading
import time
import tkinter as tk
from collections.abc import Callable

from ..result import SequenceAbort
from .clipboard import ClipboardPayload

# フックプロシージャがユーザーの Ctrl+V を保留してよい上限（秒）。
# Windows の LowLevelHooksTimeout（既定 300ms）より十分小さくする。
_HOLD_TIMEOUT = 0.15


class OneTimeService:
    def __init__(
        self,
        run_on_ui: Callable[[Callable[[], None]], None],
        clipboard,
        *,
        wait_ms: Callable[[], int] = lambda: 300,
        master: tk.Misc | None = None,
        use_hook: bool | None = None,
    ) -> None:
        self._run_on_ui = run_on_ui
        self._clipboard = clipboard
        self._wait_ms = wait_ms
        self._master = master

        self._popup: tk.Toplevel | None = None
        self._popup_label: tk.Label | None = None
        self._total = 0
        self._index = 0
        self._resolve = threading.Event()       # Ctrl+V か中止で立つ
        self._clip_ready = threading.Event()    # ペイロード投入完了で立つ（フックの保留解除用）
        self._cancelled = False
        self._pending = False
        self._shutdown = False

        self._hook = None
        if use_hook is None:
            use_hook = master is not None
        if use_hook:
            from .keyhook import KeyboardHook

            self._hook = KeyboardHook(
                on_ctrl_v=self._on_hook_ctrl_v, is_active=lambda: self._pending
            )
            self._hook.start()

    # ------------------------------------------------------------- #
    # dispatcher が呼ぶ（ワーカースレッド）
    # ------------------------------------------------------------- #
    def begin_sequence(self, total: int) -> None:
        self._total = total
        self._index = 0
        self._cancelled = False
        self._shutdown = False
        self._run_on_ui(self._ui_open)

    def end_sequence(self) -> None:
        self._pending = False
        self._clip_ready.set()
        self._run_on_ui(self._ui_close)

    # ------------------------------------------------------------- #
    # コピー機能が呼ぶ（ワーカースレッド）
    # ------------------------------------------------------------- #
    def gate_paste(self, label: str, payload: ClipboardPayload) -> None:
        """clear → Ctrl+V待ち → payload.apply → wait(ms) → clear。中止なら SequenceAbort。"""
        self._index += 1
        self._resolve.clear()
        self._clip_ready.clear()
        self._clipboard.clear()

        idx, total = self._index, self._total
        self._run_on_ui(lambda: self._ui_update(label, idx, total))

        self._pending = True
        self._resolve.wait()
        self._pending = False

        if self._cancelled or self._shutdown:
            self._clip_ready.set()          # 保留中のフックスレッドを解放
            raise SequenceAbort()

        payload.apply(self._clipboard)
        self._clip_ready.set()              # ← ここでフックがユーザーの Ctrl+V を通す
        time.sleep(max(0, self._wait_ms()) / 1000)
        self._clipboard.clear()

    # ------------------------------------------------------------- #
    # フックスレッド / UI スレッドから
    # ------------------------------------------------------------- #
    def _on_hook_ctrl_v(self) -> None:
        """フックスレッドから呼ばれる。ペイロード投入が終わるまでキーストロークを保留する。

        フックは Ctrl+V を握り潰さない。ここで最大 _HOLD_TIMEOUT だけ待ってから
        プロシージャが CallNextHookEx に進む → その時点でクリップボードは確実に埋まっている。
        タイムアウト時は従来どおり（競合あり）にフォールバック。
        """
        if not self._pending:
            return
        self._clip_ready.clear()
        self._resolve.set()
        self._clip_ready.wait(_HOLD_TIMEOUT)

    def notify_paste(self) -> None:
        """headless / テスト用（キーストローク保留なし）。"""
        if self._pending:
            self._resolve.set()

    def cancel(self) -> None:
        self._cancelled = True
        self._resolve.set()
        self._clip_ready.set()

    def shutdown(self) -> None:
        self._shutdown = True
        self._resolve.set()
        self._clip_ready.set()
        if self._hook is not None:
            self._hook.stop()

    @property
    def is_waiting(self) -> bool:
        return self._pending

    # ------------------------------------------------------------- #
    # UI（UI スレッドでのみ実行）
    # ------------------------------------------------------------- #
    def _ui_open(self) -> None:
        if self._master is None or self._popup is not None:
            return
        top = tk.Toplevel(self._master)
        top.title("ワンタイムコピー")
        top.resizable(False, False)
        top.attributes("-topmost", True)
        top.protocol("WM_DELETE_WINDOW", self.cancel)

        self._popup_label = tk.Label(top, text="準備中…", font=("", 10))
        self._popup_label.pack(padx=20, pady=12)
        tk.Button(top, text="中止", width=10, command=self.cancel).pack(pady=(0, 12))

        top.update_idletasks()
        x = top.winfo_screenwidth() // 2 - top.winfo_width() // 2
        y = top.winfo_screenheight() // 3
        top.geometry(f"+{x}+{y}")
        self._popup = top

    def _ui_update(self, label: str, index: int, total: int) -> None:
        if self._popup_label is not None:
            self._popup_label.config(
                text=f"{label} をコピー中  （{index}/{total}）\nCtrl+V で貼り付けてください"
            )

    def _ui_close(self) -> None:
        if self._popup is not None:
            self._popup.destroy()
        self._popup = None
        self._popup_label = None
