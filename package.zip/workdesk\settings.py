"""AppData への読み取り専用アクセス（機能・dispatcher が使う）。

live な AppData 参照を保持するので、設定モードの CRUD で中身が変わっても
最新状態を返す。
"""

from __future__ import annotations

from typing import Any

from .model import AppData, TaskLocation


class SettingsReader:
    def __init__(self, data: AppData) -> None:
        self._data = data

    @property
    def data(self) -> AppData:
        return self._data

    def get(self, key: str, default: Any = None) -> Any:
        return self._data.settings.get(key, default)

    def resolve_task(self, task_id: str) -> TaskLocation | None:
        return self._data.find_task(task_id)
