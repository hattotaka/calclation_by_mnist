"""メインパネル: 選択中の業務のタスクを、タスクグループでソートして縦一列。

各タスク行は **地（ペイン地色）に溶け込む**（枠なし・面なし）。選択＝`accent_soft` 面／
ホバー＝`row_hover`／実行中・結果＝層2色でだけ色づく（2026-08-31。既存ランチャーに寄せた）。
タスク名の先頭に「先頭動作の種類」の **角丸色つきタイル**（大きめ・トーナル）、右端に成功バッジ。
- 通常モード: タスクグループ間は 1px 罫。行クリックで dispatch（App が配線）。
- 設定モード（§16 Phase A）: **見た目は通常モードと同一**（グループ見出しは出さない）。
  行クリックで選択＋その下に動作一覧をアコーディオン展開（同時に 1 つだけ）。実行はしない。
  改名・削除・並べ替え・コピー等の編集 UI は**デザインラボのカードへ集約済み**（行ホバーの
  `▲▼✎✕` オーバーレイは §16bis で全廃）。並べ替えは「行のどこでもドラッグ」（`dragdrop.py`）。
"""

from __future__ import annotations

import tkinter as tk
from collections.abc import Callable

from ..model import Work
from . import theme
from .dragdrop import RowReorderDrag
from .editcontrols import HierarchyCallbacks
from .scrollable import ScrollableFrame

TASKGROUP_GAP = 18   # グループ区切り罫の「下」の余白（罫の上は 3px 固定）
ROW_GAP = 8          # タスクカード間の縦の隙間（各カードの下に付ける）
# 左右マージン／帯からの距離は `theme.box_margin()` / `theme.list_top_pad()`（デザインラボで可変）。
ACTION_ICON_SIZE = 24   # アコーディオン動作行の色つきタイル
TASK_ICON_SIZE = 44     # タスク行の先頭タイル（2行分の高さ。既存ランチャー風・淡い色）
# 色は theme.PALETTE から都度読む（テーマ切替で追随させるため。§17.7 ステージ2）。
# 旧 DIVIDER_COLOR / ROW_BG / SUBROW_BG / COLOR_* のモジュール定数は撤去した。
# 面は3段（§17.7 ステージ3）: パネル地色 = PALETTE["bg"] ＜ 行（カード）面 = PALETTE["row_normal"]。

_KIND_JA = {
    "open_file": "ファイル",
    "open_folder": "フォルダ",
    "open_url": "URL",
    "os_exec": "OS実行",
    "copy": "コピー",
    "wait": "待機",
    "slack_post": "Slack投稿",
}

# action_id -> icons.py の名前（§17.7 ステージ5）
_ICON_FOR_ACTION = {
    "open_file": "file",
    "open_folder": "folder",
    "open_url": "link",
    "os_exec": "terminal",
    "copy": "copy",
    "wait": "clock",
}


def _action_icon(a, *, size: int = ACTION_ICON_SIZE):
    """1 動作の色つきタイルアイコン（暗号化コピーだけ錠前）。生成不能なら None。"""
    if a.action_id == "copy" and a.args.get("encrypt"):
        name = "lock"
    else:
        name = _ICON_FOR_ACTION.get(a.action_id, "doc")
    return theme.icon_badge(name, size)


def _task_icon(task, *, size: int = TASK_ICON_SIZE):
    """タスク行のタイルアイコン＝先頭動作の種類（動作 0 件なら汎用 doc）。"""
    if task.actions:
        return _action_icon(task.actions[0], size=size)
    return theme.icon_badge("doc", size)


def _short(s: str, n: int = 32) -> str:
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[:n] + "…"


def _action_summary(a, template_names: dict[str, str] | None = None) -> str:
    args = a.args
    if a.action_id == "copy":
        tags = []
        if args.get("encrypt"):
            tags.append("暗号")
        if args.get("onetime"):
            tags.append("ワンタイム")
        if args.get("format") == "html":
            tags.append("書式")
        head = "コピー" + (f" {args['label']}" if args.get("label") else "")
        if tags:
            head += " [" + "/".join(tags) + "]"
        if args.get("encrypt"):
            body = "●●●"
        elif args.get("format") == "html":
            names = template_names or {}
            body = names.get(args.get("template_id", ""), "(テンプレート未選択)")
        else:
            body = _short(args.get("text", ""))
        return f"{head} — {body}" if body else head
    if a.action_id in ("open_file", "open_folder"):
        return f"{_KIND_JA[a.action_id]} — {_short(args.get('path', ''), 44)}"
    if a.action_id == "open_url":
        tag = " [新規窓]" if args.get("new_window") else ""
        return f"URL{tag} — {_short(args.get('url', ''), 44)}"
    if a.action_id == "os_exec":
        return f"OS実行 — {_short(args.get('target', ''), 44)}"
    if a.action_id == "wait":
        try:
            secs = float(args.get("seconds", 0))
        except (TypeError, ValueError):
            secs = 0
        return f"待機 — {secs:g} 秒"
    return _KIND_JA.get(a.action_id, a.action_id)


def _task_line2(task, template_names=None) -> str:
    """通常モードでタスク名の下に出す 1 行。説明があればそれ、無ければ先頭動作の要約。"""
    if task is None:
        return ""
    if getattr(task, "description", ""):
        return task.description
    if task.actions:
        return _action_summary(task.actions[0], template_names)
    return ""


def _pointer_within(widget: tk.Misc) -> bool:
    """ポインタが widget（またはその子孫）の上にあるか（ホバー解除のちらつき防止）。"""
    try:
        under = widget.winfo_containing(*widget.winfo_pointerxy())
    except tk.TclError:
        return False
    while under is not None:
        if under is widget:
            return True
        under = getattr(under, "master", None)
    return False


class TaskRow:
    def __init__(
        self, parent: tk.Misc, task_id: str, name: str, *, icon=None, desc: str = ""
    ) -> None:
        self.task_id = task_id
        # タスク行は地（ペイン地色）に溶け込む＝枠なし・面なし。選択/ホバー/実行結果でだけ色づく。
        rest = str(parent["bg"])
        self._resting_bg = rest
        self._bg = rest
        self._fg = theme.readable_ink(rest)
        self._selected = False
        self._hovering = False
        self._locked = False           # 実行中/結果の層2表示中はホバーで塗り替えない
        self._desc_text = desc          # 通常時のライン2（説明 or 先頭動作の要約）
        self._status_text = ""          # 層2のライン2（実行中/結果）。あれば優先
        self._status_tone = "sub"
        m = theme.metrics()
        self.frame = tk.Frame(
            parent, bg=rest, padx=m["row_padx"], pady=m["row_pady"], cursor="hand2",
        )
        self.frame.pack(fill="x", padx=theme.box_margin(), pady=(0, ROW_GAP))
        self.icon_lbl: tk.Label | None = None
        if icon is not None:
            self.icon_lbl = tk.Label(self.frame, image=icon, bg=rest)
            self.icon_lbl.image = icon   # GC 防止
            self.icon_lbl.pack(side="left", padx=(0, 12))
        # 成功バッジ（all_ok のときだけ右端に出る緑ピル）
        self.badge = tk.Label(
            self.frame, text="", padx=8, pady=1, font=theme.font("sub"),
            bg=str(theme.PALETTE["ok_ink"]), fg=str(theme.PALETTE["on_accent"]),
        )
        # タイトル＋ライン2 を縦積みする列
        self.textcol = tk.Frame(self.frame, bg=rest)
        self.textcol.pack(side="left", fill="x", expand=True)
        self.name = tk.Label(
            self.textcol, text=name, bg=rest, fg=self._fg, anchor="w",
            font=theme.font("task"),
        )
        self.name.pack(side="top", fill="x", anchor="w")
        self.sub = tk.Label(
            self.textcol, text="", bg=rest, anchor="w", fg=str(theme.PALETTE["sub"]),
            justify="left", font=theme.font("sub"),
        )
        self._render_line2()
        # 設定モードのアコーディオン（動作一覧）。行の直後に pack する。
        self.acc = tk.Frame(parent, bg=str(theme.PALETTE["subrow_bg"]))
        self._cb: HierarchyCallbacks | None = None
        self.frame._wd_no_send_back = True
        self.acc._wd_no_send_back = True

    # --- ライン2（説明 / 層2ステータス）の出し分け ------------------- #
    def _render_line2(self) -> None:
        text = self._status_text or self._desc_text
        tone = self._status_tone if self._status_text else "sub"
        if text:
            self.sub.configure(
                text=text, bg=self._bg,
                fg=str(theme.PALETTE[self._SUB_TONE.get(tone, "sub")]),
            )
            if not self.sub.winfo_ismapped():
                self.sub.pack(side="top", fill="x", anchor="w", pady=(2, 0))
        elif self.sub.winfo_ismapped():
            self.sub.pack_forget()

    def set_description(self, text: str) -> None:
        self._desc_text = text or ""
        self._render_line2()

    # --- 地色の出し分け（溶け込む / ホバー / 選択 / 層2） --------------- #
    def _apply_bg(self, bg: str, *, name_fg: str | None = None) -> None:
        self._bg = bg
        self._fg = name_fg or theme.readable_ink(bg)
        for w in (self.frame, self.textcol, self.name, self.sub):
            w.configure(bg=bg)
        self.name.configure(fg=self._fg)
        if self.icon_lbl is not None:
            self.icon_lbl.configure(bg=bg)

    def _refresh_bg(self) -> None:
        if self._locked:
            return   # 層2（App.paint）が地色を制御中
        if self._selected:
            self._apply_bg(
                str(theme.PALETTE["accent_soft"]), name_fg=str(theme.PALETTE["accent"])
            )
        elif self._hovering:
            self._apply_bg(str(theme.PALETTE["row_hover"]))
        else:
            self._apply_bg(self._resting_bg)

    def hover(self, on: bool) -> None:
        self._hovering = on
        self._refresh_bg()

    def _bind_hover(self, widgets) -> None:
        for w in widgets:
            w.bind("<Enter>", lambda _e: self.hover(True), add="+")
            w.bind("<Leave>", lambda _e: self._on_leave(), add="+")

    def _on_leave(self) -> None:
        if not _pointer_within(self.frame):
            self.hover(False)

    # --- 設定モード: 行クリックで選択 ＋ ドラッグ ----------------- #
    def enable_edit(
        self, cb: HierarchyCallbacks, on_select: Callable[[str], None], drag=None
    ) -> None:
        self._cb = cb
        parts = [self.frame, self.textcol, self.name, self.sub] + (
            [self.icon_lbl] if self.icon_lbl else []
        )
        if drag is not None:
            drag.bind_row(
                tuple(parts), self.task_id,
                on_click=lambda: on_select(self.task_id),
            )
        else:
            for w in parts:
                w.bind("<Button-1>", lambda _e: on_select(self.task_id))
        self._bind_hover(parts)

    def set_selected(self, on: bool) -> None:
        self._selected = on
        self._refresh_bg()

    def bind_click(self, handler: Callable[[str], None]) -> None:
        """通常モード：行クリックでタスク実行（App が配線）。単クリック即発火。"""
        widgets = [self.frame, self.textcol, self.name, self.sub]
        if self.icon_lbl is not None:
            widgets.append(self.icon_lbl)
        for w in widgets:
            w.bind("<Button-1>", lambda _e: handler(self.task_id))
        self._bind_hover(widgets)

    def paint(self, bg: str) -> None:
        """層2（実行中/結果）の地色。App が指定。ホバーより優先。"""
        self._locked = True
        self._apply_bg(bg)

    def paint_resting(self) -> None:
        """層2 表示おわり → 溶け込み地色（or 選択/ホバー）へ戻す。"""
        self._locked = False
        self._refresh_bg()

    _SUB_TONE = {"sub": "sub", "run": "run_ink", "ok": "ok_ink", "fail": "fail_ink"}

    def set_sub(self, text: str, *, tone: str = "sub") -> None:
        """層2（実行中/結果）のライン2テキスト。空にすると通常の説明表示へ戻る。"""
        self._status_text = text or ""
        self._status_tone = tone
        self._render_line2()

    def show_badge(self, text: str) -> None:
        """成功バッジ（§17.7 ステージ6）。右端に緑のピルで「成功しました」等を出す。"""
        self.badge.configure(
            text=text, bg=str(theme.PALETTE["ok_ink"]),
            fg=str(theme.PALETTE["on_accent"]),
        )
        if not self.badge.winfo_ismapped():
            self.badge.pack(side="right", padx=(8, 0), before=self.textcol)

    def hide_badge(self) -> None:
        if self.badge.winfo_ismapped():
            self.badge.pack_forget()


class MainPanel:
    def __init__(self, parent: tk.Misc) -> None:
        self.frame = ScrollableFrame(parent, bg=str(theme.PALETTE["bg"]))
        self._rows: dict[str, TaskRow] = {}
        self._tasks: dict[str, object] = {}
        self._template_names: dict[str, str] = {}
        self._on_task_click: Callable[[str], None] | None = None
        self._on_task_select: Callable[[str | None], None] | None = None
        self._on_action_select: Callable[[str | None], None] | None = None
        self._selected_action: str | None = None
        self._callbacks: HierarchyCallbacks | None = None
        self._editing = False
        self._expanded: str | None = None          # アコーディオンが開いているタスク
        self._selected_task: str | None = None     # 選択中のタスク（アコーディオンとは独立。§16bis まとまり B）
        self._layout: list[tuple[str, str, tk.Widget]] = []       # 表示順 (task_id, tg_id, frame)
        self._act_layout: list[tuple[str, str, tk.Widget]] = []   # 展開中タスクの (action_id, task_id, line)
        # D&D 並べ替え（§16bis Phase D。App が配線）
        self._on_task_reorder: Callable[[str, str, str | None], None] | None = None
        self._on_action_reorder: Callable[[str, str | None], None] | None = None
        self._task_drag = RowReorderDrag(
            scroll=self.frame,
            get_layout=lambda: [
                (i, c, w) for i, c, w in self._layout if w.winfo_exists()
            ],
            on_drop=self._task_drop,
            indicator_parent=lambda: self.frame.body,
            allow_new_container=True,   # 最終グループの下へドロップ＝新しいタスクグループ
        )
        self._action_drag = RowReorderDrag(
            scroll=self.frame,
            get_layout=lambda: [
                (i, c, w) for i, c, w in self._act_layout if w.winfo_exists()
            ],
            on_drop=self._action_drop,
            indicator_parent=self._acc_parent,
        )

    @property
    def widget(self) -> tk.Widget:
        return self.frame

    def set_task_click_handler(self, handler: Callable[[str], None]) -> None:
        self._on_task_click = handler

    def set_task_select_handler(self, handler: Callable[[str | None], None]) -> None:
        """設定モードでタスクの選択（アコーディオン展開/収納）が変わったとき呼ばれる。"""
        self._on_task_select = handler

    def set_action_select_handler(self, handler: Callable[[str | None], None]) -> None:
        """設定モードでアコーディオンの動作行を選んだとき呼ばれる（§16bis まとまり B）。"""
        self._on_action_select = handler

    @property
    def selected_action_id(self) -> str | None:
        return self._selected_action

    def update_row_label(self, entity_id: str, name: str) -> None:
        """インライン改名から。該当タスク行の見出しだけ差し替える（再構築しない）。"""
        r = self._rows.get(entity_id)
        if r is not None:
            r.name.configure(text=name)

    def refresh_task_icon(self, task_id: str) -> None:
        """先頭動作の種類が変わったとき、そのタスク行のアイコン＋ライン2（自動要約）を
        貼り替える（全再描画しない経路＝動作の編集/追加/並べ替え用）。"""
        r = self._rows.get(task_id)
        task = self._tasks.get(task_id)
        if r is None or task is None:
            return
        if r.icon_lbl is not None:
            img = _task_icon(task)
            r.icon_lbl.configure(image=img or "")
            r.icon_lbl.image = img   # GC 防止
        r.set_description(_task_line2(task, self._template_names))

    def update_task_description(self, task_id: str, text: str) -> None:
        """設定モードの説明入力から。該当タスク行のライン2を即差し替える（再構築しない）。"""
        r = self._rows.get(task_id)
        if r is not None:
            r.set_description(text or _task_line2(self._tasks.get(task_id), self._template_names))

    def select_action(self, task_id: str, action_id: str) -> None:
        """指定タスクのアコーディオンを開いて指定動作を選択する
        （動作の作成／貼り付け直後に App から呼ぶ）。"""
        if task_id not in self._rows or task_id not in self._tasks:
            return
        if self._selected_task != task_id:
            if self._selected_task and self._selected_task in self._rows:
                self._rows[self._selected_task].set_selected(False)
            self._selected_task = task_id
            self._rows[task_id].set_selected(True)
            if self._on_task_select is not None:
                self._on_task_select(task_id)
        self._collapse_accordion()
        self._expanded = task_id
        self._fill_accordion(self._rows[task_id], self._tasks[task_id])
        self._select_action(action_id)

    def set_reorder_handlers(
        self,
        *,
        task_reorder: Callable[[str, str, str | None], None],
        action_reorder: Callable[[str, str | None], None],
    ) -> None:
        """D&D 並べ替えの配線（§16bis Phase D）。
        task_reorder(task_id, dest_taskgroup_id, before_id) / action_reorder(action_id, before_id)。"""
        self._on_task_reorder = task_reorder
        self._on_action_reorder = action_reorder

    # --- D&D 補助 ------------------------------------------------- #
    def _acc_parent(self) -> tk.Widget:
        r = self._rows.get(self._expanded) if self._expanded else None
        return r.acc if r is not None else self.frame.body

    def _task_drop(self, task_id: str, before_id: str | None, tg_id: str | None) -> None:
        if self._on_task_reorder is None:
            return
        if tg_id is None:                     # 新しいタスクグループへ
            self._on_task_reorder(task_id, None, None)
        elif tg_id:
            self._on_task_reorder(task_id, tg_id, before_id)

    def _action_drop(self, action_id: str, before_id: str | None, _task_id: str) -> None:
        if self._on_action_reorder is not None:
            self._on_action_reorder(action_id, before_id)

    def rebuild_open_accordion(self) -> None:
        """展開中タスクの動作一覧だけ組み直す（動作 D&D 後。アコーディオンは閉じない）。"""
        if not self._expanded or self._expanded not in self._rows:
            return
        r = self._rows[self._expanded]
        for c in r.acc.winfo_children():
            c.destroy()
        self._fill_accordion(r, self._tasks[self._expanded])

    @property
    def selected_task_id(self) -> str | None:
        return self._selected_task

    def set_background(self, settings: bool) -> None:
        """設定モードでメインパネルの地色を暖色に（`render()` の直前に呼ぶ）。
        タスク行自体は白のままなので、行のまわりが色づく。"""
        self.frame.set_bg(
            str(theme.PALETTE["settings_pane_bg" if settings else "bg"])
        )

    def row(self, task_id: str) -> TaskRow | None:
        return self._rows.get(task_id)

    def clear_selection(self) -> None:
        """タスク／動作の選択を解除する（パネルは作り直さない）。
        親業務を（再）クリックしたときに App が呼ぶ（§16bis まとまり B 追補）。"""
        if self._selected_task and self._selected_task in self._rows:
            self._rows[self._selected_task].set_selected(False)
        self._selected_task = None
        self._collapse_accordion()   # _selected_action もクリア＋on_action_select(None)
        if self._on_task_select is not None:
            self._on_task_select(None)

    # --------------------------------------------------------------- #
    def render(
        self,
        work: Work | None,
        *,
        mode: str = "normal",
        callbacks: HierarchyCallbacks | None = None,
        template_names: dict[str, str] | None = None,
    ) -> None:
        self._task_drag.reset()
        self._action_drag.reset()
        self._rows.clear()
        self._layout.clear()
        self._act_layout.clear()
        self._tasks: dict[str, object] = {}
        self._template_names = template_names or {}
        self._callbacks = callbacks
        self._editing = mode == "settings" and callbacks is not None
        self._expanded: str | None = None
        self._selected_task = None
        self._selected_action = None
        body = self.frame.begin_rebuild()

        if work is None:
            msg = "（左で業務を選ぶか、業務を追加してください）" if self._editing else "（業務を選択してください）"
            tk.Label(
                body, text=msg, bg=body["bg"], fg=str(theme.PALETTE["faint"]),
                padx=14, pady=14, anchor="w", font=theme.font("body"),
            ).pack(fill="x")
            self.frame.commit_rebuild()
            return

        # 先頭に「選択中の業務名」の見出し（ユーザー要望 2026-08-31）
        tk.Frame(body, height=theme.list_top_pad(), bg=body["bg"]).pack(fill="x")
        tk.Label(
            body, text=work.name, bg=body["bg"], fg=str(theme.PALETTE["ink"]),
            anchor="w", font=theme.font("task"), padx=theme.box_margin() + 2,
        ).pack(fill="x")
        tk.Frame(body, height=10, bg=body["bg"]).pack(fill="x")

        # グループ間は区切り線のみ（見出しは出さない）
        first = True
        for tg in work.task_groups:
            if not tg.tasks:
                continue   # 空グループは描かない（1px 線が2本並ぶのを防ぐ）
            if not first:
                # グループ区切り＝カード幅に合わせた 1px 罫（`divider`。ライトでも見える濃さ）
                tk.Frame(body, height=1, bg=str(theme.PALETTE["divider"])).pack(
                    fill="x", padx=theme.box_margin(), pady=(3, TASKGROUP_GAP)
                )
            first = False
            block = tk.Frame(body, bg=body["bg"])
            block.pack(fill="x")
            for task in tg.tasks:
                self._tasks[task.id] = task
                r = TaskRow(
                    block, task.id, task.name, icon=_task_icon(task),
                    desc=_task_line2(task, self._template_names),
                )
                self._rows[task.id] = r
                if self._editing and callbacks is not None:
                    r.enable_edit(callbacks, self._toggle_task, self._task_drag)
                    self._layout.append((task.id, tg.id, r.frame))
                elif self._on_task_click is not None:
                    r.bind_click(self._on_task_click)

        self.frame.commit_rebuild()

    # --- 設定モード: 選択 ＋ アコーディオン（動作一覧） ----------- #
    def _toggle_task(self, task_id: str) -> None:
        """クリックしたタスクは **必ず選択**（デザインラボの対象）。アコーディオンは
        独立にトグル（同じタスクの再クリックで閉じるが、選択は保つ。§16bis まとまり B）。"""
        if self._selected_task and self._selected_task != task_id and self._selected_task in self._rows:
            self._rows[self._selected_task].set_selected(False)
        self._selected_task = task_id
        self._rows[task_id].set_selected(True)

        if self._expanded == task_id:
            self._collapse_accordion()
        else:
            self._collapse_accordion()
            self._expanded = task_id
            self._fill_accordion(self._rows[task_id], self._tasks[task_id])

        if self._on_task_select is not None:
            self._on_task_select(self._selected_task)

    def reselect_task(self, task_id: str) -> None:
        """貼り付け直後などに、行の選択状態を作り直す（アコーディオンは開かない）。"""
        if task_id not in self._rows:
            return
        if self._selected_task and self._selected_task in self._rows:
            self._rows[self._selected_task].set_selected(False)
        self._selected_task = task_id
        self._rows[task_id].set_selected(True)
        if self._on_task_select is not None:
            self._on_task_select(task_id)

    def _collapse_accordion(self) -> None:
        """アコーディオンだけ閉じる（タスクの選択状態は触らない）。"""
        if self._expanded and self._expanded in self._rows:
            r = self._rows[self._expanded]
            for c in r.acc.winfo_children():
                c.destroy()
            r.acc.pack_forget()
            r.frame.pack_configure(pady=(0, ROW_GAP))   # 閉じたらカード下の隙間を戻す
        self._action_drag.reset()
        self._act_layout.clear()
        self._expanded = None
        if self._selected_action is not None:
            self._selected_action = None
            if self._on_action_select is not None:
                self._on_action_select(None)

    def _select_action(self, action_id: str) -> None:
        """アコーディオンの動作行クリックで選択（同時1つ。§16bis まとまり B）。"""
        self._selected_action = action_id
        sub_bg = str(theme.PALETTE["subrow_bg"])
        for aid, _tid, line in self._act_layout:
            on = aid == action_id
            edge = str(theme.PALETTE["accent"]) if on else sub_bg
            line.configure(highlightbackground=edge, highlightcolor=edge)
        if self._on_action_select is not None:
            self._on_action_select(action_id)

    def _bind_acc_hover(self, widgets, aid: str, base: str, hover: str) -> None:
        """動作行のホバーで薄く色を変える（選択中の行は border 表現なので触らない）。"""
        def on(_e):
            if aid != self._selected_action:
                for w in widgets:
                    w.configure(bg=hover)
        def off(_e):
            if _pointer_within(widgets[0]):
                return
            for w in widgets:
                w.configure(bg=base)
        for w in widgets:
            w.bind("<Enter>", on, add="+")
            w.bind("<Leave>", off, add="+")

    def _fill_accordion(self, row: TaskRow, task) -> None:
        acc, cb = row.acc, self._callbacks
        sub_bg = str(theme.PALETTE["subrow_bg"])
        hover_bg = str(theme.PALETTE["subrow_hover"])   # subrow_bg 基準（row_hover は bg 基準で暗色差が出ない）
        divider = str(theme.PALETTE["divider"])
        sub_fg = str(theme.PALETTE["sub"])
        self._act_layout.clear()
        for i, a in enumerate(task.actions):
            if i > 0:
                tk.Frame(acc, height=1, bg=divider).pack(fill="x")
            summary = _action_summary(a, self._template_names)
            sel = a.id == self._selected_action
            edge = str(theme.PALETTE["accent"]) if sel else sub_bg
            line = tk.Frame(
                acc, bg=sub_bg, padx=14, pady=3, cursor="hand2",
                highlightthickness=1, highlightbackground=edge, highlightcolor=edge,
            )
            line.pack(fill="x")
            self._act_layout.append((a.id, task.id, line))
            # 先頭アイコンは廃止（ごちゃつくため）。無くなった分は詰めずに軽くインデント。
            name = tk.Label(
                line, text=summary, bg=sub_bg, anchor="w", fg=str(theme.PALETTE["ink"]),
                cursor="hand2", font=theme.font("action"),
            )
            name.pack(side="left", fill="x", expand=True, padx=(18, 0))
            parts = (line, name)
            self._action_drag.bind_row(
                tuple(parts), a.id, on_click=lambda aid=a.id: self._select_action(aid)
            )
            self._bind_acc_hover(parts, a.id, sub_bg, hover_bg)
        bar = tk.Frame(acc, bg=sub_bg)
        bar.pack(fill="x", pady=(0, 4))
        # 「＋動作」＝クリック領域は行の右端まで、地色・ホバー色とも動作行と同じ
        # （`activebackground` は「押下中」だけなので `<Enter>/<Leave>` で明示的に塗る）。
        plus = tk.Button(
            bar, text="＋動作", command=lambda tid=task.id: cb.add_action(tid),
            relief="flat", anchor="w", padx=(18 + 14), fg=sub_fg, font=theme.font("action"),
            cursor="hand2", bg=sub_bg, activebackground=hover_bg,
            activeforeground=sub_fg, bd=0, highlightthickness=0,
        )
        plus.pack(side="left", fill="x", expand=True)
        plus.bind("<Enter>", lambda _e: plus.configure(bg=hover_bg))
        plus.bind("<Leave>", lambda _e: plus.configure(bg=sub_bg))
        # アコーディオンは上のタスクカードに“くっつけ”つつ、左は **カード端から少しインデント**
        # ＝「このタスクの下にぶら下がっている」と読ませる（ユーザー指摘 2026-08-31）。
        row.frame.pack_configure(pady=(0, 0))
        acc.pack(
            fill="x", after=row.frame,
            padx=(theme.box_margin() + 18, theme.box_margin()), pady=(0, ROW_GAP),
        )
