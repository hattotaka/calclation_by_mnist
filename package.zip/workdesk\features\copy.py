"""文字列コピー（同期）。

args:
    text        … コピーする文字列（平文）
    format      … "plain"（既定）/ "html"
    template_id … format == "html" のとき、共通設定で登録した HTML テンプレートの ID
    encrypt     … true で暗号化。text は持たず secret_id で secrets.json を引く（html とは排他）
    secret_id   … encrypt 時の暗号文キー（動作作成時に採番）
    mention     … true で Slack メンション。実行時に宛先名一覧を出し、選ばれた
                  メンション文字列 + 半角スペース を text の先頭に付ける（encrypt / html とは排他）
    onetime     … true でワンタイム（順次貼り付け）。html / mention とも併用可
    label       … 表示・ポップアップ用の呼称（"ID" 等）

- 平文: clipboard.set_text
- 暗号化: ctx.crypto.decrypt(secret_id)（失敗はワンタイム待ちに入る前に FAILED）
- 書式付き: ctx.templates.get(template_id) の html/text を clipboard.set_html
  （テンプレートは「コピー→共通設定で登録」で作る。大きな本文を想定するので暗号化しない）
- Slack メンション: ctx.mention_directory.pick() で宛先を1つ選ばせる（「メンション無し」可）。
  選ばれた "@xxx" を `"@xxx" + " " + text` の形で先頭付与。ワンタイム待ちに入る前に解決する。
- ワンタイム: ctx.onetime.gate_paste(label, payload) に委譲
"""

from __future__ import annotations

from typing import Any

from ..result import PreflightError, Result, Status
from ..services.clipboard import ClipboardPayload
from ..services.crypto import CryptoError
from .base import Feature
from .registry import register


@register("copy")
class CopyFeature(Feature):
    feature_name = "コピー"
    is_async = False

    def is_interactive(self, args: dict[str, Any]) -> bool:
        return bool(args.get("onetime"))

    def preflight(self, args: dict[str, Any], ctx) -> None:
        if args.get("mention") and (args.get("encrypt") or args.get("format") == "html"):
            raise PreflightError("Slackメンションは暗号化・HTMLと同時には使えません")
        if args.get("encrypt"):
            crypto = getattr(ctx, "crypto", None)
            sid = args.get("secret_id")
            if not sid:
                raise PreflightError("暗号化の登録が不完全です（secret_id なし）")
            if crypto is None or not crypto.is_configured():
                raise PreflightError("暗号化が初期化されていません")
            if not crypto.unlocked:
                raise PreflightError("暗号鍵がロックされています（パスフレーズ未入力）")
            if not crypto.has_secret(sid):
                raise PreflightError("暗号化された文字列が登録されていません")
            return
        if args.get("format") == "html":
            ts = getattr(ctx, "templates", None)
            tid = args.get("template_id")
            if not tid:
                raise PreflightError("HTMLテンプレートが選択されていません")
            if ts is None or ts.get(tid) is None:
                raise PreflightError("HTMLテンプレートが見つかりません")
            return
        if "text" not in args:
            raise PreflightError("コピーする文字列が登録されていません")

    def _payload(self, args: dict[str, Any], ctx) -> ClipboardPayload:
        if args.get("encrypt"):
            text = ctx.crypto.decrypt(args["secret_id"])   # CryptoError は execute で捕捉
            return ClipboardPayload(text=text)
        if args.get("format") == "html":
            t = ctx.templates.get(args["template_id"])
            return ClipboardPayload(text=t.text, html=t.html)
        return ClipboardPayload(text=str(args.get("text", "")))

    def _pick_mention(self, args: dict[str, Any], ctx) -> str:
        """宛先名一覧を出して選ばせる。選ばれたメンション文字列（無しは ""）。"""
        md = getattr(ctx, "mention_directory", None)
        if md is None:
            return ""
        return md.pick(
            preview=str(args.get("text", "")),
            label=str(args.get("label") or ""),
        )

    def execute(self, args: dict[str, Any], ctx) -> Result:
        label = args.get("label")
        mention = ""
        try:
            if args.get("mention"):
                mention = self._pick_mention(args, ctx)   # ワンタイム待ちに入る前に解決
            payload = self._payload(args, ctx)
        except CryptoError as e:
            return Result(Status.FAILED, str(e))

        if mention:
            payload = ClipboardPayload(text=f"{mention} {payload.text}", html=payload.html)
        detail = ""
        if args.get("mention"):
            detail = f"宛先={mention or '（メンション無し）'}"

        if args.get("onetime") and getattr(ctx, "onetime", None) is not None:
            ctx.onetime.gate_paste(label or "文字列", payload)   # 中止時は SequenceAbort
            msg = f"貼り付け完了（{label}）" if label else "貼り付け完了"
            return Result(Status.OK, message=msg, detail=detail)

        payload.apply(ctx.clipboard)
        msg = f"コピーしました（{label}）" if label else "コピーしました"
        return Result(Status.OK, message=msg, detail=detail)
