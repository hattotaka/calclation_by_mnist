"""階層要素の CRUD（純粋関数）。設定モードの編集操作の実体。

- 対象: 業務グループ / 業務 / タスクグループ / タスク / 動作。
- ID はツリー全体で一意なので、delete / rename / insert_after は ID だけで対象を特定できる。
- add は親コンテキスト（親 ID）が要るので型別の関数を用意する。
- 並べ替え・グループ移動は `move_before_sibling` / `move_work` / `move_task` /
  `move_*_to_new_group`（§16bis Phase D。行のどこでもドラッグ）。
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from .model import Action, AppData, Task, TaskGroup, Work, WorkGroup


# --------------------------------------------------------------------------- #
# 内部: ツリー内の全順序リストを走査
# --------------------------------------------------------------------------- #
def _all_lists(data: AppData) -> Iterator[list]:
    yield data.work_groups
    for wg in data.work_groups:
        yield wg.works
        for w in wg.works:
            yield w.task_groups
            for tg in w.task_groups:
                yield tg.tasks
                for t in tg.tasks:
                    yield t.actions


def _owner(data: AppData, entity_id: str) -> tuple[list | None, int]:
    for lst in _all_lists(data):
        for i, item in enumerate(lst):
            if item.id == entity_id:
                return lst, i
    return None, -1


# --------------------------------------------------------------------------- #
# 検索
# --------------------------------------------------------------------------- #
def find_work_group(data: AppData, gid: str) -> WorkGroup | None:
    return next((g for g in data.work_groups if g.id == gid), None)


def find_work(data: AppData, wid: str) -> Work | None:
    for g in data.work_groups:
        for w in g.works:
            if w.id == wid:
                return w
    return None


def find_task_group(data: AppData, tgid: str) -> TaskGroup | None:
    for g in data.work_groups:
        for w in g.works:
            for tg in w.task_groups:
                if tg.id == tgid:
                    return tg
    return None


def find_task(data: AppData, tid: str) -> Task | None:
    for g in data.work_groups:
        for w in g.works:
            for tg in w.task_groups:
                for t in tg.tasks:
                    if t.id == tid:
                        return t
    return None


def find_action(data: AppData, aid: str) -> Action | None:
    for lst in _all_lists(data):
        for item in lst:
            if isinstance(item, Action) and item.id == aid:
                return item
    return None


def parent_task_of_action(data: AppData, aid: str) -> Task | None:
    """動作 `aid` が属するタスクを返す（無ければ None）。"""
    for g in data.work_groups:
        for w in g.works:
            for tg in w.task_groups:
                for t in tg.tasks:
                    if any(a.id == aid for a in t.actions):
                        return t
    return None


def ancestor_names(data: AppData, entity_id: str) -> list[str]:
    """`entity_id`（業務/タスク/動作）の祖先の名前を上位→直近の順で返す。

    業務 → `[]` ／ タスク → `[業務名]` ／ 動作 → `[業務名, タスク名]`。
    デザインラボのパンくず表示に使う（entity 自身は含めない）。
    """
    for g in data.work_groups:
        for w in g.works:
            if w.id == entity_id:
                return []
            for tg in w.task_groups:
                for t in tg.tasks:
                    if t.id == entity_id:
                        return [w.name]
                    if any(a.id == entity_id for a in t.actions):
                        return [w.name, t.name]
    return []


# --------------------------------------------------------------------------- #
# 汎用操作（ID 指定）
# --------------------------------------------------------------------------- #
def rename(data: AppData, entity_id: str, new_name: str) -> bool:
    lst, i = _owner(data, entity_id)
    if lst is None:
        return False
    lst[i].name = new_name
    return True


def delete(data: AppData, entity_id: str) -> bool:
    lst, i = _owner(data, entity_id)
    if lst is None:
        return False
    del lst[i]
    return True


# --------------------------------------------------------------------------- #
# 追加（型別）
# --------------------------------------------------------------------------- #
def add_work_group(data: AppData, name: str = "") -> WorkGroup:
    wg = WorkGroup(name=name)
    data.work_groups.append(wg)
    return wg


def add_work(data: AppData, group_id: str, name: str) -> Work | None:
    g = find_work_group(data, group_id)
    if g is None:
        return None
    w = Work(name=name)
    g.works.append(w)
    return w


def add_task_group(data: AppData, work_id: str, name: str = "") -> TaskGroup | None:
    w = find_work(data, work_id)
    if w is None:
        return None
    tg = TaskGroup(name=name)
    w.task_groups.append(tg)
    return tg


def add_task(data: AppData, task_group_id: str, name: str) -> Task | None:
    tg = find_task_group(data, task_group_id)
    if tg is None:
        return None
    t = Task(name=name)
    tg.tasks.append(t)
    return t


def move_before_sibling(data: AppData, entity_id: str, before_id: str | None) -> bool:
    """`entity_id` を **同じ親リスト内** で `before_id` の直前へ移す。
    `before_id=None` で末尾へ。`before_id` が別リストの要素なら False（動作の D&D 用）。
    """
    lst, i = _owner(data, entity_id)
    if lst is None:
        return False
    item = lst[i]
    if before_id is None:
        lst.pop(i)
        lst.append(item)
        return True
    lst2, _j = _owner(data, before_id)
    if lst2 is not lst:
        return False
    lst.pop(i)
    k = next((n for n, x in enumerate(lst) if x.id == before_id), len(lst))
    lst.insert(k, item)
    return True


def move_work(
    data: AppData, work_id: str, dest_group_id: str, before_id: str | None = None
) -> bool:
    """業務を `dest_group_id` の業務グループへ移す（`before_id` の直前 / None で末尾）。
    D&D の並べ替え＋グループ間移動（§16bis Phase D）。同一グループ内の並べ替えも兼ねる。
    """
    src, i = _owner(data, work_id)
    dest = find_work_group(data, dest_group_id)
    if src is None or dest is None or not isinstance(src[i], Work):
        return False
    w = src.pop(i)
    if before_id is None:
        dest.works.append(w)
    else:
        k = next((n for n, x in enumerate(dest.works) if x.id == before_id), len(dest.works))
        dest.works.insert(k, w)
    return True


def move_task(
    data: AppData, task_id: str, dest_group_id: str, before_id: str | None = None
) -> bool:
    """タスクを `dest_group_id` のタスクグループへ移す（`before_id` の直前 / None で末尾）。
    D&D の並べ替え＋タスクグループ間移動（§16bis Phase D）。同一グループ内の並べ替えも兼ねる。
    """
    src, i = _owner(data, task_id)
    dest = find_task_group(data, dest_group_id)
    if src is None or dest is None or not isinstance(src[i], Task):
        return False
    t = src.pop(i)
    if before_id is None:
        dest.tasks.append(t)
    else:
        k = next((n for n, x in enumerate(dest.tasks) if x.id == before_id), len(dest.tasks))
        dest.tasks.insert(k, t)
    return True


def move_work_to_new_group(data: AppData, work_id: str) -> bool:
    """業務を **新しい業務グループ**（末尾に作る）へ移す（§16bis Phase D。最終行の下へドロップ）。"""
    src, i = _owner(data, work_id)
    if src is None or not isinstance(src[i], Work):
        return False
    wg = WorkGroup(name="")
    data.work_groups.append(wg)
    wg.works.append(src.pop(i))
    return True


def move_task_to_new_group(data: AppData, task_id: str, work_id: str) -> bool:
    """タスクを **新しいタスクグループ**（その業務の末尾に作る）へ移す（§16bis Phase D）。"""
    src, i = _owner(data, task_id)
    w = find_work(data, work_id)
    if src is None or w is None or not isinstance(src[i], Task):
        return False
    tg = TaskGroup(name="")
    w.task_groups.append(tg)
    tg.tasks.append(src.pop(i))
    return True


def insert_after(data: AppData, anchor_id: str, item: Any) -> bool:
    """`anchor_id` の要素の直後に、同じ親リストへ `item` を挿入する（兄弟挿入）。

    コピー&貼り付け（design-notes §16bis Phase C）用。`item` の型が親リストと
    整合しているかは呼び出し側の責任（Work→works / Task→tasks / Action→actions）。
    """
    lst, i = _owner(data, anchor_id)
    if lst is None:
        return False
    lst.insert(i + 1, item)
    return True


def add_action(data: AppData, task_id: str, action_id: str, args: dict[str, Any]) -> Action | None:
    t = find_task(data, task_id)
    if t is None:
        return None
    a = Action(action_id=action_id, args=dict(args))
    t.actions.append(a)
    return a
