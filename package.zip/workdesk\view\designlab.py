"""デザインラボ（design-notes §16 / §16bis まとまり A）。

実画面を見ながら調整する常設パネル。モードレス（掴んだまま本体を触れる）。2 タブ:
- **レイアウト** … 業務・タスク・動作の構成（追加 / 改名 / 色 / コピー&貼り付け）。
  最上部の「設定モード」スイッチが ON のときだけ編集できる（＝App のモード切替口はここだけ）。
- **スタイル** … 画面そのものの見た目（**テーマ ライト/ダーク** / フォント / スクロールバー /
  フォーカス・ホバー表現 / クリック密度 / 最背面 dblclick）。`theme.set_theme` / `set_font` /
  `set_option` を叩くだけで即反映、theme の保存フックで `settings.appearance` に永続化。
  テーマ切替は App が全再構築＋このパネルを `reskin()`（子を捨てて `_build_ui()` 再実行。
  Toplevel・位置永続化・`_edit_ping` は残す。after(0) で＝ラジオの callback を抜けてから）。

- このパネル自身の文字はアプリの設定に追従させず **Yu Gothic UI / 12 固定**。
- コントロールは Windows ネイティブ感を避け、アプリの行と同じ質感の自作パーツ。フォント一覧のみ Combobox。
- 「設定モード」スイッチは **既定 OFF・状態は保存しない**（開くたび通常モードから）。閉じると通常モードへ。
"""

from __future__ import annotations

import tkinter as tk
from tkinter import colorchooser, ttk

from .. import hierarchy
from . import theme
from .dockpanel import DockPanel
from .uikit import Debouncer, accent_button

_UI = ("Yu Gothic UI", 12)
_UI_BOLD = ("Yu Gothic UI", 12, "bold")
_UI_BIG = ("Yu Gothic UI", 15, "bold")   # レイアウトタブの「種別」見出し
_UI_SMALL = ("Yu Gothic UI", 10)          # レイアウトタブのパンくず
_STEP = ("Yu Gothic UI", 13, "bold")
_INPUT = ("Yu Gothic UI", 13)

_THEME = [
    ("light", "ライト"),
    ("dark", "ダーク"),
]
_SCROLLBAR = [
    ("always", "常に表示"),
    ("auto", "収まる時は隠す"),
    ("thin", "細身"),
    ("hover", "ホバー時のみ"),
]
_DENSITY = [
    ("compact", "狭い"),
    ("normal", "標準"),
    ("roomy", "広い"),
]


class _Switch(tk.Canvas):
    """iOS 風のトグルスイッチ（Tk に無いので Canvas で自作）。

    トラック＝両端の円＋中央の矩形で角丸を作る。ノブ＝白い円が左右にスライド。
    ON＝アクセント色 / OFF＝グレー。`command(on: bool)` を発火する。
    """

    _W, _H, _PAD = 38, 20, 3

    def __init__(self, parent: tk.Misc, *, command, bg: str) -> None:
        super().__init__(
            parent, width=self._W, height=self._H,
            highlightthickness=0, bd=0, bg=bg, cursor="hand2",
        )
        self._on = False
        self._command = command
        self.bind("<Button-1>", lambda _e: self.toggle())
        self._draw()

    def set(self, on: bool) -> None:
        self._on = bool(on)
        self._draw()

    def toggle(self) -> None:
        self._on = not self._on
        self._draw()
        if self._command is not None:
            self._command(self._on)

    def _draw(self) -> None:
        self.delete("all")
        w, h, p = self._W, self._H, self._PAD
        track = str(theme.PALETTE["accent"]) if self._on else str(theme.PALETTE["switch_off"])
        # 両端は半円（弧の平ら側＝垂直）＋中央は矩形。すべて垂直線で接するので
        # 「曲線と水平線のズレ」による角が出ない。
        self.create_arc(0, 0, h, h, start=90, extent=180, style="pieslice",
                        fill=track, outline=track)
        self.create_arc(w - h, 0, w, h, start=270, extent=180, style="pieslice",
                        fill=track, outline=track)
        self.create_rectangle(h / 2, 0, w - h / 2, h, fill=track, outline=track)
        kx = (w - h) if self._on else 0
        knob = str(theme.PALETTE["switch_knob"])
        self.create_oval(kx + p, p, kx + h - p, h - p, fill=knob, outline=knob)


class DesignLabWindow(DockPanel):
    pos_key = "design_lab"

    def __init__(self, app) -> None:
        super().__init__(app)
        self._edit_ping = Debouncer(self)   # 選択/モード変更 → refresh_edit を after(0) で1回に
        self._edit_body: tk.Frame | None = None
        self._act_form_aid: str | None = None   # 動作フォームを開いている動作 id
        self._act_form = None
        self.title("デザインラボ")

        self._build_ui()
        # 既定位置は本体の右隣（横に並べて切り替わりを見たいという要望）
        self.install_position_persistence()

    def _build_ui(self) -> None:
        """パネル中身を組む。`reskin()`（テーマ切替）から再実行される＝Toplevel と
        位置永続化・`_edit_ping` は残したまま、子ウィジェットだけ作り直す。"""
        # 最上部: 「設定モード」スイッチ（両タブから見える＝ノートブックの外）
        self._build_mode_switch()

        theme.style_ttk(self)   # clam 土台＋Combobox/Notebook をテーマ色へ（§17.7 改善）
        style = ttk.Style(self)
        surf = str(theme.PALETTE["row_normal"])
        style.configure(
            "Lab.TNotebook", background=self["bg"], borderwidth=0,
        )
        style.configure(
            "Lab.TNotebook.Tab", padding=(8, 5), font=_UI, width=9, anchor="center",
            background=self["bg"], foreground=str(theme.PALETTE["sub"]),
            bordercolor=str(theme.PALETTE["input_border"]), lightcolor=self["bg"],
        )
        style.map(
            "Lab.TNotebook.Tab",
            background=[("selected", surf)],
            # 選択中のタブ見出しはアクセント色＋太字で（どちらを見ているか一目で分かる）
            foreground=[("selected", str(theme.PALETTE["accent"]))],
            font=[("selected", _UI_BOLD)],
            lightcolor=[("selected", surf)],
        )
        nb = ttk.Notebook(self, style="Lab.TNotebook")
        nb.pack(fill="x", padx=6, pady=(24, 0))   # スイッチとタブ見出しの間隔
        self._nb = nb
        self._layout_tab = tk.Frame(nb, bg=self["bg"])
        self._style_tab = tk.Frame(nb, bg=self["bg"])
        nb.add(self._layout_tab, text="レイアウト")
        nb.add(self._style_tab, text="スタイル")

        # --- スタイルタブ（画面そのものの見た目） --------------------- #
        self._host = self._style_tab
        self._section("テーマ")
        self._segmented("theme", _THEME, setter=theme.set_theme)
        self._section("フォント")
        self._font_controls()
        self._section("スクロールバー")
        self._segmented("scrollbar_mode", _SCROLLBAR)
        self._section("選択中の業務のインデント")
        self._indent_row()
        self._section("クリック領域")
        self._segmented("click_density", _DENSITY)
        self._section("余白")
        self._slider_row("list_top_pad", "帯からの距離", 0, 40)
        self._section("その他")
        self._checkrow("send_to_back_dblclick", "ダブルクリックで最背面へ")
        tk.Frame(self._style_tab, height=12, bg=self["bg"]).pack()

        # --- レイアウトタブ（構成の編集。選択に応じて中身が変わる） ----- #
        self._edit_wrap = tk.Frame(self._layout_tab, bg=self["bg"])
        self._edit_wrap.pack(fill="x")
        self.refresh_edit()
        tk.Frame(self._layout_tab, height=12, bg=self["bg"]).pack()

        nb.select(self._layout_tab)   # 既定＝レイアウト（使用頻度が高い）

    def reskin(self) -> None:
        """テーマ切替（§17.7）。子ウィジェットを捨てて `_build_ui()` で作り直す
        （色が各所に直書きのため。App `_rebuild_for_theme` が after(0) で呼ぶ）。"""
        if not self.winfo_exists():
            return
        try:
            cur_tab = self._nb.index(self._nb.select())
        except (tk.TclError, AttributeError):
            cur_tab = 0
        self._bg = str(theme.PALETTE["row_normal"])
        self.configure(bg=self._bg)
        self._act_form = None
        for w in list(self.winfo_children()):
            w.destroy()
        self._build_ui()
        try:
            self._nb.select(cur_tab)
        except tk.TclError:
            pass

    # --- 「設定モード」スイッチ（App のモード切替口はここだけ） ------- #
    def _build_mode_switch(self) -> None:
        bar = tk.Frame(self, bg=self["bg"])
        bar.pack(fill="x", padx=12, pady=(18, 2))   # 窓の帯とスイッチの間隔
        self._switch = _Switch(bar, command=self._on_switch, bg=self["bg"])
        self._switch.pack(side="left")
        self._mode_lbl = tk.Label(
            bar, text="設定モード（配置を編集）", bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_UI_BOLD, cursor="hand2"
        )
        self._mode_lbl.pack(side="left", padx=(8, 0))
        self._mode_lbl.bind("<Button-1>", lambda _e: self._switch.toggle())
        self.sync_mode_switch()

    def _on_switch(self, on: bool) -> None:
        self.app.set_edit_mode(on)   # App が _set_mode → sync_mode_switch を呼び戻す

    def sync_mode_switch(self) -> None:
        """App 側で mode が変わったら呼ばれる（スイッチの見た目を合わせる）。"""
        if not self.winfo_exists():
            return
        self._switch.set(self.app.mode == "settings")

    def request_edit_refresh(self) -> None:
        """選択/モード変更で App から呼ばれる。クリック処理中に widget を壊さないよう
        `after(0)` で 1 回にまとめて `refresh_edit()`。"""
        self._edit_ping.schedule(0, self.refresh_edit)

    # --- レイアウトタブの編集セクション（設定モード時のみ中身が入る） --- #
    def refresh_edit(self) -> None:
        """選択やモードが変わるたびに App から呼ばれる。中身をアトミックに差し替える。"""
        if not self.winfo_exists():
            return
        app = self.app
        old = self._edit_body
        body = tk.Frame(self._edit_wrap, bg=self["bg"])

        if getattr(app, "mode", "normal") == "settings" and app._cb is not None:  # noqa: SLF001
            self._build_edit(body)
        else:
            self._hint(body, "上の「設定モード」をオンにすると 業務・タスク・動作を編集できます")

        body.pack(fill="x")
        if old is not None:
            old.destroy()
        self._edit_body = body

    def _build_edit(self, body: tk.Frame) -> None:
        """レイアウトタブの中身。**選択している種類（業務/タスク/動作）でカードを出し分ける**
        （§16bis まとまり B）。"""
        kind, ident = self.app._sel  # noqa: SLF001
        # 「フォームを開いた当の動作」以外に移ったら、その開状態を捨てる
        # （別の動作を選んで戻ってきたら閉じている＝再度「編集」を押す。§16bis まとまり B 追補 #5）
        if not (kind == "action" and ident == self._act_form_aid):
            self._act_form_aid = None
        if kind in ("work", "task", "action"):
            self._crumb_header(body, kind, ident)
        if kind == "work":
            self._card_work(body, ident)
        elif kind == "task":
            self._card_task(body, ident)
        elif kind == "action":
            self._card_action(body, ident)
        else:
            self._card_none(body)

    def _crumb_header(self, body: tk.Frame, kind: str, ident: str) -> None:
        """カード上部の2行ヘッダ＝①祖先のパンくず（小・sub 色）②種別（大）。"""
        names = hierarchy.ancestor_names(self.app.app_data, ident)
        crumb = "".join(n + " ＞ " for n in names).strip() or "＞"
        tk.Label(
            body, text=crumb, bg=self["bg"], fg=str(theme.PALETTE["sub"]),
            font=_UI_SMALL, anchor="w",
        ).pack(fill="x", padx=14, pady=(10, 0))
        kind_ja = {"work": "業務", "task": "タスク", "action": "動作"}.get(kind, "")
        tk.Label(
            body, text=kind_ja, bg=self["bg"], fg=str(theme.PALETTE["ink"]),
            font=_UI_BIG, anchor="w",
        ).pack(fill="x", padx=14, pady=(0, 2))

    # --- 種類別カード ------------------------------------------- #
    def _card_none(self, body: tk.Frame) -> None:
        self._hint(body, "サイドバーで業務を、メインでタスク・動作を選ぶと ここに編集項目が出ます")
        row = tk.Frame(body, bg=self["bg"])
        row.pack(fill="x", padx=14, pady=(6, 0))
        accent_button(row, "＋ 新規グループ", self.app.add_work_in_new_group).pack(side="left")

    def _card_work(self, body: tk.Frame, wid: str) -> None:
        app = self.app
        cb = app._cb  # noqa: SLF001
        work = hierarchy.find_work(app.app_data, wid)
        gidx, gid = app._group_of_work(wid)  # noqa: SLF001
        if work is None or gid is None:
            self._card_none(body)
            return
        self._name_field(body, "業務名", work.name, lambda s: app.rename_live(wid, s))
        self._btn_row(
            body,
            ("＋ 同じグループ", lambda g=gid: cb.add_work(g)),
            ("＋ 新規グループ", app.add_work_in_new_group),
            copy=("work", wid),
            delete=(wid, work.name),
        )
        self._group_color_row(body, gidx)

    def _card_task(self, body: tk.Frame, tid: str) -> None:
        app = self.app
        cb = app._cb  # noqa: SLF001
        task = hierarchy.find_task(app.app_data, tid)
        work = next(
            (w for wg in app.app_data.work_groups for w in wg.works
             for tg in w.task_groups if any(t.id == tid for t in tg.tasks)),
            None,
        )
        if task is None or work is None:
            self._card_none(body)
            return
        tgid = app._taskgroup_id_of_task(work, tid)  # noqa: SLF001
        self._name_field(body, "タスク名", task.name, lambda s: app.rename_live(tid, s))
        self._desc_field(body, task.description, lambda s: app.set_task_description(tid, s))
        self._btn_row(
            body,
            ("＋ 同じグループ", lambda t=tgid: cb.add_task(t)),
            ("＋ 新規グループ", lambda w=work.id: app.add_task_in_new_group(w)),
            copy=("task", tid),
            delete=(tid, task.name),
        )

    def _card_action(self, body: tk.Frame, aid: str) -> None:
        from .main_panel import _action_summary   # 遅延 import（循環回避）

        app = self.app
        action = hierarchy.find_action(app.app_data, aid)
        if action is None:
            self._card_none(body)
            return
        names = {t.id: t.name for t in app.templates.list()}
        summary = _action_summary(action, names)
        tk.Label(
            body, text=summary, bg=self["bg"], fg=str(theme.PALETTE["ink"]),
            font=_UI, anchor="w", wraplength=320, justify="left",
        ).pack(fill="x", padx=14, pady=(4, 0))
        ptask = hierarchy.parent_task_of_action(app.app_data, aid)
        acts: list[tuple[str, object]] = [("編集", lambda: self._toggle_action_form(aid))]
        if ptask is not None:
            acts.append(("追加", lambda t=ptask.id: app.add_action(t)))
        self._btn_row(
            body,
            *acts,
            copy=("action", aid),
            delete=(aid, summary),
        )
        if self._act_form_aid == aid:
            self._build_action_form(body, aid)

    def _toggle_action_form(self, aid: str) -> None:
        self._act_form_aid = None if self._act_form_aid == aid else aid
        self.refresh_edit()

    def _build_action_form(self, body: tk.Frame, aid: str) -> None:
        """動作の入力フォームをカード内（ボタンの下）にインライン表示する（§16bis まとまり B 追補）。"""
        from tkinter import messagebox

        from .actiondialog import _ActionForm

        action = hierarchy.find_action(self.app.app_data, aid)
        if action is None:
            return
        wrap = tk.Frame(
            body, bg=self["bg"], highlightthickness=1,
            highlightbackground=str(theme.PALETTE["divider"]),
        )
        wrap.pack(fill="x", padx=14, pady=(8, 0))
        self._act_form = _ActionForm(wrap, self.app, action)
        self._act_form.frame.pack(fill="x", padx=8, pady=8)
        brow = tk.Frame(wrap, bg=self["bg"])
        brow.pack(fill="x", padx=8, pady=(0, 8))

        def apply_() -> None:
            try:
                res = self._act_form.collect()
            except ValueError as e:
                messagebox.showerror("入力エラー", str(e), parent=self)
                return
            self.app.apply_action_edit(aid, res)

        accent_button(brow, "適用", apply_).pack(side="left")

    # --- カード部品 ------------------------------------------- #
    def _desc_field(self, parent: tk.Misc, initial: str, on_change) -> None:
        """タスクの 1 行説明（空欄可・即反映）。通常モードでタイトルの下に出る。"""
        bg = self["bg"]
        wrap = tk.Frame(parent, bg=bg)
        wrap.pack(fill="x", padx=14, pady=(6, 0))
        tk.Label(
            wrap, text="説明（通常モードでタイトルの下に表示）", bg=bg,
            fg=str(theme.PALETTE["sub"]), font=_UI,
        ).pack(anchor="w")
        var = tk.StringVar(value=initial)
        ent = tk.Entry(
            wrap, textvariable=var, font=_INPUT, bd=0, relief="flat",
            bg=str(theme.PALETTE["row_normal"]), fg=str(theme.PALETTE["ink"]),
            insertbackground=str(theme.PALETTE["ink"]), highlightthickness=1,
            highlightbackground=str(theme.PALETTE["input_border"]),
            highlightcolor=str(theme.PALETTE["accent"]),
        )
        ent.pack(fill="x", pady=(2, 0))
        var.trace_add("write", lambda *_a: on_change(var.get()))
        ent.bind("<Return>", lambda _e: parent.focus_set())

    def _name_field(self, parent: tk.Misc, label: str, initial: str, on_change) -> None:
        """名前のインライン編集（保存ボタン無し・即反映）。空欄は FocusOut で直近値へ戻す。"""
        bg = self["bg"]
        wrap = tk.Frame(parent, bg=bg)
        wrap.pack(fill="x", padx=14, pady=(6, 0))
        tk.Label(wrap, text=label, bg=bg, fg=str(theme.PALETTE["sub"]), font=_UI).pack(anchor="w")
        var = tk.StringVar(value=initial)
        ent = tk.Entry(
            wrap, textvariable=var, font=_INPUT, bd=0, relief="flat",
            bg=str(theme.PALETTE["row_normal"]), fg=str(theme.PALETTE["ink"]),
            insertbackground=str(theme.PALETTE["ink"]), highlightthickness=1,
            highlightbackground=str(theme.PALETTE["input_border"]),
            highlightcolor=str(theme.PALETTE["accent"]),
        )
        ent.pack(fill="x", pady=(2, 0))
        last = {"v": initial}

        def changed(*_a) -> None:
            s = var.get()
            if s.strip():
                last["v"] = s
                on_change(s)

        def restore(_e: tk.Event | None = None) -> None:
            if not var.get().strip():
                var.set(last["v"])

        var.trace_add("write", changed)
        ent.bind("<FocusOut>", restore)
        ent.bind("<Return>", lambda _e: parent.focus_set())

    def _btn_row(
        self,
        parent: tk.Misc,
        *actions,
        copy: tuple[str, str] | None = None,
        delete: tuple[str, str] | None = None,
    ) -> None:
        """[ボタン][ボタン] … を等間隔で左詰め（＋ 種類が合えば [コピー] [貼付]、指定あれば [削除]）。"""
        app = self.app
        row = tk.Frame(parent, bg=self["bg"])
        row.pack(fill="x", padx=14, pady=(6, 0))
        items: list[tuple[str, object]] = list(actions)
        if copy is not None:
            kind, ident = copy
            items.append(("コピー", lambda k=kind, x=ident: app.copy_entity(k, x)))
            if app.can_paste(kind):
                items.append(("貼付", lambda k=kind, x=ident: app.paste_entity(k, x)))
        if delete is not None:
            eid, label = delete
            items.append(
                ("削除", lambda e=eid, la=label: app._cb.delete(e, la))  # noqa: SLF001
            )
        for i, (text, cmd) in enumerate(items):
            accent_button(row, text, cmd).pack(side="left", padx=(0 if i == 0 else 6, 0))

    def _hint(self, parent: tk.Misc, text: str) -> None:
        tk.Label(
            parent, text=text, bg=self["bg"], fg=str(theme.PALETTE["sub"]), font=_UI, anchor="w",
        ).pack(fill="x", padx=14, pady=(8, 0))

    _QUICKPICK_MAX = 6   # パネル幅に収まる個数

    def _group_color_row(self, parent: tk.Misc, gidx: int) -> None:
        bg = self["bg"]
        wrap = tk.Frame(parent, bg=bg)
        wrap.pack(fill="x", padx=14, pady=(6, 0))
        tk.Label(wrap, text="グループ色", bg=bg, fg=str(theme.PALETTE["sub"]), font=_UI).pack(side="left")

        cur = theme.group_color(gidx)
        edge = str(theme.PALETTE["divider"])
        # 現在の色（右クリックで既定へ戻す）
        now = tk.Label(
            wrap, bg=cur, width=3, height=1, bd=0, highlightthickness=1,
            highlightbackground=edge,
        )
        now.pack(side="left", padx=(6, 0))
        now.bind("<Button-3>", lambda _e, i=gidx: theme.set_group_color(i, None))

        # 少し隙間 → クイックピック（履歴を先に、幅に収まる個数だけ）
        pal = list(theme.STATE.get("group_color_palette") or [])
        picks, seen = [], set()
        for c in [*reversed(pal), *theme.GROUP_COLOR_PRESETS]:
            k = str(c).lower()
            if k not in seen:
                seen.add(k)
                picks.append(str(c))
            if len(picks) >= self._QUICKPICK_MAX:
                break
        strip = tk.Frame(wrap, bg=bg)
        strip.pack(side="left", padx=(14, 0))
        acc = str(theme.PALETTE["accent"])
        for hexc in picks:
            shown = theme.fit_tint(hexc)   # 表示も現テーマ向けに正規化
            on = shown == cur
            sw = tk.Label(
                strip, bg=shown, width=2, height=1, cursor="hand2", bd=0,
                highlightthickness=2 if on else 1,
                highlightbackground=acc if on else edge,
            )
            sw.pack(side="left", padx=2)
            sw.bind("<Button-1>", lambda _e, c=hexc, i=gidx: theme.set_group_color(i, c))

        other = tk.Label(wrap, text="その他…", bg=bg, fg=str(theme.PALETTE["accent"]),
                         font=_UI, cursor="hand2")
        other.pack(side="left", padx=(8, 0))
        other.bind("<Button-1>", lambda _e, i=gidx: self._pick_color(i))

    def _pick_color(self, gidx: int) -> None:
        try:
            _rgb, hexc = colorchooser.askcolor(
                color=theme.group_color(gidx), parent=self, title="グループ色"
            )
        except tk.TclError:
            return
        if hexc:
            theme.set_group_color(gidx, hexc)
            theme.add_palette_color(hexc)   # 選んだ色はパレットへ自動登録

    # --- パーツ ------------------------------------------------- #
    def _section(self, text: str, parent: tk.Misc | None = None) -> None:
        tk.Label(
            parent or self._host, text=text, bg=self["bg"],
            fg=str(theme.PALETTE["sub"]), font=_UI_BOLD, anchor="w",
        ).pack(fill="x", padx=14, pady=(12, 4))

    def _cell_paint(self, cell: tk.Label, active: bool) -> None:
        # 枠は relief=solid（黒）ではなく highlightbackground（テーマ色）で（§17 ユーザー指摘）
        accent = str(theme.PALETTE["accent"])
        edge = accent if active else str(theme.PALETTE["input_border"])
        cell.configure(
            bg=accent if active else str(theme.PALETTE["row_normal"]),
            fg=str(theme.PALETTE["on_accent" if active else "ink"]),
            bd=0, relief="flat", highlightthickness=1,
            highlightbackground=edge, highlightcolor=edge,
        )

    def _segmented(self, key: str, options: list[tuple[str, str]], setter=None) -> None:
        """`key` の値をセグメントボタンで選ぶ。`setter(val)` 既定は `theme.set_option(key, ·)`。
        テーマだけは `setter=theme.set_theme`（PALETTE 差し替え＋キャッシュ破棄まで行う）。"""
        apply = setter or (lambda v: theme.set_option(key, v))
        row = tk.Frame(self._host, bg=self["bg"])
        row.pack(fill="x", padx=14)
        cells: dict[str, tk.Label] = {}

        def pick(val: str) -> None:
            apply(val)
            for v, c in cells.items():
                if c.winfo_exists():   # setter がテーマ切替なら reskin で消えていることがある
                    self._cell_paint(c, v == val)

        for val, label in options:
            c = tk.Label(
                row, text=label, font=_UI, padx=12, pady=6, cursor="hand2",
            )
            c.pack(side="left", padx=(0, 6))
            c.bind("<Button-1>", lambda _e, v=val: pick(v))
            cells[val] = c
        for v, c in cells.items():
            self._cell_paint(c, v == theme.STATE[key])

    def _checkrow(self, key: str, text: str) -> None:
        row = tk.Frame(self._host, bg=self["bg"], cursor="hand2")
        row.pack(fill="x", padx=14, pady=2)
        box = tk.Label(row, bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_STEP)
        box.pack(side="left")
        lbl = tk.Label(row, text=text, bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_UI)
        lbl.pack(side="left", padx=(6, 0))
        state = {"on": bool(theme.STATE[key])}

        def render() -> None:
            box.configure(
                text="☑" if state["on"] else "☐",
                fg=str(theme.PALETTE["accent"]) if state["on"] else str(theme.PALETTE["faint"]),
            )

        def toggle(_e: tk.Event | None = None) -> None:
            state["on"] = not state["on"]
            theme.set_option(key, state["on"])
            render()

        for w in (row, box, lbl):
            w.bind("<Button-1>", toggle)
        render()

    def _indent_row(self) -> None:
        """[☑ インデント  ====o====  7]  … チェックのすぐ右にスライダー。"""
        row = tk.Frame(self._host, bg=self["bg"])
        row.pack(fill="x", padx=14, pady=2)
        box = tk.Label(row, bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_STEP, cursor="hand2")
        box.pack(side="left")
        lbl = tk.Label(row, text="インデント", bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_UI, cursor="hand2")
        lbl.pack(side="left", padx=(6, 8))   # 「ト」から少しだけ間を空けてスライダー
        state = {"on": bool(theme.STATE["sel_indent"])}

        def render() -> None:
            box.configure(
                text="☑" if state["on"] else "☐",
                fg=str(theme.PALETTE["accent"]) if state["on"] else str(theme.PALETTE["faint"]),
            )

        def toggle(_e: tk.Event | None = None) -> None:
            state["on"] = not state["on"]
            theme.set_option("sel_indent", state["on"])
            render()

        for w in (box, lbl):
            w.bind("<Button-1>", toggle)

        cur = int(theme.STATE.get("sel_indent_px", theme.SEL_INDENT))
        last = {"v": cur}
        val = tk.Label(row, bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_UI, width=2, anchor="w", text=str(cur))

        def on_slide(v: str) -> None:
            n = int(float(v))
            val.configure(text=str(n))
            if n == last["v"]:
                return
            last["v"] = n
            theme.set_option("sel_indent_px", n)

        s = tk.Scale(
            row, from_=0, to=32, orient="horizontal", showvalue=False,
            length=140, bg=self["bg"], highlightthickness=0, bd=0,
            width=15, sliderlength=30, troughcolor=str(theme.PALETTE["trough"]),
        )
        s.set(cur)
        s.configure(command=on_slide)
        s.pack(side="left")
        val.pack(side="left", padx=(8, 0))
        render()

    def _slider_row(self, key: str, label: str, lo: int, hi: int) -> None:
        """[ラベル  ====o====  N]  … 整数値スライダー（`theme.set_option(key, N)`）。"""
        row = tk.Frame(self._host, bg=self["bg"])
        row.pack(fill="x", padx=14, pady=2)
        tk.Label(
            row, text=label, bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_UI,
        ).pack(side="left", padx=(0, 8))
        cur = int(theme.STATE.get(key, lo))
        last = {"v": cur}
        val = tk.Label(
            row, bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_UI, width=2,
            anchor="w", text=str(cur),
        )

        def on_slide(v: str) -> None:
            n = int(float(v))
            val.configure(text=str(n))
            if n == last["v"]:
                return
            last["v"] = n
            theme.set_option(key, n)

        s = tk.Scale(
            row, from_=lo, to=hi, orient="horizontal", showvalue=False,
            length=140, bg=self["bg"], highlightthickness=0, bd=0,
            width=15, sliderlength=30, troughcolor=str(theme.PALETTE["trough"]),
        )
        s.set(cur)
        s.configure(command=on_slide)
        s.pack(side="left")
        val.pack(side="left", padx=(8, 0))

    def _font_controls(self) -> None:
        wrap = tk.Frame(self._host, bg=self["bg"])
        wrap.pack(fill="x", padx=14)
        fams = theme.available_families(self) or [str(theme.STATE["font_family"])]
        self._family = tk.StringVar(value=str(theme.STATE["font_family"]))
        cb = ttk.Combobox(
            wrap, textvariable=self._family, values=fams, state="readonly",
            width=26, height=20, font=_UI,
        )
        cb.pack(side="left")
        cb.bind(
            "<<ComboboxSelected>>",
            lambda _e: theme.set_font(family=self._family.get()),
        )

        srow = tk.Frame(self._host, bg=self["bg"])
        srow.pack(fill="x", padx=14, pady=(8, 0))
        tk.Label(srow, text="サイズ", bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_UI).pack(side="left")
        self._size_lbl = tk.Label(
            srow, width=3, bg=self["bg"], fg=str(theme.PALETTE["ink"]), font=_STEP, text=str(theme.STATE["font_size"])
        )

        def bump(d: int) -> None:
            n = max(7, min(16, int(theme.STATE["font_size"]) + d))
            theme.set_font(size=n)
            self._size_lbl.configure(text=str(n))

        self._stepper(srow, "−", lambda: bump(-1)).pack(side="left", padx=(10, 3))
        self._size_lbl.pack(side="left", padx=3)
        self._stepper(srow, "＋", lambda: bump(1)).pack(side="left", padx=3)

    def _stepper(self, parent: tk.Misc, text: str, cmd) -> tk.Label:
        edge = str(theme.PALETTE["input_border"])
        b = tk.Label(
            parent, text=text, font=_STEP, width=2, padx=8, pady=2, cursor="hand2",
            bg=str(theme.PALETTE["row_normal"]), fg=str(theme.PALETTE["ink"]),
            bd=0, relief="flat", highlightthickness=1,
            highlightbackground=edge, highlightcolor=edge,
        )
        b.bind("<Button-1>", lambda _e: cmd())
        return b
