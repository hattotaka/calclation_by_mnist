"""階層データモデル。

    業務グループ ＞ 業務 ＞ タスクグループ ＞ タスク ＞ 動作

- 業務グループ / タスクグループ … 形式的な名前のみ。表示しない。並び順・グルーピングの単位。
- 業務 … サイドバーに表示。
- タスク … メインパネルに表示。クリックで動作列を実行。
- 動作 … 名前なし。`action_id`（機能の種類）＋ `args`。

順序はすべてリストの並び順で表現する。ID は UUID4（16進文字列）。
"""

from __future__ import annotations

import copy
import uuid
from dataclasses import dataclass, field
from typing import Any, Iterator

# 業務が必ず属する既定グループ（空のグループ名の代わりに使う表示上の概念）。
DEFAULT_GROUP_NAME = "未分類"


def new_id() -> str:
    """新しいエンティティ ID を発行する。"""
    return uuid.uuid4().hex


# --------------------------------------------------------------------------- #
# 動作
# --------------------------------------------------------------------------- #
@dataclass
class Action:
    """タスクにぶら下がる 1 つの処理。第1版では JSON シードで投入する。"""

    action_id: str                                   # "copy" / "open_file" / ...
    args: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=new_id)

    @classmethod
    def from_dict(cls, d: dict) -> "Action":
        return cls(
            action_id=d["action_id"],
            args=dict(d.get("args") or {}),
            id=d.get("id") or new_id(),
        )

    def to_dict(self) -> dict:
        return {"id": self.id, "action_id": self.action_id, "args": self.args}


# --------------------------------------------------------------------------- #
# タスク
# --------------------------------------------------------------------------- #
@dataclass
class Task:
    name: str
    actions: list[Action] = field(default_factory=list)
    id: str = field(default_factory=new_id)
    description: str = ""   # 通常モードでタイトルの下に出す 1 行説明（任意。設定モードで編集）

    @classmethod
    def from_dict(cls, d: dict) -> "Task":
        return cls(
            name=d["name"],
            actions=[Action.from_dict(a) for a in d.get("actions") or []],
            id=d.get("id") or new_id(),
            description=str(d.get("description") or ""),
        )

    def to_dict(self) -> dict:
        out = {
            "id": self.id,
            "name": self.name,
            "actions": [a.to_dict() for a in self.actions],
        }
        if self.description:
            out["description"] = self.description
        return out


@dataclass
class TaskGroup:
    name: str = ""
    tasks: list[Task] = field(default_factory=list)
    id: str = field(default_factory=new_id)

    @classmethod
    def from_dict(cls, d: dict) -> "TaskGroup":
        return cls(
            name=d.get("name", ""),
            tasks=[Task.from_dict(t) for t in d.get("tasks") or []],
            id=d.get("id") or new_id(),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "tasks": [t.to_dict() for t in self.tasks],
        }


# --------------------------------------------------------------------------- #
# 業務
# --------------------------------------------------------------------------- #
@dataclass
class Work:
    name: str
    task_groups: list[TaskGroup] = field(default_factory=list)
    id: str = field(default_factory=new_id)

    @classmethod
    def from_dict(cls, d: dict) -> "Work":
        return cls(
            name=d["name"],
            task_groups=[TaskGroup.from_dict(g) for g in d.get("task_groups") or []],
            id=d.get("id") or new_id(),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "task_groups": [g.to_dict() for g in self.task_groups],
        }


@dataclass
class WorkGroup:
    name: str = ""
    works: list[Work] = field(default_factory=list)
    id: str = field(default_factory=new_id)

    @classmethod
    def from_dict(cls, d: dict) -> "WorkGroup":
        return cls(
            name=d.get("name", ""),
            works=[Work.from_dict(w) for w in d.get("works") or []],
            id=d.get("id") or new_id(),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "works": [w.to_dict() for w in self.works],
        }


# --------------------------------------------------------------------------- #
# 複製（コピー&貼り付け用。ID を全階層で新規採番する。design-notes §16bis Phase C）
# --------------------------------------------------------------------------- #
def _clone_args(action_id: str, args: dict[str, Any]) -> dict[str, Any]:
    """動作の args を deepcopy する。暗号化動作は `secret_id` を空にする。

    同一暗号文が2箇所に増えると「片方の解析が両方へ波及」するため、複製では
    `secret_id` を捨てて『要再入力』にする（`copy` 機能の preflight が
    「暗号文が見つかりません」で FAILED を出すので、動作エディタで入れ直す）。
    """
    new = copy.deepcopy(dict(args))
    if action_id == "copy" and new.get("encrypt"):
        new["secret_id"] = ""
    return new


def clone_action(a: Action) -> Action:
    """動作を複製（新しい ID）。暗号化動作は `secret_id` を空にする。"""
    return Action(action_id=a.action_id, args=_clone_args(a.action_id, a.args))


def clone_task(t: Task) -> Task:
    """タスクを中の動作ごと複製（全階層で新しい ID）。"""
    return Task(
        name=t.name, actions=[clone_action(a) for a in t.actions],
        description=t.description,
    )


def clone_task_group(g: TaskGroup) -> TaskGroup:
    """タスクグループを中身ごと複製（全階層で新しい ID）。"""
    return TaskGroup(name=g.name, tasks=[clone_task(t) for t in g.tasks])


def clone_work(w: Work) -> Work:
    """業務をタスクグループ／タスク／動作ごと複製（全階層で新しい ID）。"""
    return Work(name=w.name, task_groups=[clone_task_group(g) for g in w.task_groups])


# --------------------------------------------------------------------------- #
# ルート
# --------------------------------------------------------------------------- #
DEFAULT_SETTINGS: dict[str, Any] = {
    "onetime_wait_ms": 300,        # ワンタイム: ペイロード投入後の待機（Chromium 対策）
    "min_lock_seconds": 1.0,       # 連打ロックの最低時間
    "layer2_hold_seconds": 3.0,    # 完了時の背景色を保持する時間
}


@dataclass
class TaskLocation:
    """タスク 1 件と、その祖先。ログの階層情報・実行時の解決に使う。"""

    work_group: WorkGroup
    work: Work
    task_group: TaskGroup
    task: Task

    def path_label(self) -> str:
        wg = self.work_group.name or DEFAULT_GROUP_NAME
        tg = self.task_group.name or DEFAULT_GROUP_NAME
        return f"{wg}/{self.work.name} > {tg}/{self.task.name}"


@dataclass
class AppData:
    work_groups: list[WorkGroup] = field(default_factory=list)
    settings: dict[str, Any] = field(default_factory=lambda: dict(DEFAULT_SETTINGS))

    # --- 直列化 --------------------------------------------------------- #
    @classmethod
    def from_dict(cls, d: dict) -> "AppData":
        settings = dict(DEFAULT_SETTINGS)
        settings.update(d.get("settings") or {})
        return cls(
            work_groups=[WorkGroup.from_dict(g) for g in d.get("work_groups") or []],
            settings=settings,
        )

    def to_dict(self) -> dict:
        return {
            "settings": self.settings,
            "work_groups": [g.to_dict() for g in self.work_groups],
        }

    # --- 走査 --------------------------------------------------------- #
    def iter_tasks(self) -> Iterator[TaskLocation]:
        for wg in self.work_groups:
            for w in wg.works:
                for tg in w.task_groups:
                    for t in tg.tasks:
                        yield TaskLocation(wg, w, tg, t)

    def find_task(self, task_id: str) -> TaskLocation | None:
        for loc in self.iter_tasks():
            if loc.task.id == task_id:
                return loc
        return None
