"""起動系の機能: ファイル / フォルダ / URL / OS実行。

すべて非同期（投げっぱなし）。成功時は何もしない。
起動呼び出し自体が例外を出したら FAILED（dispatcher が正規化）。
可能なものは preflight で FAILED に格上げする。
"""

from __future__ import annotations

import os
import webbrowser
from pathlib import Path
from typing import Any

from ..result import PreflightError, Result, Status
from ..services import browser as _browser
from .base import Feature
from .registry import register


@register("open_file")
class OpenFileFeature(Feature):
    feature_name = "ファイルを開く"
    is_async = True

    def preflight(self, args: dict[str, Any], ctx) -> None:
        path = args.get("path", "")
        if not path:
            raise PreflightError("パスが指定されていません")
        if not Path(path).is_file():
            raise PreflightError("ファイルが見つかりません", f"not a file: {path}")

    def execute(self, args: dict[str, Any], ctx) -> Result:
        os.startfile(args["path"])  # noqa: S606  (Windows shell 起動)
        return Result(Status.DISPATCHED)


@register("open_folder")
class OpenFolderFeature(Feature):
    feature_name = "フォルダを開く"
    is_async = True

    def preflight(self, args: dict[str, Any], ctx) -> None:
        path = args.get("path", "")
        if not path:
            raise PreflightError("パスが指定されていません")
        if not Path(path).is_dir():
            raise PreflightError("フォルダが見つかりません", f"not a dir: {path}")

    def execute(self, args: dict[str, Any], ctx) -> Result:
        os.startfile(args["path"])
        return Result(Status.DISPATCHED)


@register("open_url")
class OpenUrlFeature(Feature):
    feature_name = "URLを開く"
    is_async = True

    def preflight(self, args: dict[str, Any], ctx) -> None:
        url = args.get("url", "")
        if "://" not in url:
            raise PreflightError("URL の形式が不正です", f"no scheme: {url}")

    def execute(self, args: dict[str, Any], ctx) -> Result:
        if args.get("new_window"):
            _browser.open_url(args["url"], new_window=True)
        else:
            webbrowser.open(args["url"])
        return Result(Status.DISPATCHED)


@register("os_exec")
class OsExecFeature(Feature):
    """claude:// などのカスタムスキーム/コマンドを OS に渡す。"""

    feature_name = "OS実行"
    is_async = True

    def preflight(self, args: dict[str, Any], ctx) -> None:
        if not args.get("target"):
            raise PreflightError("実行対象が指定されていません")

    def execute(self, args: dict[str, Any], ctx) -> Result:
        os.startfile(args["target"])
        return Result(Status.DISPATCHED)
