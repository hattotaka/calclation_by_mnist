"""16px 単色ラインアイコンの手続き生成（design-notes §17.4 / §17.7 ステージ5）。

- `PIL.ImageDraw` で 4x のキャンバスに線画 → `LANCZOS` 縮小で AA → `ImageTk.PhotoImage`。
- アイコン画像ファイルは同梱しない（配布を軽く保つ。`cryptography` に次ぐ2つ目の pip 依存として
  Pillow を「見た目のためのライブラリ」の例外扱いで許容。§4）。
- 呼び出しは必ず `theme.icon(name, tone, size)` 経由（色解決＋module キャッシュ＋GC 防止）。
  ここは「name と色と最終サイズ」だけ受け取り、素の PhotoImage を返す純粋な描画。
- `make()` は PIL 不在・Tk root 不在なら例外を投げる（`theme.icon` 側が握って None を返す）。

座標は 0..1 の比率 × S（＝4x サイズ）で書く。線幅 `w` も 4x 空間の px。
"""

from __future__ import annotations

import math

_SCALE = 4  # スーパーサンプリング倍率


def _folder(dr, S, c, w):
    dr.rounded_rectangle([S * 0.13, S * 0.31, S * 0.87, S * 0.80],
                         radius=S * 0.08, outline=c, width=w)
    dr.line([S * 0.13, S * 0.31, S * 0.13, S * 0.22, S * 0.44, S * 0.22, S * 0.52, S * 0.31],
            fill=c, width=w, joint="curve")


def _file(dr, S, c, w):
    dr.rounded_rectangle([S * 0.23, S * 0.11, S * 0.77, S * 0.89],
                         radius=S * 0.07, outline=c, width=w)
    thin = max(1, int(w * 0.72))
    for y in (0.36, 0.50, 0.64):
        dr.line([S * 0.34, y * S, S * 0.66, y * S], fill=c, width=thin)


def _link(dr, S, c, w):
    # 右上が開いた箱
    dr.line([S * 0.50, S * 0.22, S * 0.22, S * 0.22, S * 0.22, S * 0.80,
             S * 0.80, S * 0.80, S * 0.80, S * 0.50], fill=c, width=w, joint="curve")
    # 右上へ伸びる矢印
    dr.line([S * 0.48, S * 0.52, S * 0.82, S * 0.18], fill=c, width=w)
    dr.line([S * 0.58, S * 0.16, S * 0.84, S * 0.16, S * 0.84, S * 0.42],
            fill=c, width=w, joint="curve")


def _terminal(dr, S, c, w):
    dr.rounded_rectangle([S * 0.13, S * 0.20, S * 0.87, S * 0.80],
                         radius=S * 0.09, outline=c, width=w)
    dr.line([S * 0.28, S * 0.38, S * 0.43, S * 0.50, S * 0.28, S * 0.62],
            fill=c, width=w, joint="curve")
    dr.line([S * 0.50, S * 0.63, S * 0.68, S * 0.63], fill=c, width=w)


def _copy(dr, S, c, w):
    dr.rounded_rectangle([S * 0.12, S * 0.12, S * 0.60, S * 0.60],
                         radius=S * 0.08, outline=c, width=w)
    dr.rounded_rectangle([S * 0.40, S * 0.40, S * 0.88, S * 0.88],
                         radius=S * 0.08, outline=c, width=w)


def _lock(dr, S, c, w):
    # 箱いっぱいに（gear/lock は元が小さめでバランスが悪かった）
    dr.rounded_rectangle([S * 0.20, S * 0.42, S * 0.80, S * 0.88],
                         radius=S * 0.09, outline=c, width=w)
    dr.arc([S * 0.29, S * 0.10, S * 0.71, S * 0.58], start=180, end=360, fill=c, width=w)
    dr.ellipse([S * 0.45, S * 0.58, S * 0.55, S * 0.68], fill=c)


def _clock(dr, S, c, w):
    dr.ellipse([S * 0.14, S * 0.14, S * 0.86, S * 0.86], outline=c, width=w)
    cx = cy = S / 2
    dr.line([cx, cy, cx, S * 0.30], fill=c, width=w)      # 分針（上）
    dr.line([cx, cy, S * 0.66, cy], fill=c, width=w)      # 時針（右）


def _sliders(dr, S, c, w):
    knob = S * 0.10
    for y, kx in ((0.26, 0.36), (0.50, 0.64), (0.74, 0.46)):
        yy = y * S
        dr.line([S * 0.11, yy, S * 0.89, yy], fill=c, width=w)
        cx = kx * S
        dr.ellipse([cx - knob, yy - knob, cx + knob, yy + knob], fill=c)


def _gear(dr, S, c, w):
    cx = cy = S / 2
    r_in, r_out = S * 0.24, S * 0.40   # 箱いっぱいに（元は 0.19/0.30 で小さかった）
    for k in range(8):
        a = k * math.pi / 4
        dr.line([cx + r_in * math.cos(a), cy + r_in * math.sin(a),
                 cx + r_out * math.cos(a), cy + r_out * math.sin(a)], fill=c, width=w)
    dr.ellipse([cx - r_in, cy - r_in, cx + r_in, cy + r_in], outline=c, width=w)
    dr.ellipse([cx - S * 0.075, cy - S * 0.075, cx + S * 0.075, cy + S * 0.075], fill=c)


_ICONS = {
    "folder": _folder,
    "file": _file,
    "doc": _file,
    "link": _link,
    "terminal": _terminal,
    "copy": _copy,
    "lock": _lock,
    "sliders": _sliders,
    "gear": _gear,
    "clock": _clock,
}


def make(name: str, color: str, size: int):
    """`name` のアイコンを `color`・`size`px の `ImageTk.PhotoImage` で返す。

    未知の name は `doc` にフォールバック。PIL 不在・Tk root 不在なら例外
    （呼び出し側の `theme.icon` が握る）。
    """
    from PIL import Image, ImageDraw, ImageTk

    size = int(size)
    S = size * _SCALE
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    dr = ImageDraw.Draw(im)
    w = max(1, round(max(1.4, size / 10.5) * _SCALE))
    (_ICONS.get(name) or _ICONS["doc"])(dr, S, color, w)
    im = im.resize((size, size), Image.LANCZOS)
    return ImageTk.PhotoImage(im)


def make_tile(name: str, tint: str, size: int, glyph: str = "#ffffff"):
    """角丸の色つきタイル＋白グリフ（既存の自作ランチャー風の「大きい色つきアイコン」）。

    `tint` がタイルの塗り、`glyph` が中に描く線画の色。未知 name は `doc` にフォールバック。
    """
    from PIL import Image, ImageDraw, ImageTk

    size = int(size)
    S = size * _SCALE
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    ImageDraw.Draw(im).rounded_rectangle(
        [0, 0, S - 1, S - 1], radius=S * 0.26, fill=tint
    )
    # グリフはタイル内側に ~58% で中央配置（別レイヤに描いて合成）
    inset = int(S * 0.21)
    gs = S - inset * 2
    g = Image.new("RGBA", (gs, gs), (0, 0, 0, 0))
    gw = max(2, round(gs * 0.09))
    (_ICONS.get(name) or _ICONS["doc"])(ImageDraw.Draw(g), gs, glyph, gw)
    im.alpha_composite(g, (inset, inset))
    im = im.resize((size, size), Image.LANCZOS)
    return ImageTk.PhotoImage(im)
