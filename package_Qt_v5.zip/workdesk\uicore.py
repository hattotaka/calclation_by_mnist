"""画面の裏側にある「データ操作」だけをまとめたコントローラ（**GUI 非依存**）。

`view/app.py` の `App` が「Tk のルート窓」と「階層 CRUD のコントローラ」を兼ねていたのを
分けたもの（design-notes「2026-09-04 …」Phase 2c）。ここには

- 階層の 追加 / 挿入 / 削除 / 改名 / 説明 / 動作の編集
- コピー & 貼り付けバッファ（1 セッション限り）
- 並べ替え（ドラッグ）
- グループ分けとグループ色の付け直し
- 削除後にどれを選ぶかの規則
- `workdesk.json` への保存と、削除で孤児になった暗号文の GC

だけを置く。**「保存したあと画面をどう描き直すか」は持たない**（それは view の仕事）。
各メソッドは「作った / 動かした要素」か bool を返すので、view はそれを見て再描画と選択を行う。

こうしてある理由: Qt 版はこのクラスをそのまま使い、薄い描画層だけを書けばよい。
テストも `Tk` 無しでここを直接叩ける。

例外的な依存: `split_group` のグループ色の付け直しだけ `theme_tokens` を使う
（ツールキット非依存なので層は跨がない）。グループ色の存廃は保留事項
（design-notes「保留：グループ色の扱い」）なので、決まったらここごと消える可能性がある。
"""

from __future__ import annotations

from pathlib import Path

from . import hierarchy, model, persistence, theme_tokens
from .model import AppData

# 追加時は名前入力ポップアップを出さず既定名で作る（作業を止めない。2026-09-02）。
DEFAULT_WORK_NAME = "新しい業務"
DEFAULT_TASK_NAME = "新しいタスク"

KIND_JA = {"work": "業務", "task": "タスク", "action": "動作"}

# kind（"work"/"task"/"action"）→ (探索関数, 複製関数)
_ENTITY_OPS = {
    "work": (hierarchy.find_work, model.clone_work),
    "task": (hierarchy.find_task, model.clone_task),
    "action": (hierarchy.find_action, model.clone_action),
}


class UiCore:
    def __init__(self, app_data: AppData, save_path: str | Path) -> None:
        self.app_data = app_data
        self.save_path = Path(save_path)
        # コピー&貼り付けバッファ（§16bis Phase C。1 セッション限り）
        self._copy_buf: dict | None = None

    # --- 保存 ------------------------------------------------------ #
    def save(self) -> None:
        """階層＋設定を workdesk.json へ書き出す（原子的）。"""
        persistence.save(self.save_path, self.app_data)

    # --- 追加 ------------------------------------------------------ #
    def seed_default_task(self, work) -> None:
        """新規業務に、動作の無い空タスクを1つ用意する
        （他にタスクを作る導線が無いため。2026-09-02）。"""
        if work is None:
            return
        tg = hierarchy.add_task_group(self.app_data, work.id, "")
        if tg is not None:
            hierarchy.add_task(self.app_data, tg.id, DEFAULT_TASK_NAME)

    def add_work(self, group_id: str):
        w = hierarchy.add_work(self.app_data, group_id, DEFAULT_WORK_NAME)
        self.seed_default_task(w)
        return w

    def add_work_in_new_group(self):
        """新しい業務グループを作り、そこへ業務を1つ追加（空グループは作らない）。"""
        wg = hierarchy.add_work_group(self.app_data, "")
        w = hierarchy.add_work(self.app_data, wg.id, DEFAULT_WORK_NAME)
        self.seed_default_task(w)
        return w

    def add_task(self, task_group_id: str):
        """指定タスクグループの末尾へタスクを1つ足す（既定名）。"""
        return hierarchy.add_task(self.app_data, task_group_id, DEFAULT_TASK_NAME)

    def add_task_in_new_group(self, work_id: str):
        """新しいタスクグループを作り、そこへタスクを1つ追加（既定名）。"""
        tg = hierarchy.add_task_group(self.app_data, work_id, "")
        if tg is None:
            return None
        return hierarchy.add_task(self.app_data, tg.id, DEFAULT_TASK_NAME)

    def add_action(self, task_id: str, action_id: str, args: dict):
        return hierarchy.add_action(self.app_data, task_id, action_id, args)

    # --- 挿入（anchor の直後） -------------------------------------- #
    def insert_after(self, kind: str, anchor_id: str, *, action: tuple[str, dict] | None = None):
        """`anchor_id` のすぐ下に 1 つ作る。作れたらその要素、駄目なら None。

        `kind == "action"` のときは `action=(action_id, args)` を渡す
        （種類を選ばせるダイアログは view の仕事）。
        """
        if not anchor_id:
            return None
        if kind == "work":
            node = model.Work(name=DEFAULT_WORK_NAME)
        elif kind == "task":
            node = model.Task(name=DEFAULT_TASK_NAME)
        elif kind == "action":
            if action is None:
                return None
            node = model.Action(action_id=action[0], args=dict(action[1]))
        else:
            return None
        if not hierarchy.insert_after(self.app_data, anchor_id, node):
            return None
        if kind == "work":
            self.seed_default_task(node)
        return node

    # --- コピー & 貼り付け（§16bis Phase C） ------------------------ #
    def can_paste(self, kind: str) -> bool:
        """指定種別（"work" / "task" / "action"）の貼り付けバッファがあるか。"""
        return bool(self._copy_buf) and self._copy_buf["kind"] == kind

    def copy_entity(self, kind: str, entity_id: str) -> bool:
        """業務 / タスク / 動作を1セッション限りのバッファへ複製して控える。

        バッファには**コピー時点の複製**（新 ID）を持ち、貼り付けのたびに
        そこから更に複製する（複数回貼っても各々独立）。
        """
        ops = _ENTITY_OPS.get(kind)
        if ops is None:
            return False
        find, clone = ops
        src = find(self.app_data, entity_id)
        if src is None:
            return False
        self._copy_buf = {"kind": kind, "data": clone(src)}
        return True

    def paste_entity(self, kind: str, anchor_id: str):
        """バッファの複製を `anchor_id` の直後へ兄弟として挿入する（全階層で新 ID）。"""
        ops = _ENTITY_OPS.get(kind)
        if ops is None or not self.can_paste(kind):
            return None
        _find, clone = ops
        new = clone(self._copy_buf["data"])
        if not hierarchy.insert_after(self.app_data, anchor_id, new):
            return None
        return new

    def paste_action_head(self, task_id: str):
        """動作バッファの複製をタスクの**先頭**へ挿入する。

        「タスクを選択して Ctrl+V」＝『0 番目の動作が選択されている』とみなす解釈
        （動作0件のタスクにも貼れる）。
        """
        if not self.can_paste("action"):
            return None
        task = hierarchy.find_task(self.app_data, task_id)
        if task is None:
            return None
        new = model.clone_action(self._copy_buf["data"])
        task.actions.insert(0, new)
        return new

    # --- 並べ替え（ドラッグ。§16bis Phase D） ----------------------- #
    def reorder_work(
        self, work_id: str, dest_group_id: str | None, before_id: str | None
    ) -> bool:
        """業務の並べ替え／グループ間移動。`dest_group_id=None` で新しいグループへ。
        **実際に順序が変わったときだけ True**（呼び出し側はそのときだけ保存・再描画する）。"""
        def snapshot() -> list[tuple[str, str]]:
            return [(wg.id, w.id) for wg in self.app_data.work_groups for w in wg.works]

        def do_move() -> bool:
            if dest_group_id is None:
                return hierarchy.move_work_to_new_group(self.app_data, work_id)
            return hierarchy.move_work(self.app_data, work_id, dest_group_id, before_id)

        moved = self._reordered(snapshot, do_move)
        if moved:
            self.prune_empty_groups()       # 最後の 1 件を出したら元の入れ物は空
        return moved

    def reorder_task(
        self, work_id: str, task_id: str, dest_group_id: str | None, before_id: str | None
    ) -> bool:
        """タスクの並べ替え／タスクグループ間移動。`dest_group_id=None` で新グループへ。"""
        work = hierarchy.find_work(self.app_data, work_id or "")
        if work is None:
            return False

        def snapshot() -> list[tuple[str, str]]:
            return [(tg.id, t.id) for tg in work.task_groups for t in tg.tasks]

        def do_move() -> bool:
            if dest_group_id is None:
                return hierarchy.move_task_to_new_group(self.app_data, task_id, work.id)
            return hierarchy.move_task(self.app_data, task_id, dest_group_id, before_id)

        moved = self._reordered(snapshot, do_move)
        if moved:
            self.prune_empty_groups()
        return moved

    def reorder_action(self, task_id: str, action_id: str, before_id: str | None) -> bool:
        """動作の並べ替え（同一タスク内）。"""
        if before_id == action_id:
            return False
        task = hierarchy.find_task(self.app_data, task_id or "")
        was = [a.id for a in task.actions] if task is not None else None
        if not hierarchy.move_before_sibling(self.app_data, action_id, before_id):
            return False
        return not (task is not None and [a.id for a in task.actions] == was)

    @staticmethod
    def _reordered(snapshot, do_move) -> bool:
        """`snapshot()`（順序の指紋）→ `do_move()` → 指紋が変わったか。"""
        was = snapshot()
        return bool(do_move()) and snapshot() != was

    # --- 名前 / 説明 / 動作の中身 ----------------------------------- #
    def rename(self, entity_id: str, name: str) -> bool:
        """空文字は拒否（呼び出し側が行ラベルだけ先に追従させる）。"""
        if not name:
            return False
        return bool(hierarchy.rename(self.app_data, entity_id, name))

    def set_task_description(self, task_id: str, text: str) -> bool:
        """タスクの説明を差し替える。**変わったときだけ True**（空欄可）。"""
        t = hierarchy.find_task(self.app_data, task_id)
        if t is None or t.description == text:
            return False
        t.description = text
        return True

    def apply_action_edit(self, action_id: str, res: tuple[str, dict]):
        """動作の種類と引数を差し替える。差し替えた動作を返す（無ければ None）。"""
        act = hierarchy.find_action(self.app_data, action_id)
        if act is None:
            return None
        act.action_id, act.args = res
        return act

    # --- グループを分ける ------------------------------------------- #
    def split_group(self, entity_id: str) -> bool:
        """`entity_id` とそれ以降の同グループ内の兄弟を、直後の新グループへ分ける。
        全体の並び順は保持。業務なら**分かれた側だけ**色が変わる。"""
        work = hierarchy.find_work(self.app_data, entity_id)
        gi_before = (
            hierarchy.work_group_of_work(self.app_data, entity_id)[0]
            if work is not None else None
        )
        if not hierarchy.split_group_before(self.app_data, entity_id):
            return False
        if gi_before is not None:
            self._pin_group_colors_after_split(gi_before)
        return True

    def _pin_group_colors_after_split(self, gi: int) -> None:
        """業務グループ `gi` の直後に新グループが 1 つ挿入された。以降のグループ色が
        位置ずれしないよう、全グループの**色相**を明示上書きに固定し、新グループの位置へ
        色相を 1 つ挿入する。

        Qt 版はグループ色を **hex ではなく色相（度）** で持つ
        （design-notes「色相はユーザー / 明度・彩度はテーマ」）。
        Tk 版は `PALETTE["group_colors"]`（hex の配列）を読んでいたが、Qt 版の
        色トークンにそのキーは無い（2026-09-05 にテストで発覚）。
        """
        n_before = len(self.app_data.work_groups) - 1   # 挿入前のグループ数
        # いま実際に使われている色相（上書きが無ければ既定の循環）を確定させる
        hues = [theme_tokens.group_hue(k) for k in range(n_before)]
        base = list(theme_tokens.DEFAULT_GROUP_HUES)
        avoid = {hues[gi]} if gi < len(hues) else set()
        if gi + 1 < len(hues):
            avoid.add(hues[gi + 1])
        new_h = next((h for h in base if h not in avoid), base[(gi + 1) % len(base)])
        hues.insert(gi + 1, new_h)
        theme_tokens.set_option("group_hues", hues)

    # --- 削除 -------------------------------------------------------- #
    @staticmethod
    def pick_sibling(ids: list[str], removed_id: str) -> str | None:
        """`removed_id` を除いたあと、その位置へ繰り上がる要素
        （末尾を消したときは新しい末尾）。兄弟が居なくなれば None。"""
        if removed_id not in ids:
            return None
        i = ids.index(removed_id)
        rest = ids[:i] + ids[i + 1:]
        if not rest:
            return None
        return rest[i] if i < len(rest) else rest[-1]

    def next_after_delete(self, entity_id: str) -> tuple[str, str] | None:
        """削除後に選択する要素 `(種類, id)`。表示順で「次の兄弟」／消したのが一番下なら
        「削除後の新しい末尾」／兄弟が尽きたら親（動作→タスク／タスク→業務／業務→なし）。
        タスク・業務の兄弟はグループをまたいで表示順どおりに数える。"""
        ptask = hierarchy.parent_task_of_action(self.app_data, entity_id)
        if ptask is not None:
            sib = self.pick_sibling([a.id for a in ptask.actions], entity_id)
            return ("action", sib) if sib else ("task", ptask.id)
        if hierarchy.find_task(self.app_data, entity_id) is not None:
            work = hierarchy.parent_work_of_task(self.app_data, entity_id)
            ids = (
                [t.id for tg in work.task_groups for t in tg.tasks]
                if work is not None else []
            )
            sib = self.pick_sibling(ids, entity_id)
            if sib:
                return ("task", sib)
            return ("work", work.id) if work is not None else None
        if hierarchy.find_work(self.app_data, entity_id) is not None:
            ids = [w.id for wg in self.app_data.work_groups for w in wg.works]
            sib = self.pick_sibling(ids, entity_id)
            return ("work", sib) if sib else None
        return None

    def delete(self, entity_id: str) -> None:
        """要素を消して保存する。

        削除の確認ダイアログと、削除後にどれを選ぶか（`next_after_delete`）の適用は
        呼び出し側（view）の仕事。

        **暗号文は道連れにしない**（2026-09-08）。以前は「参照されなくなった
        暗号文」をここで消していたが、暗号文は設定パネルの一覧で管理する
        ものになった ── 登録しただけでまだ動作から使っていないものが
        消えてしまう。消すのは一覧からの明示的な削除だけ。
        """
        hierarchy.delete(self.app_data, entity_id)
        self.prune_empty_groups()           # 最後の 1 件を消したら入れ物も消える
        self.save()

    # --- 空グループの GC ---------------------------------------------- #
    def prune_empty_groups(self) -> bool:
        """空になったグループを片付ける。**消したら True**（呼び出し側が保存・再描画）。

        業務グループの位置は `STATE["group_hues"]` の添字でもあるので、消したぶん
        色も詰める ── 詰めないと、消したグループより後ろの色が 1 つずつずれる。
        ここでは `set_option` を通さない（通知＝再描画を削除の途中で起こさない。
        呼び出し側がこのあと描き直して保存する）。
        """
        removed = hierarchy.prune_empty_groups(self.app_data)
        if not removed:
            return False
        hues = list(theme_tokens.STATE.get("group_hues") or [])
        for i in reversed(removed):         # 後ろから消す＝前の添字がずれない
            if i < len(hues):
                del hues[i]
        theme_tokens.STATE["group_hues"] = hues
        return True

    # --- 暗号文の使われ方（設定パネルの一覧。2026-09-08） -------------- #
    def secret_use_counts(self) -> dict[str, int]:
        """`{secret_id: それを使っている動作の数}`。

        暗号文を一覧から消すと、それを使っている動作は実行時に失敗する ──
        消す前に「何件で使われているか」を見せるための材料。
        以前は同じ走査で「参照されなくなった暗号文の GC」をしていたが、
        暗号文を明示的にしか消さなくしたのでその用途は無くなった。
        """
        out: dict[str, int] = {}
        for wg in self.app_data.work_groups:
            for w in wg.works:
                for tg in w.task_groups:
                    for t in tg.tasks:
                        for a in t.actions:
                            if a.action_id == "copy" and a.args.get("encrypt"):
                                sid = a.args.get("secret_id")
                                if sid:
                                    out[sid] = out.get(sid, 0) + 1
        return out

    def referenced_secret_ids(self) -> set[str]:
        """いま階層内の暗号化コピー動作が指している `secret_id` の集合。"""
        return set(self.secret_use_counts())
