"""Qt(PySide6) 版の view。Tk 版の `workdesk/view/` を置き換える。

**この配下だけが PySide6 に依存する。** ほかの層（model / hierarchy / dispatch /
features / services / bootstrap / uicore / theme_tokens）は Tk 版からそのまま
コピーしたもので、GUI ツールキットを一切 import しない（design-notes Phase 2）。
"""
