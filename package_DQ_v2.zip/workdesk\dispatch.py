"""画面 ⇄ 各機能の継ぎ目（§14）。

- view → dispatcher: `Command(task_id)` を `dispatch(cmd, on_event)` で渡す（B ＋ 1）。
- dispatcher → view: `Event` を `on_event` で返す（b）。
  `on_event` は「UIスレッドへマーシャルして呼ぶ」責務を呼び出し側（App）が持つ。
- 動作列はワーカースレッドで逐次実行。列内は同期。非同期系も現状は execute() が
  すぐ返る（DISPATCHED）ので逐次でよい。
"""

from __future__ import annotations

import threading
from collections.abc import Callable
from dataclasses import dataclass

from . import features
from .context import Context
from .result import PreflightError, Result, SequenceAbort, Status
from .settings import SettingsReader

# --------------------------------------------------------------------------- #
# メッセージ
# --------------------------------------------------------------------------- #
@dataclass
class Command:
    task_id: str


@dataclass
class Event:
    kind: str                 # "task_started" | "action_done" | "task_finished"
    task_id: str
    feature_name: str = ""
    status: str = ""          # action_done: OK / DISPATCHED / FAILED
    message: str = ""         # 層3テキスト
    outcome: str = ""         # task_finished: all_ok / has_failure / aborted


EventHandler = Callable[[Event], None]


# --------------------------------------------------------------------------- #
# ディスパッチャ
# --------------------------------------------------------------------------- #
class Dispatcher:
    def __init__(self, context: Context, settings: SettingsReader) -> None:
        self._ctx = context
        self._settings = settings

    def dispatch(self, command: Command, on_event: EventHandler) -> None:
        """即座に返る。実行はワーカースレッド。"""
        loc = self._settings.resolve_task(command.task_id)
        if loc is None:
            on_event(Event("task_finished", command.task_id, outcome="has_failure",
                           message="タスクが見つかりません"))
            return
        threading.Thread(
            target=self._run, args=(loc, on_event), name=f"task-{command.task_id[:8]}", daemon=True
        ).start()

    # --- ワーカースレッド ------------------------------------------- #
    def _run(self, loc, on_event: EventHandler) -> None:
        task = loc.task
        plan: list[tuple[object, dict]] = []
        for action in task.actions:
            try:
                feat = features.get(action.action_id)
            except KeyError:
                feat = None
            plan.append((feat, action.args))

        # 貼り付け待ちを伴う動作の数 = ポップアップの k/N の N（ループは駆動しない）
        paste_total = sum(
            1 for feat, args in plan if feat is not None and feat.is_interactive(args)
        )
        onetime = getattr(self._ctx, "onetime", None)
        use_seq = onetime is not None and paste_total > 0

        self._ctx.log.task_start(loc)
        on_event(Event("task_started", task.id))

        outcome = "all_ok"
        if use_seq:
            onetime.begin_sequence(paste_total)
        try:
            for feat, args in plan:
                result, aborted = self._run_one(feat, args, loc)
                if aborted:
                    outcome = "aborted"
                    break
                if result.status == Status.FAILED:
                    outcome = "has_failure"
                name = getattr(feat, "feature_name", "") or "(不明)"
                on_event(Event(
                    "action_done", task.id, feature_name=name, status=result.status,
                    message=result.message,
                ))
        finally:
            if use_seq:
                onetime.end_sequence()

        self._ctx.log.task_finish(loc, outcome)
        on_event(Event("task_finished", task.id, outcome=outcome))

    def _run_one(self, feat, args, loc) -> tuple[Result, bool]:
        if feat is None:
            r = Result(Status.FAILED, "未知の機能です", "unknown action_id")
            self._ctx.log.action(loc, "(不明)", r.status, r.detail)
            return r, False
        try:
            feat.preflight(args, self._ctx)
            r = feat.execute(args, self._ctx)
        except SequenceAbort as e:
            self._ctx.log.action(loc, feat.feature_name, "ABORTED", e.reason)
            return Result(Status.FAILED, e.reason), True
        except PreflightError as e:
            r = Result(Status.FAILED, e.user_message, e.detail)
        except Exception as e:  # noqa: BLE001  機能の例外は握って正規化する
            r = Result(Status.FAILED, "失敗しました", repr(e))
        self._ctx.log.action(loc, feat.feature_name, r.status, r.detail)
        return r, False
