"""WorkDeskLauncher — 疎結合な業務ランチャー。

構成:
    view/       画面（Tkinter）。Command を送り Event を受けるだけ。
    dispatcher  画面 ⇄ 各機能の継ぎ目。ルーティング＋動作列の実行。
    features/   機能モジュール（@register で登録）。
    services/   共有サービス（clipboard / onetime / logger など）。Context 経由で機能へ注入。
    model       階層データの dataclass。
    persistence 階層データの JSON ロード/セーブ。

詳細は docs/design-notes.md を参照。
"""

__version__ = "0.0.1"
