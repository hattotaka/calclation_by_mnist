"""グローバルキーボードフック（WH_KEYBOARD_LL）で Ctrl+V を検知する。

- 専用スレッドでフックを設置し、メッセージループを常駐させる。
- `is_active()` が True のときだけ Ctrl+V に反応して `on_ctrl_v()` を呼ぶ。
  それ以外は完全に素通し（他アプリの Ctrl+V に一切干渉しない）。
- **Ctrl+V は握り潰さない**（ユーザーの Ctrl+V がそのまま貼り付けを実行する）。
  → 「検知 → ペイロードをクリップボードへ」が実際の貼り付けに間に合う必要がある。
     負けた場合は空貼り付けになり、もう一度 Ctrl+V で復帰できる（ペイロードは既にセット済み）。
     実運用で不安定なら「握り潰し＋SendInput 再送」へ切り替える（要マーカーで再入防止）。
"""

from __future__ import annotations

import ctypes
import threading
from collections.abc import Callable
from ctypes import wintypes

WH_KEYBOARD_LL = 13
WM_KEYDOWN = 0x0100
WM_SYSKEYDOWN = 0x0104
WM_QUIT = 0x0012
VK_CONTROL = 0x11
VK_V = 0x56

LRESULT = ctypes.c_ssize_t
ULONG_PTR = ctypes.c_size_t

_user32 = ctypes.WinDLL("user32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [
        ("vkCode", wintypes.DWORD),
        ("scanCode", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ULONG_PTR),
    ]


_HOOKPROC = ctypes.CFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)

_user32.SetWindowsHookExW.restype = wintypes.HHOOK
_user32.SetWindowsHookExW.argtypes = [ctypes.c_int, _HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
_user32.CallNextHookEx.restype = LRESULT
_user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
_user32.UnhookWindowsHookEx.argtypes = [wintypes.HHOOK]
_user32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
_user32.GetAsyncKeyState.restype = ctypes.c_short
_user32.GetAsyncKeyState.argtypes = [ctypes.c_int]
_user32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
_kernel32.GetCurrentThreadId.restype = wintypes.DWORD


def should_fire(n_code: int, w_param: int, vk_code: int, ctrl_down: bool) -> bool:
    """フックが Ctrl+V と判定する条件（純粋関数。テスト対象）。"""
    if n_code < 0:
        return False
    if w_param not in (WM_KEYDOWN, WM_SYSKEYDOWN):
        return False
    return vk_code == VK_V and ctrl_down


class KeyboardHook:
    def __init__(self, on_ctrl_v: Callable[[], None], is_active: Callable[[], bool]) -> None:
        self._on_ctrl_v = on_ctrl_v
        self._is_active = is_active
        self._proc = _HOOKPROC(self._proc_impl)   # GC 防止で参照を保持
        self._thread: threading.Thread | None = None
        self._thread_id: int | None = None
        self._hook = None
        self._ready = threading.Event()

    # --- フックスレッド ------------------------------------------- #
    def _proc_impl(self, n_code: int, w_param: int, l_param: int) -> int:
        try:
            if self._is_active() and should_fire(
                n_code, w_param,
                ctypes.cast(l_param, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents.vkCode,
                bool(_user32.GetAsyncKeyState(VK_CONTROL) & 0x8000),
            ):
                self._on_ctrl_v()
        except Exception:  # noqa: BLE001  フックプロシージャ内で絶対に例外を漏らさない
            pass
        return _user32.CallNextHookEx(None, n_code, w_param, l_param)

    def _run(self) -> None:
        self._thread_id = _kernel32.GetCurrentThreadId()
        self._hook = _user32.SetWindowsHookExW(WH_KEYBOARD_LL, self._proc, None, 0)
        self._ready.set()
        if not self._hook:
            return
        msg = wintypes.MSG()
        while _user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            pass  # WM_QUIT で GetMessageW が 0 を返しループ終了
        _user32.UnhookWindowsHookEx(self._hook)
        self._hook = None

    # --- 公開 API ------------------------------------------------- #
    def start(self) -> bool:
        if self._thread is not None:
            return True
        self._thread = threading.Thread(target=self._run, name="kbd-hook", daemon=True)
        self._thread.start()
        self._ready.wait(2)
        return self._hook is not None

    def stop(self) -> None:
        if self._thread_id:
            _user32.PostThreadMessageW(self._thread_id, WM_QUIT, 0, 0)
        if self._thread is not None:
            self._thread.join(2)
        self._thread = None
        self._thread_id = None
