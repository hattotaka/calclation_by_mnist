"""単色ラインアイコンを `QPainter` で描く（Tk 版 `view/icons.py` の置き換え）。

Tk 版は Pillow で 4x 描画 → 縮小 AA → `ImageTk.PhotoImage` していた。Qt は
アンチエイリアスが標準なので **Pillow を落とせる**（design-notes Phase 1 ④
＝ 配布サイズ -12MB、pip 依存 3 つのまま）。

- 座標は 0..1 の比率で書く（`_ICONS` の各関数）。実サイズはここが掛ける。
- 色は呼び出し側が決める（`theme_tokens.kind_tone()` 等）。**ここに色を持たない。**
- `pixmap(name, color, size)` の結果は module キャッシュに載る。テーマ切替では
  `clear_cache()` を呼ぶ（`qtheme` の `on_palette_changed` から）。
"""

from __future__ import annotations

import math
from collections.abc import Callable

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap

_cache: dict[tuple[str, str, int], QPixmap] = {}


def clear_cache() -> None:
    _cache.clear()


# --- 各アイコンの描き方（座標は 0..1 の比率 × side） ------------------- #
def _link(p: QPainter, s: float) -> None:
    """外部リンク（URL を開く）＝右上への矢印つきの枠。"""
    p.drawRoundedRect(QRectF(0.14 * s, 0.28 * s, 0.44 * s, 0.44 * s), 0.06 * s, 0.06 * s)
    p.drawLine(QPointF(0.48 * s, 0.52 * s), QPointF(0.84 * s, 0.18 * s))
    p.drawPolyline([QPointF(0.60 * s, 0.16 * s), QPointF(0.86 * s, 0.16 * s),
                    QPointF(0.86 * s, 0.42 * s)])


def _file(p: QPainter, s: float) -> None:
    """書類＝右上の角が折れた四角。"""
    path = QPainterPath()
    path.moveTo(0.24 * s, 0.14 * s)
    path.lineTo(0.60 * s, 0.14 * s)
    path.lineTo(0.78 * s, 0.34 * s)
    path.lineTo(0.78 * s, 0.86 * s)
    path.lineTo(0.24 * s, 0.86 * s)
    path.closeSubpath()
    p.drawPath(path)
    p.drawPolyline([QPointF(0.60 * s, 0.14 * s), QPointF(0.60 * s, 0.34 * s),
                    QPointF(0.78 * s, 0.34 * s)])


def _folder(p: QPainter, s: float) -> None:
    path = QPainterPath()
    path.moveTo(0.14 * s, 0.76 * s)
    path.lineTo(0.14 * s, 0.26 * s)
    path.lineTo(0.42 * s, 0.26 * s)
    path.lineTo(0.52 * s, 0.38 * s)
    path.lineTo(0.86 * s, 0.38 * s)
    path.lineTo(0.86 * s, 0.76 * s)
    path.closeSubpath()
    p.drawPath(path)


def _terminal(p: QPainter, s: float) -> None:
    """OS 実行＝コンソール（プロンプトの > と下線）。"""
    p.drawRoundedRect(QRectF(0.12 * s, 0.20 * s, 0.76 * s, 0.60 * s), 0.07 * s, 0.07 * s)
    p.drawPolyline([QPointF(0.28 * s, 0.38 * s), QPointF(0.44 * s, 0.50 * s),
                    QPointF(0.28 * s, 0.62 * s)])
    p.drawLine(QPointF(0.52 * s, 0.63 * s), QPointF(0.72 * s, 0.63 * s))


def _copy(p: QPainter, s: float) -> None:
    """コピー＝2 枚重なった四角。"""
    p.drawRoundedRect(QRectF(0.14 * s, 0.14 * s, 0.46 * s, 0.46 * s), 0.06 * s, 0.06 * s)
    p.drawRoundedRect(QRectF(0.38 * s, 0.38 * s, 0.46 * s, 0.46 * s), 0.06 * s, 0.06 * s)


def _lock(p: QPainter, s: float) -> None:
    """暗号化コピー＝錠前。"""
    p.drawRoundedRect(QRectF(0.20 * s, 0.44 * s, 0.60 * s, 0.42 * s), 0.07 * s, 0.07 * s)
    path = QPainterPath()
    path.moveTo(0.32 * s, 0.44 * s)
    path.lineTo(0.32 * s, 0.30 * s)
    path.arcTo(QRectF(0.32 * s, 0.12 * s, 0.36 * s, 0.36 * s), 180, -180)
    path.lineTo(0.68 * s, 0.44 * s)
    p.drawPath(path)


def _clock(p: QPainter, s: float) -> None:
    """待機＝時計。"""
    p.drawEllipse(QRectF(0.14 * s, 0.14 * s, 0.72 * s, 0.72 * s))
    p.drawPolyline([QPointF(0.50 * s, 0.30 * s), QPointF(0.50 * s, 0.52 * s),
                    QPointF(0.68 * s, 0.62 * s)])


def _app(p: QPainter, s: float) -> None:
    """アプリ起動＝ウィンドウ（タイトル帯つき）。"""
    p.drawRoundedRect(QRectF(0.14 * s, 0.20 * s, 0.72 * s, 0.60 * s), 0.07 * s, 0.07 * s)
    p.drawLine(QPointF(0.14 * s, 0.38 * s), QPointF(0.86 * s, 0.38 * s))


def _sliders(p: QPainter, s: float) -> None:
    """デザインラボ＝つまみ付きの横スライダー 3 本（Tk 版と同じ形）。"""
    knob = 0.10 * s
    for y, kx in ((0.26, 0.36), (0.50, 0.64), (0.74, 0.46)):
        yy = y * s
        p.drawLine(QPointF(0.11 * s, yy), QPointF(0.89 * s, yy))
        cx = kx * s
        p.save()
        p.setBrush(p.pen().color())          # つまみは塗りつぶし
        p.drawEllipse(QPointF(cx, yy), knob, knob)
        p.restore()


def _gear(p: QPainter, s: float) -> None:
    """設定＝歯車（Tk 版と同じ形。歯は 8 本の放射線）。"""
    c = s / 2
    r_in, r_out = 0.24 * s, 0.40 * s
    for k in range(8):
        a = k * math.pi / 4
        p.drawLine(QPointF(c + r_in * math.cos(a), c + r_in * math.sin(a)),
                   QPointF(c + r_out * math.cos(a), c + r_out * math.sin(a)))
    p.drawEllipse(QPointF(c, c), r_in, r_in)
    p.save()
    p.setBrush(p.pen().color())              # 軸は塗りつぶし
    p.drawEllipse(QPointF(c, c), 0.075 * s, 0.075 * s)
    p.restore()


def _chevron_down(p: QPainter, s: float) -> None:
    """下に続きがあることの合図（一覧の下端に小さく出す）。"""
    p.drawPolyline([QPointF(0.20 * s, 0.36 * s), QPointF(0.50 * s, 0.66 * s),
                    QPointF(0.80 * s, 0.36 * s)])


def _chevron_up(p: QPainter, s: float) -> None:
    """上に続きがあることの合図（見出しと一覧の間に小さく出す）。"""
    p.drawPolyline([QPointF(0.20 * s, 0.64 * s), QPointF(0.50 * s, 0.34 * s),
                    QPointF(0.80 * s, 0.64 * s)])


def _minimize(p: QPainter, s: float) -> None:
    """最小化＝水平線 1 本（Windows の帯ボタンと同じ）。

    真ん中よりわずかに下に置く ── ボタンの光学的中心はそこ（Segoe の
    最小化グリフも中央より下）。
    """
    y = 0.54 * s
    p.drawLine(QPointF(0.20 * s, y), QPointF(0.80 * s, y))


def _close(p: QPainter, s: float) -> None:
    """閉じる＝細い ✕（文字の `✕` は太く、他のアイコンと線の太さが揃わない）。"""
    a, b = 0.24 * s, 0.76 * s
    p.drawLine(QPointF(a, a), QPointF(b, b))
    p.drawLine(QPointF(b, a), QPointF(a, b))


_ICONS: dict[str, Callable[[QPainter, float], None]] = {
    "link": _link,
    "file": _file,
    "doc": _file,
    "folder": _folder,
    "terminal": _terminal,
    "copy": _copy,
    "lock": _lock,
    "clock": _clock,
    "app": _app,
    "sliders": _sliders,
    "gear": _gear,
    "minimize": _minimize,
    "close": _close,
    "chevron_down": _chevron_down,
    "chevron_up": _chevron_up,
}


def known() -> list[str]:
    return sorted(_ICONS)


def pixmap(name: str, color: str, size: int = 18) -> QPixmap | None:
    """単色ラインアイコン。未知の名前・描画失敗なら None（＝呼び出し側はアイコン無しで成立させる）。"""
    key = (name, color, int(size))
    hit = _cache.get(key)
    if hit is not None:
        return hit
    draw = _ICONS.get(name)
    if draw is None:
        return None
    try:
        pm = QPixmap(int(size), int(size))
        pm.fill(QColor(0, 0, 0, 0))          # 透明
        p = QPainter(pm)
        p.setRenderHint(QPainter.Antialiasing, True)
        pen = QPen(QColor(color))
        pen.setWidthF(max(1.2, size * 0.085))
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)
        draw(p, float(size))
        p.end()
    except Exception:  # noqa: BLE001  アイコンが出ないだけで画面は成立させる
        return None
    _cache[key] = pm
    return pm
