"""URL を『新規ウィンドウ』で開く（Windows）。

`webbrowser` の既定（`WindowsDefault` ＝ `os.startfile`）は new-window 指定を無視するので、
レジストリから既定ブラウザの実行ファイルを引き、Chromium 系なら `--new-window`、
Firefox 系なら `-new-window` を付けて起動する。判別できないブラウザは `os.startfile`
（＝既存ウィンドウのタブで開く）へ退避する。

※レジストリ読みは stdlib の `winreg`（Windows 専用・パッケージ不要）を使う。
  Credential Manager と違い読み取り専用で単純なので ctypes 化はしない。
"""

from __future__ import annotations

import os
import shlex
import subprocess

try:  # Windows 以外（テスト環境など）でも import は通す
    import winreg
except ImportError:  # pragma: no cover
    winreg = None  # type: ignore[assignment]

# 実行ファイル名（小文字）→ 新規ウィンドウを開くフラグ
_NEW_WINDOW_FLAG = {
    "chrome.exe": "--new-window",
    "msedge.exe": "--new-window",
    "brave.exe": "--new-window",
    "vivaldi.exe": "--new-window",
    "opera.exe": "--new-window",
    "firefox.exe": "-new-window",
    "librewolf.exe": "-new-window",
}


def _default_browser_command() -> str | None:
    """既定ブラウザ（https）の `shell\\open\\command` 文字列。取れなければ None。"""
    if winreg is None:
        return None
    try:
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\Shell\Associations"
            r"\UrlAssociations\https\UserChoice",
        ) as key:
            progid, _ = winreg.QueryValueEx(key, "ProgId")
        with winreg.OpenKey(
            winreg.HKEY_CLASSES_ROOT, rf"{progid}\shell\open\command"
        ) as key:
            command, _ = winreg.QueryValueEx(key, None)
        return str(command)
    except OSError:
        return None


def _exe_from_command(command: str) -> str | None:
    """`"C:\\...\\chrome.exe" -- "%1"` のような文字列から実行ファイルパスを取り出す。"""
    try:
        parts = shlex.split(command, posix=False)
    except ValueError:
        return None
    if not parts:
        return None
    exe = parts[0].strip('"')
    return exe if os.path.isfile(exe) else None


def open_url(url: str, *, new_window: bool = False) -> bool:
    """URL を開く。`new_window` 指定時、既定ブラウザが分かれば新規ウィンドウで開く。

    新規ウィンドウで開けたら True。無理／不要なら `os.startfile` で開いて False。
    """
    if new_window:
        command = _default_browser_command()
        exe = _exe_from_command(command) if command else None
        if exe:
            flag = _NEW_WINDOW_FLAG.get(os.path.basename(exe).lower())
            if flag:
                try:
                    subprocess.Popen([exe, flag, url], close_fds=True)  # noqa: S603
                    return True
                except OSError:
                    pass
    os.startfile(url)  # noqa: S606  退避（＝既存ウィンドウのタブで開く）
    return False
