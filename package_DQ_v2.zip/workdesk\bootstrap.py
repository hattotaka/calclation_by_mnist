"""実行基盤の合成ルート（サービス生成 → `Context` → `Dispatcher`）。

**GUI ツールキットを import しない。** どの view（Tkinter / PySide6）から呼んでも同じものが
組み上がるように、`App.__init__` の中に埋まっていた組み立てをここへ出した
（design-notes「2026-09-04 …」Phase 2b）。

view が渡すのは 3 つだけ:
- `run_on_ui(fn)` … 他スレッドから UI スレッドへ関数を回す口（Tk なら `_ui_q`＋`after`、
  Qt ならシグナル/スロット）。
- `onetime_popup` / `mention_picker` … `services/ui_ports.py` の実装（省略可＝窓を出さない）。

`Fake*` を差し込みたいテストは `clipboard=` / `log=` / `crypto=` / `templates=` に渡す。
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from .context import Context
from .dispatch import Dispatcher
from .model import AppData
from .services.clipboard import ClipboardService
from .services.crypto import CryptoService
from .services.logger import Logger
from .services.mention import MentionDirectory
from .services.onetime import OneTimeService
from .services.templates import TemplateStore
from .services.ui_ports import MentionPicker, OneTimePopup
from .settings import SettingsReader


@dataclass
class Runtime:
    """組み上がった実行基盤一式。view はこれを受け取って各サービスを公開するだけ。"""

    settings: SettingsReader
    clipboard: object
    log: object
    onetime: OneTimeService
    crypto: object
    templates: object
    mention_directory: MentionDirectory
    context: Context
    dispatcher: Dispatcher


def build(
    app_data: AppData,
    save_path: str | Path,
    *,
    run_on_ui: Callable[[Callable[[], None]], None],
    onetime_popup: OneTimePopup | None = None,
    mention_picker: MentionPicker | None = None,
    clipboard=None,
    log=None,
    crypto=None,
    templates=None,
    use_hook: bool | None = None,
) -> Runtime:
    """サービスを組み立てて `Runtime` を返す。

    `app_data` は **view が保持し続ける live なオブジェクト**を渡すこと
    （`SettingsReader` がそれを包むので、階層 CRUD の結果がそのまま設定にも反映される）。
    `save_path` の親フォルダが `secrets.json` と `templates/` の置き場になる。
    """
    save_path = Path(save_path)

    settings = SettingsReader(app_data)

    clip = clipboard or ClipboardService()
    if hasattr(clip, "warmup"):
        clip.warmup()   # 初回貼り付けの取りこぼし対策（cold OpenClipboard コストを先払い）

    onetime = OneTimeService(
        run_on_ui=run_on_ui,
        clipboard=clip,
        wait_ms=lambda: int(settings.get("onetime_wait_ms", 300)),
        popup=onetime_popup,
        use_hook=use_hook,
    )
    crypto_svc = crypto or CryptoService(save_path.parent / "secrets.json")
    template_store = templates or TemplateStore(save_path.parent / "templates", clip)
    mention_dir = MentionDirectory(
        run_on_ui=run_on_ui,
        entries=lambda: app_data.settings.get("mention_directory", []),
        picker=mention_picker,
    )
    logger = log or Logger()

    context = Context(
        settings=settings,
        clipboard=clip,
        log=logger,
        onetime=onetime,
        crypto=crypto_svc,
        templates=template_store,
        mention_directory=mention_dir,
    )
    return Runtime(
        settings=settings,
        clipboard=clip,
        log=logger,
        onetime=onetime,
        crypto=crypto_svc,
        templates=template_store,
        mention_directory=mention_dir,
        context=context,
        dispatcher=Dispatcher(context, settings),
    )
