"""services が出す 2 つのポップアップの **Qt 実装**（`services/ui_ports.py` の口）。

Tk 版 `view/popups.py` の置き換え。**services は tkinter も PySide6 も知らない**
（Phase 2a で Protocol に切った）ので、ここを差し替えるだけで載る。

スパイク5 で実機検証済みの型を守る（design-notes「2026-09-04 Qt 移行 Phase 1 ⑤」）:
  - ワーカースレッドは `threading.Event` / `queue.Queue` でブロックする
    （`exec()` のようなモーダルループは使わない ── キーボードフックのポンプと
      再入して GIL クラッシュする。CLAUDE.md §3）
  - UI の生成・更新は services が `run_on_ui` で UI スレッドへ回す
  - 最前面に出すが**貼り付け先のフォーカスを奪わない**
    （`Qt.Tool` ＋ `WA_ShowWithoutActivating`）
"""

from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout, QLabel, QPushButton, QScrollArea, QVBoxLayout, QWidget,
)

from .uikit import pal as _pal

_POPUP_FLAGS = Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
_LIST_WIDTH = 270
_LIST_MAX_HEIGHT = 420
_NO_MENTION = "（メンション無し）"


def _shell(parent: QWidget | None) -> QWidget:
    """共通の外枠。最前面・枠なし・**フォーカスを奪わない**。"""
    w = QWidget(parent, _POPUP_FLAGS)
    w.setAttribute(Qt.WA_ShowWithoutActivating, True)
    w.setObjectName("popupShell")
    w.setAttribute(Qt.WA_StyledBackground, True)
    w.setStyleSheet(
        "#popupShell{background:%s;border:1px solid %s;border-radius:10px;}"
        % (_pal("card_face"), _pal("card_edge")))
    return w


def _center_on(win: QWidget, host: QWidget | None, *, dy: int = 0) -> None:
    win.adjustSize()
    if host is not None and host.isVisible():
        g = host.frameGeometry()
        x = g.x() + (g.width() - win.width()) // 2
        y = g.y() + (g.height() - win.height()) // 2 + dy
    else:
        scr = win.screen().availableGeometry()
        x = scr.x() + (scr.width() - win.width()) // 2
        y = scr.y() + scr.height() // 3
    win.move(max(0, x), max(0, y))


class QtOneTimePopup:
    """`services.ui_ports.OneTimePopup` の Qt 実装。

    ワンタイム（順次貼り付け）の進行を出す小窓。`close()` は冪等。
    """

    def __init__(self, host: QWidget | None, *, on_cancel: Callable[[], None]) -> None:
        self._host = host
        self._on_cancel = on_cancel
        self._win: QWidget | None = None
        self._label: QLabel | None = None

    def open(self) -> None:
        if self._win is not None:
            return
        win = _shell(self._host)
        v = QVBoxLayout(win)
        v.setContentsMargins(22, 16, 22, 14)
        v.setSpacing(10)
        self._label = QLabel("")
        self._label.setAlignment(Qt.AlignCenter)
        self._label.setStyleSheet("QLabel{color:%s;background:transparent;border:none;}"
                                  % _pal("ink"))
        v.addWidget(self._label)
        btn = QPushButton("中止")
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda: self._on_cancel())
        v.addWidget(btn, alignment=Qt.AlignCenter)
        # **ここでは出さない。** 文言が入る前に `show()` すると、既定の小さい窓が
        # 一度実体化してから文言の幅へ広がる ── 古い Windows では「小さい窓が
        # 一瞬開いて閉じた」ように見える（2026-09-07。Windows 10 1607 の実機報告）。
        # 出すのは文言を入れた `update()`（`OneTimeService` が open→update と呼ぶ）。
        self._win = win

    def update(self, label: str, index: int, total: int) -> None:
        if self._label is not None:
            self._label.setText(
                "%s をコピー中  （%d/%d）\nCtrl+V で貼り付けてください" % (label, index, total))
            if self._win is not None:
                _center_on(self._win, self._host)     # adjustSize を含む
                if not self._win.isVisible():
                    self._win.show()

    def close(self) -> None:
        if self._win is not None:
            self._win.close()
            self._win.deleteLater()
        self._win = None
        self._label = None


class _Choice(QWidget):
    """宛先 1 件の「箱」。マウスが乗ったときだけうっすら色づく（キーボード操作は無い）。"""

    def __init__(self, text: str, mention: str,
                 on_choose: Callable[[str], None]) -> None:
        super().__init__()
        self._mention = mention
        self._on_choose = on_choose
        self.setObjectName("mentionBox")
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setCursor(Qt.PointingHandCursor)
        h = QHBoxLayout(self)
        h.setContentsMargins(12, 11, 12, 11)
        self._label = QLabel(text)
        self._label.setAlignment(Qt.AlignCenter)
        h.addWidget(self._label, 1)
        self._paint(False)

    def _paint(self, hover: bool) -> None:
        face = _pal("row_hover") if hover else "transparent"
        edge = _pal("input_border") if not hover else _pal("sub")
        self.setStyleSheet(
            "#mentionBox{background:%s;border:1px solid %s;border-radius:6px;}"
            "QLabel{color:%s;background:transparent;border:none;}"
            % (face, edge, _pal("ink")))

    def enterEvent(self, _e) -> None:   # noqa: N802
        self._paint(True)

    def leaveEvent(self, _e) -> None:   # noqa: N802
        self._paint(False)

    def mouseReleaseEvent(self, e) -> None:   # noqa: N802
        # ポインタが箱の外へ出てからの離しは無視（誤選択防止。Tk 版と同じ）
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self._on_choose(self._mention)


class QtMentionPicker:
    """`services.ui_ports.MentionPicker` の Qt 実装。

    宛先を 1 つ選ばせる窓。**× で閉じない**（必ず選ばせる）。キーボード操作は無い。
    """

    def __init__(self, host: QWidget | None,
                 *, anchor_rect: Callable[[], tuple[int, int, int, int] | None] | None = None
                 ) -> None:
        self._host = host
        self._anchor_rect = anchor_rect
        self._win: QWidget | None = None

    def open(self, rows: list[tuple[str, str]], preview: str,
             on_choose: Callable[[str | None], None]) -> None:
        win = _shell(self._host)
        self._win = win
        v = QVBoxLayout(win)
        v.setContentsMargins(22, 16, 22, 18)
        v.setSpacing(8)

        head = QLabel("メンション先を選んでください")
        head.setStyleSheet("QLabel{color:%s;background:transparent;border:none;}"
                           % _pal("sub"))
        v.addWidget(head)

        if preview:
            text = "  ".join(preview.strip().splitlines()[:2])
            if len(text) > 60:
                text = text[:60] + "…"
            pv = QLabel(text)
            pv.setWordWrap(True)
            pv.setFixedWidth(_LIST_WIDTH)
            pv.setStyleSheet(
                "QLabel{color:%s;background:%s;border:none;border-radius:4px;padding:6px 10px;}"
                % (_pal("sub"), _pal("row_hover")))
            v.addWidget(pv)

        body = QWidget()
        bv = QVBoxLayout(body)
        bv.setContentsMargins(0, 0, 0, 0)
        bv.setSpacing(8)
        picks = [(n or m, m) for n, m in rows] + [(_NO_MENTION, "")]
        for label, mention in picks:
            bv.addWidget(_Choice(label, mention, on_choose))
        body.setFixedWidth(_LIST_WIDTH)

        if len(picks) * 46 > _LIST_MAX_HEIGHT:
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(body)
            scroll.setFixedSize(_LIST_WIDTH + 16, _LIST_MAX_HEIGHT)
            scroll.setStyleSheet("QScrollArea{background:transparent;border:none;}")
            v.addWidget(scroll)
        else:
            v.addWidget(body)

        self._place(win)
        win.show()

    def close(self) -> None:
        if self._win is not None:
            self._win.close()
            self._win.deleteLater()
        self._win = None

    def _place(self, win: QWidget) -> None:
        """実行中タスク行の中央に出す。取れなければ本体の中央やや上。"""
        win.adjustSize()
        rect = self._anchor_rect() if self._anchor_rect is not None else None
        if rect is not None:
            rx, ry, rw, rh = rect
            win.move(max(0, rx + rw // 2 - win.width() // 2),
                     max(0, ry + rh // 2 - win.height() // 2))
        else:
            _center_on(win, self._host, dy=-40)
