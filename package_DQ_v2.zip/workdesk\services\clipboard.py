"""クリップボード操作（Windows, ctypes）。

- 平文: CF_UNICODETEXT
- 書式付き: CF_HTML（"HTML Format"）＋ 平文フォールバックを同時に載せる
- **秘密の文字列（`private=True`）は Win+V のクリップボード履歴／クラウド同期から外す**
  （design-notes「2026-09-02 その5」）。

クリップボード履歴（Win+V）について:
    履歴は「載せた瞬間のスナップショット」なので、**あとから `clear()` しても消えない**。
    ワンタイムの「貼り付け後にクリアする」は履歴に対しては無力（実測: 既定の 300ms 待ちでは
    毎回残った。50〜100ms だと残らないことがあるが、それは履歴サービスが読む前に消せた
    という偶然にすぎない）。
    確実に外すには、**データと同じ `OpenClipboard`〜`CloseClipboard` の中で**
    Microsoft が定めた登録フォーマットを一緒に載せる（`_PRIVATE_FORMATS`）。
"""

from __future__ import annotations

import ctypes
import threading
from ctypes import wintypes
from dataclasses import dataclass

CF_UNICODETEXT = 13
GMEM_MOVEABLE = 0x0002

_user32 = ctypes.WinDLL("user32", use_last_error=True)
_kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)

_user32.OpenClipboard.argtypes = [wintypes.HWND]
_user32.OpenClipboard.restype = wintypes.BOOL
_user32.EmptyClipboard.restype = wintypes.BOOL
_user32.CloseClipboard.restype = wintypes.BOOL
_user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
_user32.SetClipboardData.restype = wintypes.HANDLE
_user32.GetClipboardData.argtypes = [wintypes.UINT]
_user32.GetClipboardData.restype = wintypes.HANDLE
_user32.RegisterClipboardFormatW.argtypes = [wintypes.LPCWSTR]
_user32.RegisterClipboardFormatW.restype = wintypes.UINT
# クリップボードが変わるたびに増える通し番号。**「まだ自分が載せたものか」**の判定に使う
# （時間差クリアで、ユーザーがその間にコピーしたものを消さないため）。
_user32.GetClipboardSequenceNumber.argtypes = []
_user32.GetClipboardSequenceNumber.restype = wintypes.DWORD

_kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
_kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
_kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
_kernel32.GlobalLock.restype = wintypes.LPVOID
_kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
_kernel32.GlobalUnlock.restype = wintypes.BOOL
_kernel32.GlobalFree.argtypes = [wintypes.HGLOBAL]
_kernel32.GlobalFree.restype = wintypes.HGLOBAL
_kernel32.GlobalSize.argtypes = [wintypes.HGLOBAL]
_kernel32.GlobalSize.restype = ctypes.c_size_t

_CF_HTML = _user32.RegisterClipboardFormatW("HTML Format")

# 「クリップボード履歴／クラウド同期に載せない」ことを示す登録フォーマット。
#   ExcludeClipboardContentFromMonitorProcessing … 監視系すべてから除外
#   CanIncludeInClipboardHistory (=0)            … Win+V の履歴に載せない
#   CanUploadToCloudClipboard    (=0)            … 端末間のクラウド同期に載せない
# 実測（2026-09-02）: 上 2 つはそれぞれ単独でも履歴に載らなくなる。3 つとも付けるのは
# 「履歴」と「クラウド」で担当が違うため（クラウド同期はこの端末では無効で単独検証できず）。
_PRIVATE_FORMATS = tuple(
    _user32.RegisterClipboardFormatW(name)
    for name in (
        "ExcludeClipboardContentFromMonitorProcessing",
        "CanIncludeInClipboardHistory",
        "CanUploadToCloudClipboard",
    )
)


def parse_cf_html_fragment(blob: bytes) -> str:
    """CF_HTML バイト列から StartFragment〜EndFragment を取り出して返す。"""
    text = blob.split(b"\x00", 1)[0]
    off: dict[str, int] = {}
    head_end = text.find(b"<")
    header = text[: head_end if head_end > 0 else len(text)].decode("ascii", "replace")
    for line in header.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            if v.strip().isdigit():
                off[k.strip()] = int(v)
    sf, ef = off.get("StartFragment"), off.get("EndFragment")
    if sf is not None and ef is not None and 0 <= sf <= ef <= len(text):
        return text[sf:ef].decode("utf-8", "replace")
    sh, eh = off.get("StartHTML"), off.get("EndHTML")
    if sh is not None and eh is not None and 0 <= sh <= eh <= len(text):
        return text[sh:eh].decode("utf-8", "replace")
    return text.decode("utf-8", "replace")


def cf_html_blob(fragment_html: str) -> bytes:
    """CF_HTML のバイト列（UTF-8、オフセットヘッダ付き）を作る。"""
    header = (
        "Version:0.9\r\n"
        "StartHTML:{sh:010d}\r\n"
        "EndHTML:{eh:010d}\r\n"
        "StartFragment:{sf:010d}\r\n"
        "EndFragment:{ef:010d}\r\n"
    )
    pre = "<html><body><!--StartFragment-->"
    post = "<!--EndFragment--></body></html>"

    hlen = len(header.format(sh=0, eh=0, sf=0, ef=0).encode("utf-8"))
    start_html = hlen
    start_frag = hlen + len(pre.encode("utf-8"))
    end_frag = start_frag + len(fragment_html.encode("utf-8"))
    end_html = end_frag + len(post.encode("utf-8"))

    doc = header.format(sh=start_html, eh=end_html, sf=start_frag, ef=end_frag) + pre + fragment_html + post
    return doc.encode("utf-8")


@dataclass
class ClipboardPayload:
    """コピー機能が用意する「載せるもの」。html があれば書式付き。

    `private=True` は「秘密なので Win+V の履歴に残さない」印。暗号化コピーと
    ワンタイムで立てる（`features/copy.py`）。ワンタイム経由でも `apply()` を通るので、
    この 1 つのフラグで両方の経路に効く。
    """

    text: str = ""
    html: str | None = None
    private: bool = False

    def apply(self, clipboard) -> None:
        if self.html is not None:
            clipboard.set_html(self.html, self.text, private=self.private)
        else:
            clipboard.set_text(self.text, private=self.private)


class ClipboardService:
    """Windows のクリップボード。**時間差クリアの予約もここが持つ**（2026-09-06）。

    予約は**常に 1 つだけ**（`auto_clear_after` を呼ぶと前の予約は破棄される）。
    「暗号化コピーを 295 秒後にもう一度実行したら、5 秒後に消えた」を避けるため
    ── 経過時間を持ち越さず、そのつど数え直す。
    """

    def __init__(self) -> None:
        self._timer: threading.Timer | None = None
        self._armed_seq: int | None = None
        self._lock = threading.Lock()

    # --- 時間差クリア（暗号化コピー） -------------------------------- #
    def auto_clear_after(self, seconds: float) -> None:
        """いま載せたものを `seconds` 後に消す予約。`seconds<=0` なら予約しない。

        **その時点でクリップボードが自分の載せたままなら**消す ── 途中で
        ユーザーが別のものをコピーしていたら、それを消してしまうので何もしない
        （`GetClipboardSequenceNumber` で判定する）。
        """
        with self._lock:
            self._cancel_locked()
            if seconds <= 0:
                return
            self._armed_seq = int(_user32.GetClipboardSequenceNumber())
            self._timer = threading.Timer(float(seconds), self._fire_auto_clear)
            self._timer.daemon = True       # 予約が残っていてもアプリは終了できる
            self._timer.start()

    def cancel_auto_clear(self) -> None:
        with self._lock:
            self._cancel_locked()

    def _cancel_locked(self) -> None:
        if self._timer is not None:
            self._timer.cancel()
        self._timer = None
        self._armed_seq = None

    def _fire_auto_clear(self) -> None:
        """タイマースレッドから。**上書きされていたら何もしない。**"""
        with self._lock:
            armed, self._timer, self._armed_seq = self._armed_seq, None, None
        if armed is None or int(_user32.GetClipboardSequenceNumber()) != armed:
            return                          # 誰かが別のものをコピーした
        try:
            self.clear()
        except OSError:
            pass                            # 消せなくても実行は続く（次の コピーで上書き）

    def _open(self) -> None:
        for _ in range(10):
            if _user32.OpenClipboard(None):
                return
            _kernel32.Sleep(10)
        raise OSError(f"OpenClipboard failed (err={ctypes.get_last_error()})")

    def _set_handle(self, fmt: int, buf: bytes) -> None:
        handle = _kernel32.GlobalAlloc(GMEM_MOVEABLE, len(buf))
        if not handle:
            raise OSError("GlobalAlloc failed")
        ptr = _kernel32.GlobalLock(handle)
        if not ptr:
            _kernel32.GlobalFree(handle)
            raise OSError("GlobalLock failed")
        ctypes.memmove(ptr, buf, len(buf))
        _kernel32.GlobalUnlock(handle)
        if not _user32.SetClipboardData(fmt, handle):
            _kernel32.GlobalFree(handle)
            raise OSError(f"SetClipboardData failed (fmt={fmt}, err={ctypes.get_last_error()})")

    def _mark_private(self) -> None:
        """開いているクリップボードに「履歴／クラウドに載せない」印を付ける。

        **失敗したら例外を投げる**（黙って続けると秘密が履歴へ流れるため。
        呼び出し側の `copy` 機能の例外は Dispatcher が FAILED に正規化する）。
        """
        for fmt in _PRIVATE_FORMATS:
            if not fmt:
                raise OSError("クリップボード履歴の除外フォーマットを登録できませんでした")
            self._set_handle(fmt, (0).to_bytes(4, "little"))

    def warmup(self) -> None:
        """初回 OpenClipboard の一度きりのコストを起動時に払っておく（中身は触らない）。"""
        try:
            self._open()
            _user32.CloseClipboard()
        except OSError:
            pass

    def clear(self) -> None:
        self._open()
        try:
            _user32.EmptyClipboard()
        finally:
            _user32.CloseClipboard()

    def set_text(self, text: str, *, private: bool = False) -> None:
        """`private=True` なら Win+V の履歴・クラウド同期から外す（暗号化／ワンタイム）。"""
        self._open()
        try:
            _user32.EmptyClipboard()
            if text:
                self._set_handle(CF_UNICODETEXT, text.encode("utf-16-le") + b"\x00\x00")
            if private:
                self._mark_private()   # 同じ Open/Close の中で付けないと効かない
        finally:
            _user32.CloseClipboard()

    def set_html(self, html: str, plain_fallback: str = "", *, private: bool = False) -> None:
        self._open()
        try:
            _user32.EmptyClipboard()
            if plain_fallback:
                self._set_handle(CF_UNICODETEXT, plain_fallback.encode("utf-16-le") + b"\x00\x00")
            self._set_handle(_CF_HTML, cf_html_blob(html) + b"\x00")
            if private:
                self._mark_private()
        finally:
            _user32.CloseClipboard()

    def get_text(self) -> str | None:
        """現在の平文（CF_UNICODETEXT）。載っていなければ None。

        機能は使わない（`Context` の Protocol にも無い）。**時間差クリアの検証**の
        ように「いま何が載っているか」を確かめたいときの口。
        """
        self._open()
        try:
            h = _user32.GetClipboardData(CF_UNICODETEXT)
            if not h:
                return None
            ptr = _kernel32.GlobalLock(h)
            if not ptr:
                return None
            try:
                return ctypes.wstring_at(ptr)
            finally:
                _kernel32.GlobalUnlock(h)
        finally:
            _user32.CloseClipboard()

    def get_html(self) -> tuple[str, str] | None:
        """現在のクリップボードから (HTML断片, 平文) を読む。CF_HTML が無ければ None。"""
        self._open()
        try:
            h = _user32.GetClipboardData(_CF_HTML)
            if not h:
                return None
            ptr = _kernel32.GlobalLock(h)
            if not ptr:
                return None
            try:
                raw = ctypes.string_at(ptr, _kernel32.GlobalSize(h))
            finally:
                _kernel32.GlobalUnlock(h)
            html = parse_cf_html_fragment(raw)

            text = ""
            ht = _user32.GetClipboardData(CF_UNICODETEXT)
            if ht:
                p = _kernel32.GlobalLock(ht)
                if p:
                    try:
                        text = ctypes.wstring_at(p)
                    finally:
                        _kernel32.GlobalUnlock(ht)
            return html, text
        finally:
            _user32.CloseClipboard()


class FakeClipboard:
    """テスト・ヘッドレス用。実クリップボードに触れない。"""

    def __init__(self) -> None:
        self.text: str | None = None
        self.html: str | None = None
        self.history: list = []
        self.private: bool | None = None      # 直近のコピーが履歴除外だったか
        self.private_log: list[bool] = []     # コピーごとの履歴除外フラグ
        self.auto_clear_calls: list[float] = []   # 時間差クリアの予約（秒）

    def auto_clear_after(self, seconds: float) -> None:
        """**実際には消さない**（記録だけ）。予約は 1 つだけ＝実装と同じ約束。"""
        self.auto_clear_calls.append(float(seconds))

    def cancel_auto_clear(self) -> None:
        pass

    def clear(self) -> None:
        self.text = None
        self.html = None
        self.private = None
        self.history.append(None)

    def set_text(self, text: str, *, private: bool = False) -> None:
        self.text = text
        self.html = None
        self.private = private
        self.private_log.append(private)
        self.history.append(text)

    def set_html(self, html: str, plain_fallback: str = "", *, private: bool = False) -> None:
        self.text = plain_fallback or None
        self.html = html
        self.private = private
        self.private_log.append(private)
        self.history.append(("html", html, plain_fallback))

    def get_text(self) -> str | None:
        return self.text

    def get_html(self) -> tuple[str, str] | None:
        if self.html is None:
            return None
        return self.html, self.text or ""
