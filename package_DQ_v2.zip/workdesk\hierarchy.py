"""階層要素の CRUD（純粋関数）。設定モードの編集操作の実体。

- 対象: 業務グループ / 業務 / タスクグループ / タスク / 動作。
- ID はツリー全体で一意なので、delete / rename / insert_after は ID だけで対象を特定できる。
- add は親コンテキスト（親 ID）が要るので型別の関数を用意する。
- 並べ替え・グループ移動は `move_before_sibling` / `move_work` / `move_task` /
  `move_*_to_new_group`（§16bis Phase D。行のどこでもドラッグ）。
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

from .model import Action, AppData, Task, TaskGroup, Work, WorkGroup


# --------------------------------------------------------------------------- #
# 内部: ツリー内の全順序リストを走査
# --------------------------------------------------------------------------- #
def _all_lists(data: AppData) -> Iterator[list]:
    yield data.work_groups
    for wg in data.work_groups:
        yield wg.works
        for w in wg.works:
            yield w.task_groups
            for tg in w.task_groups:
                yield tg.tasks
                for t in tg.tasks:
                    yield t.actions


def _iter_tasks(data: AppData) -> Iterator[tuple[WorkGroup, Work, TaskGroup, Task]]:
    """全タスクを祖先つきで走査する。`find_*` / `parent_*` の共通土台
    （同じ 4 重ループを関数ごとに書かない）。"""
    for wg in data.work_groups:
        for w in wg.works:
            for tg in w.task_groups:
                for t in tg.tasks:
                    yield wg, w, tg, t


def _owner(data: AppData, entity_id: str) -> tuple[list | None, int]:
    for lst in _all_lists(data):
        for i, item in enumerate(lst):
            if item.id == entity_id:
                return lst, i
    return None, -1


# --------------------------------------------------------------------------- #
# 検索
# --------------------------------------------------------------------------- #
def find_work_group(data: AppData, gid: str) -> WorkGroup | None:
    return next((g for g in data.work_groups if g.id == gid), None)


def find_work(data: AppData, wid: str) -> Work | None:
    return next(
        (w for g in data.work_groups for w in g.works if w.id == wid), None
    )


def find_task_group(data: AppData, tgid: str) -> TaskGroup | None:
    return next(
        (tg for g in data.work_groups for w in g.works
         for tg in w.task_groups if tg.id == tgid),
        None,
    )


def find_task(data: AppData, tid: str) -> Task | None:
    return next((t for _wg, _w, _tg, t in _iter_tasks(data) if t.id == tid), None)


def find_action(data: AppData, aid: str) -> Action | None:
    for lst in _all_lists(data):
        for item in lst:
            if isinstance(item, Action) and item.id == aid:
                return item
    return None


def parent_task_of_action(data: AppData, aid: str) -> Task | None:
    """動作 `aid` が属するタスクを返す（無ければ None）。"""
    for _wg, _w, _tg, t in _iter_tasks(data):
        if any(a.id == aid for a in t.actions):
            return t
    return None


def parent_work_of_task(data: AppData, tid: str) -> Work | None:
    """タスク `tid` が属する業務を返す（無ければ None）。"""
    for _wg, w, _tg, t in _iter_tasks(data):
        if t.id == tid:
            return w
    return None


def work_group_of_work(data: AppData, wid: str) -> tuple[int, WorkGroup] | tuple[None, None]:
    """業務 `wid` が属する業務グループの `(表示インデックス, グループ)`。無ければ `(None, None)`。

    インデックスはグループ色相（`theme_tokens.group_tone(i, ...)`）の決定に使うので、
    「何番目のグループか」まで返す。
    """
    for i, wg in enumerate(data.work_groups):
        if any(w.id == wid for w in wg.works):
            return i, wg
    return None, None


# --------------------------------------------------------------------------- #
# 汎用操作（ID 指定）
# --------------------------------------------------------------------------- #
def rename(data: AppData, entity_id: str, new_name: str) -> bool:
    lst, i = _owner(data, entity_id)
    if lst is None:
        return False
    lst[i].name = new_name
    return True


def delete(data: AppData, entity_id: str) -> bool:
    lst, i = _owner(data, entity_id)
    if lst is None:
        return False
    del lst[i]
    return True


def prune_empty_groups(data: AppData) -> list[int]:
    """**空になったグループを取り除く**（業務グループ＝業務が 0 / タスクグループ＝タスクが 0）。

    グループは画面に名前を出さない「順序付きの入れ物」なので、空になっても
    ユーザーには見えない（サイドバーもメインパネルも空グループは飾らない）。
    残っていても害は無いが、JSON に見えないゴミが溜まり、並べ替えの落とし先として
    生き続ける。削除・グループ間移動のたびに片付ける（2026-09-06 ユーザー判断）。

    **業務が 0 の業務グループだけを消す。** 業務そのものは、中のタスクが 0 でも
    消さない（これから作る場所として意味がある）。

    戻り値は消した**業務グループの位置**（昇順）。位置は `theme_tokens.STATE`
    の `group_hues` の添字でもあるので、呼び出し側で色も詰める必要がある
    （`uicore.UiCore.prune_empty_groups` がやる）。
    """
    removed: list[int] = []
    for i in range(len(data.work_groups) - 1, -1, -1):
        wg = data.work_groups[i]
        for w in wg.works:
            w.task_groups = [tg for tg in w.task_groups if tg.tasks]
        if not wg.works:
            del data.work_groups[i]
            removed.append(i)
    return sorted(removed)


# --------------------------------------------------------------------------- #
# 追加（型別）
# --------------------------------------------------------------------------- #
def add_work_group(data: AppData, name: str = "") -> WorkGroup:
    wg = WorkGroup(name=name)
    data.work_groups.append(wg)
    return wg


def add_work(data: AppData, group_id: str, name: str) -> Work | None:
    g = find_work_group(data, group_id)
    if g is None:
        return None
    w = Work(name=name)
    g.works.append(w)
    return w


def add_task_group(data: AppData, work_id: str, name: str = "") -> TaskGroup | None:
    w = find_work(data, work_id)
    if w is None:
        return None
    tg = TaskGroup(name=name)
    w.task_groups.append(tg)
    return tg


def add_task(data: AppData, task_group_id: str, name: str) -> Task | None:
    tg = find_task_group(data, task_group_id)
    if tg is None:
        return None
    t = Task(name=name)
    tg.tasks.append(t)
    return t


def move_before_sibling(data: AppData, entity_id: str, before_id: str | None) -> bool:
    """`entity_id` を **同じ親リスト内** で `before_id` の直前へ移す。
    `before_id=None` で末尾へ。`before_id` が別リストの要素なら False（動作の D&D 用）。
    """
    lst, i = _owner(data, entity_id)
    if lst is None:
        return False
    item = lst[i]
    if before_id is None:
        lst.pop(i)
        lst.append(item)
        return True
    lst2, _j = _owner(data, before_id)
    if lst2 is not lst:
        return False
    lst.pop(i)
    k = next((n for n, x in enumerate(lst) if x.id == before_id), len(lst))
    lst.insert(k, item)
    return True


def move_work(
    data: AppData, work_id: str, dest_group_id: str, before_id: str | None = None
) -> bool:
    """業務を `dest_group_id` の業務グループへ移す（`before_id` の直前 / None で末尾）。
    D&D の並べ替え＋グループ間移動（§16bis Phase D）。同一グループ内の並べ替えも兼ねる。
    """
    src, i = _owner(data, work_id)
    dest = find_work_group(data, dest_group_id)
    if src is None or dest is None or not isinstance(src[i], Work):
        return False
    w = src.pop(i)
    if before_id is None:
        dest.works.append(w)
    else:
        k = next((n for n, x in enumerate(dest.works) if x.id == before_id), len(dest.works))
        dest.works.insert(k, w)
    return True


def move_task(
    data: AppData, task_id: str, dest_group_id: str, before_id: str | None = None
) -> bool:
    """タスクを `dest_group_id` のタスクグループへ移す（`before_id` の直前 / None で末尾）。
    D&D の並べ替え＋タスクグループ間移動（§16bis Phase D）。同一グループ内の並べ替えも兼ねる。
    """
    src, i = _owner(data, task_id)
    dest = find_task_group(data, dest_group_id)
    if src is None or dest is None or not isinstance(src[i], Task):
        return False
    t = src.pop(i)
    if before_id is None:
        dest.tasks.append(t)
    else:
        k = next((n for n, x in enumerate(dest.tasks) if x.id == before_id), len(dest.tasks))
        dest.tasks.insert(k, t)
    return True


def move_work_to_new_group(data: AppData, work_id: str) -> bool:
    """業務を **新しい業務グループ**（末尾に作る）へ移す（§16bis Phase D。最終行の下へドロップ）。"""
    src, i = _owner(data, work_id)
    if src is None or not isinstance(src[i], Work):
        return False
    wg = WorkGroup(name="")
    data.work_groups.append(wg)
    wg.works.append(src.pop(i))
    return True


def move_task_to_new_group(data: AppData, task_id: str, work_id: str) -> bool:
    """タスクを **新しいタスクグループ**（その業務の末尾に作る）へ移す（§16bis Phase D）。"""
    src, i = _owner(data, task_id)
    w = find_work(data, work_id)
    if src is None or w is None or not isinstance(src[i], Task):
        return False
    tg = TaskGroup(name="")
    w.task_groups.append(tg)
    tg.tasks.append(src.pop(i))
    return True


def split_group_before(data: AppData, entity_id: str) -> bool:
    """`entity_id`（業務 or タスク）と、**同じグループでそれより後ろにある兄弟**を、
    直後に新しく作るグループへまとめて移す（グループの分割）。

    - 全体の並び順は保持（新グループは元グループの直後に入り、末尾側だけが移る）。
    - `entity_id` がグループ先頭なら分ける意味が無いので **False**（何もしない）。
    - 右クリック「グループを分ける」用。業務なら業務グループ、タスクならタスクグループ。
    """
    for gi, wg in enumerate(data.work_groups):
        for i, w in enumerate(wg.works):
            if w.id == entity_id:
                if i == 0:
                    return False
                new = WorkGroup(name="")
                new.works = wg.works[i:]
                wg.works = wg.works[:i]
                data.work_groups.insert(gi + 1, new)
                return True
    for w in (w for wg in data.work_groups for w in wg.works):
        for j, tg in enumerate(w.task_groups):
            for i, t in enumerate(tg.tasks):
                if t.id == entity_id:
                    if i == 0:
                        return False
                    new = TaskGroup(name="")
                    new.tasks = tg.tasks[i:]
                    tg.tasks = tg.tasks[:i]
                    w.task_groups.insert(j + 1, new)
                    return True
    return False


def insert_after(data: AppData, anchor_id: str, item: Any) -> bool:
    """`anchor_id` の要素の直後に、同じ親リストへ `item` を挿入する（兄弟挿入）。

    コピー&貼り付け（design-notes §16bis Phase C）用。`item` の型が親リストと
    整合しているかは呼び出し側の責任（Work→works / Task→tasks / Action→actions）。
    """
    lst, i = _owner(data, anchor_id)
    if lst is None:
        return False
    lst.insert(i + 1, item)
    return True


def add_action(data: AppData, task_id: str, action_id: str, args: dict[str, Any]) -> Action | None:
    t = find_task(data, task_id)
    if t is None:
        return None
    a = Action(action_id=action_id, args=dict(args))
    t.actions.append(a)
    return a
