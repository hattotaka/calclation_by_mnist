"""「一時ファイルへ書いて置換」を 1 か所にまとめる（**GUI 非依存**）。

design-notes「2026-09-08 保存のやり直しを 3 か所に効かせる」。

`os.replace` は同一ボリューム内の**原子的**な置換だが、Windows では失敗しうる ──
OneDrive / マイドライブの同期プロセスや Defender が置換先を一瞬掴んでいると
`PermissionError (WinError 5)` になる（2026-09-05 に `workdesk.json` で実際に踏んだ）。
少し待ってやり直せば通るので、`replace_with_retry()` が 0.05 → 0.30 秒で 6 回試す。

**最後まで駄目なら送出する。** 握り潰すと「保存できたつもり」になる（CLAUDE.md §5）。
呼び出し側が受けて知らせること。

以前は `persistence` だけがこのやり直しを持っていて、`crypto._save` /
`templates._write` は素の `os.replace` を 1 回呼ぶだけだった ── 同じ「一時ファイル
→ 置換」を 3 か所に書き写していたので、対策も 1 か所にしか入っていなかった。
"""

from __future__ import annotations

import os
import time
from pathlib import Path

REPLACE_RETRIES = 6
REPLACE_WAIT_S = 0.05


def replace_with_retry(tmp: str | os.PathLike[str], dest: str | os.PathLike[str]) -> None:
    """`os.replace`（原子的置換）を数回やり直す。最後まで駄目なら送出する。"""
    for i in range(REPLACE_RETRIES):
        try:
            os.replace(tmp, dest)
            return
        except PermissionError:
            if i == REPLACE_RETRIES - 1:
                raise           # 呼び出し側が知らせる。**握り潰さない**
            time.sleep(REPLACE_WAIT_S * (i + 1))


def write_text(path: str | os.PathLike[str], text: str, *,
               encoding: str = "utf-8") -> None:
    """`path` へ原子的に書く（一時ファイル → 置換）。失敗したら送出する。

    置換に失敗したときは一時ファイル（`<name>.tmp`）を**残す** ── 新しい内容が
    そこにしか無いため。改行は LF 固定（JSON なので OS に合わせる意味が無く、
    既定の変換に任せると LF のファイルが丸ごと書き換わる。CLAUDE.md §7）。
    """
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(text, encoding=encoding, newline="\n")
    replace_with_retry(tmp, p)
