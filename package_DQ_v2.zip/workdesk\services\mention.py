"""Slack メンションの宛先辞書と、実行時の宛先選択（design-notes §5 / §10.6）。

役割:
- **宛先辞書** = `settings["mention_directory"]` = `[{"id","name","mention"}]`。
  設定パネルから CRUD する。`id` は UUID で辞書エントリ内部用（改名・削除しても
  動作は壊れない＝**動作 args は id を参照しない**。動作側は `mention: true/false` だけ）。
- `pick()` … コピー機能がワーカースレッドから呼ぶ。宛先一覧の窓を出し、ユーザーが 1 つ選ぶ
  or「メンション無し」を選ぶまで **ワーカースレッドをブロック**する。戻り値は選ばれた
  メンション文字列（"@xxx"）。「メンション無し」/ 候補 0 件 / picker 無し は "" を返す。
  アプリ終了時のみ `shutdown()` で待ちを解放する。
  **窓の描画はここには無い**（`ui_ports.MentionPicker` の実装＝`view/popups.py` が持つ。
  design-notes「2026-09-04 …」Phase 2a。× で閉じない・キーボード操作は無い・出現位置は
  実行中タスク行の中央、といった振る舞いは実装側の責務）。

スレッド: OneTimeService と同じ考え方。UI 生成は `run_on_ui` 経由、ワーカーは
`queue.Queue.get()` で待つ（`wait_window` は使わない＝キーボードフックのポンプと
再入しての GIL クラッシュを避ける。CLAUDE.md §3）。
"""

from __future__ import annotations

import queue
from collections.abc import Callable

from .ui_ports import MentionPicker

class MentionDirectory:
    def __init__(
        self,
        run_on_ui: Callable[[Callable[[], None]], None],
        *,
        entries: Callable[[], list[dict]],
        picker: MentionPicker | None = None,
    ) -> None:
        self._run_on_ui = run_on_ui
        self._entries = entries          # live な settings["mention_directory"] を返す callable
        self._picker = picker            # None＝窓を出さない（headless / テスト）
        self._result: queue.Queue = queue.Queue(maxsize=1)
        self._shutdown = False

    # ------------------------------------------------------------- #
    # コピー機能が呼ぶ（ワーカースレッド）
    # ------------------------------------------------------------- #
    def pick(self, preview: str = "") -> str:
        """宛先名一覧を出し、選ばれたメンション文字列を返す。

        「メンション無し」を選んだ / 候補が 0 件 / picker 無し / 終了中 は "".
        """
        if self._shutdown or self._picker is None:
            return ""
        rows = [
            (str(e.get("name", "")), str(e.get("mention", "")))
            for e in (self._entries() or [])
            if e.get("mention")
        ]
        # 取り残しのドレイン（前回 shutdown 等）
        while not self._result.empty():
            try:
                self._result.get_nowait()
            except queue.Empty:
                break
        self._run_on_ui(lambda: self._open_ui(rows, preview))
        chosen = self._result.get()          # ← ここでブロック
        return "" if chosen is None else str(chosen)

    def shutdown(self) -> None:
        self._shutdown = True
        try:
            self._result.put_nowait(None)
        except queue.Full:
            pass

    # ------------------------------------------------------------- #
    # UI（UI スレッドでのみ実行）── 描画は `ui_ports.MentionPicker` の実装に委ねる
    # ------------------------------------------------------------- #
    def _open_ui(self, rows: list[tuple[str, str]], preview: str) -> None:
        if self._picker is None:
            self._finish(None)
            return
        self._picker.open(rows, preview, self._finish)

    def _finish(self, mention: str | None) -> None:
        """選択の確定（UI スレッド）。窓を閉じてワーカーの `pick()` を起こす。"""
        if self._picker is not None:
            self._picker.close()
        try:
            self._result.put_nowait(mention)
        except queue.Full:
            pass


class FakeMentionDirectory:
    """headless / テスト用。`pick()` は事前設定した戻り値を即返す（ブロックしない）。"""

    def __init__(self, chosen: str = "") -> None:
        self.chosen = chosen
        self.calls: list[str] = []

    def pick(self, preview: str = "") -> str:
        self.calls.append(preview)
        return self.chosen

    def shutdown(self) -> None:
        pass
