"""編集ウィンドウ（選択している業務・タスク・動作のプロパティ）。

design-notes「2026-09-05 デザインラボと編集ウィンドウを分ける」で決めた形:

- **スイッチ＝設定モードそのもの**。ON にするとこの窓が出て、**タスクは実行しない**。
- デザインラボ（外観）とは**役割が違う**ので分けてある。あちらは開いていても実行できる。
- **グループ色相はここ**（対象が特定のグループなので選択が要る）。
  色相だけがユーザーのもので、明度・彩度はテーマが決める（スパイク7 の方式）。

**動作（アクション）の編集もここに集約する**（Phase 4d。ユーザー判断 2026-09-05）。
Tk 版は「一覧＝メインパネルのアコーディオン ／ フォーム＝別窓」と分かれていたが、
Qt 版はタスクのカードの中に **動作一覧（`QListWidget`）＋フォーム**を両方置く:

- メインパネルは**実行の場**のまま触らない（「実行前は主役」）。
- 並べ替えは `QListWidget` の `InternalMove`＝**Qt の標準機能**（自前の D&D を書かない）。
- 追加は**即作成**（既定の種類で作ってフォームで詰める）＝作業を止めない（2026-09-02 の方針）。
- フォームに「適用」ボタンは無い。**選択が動くとき・窓を閉じるときに自動保存**し、
  入力漏れなら移動をブロックする（`commit_pending_edits`）。

`host.selection` の種類（"work" / "task" / "action"）でカードを出し分ける。値の反映は
`host.rename_live` / `set_task_description` / `set_group_hue` / `apply_action_edit` を通す
（データ操作の実体は `uicore.UiCore`）。

**操作要素は qt-material の既定スタイルに任せない**（2026-09-05 の恒久ルール。
既定は 18/26 テーマで AA 未満）。この窓の QSS は子（`ActionForm`）にも当たる。
"""

from __future__ import annotations

from PySide6.QtCore import QPoint, QSize, Qt
from PySide6.QtGui import QDrag, QIcon, QPainter, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QSlider, QVBoxLayout, QWidget,
)

from .. import hierarchy, theme_tokens as T
from . import actionmeta, icons, qtheme, uikit
from .uikit import pal as _pal
from .actionform import ActionForm
from .titlebar import set_titlebar_dark_mode


_LIST_V_PAD = 10   # 動作一覧の上下の余白（先頭/末尾へのドラッグを掴みやすくする）
_FORM_GAP = 18     # 動作一覧（選ぶ）とフォーム（編集する）の間の余白
_HUE_GAP = 12      # 業務名の欄とグループ色の行の間（見本バーが上端に来るぶん広く取る）
_LEAD_GAP = 10     # 窓の先頭の説明と、その下のカードの間
_ICON_PX = 16      # 一覧の行に置く種類アイコンの大きさ

#: 番号を除いた要約文。行のテキストは `_renumber()` が「番号＋これ」で組み立てる。
_SUMMARY_ROLE = Qt.UserRole + 1


def _kind_icon(name: str) -> QIcon:
    """動作の種類アイコン。**選択中の行は面がアクセントになる**ので選択時の色も持たせる。

    アイコンが無い名前でも落ちない（空の QIcon ＝ 何も描かれない）。
    """
    icon = QIcon()
    for color, mode in ((_pal("sub"), QIcon.Normal), (_pal("on_accent"), QIcon.Selected)):
        pm = icons.pixmap(name, color, _ICON_PX)
        if pm is not None:
            icon.addPixmap(pm, mode)
    return icon


class _ActionList(QListWidget):
    """動作の一覧。並べ替えは `InternalMove`（Qt の標準機能）のまま。

    **掴んだ行の残像を薄くする**（2026-09-06 要望）。Qt の既定は掴んだ行を
    そのままの濃さで描いてカーソルに追随させるので、行の高さぶんの箱が
    「ここに入る」を示す線（ドロップインジケータ）をちょうど覆ってしまい、
    どこへ落ちるのか分からなくなっていた。半透明にして線が透けるようにし、
    つかむ位置（ホットスポット）を行の上端寄りにして重なりも減らす。
    """

    #: 残像の不透明度。低すぎると何を掴んでいるか分からない
    GHOST_OPACITY = 0.4

    def startDrag(self, actions) -> None:   # noqa: N802
        item = self.currentItem()
        if item is None:
            super().startDrag(actions)
            return
        rect = self.visualItemRect(item)
        if rect.isEmpty():
            super().startDrag(actions)
            return
        src = self.viewport().grab(rect)
        ghost = QPixmap(src.size())
        ghost.fill(Qt.transparent)
        p = QPainter(ghost)
        p.setOpacity(self.GHOST_OPACITY)
        p.drawPixmap(0, 0, src)
        p.end()

        drag = QDrag(self)
        drag.setMimeData(self.model().mimeData(self.selectedIndexes()))
        drag.setPixmap(ghost)
        # 掴んだ行の「上端の少し下」を持つ＝残像が指示線より下に来ることが増える
        drag.setHotSpot(QPoint(max(rect.width() // 2, 1), 6))
        drag.exec(actions, self.defaultDropAction())


class _Swatch(QWidget):
    """グループ色の見本（レールと同じ色を出す）。"""

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("hueSwatch")
        # **`QWidget` を継承したクラスは QSS の背景を自分では描かない**
        # （素の `QWidget()` インスタンスは描く。`sidebar._thin` が動いていたのは
        # そちらだから）。この属性が無いと見本が透明のままで、地色しか見えない
        # ── 2026-09-06 に実測（`grab()` のピクセルを読む）で発覚。
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.setFixedSize(56, 20)

    def set_hue(self, hue: float) -> None:
        self.setStyleSheet("#hueSwatch{background:%s;border:none;border-radius:4px;}"
                           % T.tone(hue, "bar"))


def _hue_gradient_css(steps: int = 24) -> str:
    """色相 0〜360 度をなぞる `qlineargradient`。

    **実際にグループへ適用される色**（`T.tone(hue, "bar")`）を並べるので、
    バーの横位置がそのまま出来上がりの色になる。
    """
    stops = ", ".join(
        "stop:%.4f %s" % (i / steps, T.tone((360 * i / steps) % 360, "bar"))
        for i in range(steps + 1)
    )
    return "qlineargradient(x1:0, y1:0, x2:1, y2:0, %s)" % stops


# スライダーのつまみの幅。つまみの中心は左右それぞれ半分ぶん内側までしか動かない
# ので、見本バーも同じだけ内側へ寄せないと「バーの位置 ＝ その色」がずれる。
HANDLE_W = 14


class _HueBar(QWidget):
    """スライダーの真上に敷く色相の見本（2026-09-06 要望）。

    以前は溝そのものにグラデーションを敷いていたが、**qt-material の
    `QSlider::sub-page` / `add-page` が溝の上を塗りつぶす**ので実際には
    まったく見えず、代わりにアクセント色の「メーター」が出ていた
    （＝左端でも少し残り、右端でも埋まりきらない、という見え方になる。
    そもそも色相に「量」の意味は無いのでメーター自体が誤り）。
    見本は独立したウィジェットに出し、スライダーからは塗りを消す。
    """

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("hueBarWrap")
        self.setFixedHeight(10)
        h = QHBoxLayout(self)
        # つまみの可動域に合わせて左右を内側へ寄せる（上下は詰める）
        h.setContentsMargins(HANDLE_W // 2, 0, HANDLE_W // 2, 0)
        h.setSpacing(0)
        self._bar = QWidget()
        self._bar.setObjectName("hueBar")
        h.addWidget(self._bar)
        self.restyle()

    def restyle(self) -> None:
        self.setStyleSheet(
            "#hueBarWrap{background:transparent;border:none;}"
            "#hueBar{background:%s;border:none;border-radius:4px;}"
            % _hue_gradient_css())


class EditWindow(QDialog):
    """選択要素のプロパティ編集（モードレス）。設定モードのあいだ開いている。"""

    def __init__(self, host, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._host = host
        self.setWindowTitle("編集")
        self.setModal(False)
        self.setMinimumWidth(460)
        # QSS の背景・文字色を確実に適用させる（qt-material のグローバル QSS が
        # 既定であてる灰色・黒い文字が透けて見えることがある。2026-09-05 実機で発覚）。
        self.setAttribute(Qt.WA_StyledBackground, True)

        self._v = QVBoxLayout(self)
        self._v.setContentsMargins(18, 16, 18, 16)
        self._v.setSpacing(10)
        # **窓の一番上に「何をする窓か」を平文で置く**（2026-09-06 要望）。
        # カードは選択に応じて作り直されるが、この 1 行は出しっぱなしにする。
        self._lead = QLabel("業務やタスクを選択すると、設定内容を閲覧・編集できます。")
        self._lead.setObjectName("editLead")
        self._lead.setWordWrap(True)
        self._v.addWidget(self._lead)
        # 説明の 1 行と中身の間は**行間より広く**取る（2026-09-06 要望）。
        # 同じ間隔で続くと、説明が最初の項目の見出しに見えてしまう。
        self._v.addSpacing(_LEAD_GAP)
        self._body: QWidget | None = None
        self._key: tuple[str | None, str | None] | None = None
        #: いま出ているカードの名前欄（業務名 / タスク名）。カードを作り直すと消える
        self.name_edit: QLineEdit | None = None
        # 動作まわり（タスクカードのときだけ生きている）
        self._task_id: str | None = None
        self._act_list: _ActionList | None = None
        self._form_host: QVBoxLayout | None = None
        self._form: ActionForm | None = None
        self._form_action_id: str | None = None
        self._form_head: QLabel | None = None
        #: 直前の `commit_pending_edits` が捨てた理由（閉じ際に知らせるため）
        self._commit_error: str | None = None
        self._order: list[str] = []
        self._btn_up: QPushButton | None = None
        self._btn_down: QPushButton | None = None
        self._btn_delete: QPushButton | None = None
        # インラインで色を焼き込むウィジェット（テーマ切替のとき塗り直す）
        self._swatch: _Swatch | None = None
        self._hue_slider: QSlider | None = None
        self._hue_bar: _HueBar | None = None
        self._dividers: list[QWidget] = []
        self._syncing = False
        self.refresh(force=True)

    # ================================================================ #
    # 中身の作り直し
    # ================================================================ #
    def _key_of(self, kind: str | None, ident: str | None):
        """カードの単位。**動作は親タスクのカードの中にある**ので同じ鍵になる
        （動作を選び直しただけでカードごと作り直さない＝入力中の欄を壊さない）。"""
        if kind == "action" and ident:
            task = hierarchy.parent_task_of_action(self._host.app_data, ident)
            return ("task", task.id) if task is not None else (None, None)
        return (kind, ident)

    def refresh(self, *, force: bool = False) -> None:
        """選択に追従する。`force=True` は階層が変わったとき（一覧を作り直す）。"""
        kind, ident = self._host.selection
        key = self._key_of(kind, ident)
        if force or key != self._key:
            self._rebuild(key)
            self._key = key
        if self._act_list is not None:
            self._show_action(ident if kind == "action" else None)

    def _rebuild(self, key) -> None:
        if self._body is not None:
            self._v.removeWidget(self._body)
            self._body.setParent(None)     # deleteLater だけだと残って重なる
            self._body.deleteLater()
        self._body = None
        self.name_edit = None
        self._task_id = None
        self._act_list = None
        self._form_host = None
        self._form = None
        self._form_action_id = None
        self._form_head = None
        self._order = []
        self._btn_up = None
        self._btn_down = None
        self._btn_delete = None
        self._swatch = None
        self._hue_slider = None
        self._hue_bar = None
        self._dividers = []

        kind, ident = key
        if kind == "work":
            self._body = self._card_work(ident)
        elif kind == "task":
            self._body = self._card_task(ident)
        else:
            self._body = self._card_empty()
        self._v.addWidget(self._body)
        self._restyle()
        if self._act_list is not None:
            # `_fill_action_list` は QSS 適用（行の padding 込み）の**前**に高さを
            # 測っていた ── 実寸より少し低く固定され、先頭行がわずかに隠れて
            # 内部スクロールできてしまっていた（2026-09-05 実機で発覚）。QSS 適用後に測り直す。
            self._fit_list_height()

    def _card_empty(self) -> QWidget:
        """何も選んでいないとき。**文言は出さない** ── 窓の一番上の 1 行
        （`editLead`）が同じことを言っているので、二度書かない。"""
        w = uikit.transparent(QWidget())
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.addStretch(1)
        return w

    # --- 業務 -------------------------------------------------------- #
    def _card_work(self, work_id: str) -> QWidget:
        work = hierarchy.find_work(self._host.app_data, work_id)
        w = uikit.transparent(QWidget())
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)
        if work is None:
            v.addWidget(QLabel("業務が見つかりません"))
            return w

        self.name_edit = QLineEdit(work.name)
        self.name_edit.textChanged.connect(
            lambda t: self._host.rename_live(work_id, t))
        v.addWidget(uikit.form_row("業務名", self.name_edit, label_width=72))

        # --- グループ色相（このグループに属する業務すべてに効く） ----- #
        # **効かない設定は並べない**（2026-09-06 要望）。グループ色が画面に出るのは
        # 「グループの分け方」が「レール（色）」のときだけ（`T.group_hue_visible`）。
        if not T.group_hue_visible():
            v.addStretch(1)
            return w

        # 業務名の欄との間を空ける（色の見本バーが行の上端に来るので、
        # 既定の行間だと入力欄とくっついて見える。2026-09-06 要望）。
        v.addSpacing(_HUE_GAP)
        gi = self._group_index(work_id)
        row = uikit.transparent(QWidget())
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(10)
        # 見本バーを上、スライダーを下に重ねる（横位置は揃えてある）。
        stack = uikit.transparent(QWidget())
        sv = QVBoxLayout(stack)
        sv.setContentsMargins(0, 0, 0, 0)
        sv.setSpacing(3)
        self.hue_bar = self._hue_bar = _HueBar()
        sv.addWidget(self.hue_bar)
        self.hue_slider = self._hue_slider = QSlider(Qt.Horizontal)
        self.hue_slider.setRange(0, 359)
        self.hue_slider.setValue(int(T.group_hue(gi)) % 360)
        sv.addWidget(self.hue_slider)
        self.swatch = self._swatch = _Swatch()
        self.swatch.set_hue(self.hue_slider.value())
        self.hue_slider.valueChanged.connect(
            lambda n, i=gi: self._on_hue(i, n))
        self._style_hue_slider()
        h.addWidget(stack, 1)
        h.addWidget(self.swatch)
        v.addWidget(uikit.form_row("グループ色", row, label_width=72))
        # 説明文は置かない（2026-09-07 ユーザー指定。見本バーと見本があれば
        # 何を選ぶ欄かは見れば分かる）。
        # 窓を縦に広げても**この上の行は伸ばさない**（余った分はここへ落とす）。
        v.addStretch(1)
        return w

    # --- タスク（＋動作一覧＋動作フォーム） --------------------------- #
    def _card_task(self, task_id: str) -> QWidget:
        task = hierarchy.find_task(self._host.app_data, task_id)
        w = uikit.transparent(QWidget())
        v = QVBoxLayout(w)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)
        if task is None:
            v.addWidget(QLabel("タスクが見つかりません"))
            return w
        self._task_id = task_id

        task_head = QLabel("タスク")
        task_head.setObjectName("sectionHead")
        v.addWidget(task_head)

        self.name_edit = QLineEdit(task.name)
        self.name_edit.textChanged.connect(
            lambda t: self._host.rename_live(task_id, t))
        v.addWidget(uikit.form_row("タスク名", self.name_edit, label_width=72))

        self.desc_edit = QLineEdit(task.description or "")
        self.desc_edit.setPlaceholderText("タスクに表示する説明")
        self.desc_edit.textChanged.connect(
            lambda t: self._host.set_task_description(task_id, t))
        v.addWidget(uikit.form_row("説明", self.desc_edit, label_width=72))

        # タスクと動作の区切り。**通常の行間より広めに余白を取る**
        # （2026-09-05 要望。行が詰まって見えないように）。
        v.addSpacing(14)
        line = _hline()
        self._dividers.append(line)
        v.addWidget(line)
        v.addSpacing(14)

        lbl = QLabel("動作")
        lbl.setObjectName("sectionHead")
        v.addWidget(lbl)

        self._act_list = _ActionList()
        self._act_list.setObjectName("actionList")
        self._act_list.setIconSize(QSize(_ICON_PX, _ICON_PX))
        # 長い要約は**横スクロールさせず末尾を省く**。横スクロールバーが出ると
        # 一覧の下端に太い帯が寝そべって「進捗バー」のように見え、一覧の高さも
        # 食う（番号とアイコンを足して行が長くなり顕在化した。2026-09-06）。
        self._act_list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._act_list.setTextElideMode(Qt.ElideRight)
        # 並べ替えは Qt の標準機能に寄せる（自前の D&D を書かない）
        self._act_list.setDragDropMode(QAbstractItemView.InternalMove)
        self._act_list.setDefaultDropAction(Qt.MoveAction)
        self._act_list.setSelectionMode(QAbstractItemView.SingleSelection)
        self._act_list.setContextMenuPolicy(Qt.CustomContextMenu)
        self._act_list.customContextMenuRequested.connect(self._on_list_context)
        self._act_list.itemSelectionChanged.connect(self._on_list_selection)
        self._act_list.model().rowsMoved.connect(self._on_rows_moved)
        self._install_action_shortcuts(self._act_list)
        v.addWidget(self._act_list)      # 固定高さ（`_fit_list_height`）なので伸びない
        self._fill_action_list(task)

        # **一覧に対する操作は一覧の下**（2026-09-06 要望）。一覧にぶら下がって
        # 見えるので「上は選ぶ場所」だと分かり、下の余白で「ここから先は編集」に
        # 切り替わる。D&D・右クリックは残したまま、3 つ目の手段として置く
        # （別窓に移したことで右クリックより**ボタンの方が直感的**。2026-09-05 指摘）。
        ops = QHBoxLayout()
        ops.setContentsMargins(0, 0, 0, 0)
        ops.addStretch(1)
        self._btn_up = QPushButton("▲")
        self._btn_up.setObjectName("arrowButton")
        self._btn_up.setFixedWidth(42)
        self._btn_up.clicked.connect(lambda: self._move_action(-1))
        ops.addWidget(self._btn_up)
        self._btn_down = QPushButton("▼")
        self._btn_down.setObjectName("arrowButton")
        self._btn_down.setFixedWidth(42)
        self._btn_down.clicked.connect(lambda: self._move_action(1))
        ops.addWidget(self._btn_down)
        self._btn_delete = QPushButton("削除")
        self._btn_delete.setObjectName("browseButton")
        self._btn_delete.clicked.connect(self._delete_current_action)
        ops.addWidget(self._btn_delete)
        add = QPushButton("＋動作")
        add.setObjectName("browseButton")
        add.clicked.connect(lambda: self._host.add_action(task_id))
        ops.addWidget(add)
        v.addLayout(ops)

        # **一覧（選ぶ）とフォーム（編集する）の間に余白を空ける**（2026-09-06 要望）。
        # 詰まっていると同じ文脈に見えて「どれを触ればいいのか」が分からなくなる。
        # 見出しで対応関係（上で選んだものの中身がここ）も明示する。
        v.addSpacing(_FORM_GAP)
        self._form_head = QLabel("選択中の動作")
        self._form_head.setObjectName("formHead")
        v.addWidget(self._form_head)

        holder = uikit.transparent(QWidget())
        self._form_host = QVBoxLayout(holder)
        self._form_host.setContentsMargins(0, 0, 0, 0)
        self._form_host.setSpacing(8)
        v.addWidget(holder)
        # 窓を縦に広げても**動作一覧だけが伸びる**（タスク名・説明を巻き込まない。
        # 2026-09-05 実機の指摘）。フォームの下に余白として落ちる。
        v.addStretch(1)
        return w

    def _fill_action_list(self, task) -> None:
        names = self._host.template_names()
        secrets = self._host.secret_names()
        self._syncing = True
        self._act_list.clear()
        for a in task.actions:
            item = QListWidgetItem()
            item.setData(Qt.UserRole, a.id)
            item.setData(_SUMMARY_ROLE, actionmeta.summary(a, names, secrets))
            item.setIcon(_kind_icon(actionmeta.icon_name(a)))
            self._act_list.addItem(item)
        self._order = [a.id for a in task.actions]
        self._renumber()
        self._syncing = False
        self._fit_list_height()

    def _renumber(self) -> None:
        """行の頭に通し番号を振る（**入力欄ではなく一覧**だと見て分かるように）。

        2026-09-06 要望。番号・種類アイコン・地色の 3 つで「ここは選ぶ場所」を示す
        （枠の形だけで区別させない ── 入力欄と同じ角丸の箱に見えていた）。
        並べ替え・削除のあとにも呼ぶ。
        """
        if self._act_list is None:
            return
        for i in range(self._act_list.count()):
            item = self._act_list.item(i)
            item.setText("%d.  %s" % (i + 1, item.data(_SUMMARY_ROLE) or ""))

    def _repaint_action_icons(self) -> None:
        """テーマ切替のとき（アイコンは色を焼き込んであるので取り直す）。"""
        if self._act_list is None or self._task_id is None:
            return
        task = hierarchy.find_task(self._host.app_data, self._task_id)
        if task is None:
            return
        by_id = {a.id: a for a in task.actions}
        for i in range(self._act_list.count()):
            item = self._act_list.item(i)
            act = by_id.get(item.data(Qt.UserRole))
            if act is not None:
                item.setIcon(_kind_icon(actionmeta.icon_name(act)))

    def _fit_list_height(self) -> None:
        """中身のぶんだけ高さを取る（空き地を作らない。ただし伸びすぎない）。

        登録した動作一覧を一目で見せたい（2026-09-05 要望）ので、上限は
        かなり広めに取る（窓自体は OS のリサイズに任せられる＝溢れても手で直せる）。

        行ごとの高さは QSS のパディング分だけ見積もりとずれることがあり、
        ほんの数 px でも余ると「スクロールバーが 1 ノッチだけ出て先頭行が隠れる」
        （`QAbstractItemView` の既定はアイテム単位スクロール）。**自分の見積もりを
        信用せず、Qt 自身のスクロール量がゼロになるまで実測して足す**（2026-09-05
        実機で発覚。上限に達したら諦めて内部スクロールに任せる）。
        """
        n = self._act_list.count()
        if n == 0:
            self._act_list.setFixedHeight(46)
            return
        total = sum(max(self._act_list.sizeHintForRow(i), 20) for i in range(n))
        height = min(480, total + 2 * self._act_list.frameWidth() + _LIST_V_PAD * 2 + 8)
        self._act_list.setFixedHeight(height)
        bar = self._act_list.verticalScrollBar()
        guard = 0
        while bar.maximum() > 0 and height < 480 and guard < 20:
            height = min(480, height + bar.maximum())
            self._act_list.setFixedHeight(height)
            guard += 1
        bar.setValue(0)

    @property
    def card_kind(self) -> str | None:
        """いま出ているカードの種類（`"work"` / `"task"` / `None`）。"""
        return self._key[0] if self._key else None

    def refresh_group_color(self) -> None:
        """「グループの分け方」が変わったとき（グループ色の欄の出し入れ）。

        **業務のカードのときだけ作り直す** ── タスクのカードを作り直すと
        入力中の動作フォームが消える。
        """
        if self._key is not None and self._key[0] == "work":
            self._rebuild(self._key)

    def sync_name(self, entity_id: str, text: str) -> None:
        """メイン画面でその場で改名されたとき、開いている名前欄も合わせる。

        名前は**両方から変えられる**（2026-09-06 ユーザー判断）ので、片方で
        変えたらもう片方も追随させる。`textChanged` が跳ね返って改名し直しに
        行かないよう、シグナルを止めて入れる。
        """
        if (self.name_edit is None or self._key is None
                or self._key[1] != entity_id or self.name_edit.text() == text):
            return
        self.name_edit.blockSignals(True)
        self.name_edit.setText(text)
        self.name_edit.blockSignals(False)

    def refresh_action_labels(self) -> None:
        """要約だけ差し替える（並びも選択も触らない＝入力中のフォームを壊さない）。"""
        if self._act_list is None or self._task_id is None:
            return
        task = hierarchy.find_task(self._host.app_data, self._task_id)
        if task is None:
            return
        names = self._host.template_names()
        secrets = self._host.secret_names()
        by_id = {a.id: a for a in task.actions}
        for i in range(self._act_list.count()):
            item = self._act_list.item(i)
            act = by_id.get(item.data(Qt.UserRole))
            if act is not None:
                item.setData(_SUMMARY_ROLE, actionmeta.summary(act, names, secrets))
                item.setIcon(_kind_icon(actionmeta.icon_name(act)))
        self._renumber()

    # --- 動作フォームの出し入れ -------------------------------------- #
    def _show_action(self, action_id: str | None) -> None:
        """一覧の選択とフォームを `action_id` に合わせる。"""
        self._syncing = True
        target = -1
        for i in range(self._act_list.count()):
            if self._act_list.item(i).data(Qt.UserRole) == action_id:
                target = i
                break
        if target < 0:
            self._act_list.clearSelection()
            self._act_list.setCurrentRow(-1)
        else:
            self._act_list.setCurrentRow(target)
        self._syncing = False

        # `self._form_action_id` を先に確定してからボタン状態を計算する ── 逆順だと
        # 常に「ひとつ前の選択」で有効/無効を判定してしまい、上下ボタンが効かなく
        # 見える（2026-09-05 実機で発覚）。
        reuse_form = action_id == self._form_action_id and self._form is not None
        self._form_action_id = action_id
        self._update_action_buttons()
        if self._form_head is not None:
            self._form_head.setVisible(action_id is not None)
        if reuse_form:
            return
        self._clear_form()
        if action_id is None:
            return
        action = hierarchy.find_action(self._host.app_data, action_id)
        if action is None:
            return
        self._form = ActionForm(self._host, action)
        self._form.kindChanged.connect(self._on_form_kind_changed)
        self._form_host.addWidget(self._form)
        self._restyle()

    def _on_form_kind_changed(self) -> None:
        """種類コンボを変えた直後。**確定（コミット）前**なので、まだ引数は
        埋まっていないことがある（例: URL 欄が空）。一覧の表示は選び直した種類の
        名前にだけ差し替えて「変わった」と分かるようにする（2026-09-05 実機の指摘。
        以前は選択を動かすまで一覧が古いまま＝種類を変えた効果が見えなかった）。
        本当の要約（値込み）は確定時に `refresh_action_labels` が入れる。
        """
        self._restyle()
        if self._form is None or self._form_action_id is None:
            return
        for i in range(self._act_list.count()):
            item = self._act_list.item(i)
            if item.data(Qt.UserRole) == self._form_action_id:
                kind = actionmeta.kind_of(self._form.kind())
                item.setData(_SUMMARY_ROLE, kind.label)
                item.setIcon(_kind_icon(kind.icon))
                self._renumber()
                break

    def _clear_form(self) -> None:
        while self._form_host is not None and self._form_host.count():
            item = self._form_host.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()
        self._form = None

    # --- 一覧の操作 --------------------------------------------------- #
    def _on_list_selection(self) -> None:
        if self._syncing:
            return
        item = self._act_list.currentItem()
        aid = item.data(Qt.UserRole) if item is not None else None
        if aid is None or aid == self._form_action_id:
            return
        if not self._host.select_entity("action", aid):
            # 入力漏れで移動できなかった → 一覧の選択も元へ戻す
            self._show_action(self._form_action_id)

    def _on_list_context(self, pos) -> None:
        item = self._act_list.itemAt(pos)
        aid = item.data(Qt.UserRole) if item is not None else None
        if aid is None:
            return
        g = self._act_list.viewport().mapToGlobal(pos)
        self._host.show_context_menu("action", aid, g.x(), g.y())

    def _on_rows_moved(self, _parent, start, _end, _dest, _row) -> None:
        """`InternalMove` で並びが変わった → モデルへ反映する。

        動いた行は **`rowsMoved` の `start`（移動前の行番号）**から引く。
        「新旧を突き合わせて最初に食い違う位置」では駄目 ── 先頭を末尾へ動かすと
        1 つ後ろの要素が動いたように見えるため。
        """
        if self._syncing or self._task_id is None:
            return
        if not (0 <= start < len(self._order)):
            return
        moved = self._order[start]
        new_order = [self._act_list.item(i).data(Qt.UserRole)
                     for i in range(self._act_list.count())]
        if moved not in new_order:
            return
        i = new_order.index(moved)
        before = new_order[i + 1] if i + 1 < len(new_order) else None
        self._order = new_order
        self._renumber()
        self._host.reorder_action(self._task_id, moved, before)
        self._update_action_buttons()

    def _update_action_buttons(self) -> None:
        """上下・削除ボタンの有効/無効を選択に合わせる。"""
        if self._btn_delete is None:
            return
        aid = self._form_action_id
        idx = self._order.index(aid) if aid is not None and aid in self._order else -1
        self._btn_delete.setEnabled(idx >= 0)
        self._btn_up.setEnabled(idx > 0)
        self._btn_down.setEnabled(0 <= idx < len(self._order) - 1)

    def _move_action(self, direction: int) -> None:
        """選択中の動作をボタンで 1 つ上/下へ（D&D・右クリックと並ぶ 3 つ目の手段）。"""
        aid = self._form_action_id
        if self._task_id is None or aid is None or aid not in self._order:
            return
        idx = self._order.index(aid)
        new_idx = idx + direction
        if not (0 <= new_idx < len(self._order)):
            return
        before_id = (self._order[new_idx] if direction < 0
                     else (self._order[new_idx + 1] if new_idx + 1 < len(self._order) else None))
        self._host.reorder_action(self._task_id, aid, before_id)
        task = hierarchy.find_task(self._host.app_data, self._task_id)
        if task is not None:
            self._fill_action_list(task)
            self._show_action(aid)

    def _delete_current_action(self) -> None:
        aid = self._form_action_id
        if aid is not None:
            self._host.delete_entity("action", aid)

    # --- 動作へのコピー / 貼り付け / 削除（一覧にフォーカスがあるときだけ効く） --- #
    def _install_action_shortcuts(self, list_widget: QListWidget) -> None:
        """`Ctrl+C` / `Ctrl+V` / `Delete` を**一覧そのものにフォーカスがあるときだけ**
        効かせる。窓全体に付けると「タスク名」欄で文字を消すつもりの Delete まで
        奪ってしまうため（2026-09-05 実機の判断）。"""
        from PySide6.QtGui import QKeySequence, QShortcut

        for seq, fn in ((QKeySequence.Delete, self._delete_current_action),
                        (QKeySequence.Copy, self._copy_current_action),
                        (QKeySequence.Paste, self._paste_into_current_task)):
            sc = QShortcut(seq, list_widget)
            sc.setContext(Qt.WidgetWithChildrenShortcut)
            sc.activated.connect(fn)

    def _copy_current_action(self) -> None:
        aid = self._form_action_id
        if aid is not None:
            self._host.copy_entity("action", aid)

    def _paste_into_current_task(self) -> None:
        """コピーした動作は**他のタスク・他の業務のタスクにも**貼り付けられる
        （バッファはタスクをまたいで持ち回る）。選択中の動作の直後、無ければ先頭へ。"""
        if self._task_id is None or not self._host.core.can_paste("action"):
            return
        aid = self._form_action_id
        if aid is not None:
            self._host.paste_entity("action", aid)
        else:
            self._host.paste_action_head(self._task_id)

    # ================================================================ #
    # 未適用の編集を確定する（移動時の自動保存）
    # ================================================================ #
    def commit_pending_edits(self, *, quiet: bool = False) -> bool:
        """動作フォームの入力を確定する。**入力漏れなら False**（＝移動させない）。

        「適用」ボタンを置かない代わりに、選択が動く直前・窓を閉じる直前に呼ばれる。
        未変更（`dirty` でない）なら `collect()` すら呼ばない ── 暗号化コピーの
        再暗号化を無駄に走らせないため。
        """
        self._commit_error = None
        form, aid = self._form, self._form_action_id
        if form is None or aid is None or not form.dirty:
            return True
        try:
            res = form.collect()
        except ValueError as e:
            self._commit_error = str(e)
            if not quiet:
                self._host.warn("入力エラー", str(e))
            return False
        form.dirty = False
        self._host.apply_action_edit(aid, res)
        self.refresh_action_labels()
        return True

    # ================================================================ #
    # 補助
    # ================================================================ #
    def _group_index(self, work_id: str) -> int:
        got = hierarchy.work_group_of_work(self._host.app_data, work_id)
        return got[0] if got else 0

    def _on_hue(self, index: int, hue: int) -> None:
        self.swatch.set_hue(hue)
        self._host.set_group_hue(index, hue)

    def _style_hue_slider(self) -> None:
        """**「メーター」を出さない。**

        色相は 0〜360 度の**円環上の位置**であって量ではないので、左からの
        塗り（`sub-page`）に意味が無い。qt-material の既定はここをアクセントで
        塗るため「左端に寄せても少し残る／右端でも埋まりきらない」という
        見え方になっていた（2026-09-06 ユーザー指摘）。溝は細い無彩色のレール
        だけにして、`sub-page` / `add-page` を明示的に透明へ落とす
        （**書かないと qt-material の既定が勝つ**）。色の手掛かりは真上の
        `_HueBar` が持つ。
        """
        if self._hue_slider is None:
            return
        self._hue_slider.setStyleSheet(
            # ウィジェット本体の地色も消す（溝を細くしたら qt-material の既定
            # `#31363b` が溝の上下に帯として出た。2026-09-06 実測）
            "QSlider{background:transparent;}"
            "QSlider::groove:horizontal{height:4px;border-radius:2px;background:%s;}"
            "QSlider::sub-page:horizontal{background:transparent;}"
            "QSlider::add-page:horizontal{background:transparent;}"
            "QSlider::handle:horizontal{width:%dpx;height:14px;margin:-6px 0;"
            "border-radius:7px;background:%s;border:2px solid %s;}"
            % (_pal("divider"), HANDLE_W, _pal("bg"), _pal("ink")))

    def apply_theme(self) -> None:
        """テーマが変わったら**塗り直すだけ**（作り直さない＝入力中の欄を残す）。

        QSS で塗っているものは `_restyle()` で一括、色を焼き込んである小物
        （グループ色の見本・色相の濃淡バー・区切り線）は個別に塗り直す。
        """
        set_titlebar_dark_mode(self, qtheme.is_dark())
        self._restyle()
        self._repaint_action_icons()      # アイコンは色を焼き込んである
        if self._swatch is not None and self._hue_slider is not None:
            self._swatch.set_hue(self._hue_slider.value())
            self._style_hue_slider()
        if self._hue_bar is not None:
            self._hue_bar.restyle()
        for line in self._dividers:
            _paint_divider(line)

    def _restyle(self) -> None:
        """**自分のトークンで塗る**（qt-material の既定は 18/26 テーマで AA 未満）。
        この QSS は子ウィジェット（`ActionForm`）にも当たる。"""
        warn_face = _pal("row_fail")
        # 文字サイズ（2026-09-05 一時調整機能で確認して確定）:
        #   項目名（"タスク名"/"説明"/"種類"/"パス" 等）＝ 13px
        #   テキストボックス・ボタン内の文字 ＝ 15px
        #   "タスク"/"動作" の見出し ＝ 16px（太字）
        css = (
            "QDialog{background:%(bg)s;}"
            "QLabel{color:%(ink)s;background:transparent;border:none;font-size:15px;}"
            "#rowLabel{font-size:13px;}"
            "#formNote,#editLead{color:%(sub)s;}"
            "#sectionHead{color:%(ink)s;font-weight:700;font-size:16px;}"
            "#formWarn{color:%(warn_ink)s;background:%(warn)s;border:none;"
            "border-radius:4px;padding:6px 8px;}"
            "QLineEdit,QPlainTextEdit{background:%(face)s;color:%(ink)s;font-size:15px;"
            "border:1px solid %(border)s;border-radius:5px;padding:5px 8px;}"
            "QLineEdit:focus,QPlainTextEdit:focus{border:1px solid %(accent)s;}"
            "QComboBox{background:%(face)s;color:%(ink)s;font-size:15px;"
            "border:1px solid %(border)s;border-radius:5px;padding:4px 8px;}"
            "QComboBox:focus{border:1px solid %(accent)s;}"
            # コンボのポップアップ・一覧の選択は `uikit.selection_qss()` が持つ
            # （`color` だけでは Windows で効かない ── 2026-09-06）
            "QCheckBox{color:%(ink)s;background:transparent;spacing:6px;font-size:15px;}"
            "QCheckBox::indicator{width:14px;height:14px;border-radius:3px;"
            "border:1px solid %(border)s;background:%(face)s;}"
            "QCheckBox::indicator:checked{background:%(accent)s;border:1px solid %(accent)s;}"
            "QPushButton{background:%(face)s;color:%(ink)s;font-size:15px;"
            "border:1px solid %(border)s;border-radius:5px;padding:4px 12px;}"
            "QPushButton:hover{background:%(hover)s;}"
            "QPushButton:disabled{color:%(faint)s;background:%(bg)s;}"
            "#arrowButton{padding:4px 2px;font-size:14px;}"
            "#formHead{color:%(sub)s;font-size:13px;}"
            # 動作一覧は**入力欄と作り分ける**（2026-09-06 要望）。同じ面・同じ枠・
            # 同じ角丸だったので「テキストボックス」に見えていた。入力欄＝地から
            # 浮いた面（card_face）／一覧＝地のまま囲うだけ、と役割で分ける。
            "#actionList{background:%(bg)s;color:%(ink)s;font-size:15px;"
            "border:1px solid %(divider)s;border-radius:5px;padding:%(list_pad)dpx 0;}"
            "#actionList::item{padding:5px 8px;border:none;}"
            "#actionList::item:hover{background:%(hover)s;}"
            "#actionList::item:selected{background:%(accent)s;color:%(on_accent)s;"
            "selection-color:%(on_accent)s;}"
            "QSlider{background:transparent;}"
            "QSlider::groove:horizontal{background:%(divider)s;height:4px;border-radius:2px;}"
            "QSlider::handle:horizontal{background:%(accent)s;width:14px;height:14px;"
            "margin:-5px 0;border-radius:7px;}"
            % {"bg": _pal("bg"), "ink": _pal("ink"), "sub": _pal("sub"),
               "face": _pal("card_face"), "border": _pal("input_border"),
               "accent": _pal("accent"), "on_accent": _pal("on_accent"),
               "hover": _pal("row_hover"), "divider": _pal("divider"),
               "faint": _pal("faint"), "list_pad": _LIST_V_PAD,
               "warn": warn_face, "warn_ink": T.tinted_ink(warn_face)}
        )
        self.setStyleSheet(css + uikit.selection_qss())
        uikit.style_combo_popups(self)
        uikit.fit_label_column(self)        # 見出し列を実幅へ（左に帯を残さない）

    # --- 位置の永続化 / 閉じたら通常モードへ -------------------------- #
    def showEvent(self, e) -> None:   # noqa: N802
        super().showEvent(e)
        # OS が描くタイトルバー・枠をテーマに合わせる（枠なし窓ではないため）。
        # **`super().showEvent()` の後**（`round_corners` と同じ順序。ネイティブの
        # ウィンドウハンドルが実体化する前に `winId()` を読むと効かない）。
        set_titlebar_dark_mode(self, qtheme.is_dark())
        geo = (self._host.app_data.settings.get("window", {}) or {}).get("edit")
        if geo and len(geo) == 2:
            self.move(int(geo[0]), int(geo[1]))

    def closeEvent(self, e) -> None:   # noqa: N802
        # 閉じる操作は止めない。ただし**黙っては捨てない**（2026-09-06 実機の指摘）
        # ── 暗号化の「入力」と「確認」が食い違ったまま閉じると、登録されていない
        # のに何も出ず、登録できたつもりになってしまう。閉じるのは止めずに知らせる。
        if not self.commit_pending_edits(quiet=True) and self._host.alive:
            self._host.warn(
                "保存していない入力があります",
                "%s\n\nこの動作の変更は保存していません。" % (self._commit_error or ""))
        win = self._host.app_data.settings.setdefault("window", {})
        win["edit"] = [self.x(), self.y()]
        self._host.save()
        # **閉じたら通常モードへ戻す**（スイッチと窓は同じ状態のふたつの見え方）
        if self._host.mode == "settings":
            self._host.set_edit_mode(False)
        super().closeEvent(e)


def _paint_divider(w: QWidget) -> None:
    w.setStyleSheet("#editDivider{background:%s;border:none;}" % _pal("divider"))


def _hline() -> QWidget:
    """区切り線。`QFrame` を使わない（qt-material が border を当てる。既知の癖）。"""
    w = QWidget()
    w.setObjectName("editDivider")
    w.setFixedHeight(1)
    _paint_divider(w)
    return w
