"""設定パネル（画面を要さない設定）。Tk 版 `view/commonsettings.py` の置き換え（Phase 4e）。

セクション:

1. **書式付きコピー（テンプレート）** … クリップボードの書式付きデータを「登録」/ 改名 / 削除。
   これが 1 つも無いと**動作フォームの「書式」を選べない**（Qt 版で唯一残っていた機能の穴）。
2. **暗号化した文字列** … 登録済みの暗号文の一覧（2026-09-08）。名前を付ける / 値を
   上書きする / 消す。**中身は表示しない**（上書きだけ）。動作フォームから作った
   暗号文もここに並ぶ（名前が無いものは「（名称未設定）」）。
3. **Slackメンション宛先** … 名前＋メンション文字列。`settings["mention_directory"]` に保存。
4. **ワンタイム待機 (ms)** … 直接入力＝自動反映（デバウンスして保存）。
5. **パスフレーズ** … 未設定なら「設定」、設定済みなら「変更」（現在のパスフレーズ必須＋再暗号化）。

**テーマ・書体・密度はここではなくデザインラボ**（画面の見た目はあちらに集約）。

**単独の窓ではない**（2026-09-06 にデザインラボと統合）。`AppearanceHub` の 1 タブ
として `QWidget` で作り、窓としての振る舞い（タイトル・位置の永続化・
タイトルバーのダークモード）は `appearancehub.py` が持つ。開いていても
**タスクは実行できる**（実行を止めるのは設定モード＝編集ウィンドウだけ。2026-09-05 の設計）。

保存の考え方（Tk 版と同じ）:
- パネルへ直接入力する項目（待機ms）は**入力した時点で反映**。無効な中間入力は黙って無視し、
  確定時に直近の有効値へ戻す。
- 別ダイアログでの登録が要る項目（テンプレート／メンション／パスフレーズ）は**その処理で確定**。

**操作要素は qt-material の既定スタイルに任せない**（2026-09-05 の恒久ルール）。
配色の土台は `uikit.panel_qss()`。
"""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QAbstractItemView, QHBoxLayout, QLabel, QLineEdit, QListWidget,
    QListWidgetItem, QPushButton, QVBoxLayout, QWidget,
)

from ..model import SECRET_CLEAR_MAX, SECRET_CLEAR_MIN, new_id
from . import passdialog, uikit
from .uikit import pal as _pal

LIST_HEIGHT = 116


def _hline() -> QWidget:
    """区切り線。`QFrame` を使わない（qt-material が border を当てる。既知の癖）。"""
    w = QWidget()
    w.setObjectName("panelDivider")
    w.setFixedHeight(1)
    w.setStyleSheet("#panelDivider{background:%s;border:none;}" % _pal("divider"))
    return w


class SettingsPanel(QWidget):
    """設定パネル。`AppearanceHub` の 1 タブ（開いていてもタスクは実行できる）。"""

    def __init__(self, host, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._host = host
        self.setMinimumWidth(430)
        # 素の QWidget のまま置くと qt-material の既定の地色が透けるので、
        # 自分の ID で明示的に透明にする（`_restyle()` が上書きするので、そちらにも
        # 同じ規則を含める＝`uikit.transparent` は使わずここで固定名にする）。
        self.setObjectName("settingsPanel")

        self._dividers: list[QWidget] = []
        v = QVBoxLayout(self)
        v.setContentsMargins(18, 16, 18, 16)
        # 見出しと注記は `_section` の中で密に組むので、ここは「セクションの中の
        # 部品どうし」の間隔（2026-09-06 整理）。
        v.setSpacing(8)
        self._v = v

        self._build_templates()
        self._build_secrets()
        self._build_mentions()
        self._build_wait_ms()
        self._build_secret_clear()
        self._build_passphrase()
        v.addStretch(1)
        self._restyle()

    # ================================================================ #
    # 共通パーツ
    # ================================================================ #
    def _section(self, text: str, note: str = "", *, first: bool = False) -> None:
        """見出し（＋説明文）を 1 つの塊として置く。

        見出しと説明文は**同じことを指している**ので密に、そのあとの操作要素との
        間はレイアウトの `spacing` ぶん空ける（2026-09-06 整理。以前は全部が
        同じ間隔で並び、どこからどこまでが 1 セクションか読み取りにくかった）。
        """
        if not first:
            # 区切り線の余白は広めに（2026-09-05 要望。編集ウィンドウのタスク/動作の
            # 区切りと揃える）。
            line = _hline()
            self._dividers.append(line)
            self._v.addSpacing(14)
            self._v.addWidget(line)
            self._v.addSpacing(14)
        box = uikit.transparent(QWidget())
        bv = QVBoxLayout(box)
        bv.setContentsMargins(0, 0, 0, 0)
        bv.setSpacing(3)
        head = QLabel(text)
        head.setObjectName("panelHead")
        bv.addWidget(head)
        if note:
            lbl = QLabel(note)
            lbl.setObjectName("panelNote")
            lbl.setWordWrap(True)
            bv.addWidget(lbl)
        self._v.addWidget(box)

    def _list_with_buttons(self, buttons) -> QListWidget:
        lst = QListWidget()
        lst.setObjectName("panelList")
        lst.setSelectionMode(QAbstractItemView.SingleSelection)
        lst.setFixedHeight(LIST_HEIGHT)
        self._v.addWidget(lst)
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        for label, fn in buttons:
            b = QPushButton(label)
            # 幅の下限を QSS で与えて「2 文字のボタン」と「5 文字のボタン」が
            # ばらばらの大きさに見えないようにする（2026-09-06 整理）。
            b.setObjectName("panelRowButton")
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _c=False, f=fn: f())
            h.addWidget(b)
        h.addStretch(1)
        self._v.addLayout(h)
        return lst

    @staticmethod
    def _selected(lst: QListWidget) -> int | None:
        i = lst.currentRow()
        return i if i >= 0 else None

    # --- 窓を出す口（テストが差し替えられるよう分けてある） ---------- #
    def ask_fields(self, title: str, fields):
        return uikit.ask_fields(self, title, fields)

    def ask_text(self, title: str, label: str, initial: str = "") -> str | None:
        return uikit.ask_text(self, title, label, initial)

    def ask_new_passphrase(self) -> str | None:
        return passdialog.ask_new_passphrase(self)

    def ask_change_passphrase(self):
        return passdialog.ask_change_passphrase(self)

    # ================================================================ #
    # 1. 書式付きコピー（テンプレート）
    # ================================================================ #
    def _build_templates(self) -> None:
        self._section("書式付きコピー（テンプレート）",
                      "書式付きの文字列をコピーした状態で「登録」を押してください。"
                      "登録したテンプレートは動作の「書式」から選べます。", first=True)
        self._tmpl_ids: list[str] = []
        self.tmpl_list = self._list_with_buttons((
            ("登録", self._tmpl_add),
            ("名前を変更", self._tmpl_rename),
            ("削除", self._tmpl_delete),
        ))
        self.reload_templates()

    def reload_templates(self) -> None:
        self.tmpl_list.clear()
        self._tmpl_ids = []
        names = self._host.template_names()
        for tid, name in sorted(names.items(), key=lambda kv: kv[1]):
            self.tmpl_list.addItem(QListWidgetItem(name))
            self._tmpl_ids.append(tid)

    def _tmpl_add(self) -> None:
        name = self.ask_text("テンプレート登録", "テンプレート名:")
        if not name:
            return
        try:
            self._host.templates.add_from_clipboard(name)
        except ValueError as e:
            self._host.warn("テンプレート登録", str(e))
            return
        self.reload_templates()

    def _tmpl_rename(self) -> None:
        i = self._selected(self.tmpl_list)
        if i is None:
            return
        name = self.ask_text("名前を変更", "新しい名前:", self.tmpl_list.item(i).text())
        if not name:
            return
        self._host.templates.rename(self._tmpl_ids[i], name)
        self.reload_templates()
        self._host.refresh_action_summaries()

    def _tmpl_delete(self) -> None:
        i = self._selected(self.tmpl_list)
        if i is None:
            return
        if not self._host.confirm("削除の確認", "選択したテンプレートを削除しますか？"):
            return
        self._host.templates.delete(self._tmpl_ids[i])
        self.reload_templates()
        self._host.refresh_action_summaries()

    # ================================================================ #
    # 2. 暗号化した文字列（パスワード など）
    # ================================================================ #
    def _build_secrets(self) -> None:
        """登録済みの暗号文の一覧（2026-09-08 要望）。

        **中身は表示しない** ── 見る手段を作らないのが一番安全で、上書きできれば
        用は足りる（動作フォームも既存値は出さず「空なら維持」にしてある）。
        名前は暗号化していないので、解錠していなくても一覧は出せる。
        """
        self._section("暗号化した文字列",
                      "暗号化コピーで使う文字列の一覧です。中身は表示できません"
                      "（上書きのみ）。動作の「暗号化」で作ったものもここに並びます。")
        self._secret_ids: list[str] = []
        self.secret_list = self._list_with_buttons((
            ("登録", self._secret_add),
            ("名前を変更", self._secret_rename),
            ("値を更新", self._secret_update),
            ("削除", self._secret_delete),
        ))
        self.reload_secrets()

    def _secret_label(self, sid: str, name: str, uses: dict[str, int]) -> str:
        """一覧の 1 行。**使われている数を添える** ── 消したときに何が壊れるかが
        見えないまま削除させないため（2026-09-08 の懸念点）。"""
        n = uses.get(sid, 0)
        return "%s（%s）" % (name or "（名称未設定）",
                            "%d 件の動作で使用" % n if n else "未使用")

    def reload_secrets(self) -> None:
        """一覧を作り直す。**選んでいた行は選び直す**。

        使用件数は階層を数えて出すので、動作を編集したあとにも呼ばれる
        （2026-09-09）── そのたびに選択が飛ぶと使いにくい。
        """
        i = self._selected(self.secret_list)
        keep = self._secret_ids[i] if i is not None and i < len(self._secret_ids) else None
        self.secret_list.clear()
        self._secret_ids = []
        names = self._host.crypto.secret_names()
        uses = self._host.secret_uses()
        for sid, name in sorted(names.items(), key=lambda kv: (not kv[1], kv[1])):
            self.secret_list.addItem(QListWidgetItem(self._secret_label(sid, name, uses)))
            self._secret_ids.append(sid)
        if keep in self._secret_ids:
            self.secret_list.setCurrentRow(self._secret_ids.index(keep))

    def _secret_add(self) -> None:
        """登録は `MainWindow.register_secret()` に委ねる ── 動作フォームの
        「新規登録…」と**同じ道**を通す（2026-09-09）。"""
        if self._host.register_secret():
            self.reload_secrets()

    def _secret_rename(self) -> None:
        i = self._selected(self.secret_list)
        if i is None:
            return
        sid = self._secret_ids[i]
        cur = self._host.crypto.secret_names().get(sid, "")
        name = self.ask_text("名前を変更", "新しい名前:", cur)
        if not name:
            return
        try:
            self._host.crypto.rename_secret(sid, name)
        except Exception as e:  # noqa: BLE001
            self._host.warn("暗号化した文字列", "名前を変更できませんでした:\n%s" % e)
            return
        self.reload_secrets()

    def _secret_update(self) -> None:
        """値を上書きする ── **これが一元化の意味**（パスワードが変わったら
        ここだけ直す）。使っている動作は `secret_id` を持ったままなので触らない。"""
        i = self._selected(self.secret_list)
        if i is None:
            return
        sid = self._secret_ids[i]
        value = self._host.ask_secret_value("値を更新")
        if value is None:
            return
        if not self._host.ensure_crypto_ready():
            return
        try:
            self._host.crypto.encrypt(sid, value)
        except Exception as e:  # noqa: BLE001
            self._host.warn("暗号化した文字列", "更新できませんでした:\n%s" % e)
            return
        self.reload_secrets()

    def _secret_delete(self) -> None:
        i = self._selected(self.secret_list)
        if i is None:
            return
        sid = self._secret_ids[i]
        n = self._host.secret_uses().get(sid, 0)
        note = ("この文字列を使っている動作が %d 件あります。"
                "消すとその動作は実行できなくなります。" % n) if n else ""
        if not self._host.confirm("削除の確認",
                                  "選択した文字列を削除しますか？" + ("\n" + note if note else "")):
            return
        try:
            self._host.crypto.remove_secret(sid)
        except Exception as e:  # noqa: BLE001
            self._host.warn("暗号化した文字列", "削除できませんでした:\n%s" % e)
            return
        self.reload_secrets()

    # ================================================================ #
    # 3. Slackメンション宛先
    # ================================================================ #
    def _build_mentions(self) -> None:
        self._section("Slackメンション宛先",
                      "コピー動作の「Slackメンション」を ON にすると、"
                      "実行時にここの一覧から宛先を選びます。")
        self.mention_list = self._list_with_buttons((
            ("追加", self._mention_add),
            ("編集", self._mention_edit),
            ("削除", self._mention_delete),
        ))
        self.reload_mentions()

    def _mentions(self) -> list[dict]:
        return self._host.app_data.settings.setdefault("mention_directory", [])

    def reload_mentions(self) -> None:
        self.mention_list.clear()
        for e in self._mentions():
            name = str(e.get("name", "")) or str(e.get("mention", ""))
            self.mention_list.addItem(
                QListWidgetItem("%s   %s" % (name, e.get("mention", ""))))

    def _ask_mention(self, title: str, cur: dict | None = None):
        cur = cur or {}
        res = self.ask_fields(title, [
            ("name", "名前:", cur.get("name", "")),
            ("mention", "メンション文字列（@xxx）:", cur.get("mention", "")),
        ])
        if not res:
            return None
        name, mention = res["name"].strip(), res["mention"].strip()
        if not name or not mention:
            self._host.warn("メンション宛先",
                            "名前とメンション文字列の両方を入力してください。")
            return None
        return name, mention

    def _mention_add(self) -> None:
        got = self._ask_mention("メンション宛先の登録")
        if got is None:
            return
        name, mention = got
        self._mentions().append({"id": new_id(), "name": name, "mention": mention})
        self._host.save()
        self.reload_mentions()

    def _mention_edit(self) -> None:
        i = self._selected(self.mention_list)
        if i is None:
            return
        cur = self._mentions()[i]
        got = self._ask_mention("メンション宛先の編集", cur)
        if got is None:
            return
        cur["name"], cur["mention"] = got
        self._host.save()
        self.reload_mentions()

    def _mention_delete(self) -> None:
        i = self._selected(self.mention_list)
        if i is None:
            return
        if not self._host.confirm("削除の確認", "選択したメンション宛先を削除しますか？"):
            return
        del self._mentions()[i]
        self._host.save()
        self.reload_mentions()

    # ================================================================ #
    # 4. ワンタイム待機 (ms)
    # ================================================================ #
    def _build_wait_ms(self) -> None:
        self._section("ワンタイム待機 (ms)",
                      "ワンタイムで貼り付けた文字列を、クリップボードから"
                      "クリアするまでの時間（ミリ秒）。")
        cur = str(self._host.settings.get("onetime_wait_ms", 300))
        self._wait_last_valid = cur
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        self.wait_edit = QLineEdit(cur)
        self.wait_edit.setFixedWidth(90)
        self.wait_edit.textEdited.connect(self._wait_changed)
        self.wait_edit.editingFinished.connect(self.wait_commit)
        h.addWidget(self.wait_edit)
        h.addStretch(1)
        self._v.addLayout(h)
        self._wait_timer = QTimer(self)
        self._wait_timer.setSingleShot(True)
        self._wait_timer.timeout.connect(self._wait_debounced)

    def _wait_changed(self, _text: str) -> None:
        self._wait_timer.start(400)

    def _wait_debounced(self) -> None:
        v = self.wait_edit.text().strip()
        if v.isdigit():
            self._persist_wait(int(v))

    def wait_commit(self) -> None:
        """確定（フォーカスアウト / Enter）。無効値は直近の有効値へ戻す。"""
        self._wait_timer.stop()
        v = self.wait_edit.text().strip()
        if v.isdigit():
            self._persist_wait(int(v))
        else:
            self.wait_edit.setText(self._wait_last_valid)

    def _persist_wait(self, n: int) -> None:
        self._wait_last_valid = str(n)
        self._host.app_data.settings["onetime_wait_ms"] = n
        self._host.save()

    # ================================================================ #
    # 5. 暗号化コピーの自動クリア (秒)
    # ================================================================ #
    def _build_secret_clear(self) -> None:
        """暗号化した文字列をクリップボードに載せっぱなしにしない（2026-09-06 要望）。

        ワンタイムは「順次貼る」ための道具で、消えるのは副産物にすぎない
        ── 単独の暗号化コピーにも時間差クリアが要る、というユーザー判断。
        """
        self._section("暗号化コピーの自動クリア (秒)",
                      "暗号化した文字列をクリップボードから消すまでの時間"
                      "（%d〜%d 秒）。" % (SECRET_CLEAR_MIN, SECRET_CLEAR_MAX))
        cur = str(self._host.settings.get("secret_clear_seconds", 300))
        self._sc_last_valid = cur
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        self.secret_clear_edit = QLineEdit(cur)
        self.secret_clear_edit.setFixedWidth(90)
        self.secret_clear_edit.textEdited.connect(lambda _t: self._sc_timer.start(400))
        self.secret_clear_edit.editingFinished.connect(self.secret_clear_commit)
        h.addWidget(self.secret_clear_edit)
        h.addStretch(1)
        self._v.addLayout(h)
        self._sc_timer = QTimer(self)
        self._sc_timer.setSingleShot(True)
        self._sc_timer.timeout.connect(self._sc_debounced)

    def _sc_debounced(self) -> None:
        v = self.secret_clear_edit.text().strip()
        if v.isdigit():
            self._persist_secret_clear(int(v))

    def secret_clear_commit(self) -> None:
        """確定（フォーカスアウト / Enter）。無効値は直近の有効値へ戻す。"""
        self._sc_timer.stop()
        v = self.secret_clear_edit.text().strip()
        if v.isdigit():
            self._persist_secret_clear(int(v))
        else:
            self.secret_clear_edit.setText(self._sc_last_valid)

    def _persist_secret_clear(self, n: int) -> None:
        """**範囲は `SECRET_CLEAR_MIN`〜`SECRET_CLEAR_MAX` 秒**
        （上限 2026-09-06 / 下限 2026-09-07 ユーザー指定）。

        長すぎる予約は「消えるつもりで消えていない」時間が延びるだけなので頭を打つ。
        下限が 1 秒なので**「消さない」は選べない**。外れた入力は丸めて欄にも
        書き戻す（黙って捨てない）。
        """
        n = max(SECRET_CLEAR_MIN, min(int(n), SECRET_CLEAR_MAX))
        self._sc_last_valid = str(n)
        if self.secret_clear_edit.text().strip() != str(n):
            self.secret_clear_edit.setText(str(n))
        self._host.app_data.settings["secret_clear_seconds"] = n
        self._host.save()

    # ================================================================ #
    # 6. パスフレーズ
    # ================================================================ #
    def _build_passphrase(self) -> None:
        self._section("パスフレーズ",
                      "暗号化コピーの鍵。パスフレーズ自体は保存されません"
                      "（鍵は Windows の資格情報マネージャーに入ります）。")
        h = QHBoxLayout()
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        self.pp_status = QLabel("")
        # 「未設定」と「設定済み」で文字数が違うので、ボタンの左端が動かないよう
        # 下限幅を与える（2026-09-06 整理）。
        self.pp_status.setMinimumWidth(64)
        self.pp_button = QPushButton("")
        self.pp_button.setObjectName("primaryButton")
        self.pp_button.setCursor(Qt.PointingHandCursor)
        self.pp_button.clicked.connect(self.passphrase_action)
        h.addWidget(self.pp_status)
        h.addWidget(self.pp_button)
        h.addStretch(1)
        self._v.addLayout(h)
        self.refresh_passphrase()

    def refresh_passphrase(self) -> None:
        configured = bool(self._host.crypto.is_configured())
        self.pp_status.setText("設定済み" if configured else "未設定")
        self.pp_button.setText("変更" if configured else "設定")

    def passphrase_action(self) -> None:
        if self._host.crypto.is_configured():
            res = self.ask_change_passphrase()
            if res is None:
                return
            cur, new = res
            if self._host.crypto.change_passphrase(cur, new):
                self._host.inform("パスフレーズ", "変更しました。")
            else:
                self._host.warn("パスフレーズ", "現在のパスフレーズが違います。")
        else:
            pp = self.ask_new_passphrase()
            if not pp:
                return
            try:
                self._host.crypto.setup(pp)
                self._host.inform("パスフレーズ", "設定しました。")
            except Exception as e:  # noqa: BLE001  失敗理由は見せて続行する
                self._host.warn("パスフレーズ", "設定に失敗しました:\n%s" % e)
        self.refresh_passphrase()

    # ================================================================ #
    # 見た目 / 位置の永続化
    # ================================================================ #
    def showEvent(self, e) -> None:   # noqa: N802
        """表示されるたびに**使用件数を数え直す**（2026-09-09 実機の指摘）。

        「N 件の動作で使用」は階層を数えて作る一方、パネルは 1 度だけ組み立てて
        使い回す（`AppearanceHub` のタブ）。作ったあとにタスクへ登録しても
        数字が古いままだった ── タブが出るたびにここで直す。
        """
        super().showEvent(e)
        self.reload_secrets()

    def apply_theme(self) -> None:
        """テーマが変わったら塗り直す（`AppearanceHub` から呼ばれる）。"""
        self._restyle()
        for line in self._dividers:
            line.setStyleSheet("#panelDivider{background:%s;border:none;}"
                               % _pal("divider"))

    def _restyle(self) -> None:
        css = (
            "#settingsPanel{background:transparent;border:none;}"
            + uikit.panel_qss()
            + ("#panelList{background:%(face)s;color:%(ink)s;"
               "border:1px solid %(border)s;border-radius:5px;}"
               "#panelList::item{padding:3px 6px;border:none;}"
               "#panelList::item:selected{background:%(accent)s;color:%(on_accent)s;}"
               % {"face": _pal("card_face"), "ink": _pal("ink"),
                  "border": _pal("input_border"), "accent": _pal("accent"),
                  "on_accent": _pal("on_accent")})
        )
        # 文字サイズ（2026-09-05 一時調整機能で確認して確定）:
        #   項目名（"書式付きコピー（テンプレート）" 等）＝ 16px ／ 説明文 ＝ 13px ／
        #   テキストボックス・ボタン内の文字 ＝ 15px。
        css += ("QLineEdit,QPushButton,#panelList{font-size:15px;}"
                "#panelHead{font-size:16px;}"
                "#panelNote{font-size:13px;}"
                # 一覧の下に並ぶボタンと「設定 / 変更」ボタンの幅を揃える
                "#panelRowButton,#primaryButton{min-width:72px;}")
        self.setStyleSheet(css)
        uikit.style_combo_popups(self)
        uikit.fit_label_column(self)        # 見出し列を実幅へ（左に帯を残さない）
