"""qt-material のテーマ → `theme_tokens.PALETTE` の橋渡し（Phase 3c）。

design-notes「2026-09-04 PySide6 + qt-material への UI 移行」の決めたこと 5:

    qt-material が持つグローバル QSS と `theme.PALETTE` を二重管理すると必ず食い違う。
    **qt-material の active テーマ → PALETTE トークン**の**一方向**にする。

qt-material は `apply_stylesheet()` のたびに `QTMATERIAL_*` 環境変数へ 7 色を出す。
それを入力に、`theme_tokens` の色の理屈（`contrast_step` / `elevated_face` / `tone`）で
残りのトークンを**すべて逆算**する。**ここに hex を直書きしない。**

qt-material の既知の癖（スパイク3・9 で実際に踏んだもの）:
  - `qt_material` は **PySide6 の後に** import する（先だとフォント関連が壊れる）
  - ライト系テーマは `invert_secondary=True` が要る
  - `apply_stylesheet()` は**フォントも上書きする**ので毎回 和文フォントへ戻す

Qt 側のスタイリングでの注意（同じくスパイク9 で踏んだもの。ウィジェットを書くとき）:
  - `QFrame` には border が当たる → 細い矩形は `QWidget` で作る
  - ウィジェット側 QSS はセレクタ無しだと詳細度で負ける → `QLabel{...}` / `#id{...}`
  - `QScrollArea` の地色は palette では塗れない → ID セレクタ ＋ `WA_StyledBackground`
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

from .. import theme_tokens as T

# 目標コントラスト（地色に対して）。**この表が「濃さ」の唯一の情報源**。
# 値の根拠はスパイク10（テーマ既定の secondarylightcolor は 1.14〜2.18 とばらつき、
# ライトではほぼ見えなかった）。
CR: dict[str, float] = {
    "divider": 2.60,      # グループの区切り線（サイドバー・タスクグループ。2026-09-05 濃く）
    "rail": 2.40,         # グループのレール（無彩色スタイル E）
    "card_edge": 2.90,    # グループカード（スタイル D）の枠。サイドバー全体の外枠も同じトークン
    "card_face": 1.35,    # グループカードの面
    "row_hover": 1.14,    # 行のマウスオーバー（ごく薄く）
    "input_border": 2.00,  # 入力欄などの枠
    "sub_ink": 4.60,      # 二次テキスト（AA 4.5 をわずかに超える）
    "faint_ink": 3.00,    # プレースホルダ・OFF 状態（AA 未満は承知の上）
    "frame": 2.90,        # ペインを囲う枠（`T.frame_width()` が 0 のテーマでは使わない）
}

# --- 自前のテーマ（2026-09-09） -------------------------------------- #
# `qt_material.get_theme()` は **実在するパスならその XML をそのまま読む**ので、
# qt-material のインストール先を汚さずに種を足せる。名前（`dq_white.xml`）は
# 設定に保存する識別子で、パスへの変換は `_resolve()` が引き受ける。
def _bundled_dir(name: str) -> Path:
    """同梱データ（`themes` / `fonts`）の置き場。

    通常実行はこのファイルの隣。**exe（PyInstaller）でも同じ形になる**ように
    spec の `datas` へ `workdesk/viewqt/<name>` として入れてあるが、
    展開先が違っても拾えるよう `sys._MEIPASS` も見る（無ければ隣を返す）。
    """
    here = Path(__file__).resolve().parent
    if getattr(sys, "frozen", False):
        base = Path(getattr(sys, "_MEIPASS", "") or here)
        cand = base / "workdesk" / "viewqt" / name
        if cand.is_dir():
            return cand
    return here / name


_THEME_DIR = _bundled_dir("themes")

# ドラクエ風スキンの濃さ。**ホバーだけは低く保つ**（面がうっすら浮くだけ）。
# **区切り線・レールは前景色そのままにしない**（2026-09-09 実測）── 3px の枠と
# 同じ強さで出るので、一覧の中の仕切りが「もう 1 つの枠」に見える。当時の画面に
# 窓の中の仕切り線は無い（分けたいものは別の窓にする）ので、抑えた濃さにする。
CR_DQ: dict[str, float] = dict(CR, divider=4.00, rail=4.00, sub_ink=4.60,
                               faint_ink=3.00, row_hover=1.90)

# 自前テーマの定義。`mono` は「**前景は 1 色**（枠も文字も `▶` も種の
# `primaryColor`）」という作り ── 原作の画面がそうなっている。
CUSTOM_THEMES: dict[str, dict] = {
    name: {"file": name, "skin": "dq", "cr": CR_DQ, "dark": True, "mono": True}
    for name in ("dq_white.xml", "dq_yellow.xml", "dq_orange.xml")
}

# 枠の色の選択肢（デザインラボの「枠の色」）。`auto` は時計で選ぶ。
RETRO_FRAMES: dict[str, str] = {
    "white": "dq_white.xml", "yellow": "dq_yellow.xml", "orange": "dq_orange.xml",
}
# 何時からどの色か（原作で HP が減るほど窓の色が変わるのになぞらえた。
# 2026-09-09 ユーザー指定）。**開始時刻の昇順**で持ち、後ろから見る。
#   5:00〜13:00 白 ／ 13:00〜17:00 黄 ／ 17:00〜翌 5:00 オレンジ
RETRO_SCHEDULE: tuple[tuple[int, str], ...] = ((0, "orange"), (5, "white"),
                                               (13, "yellow"), (17, "orange"))


def retro_theme_name(now=None) -> str:
    """いま当てるべきレトロのテーマ名（`STATE["retro_frame"]` から決める）。

    `auto` のときだけ時計を見る ── 昼を過ぎると黄、夕方からはオレンジ。
    """
    key = str(T.STATE.get("retro_frame", "white"))
    if key == "auto":
        import datetime

        hour = (now or datetime.datetime.now()).hour
        key = next(k for h, k in reversed(RETRO_SCHEDULE) if hour >= h)
    return RETRO_FRAMES.get(key, RETRO_FRAMES["white"])


def _meta(theme_name: str) -> dict:
    return CUSTOM_THEMES.get(theme_name, {})


def is_mono(theme_name: str) -> bool:
    """前景を 1 色で作るテーマか（枠・文字・記号が同じ色）。"""
    return bool(_meta(theme_name).get("mono"))


def _resolve(theme_name: str) -> str:
    """設定に保存されたテーマ名を `apply_stylesheet` に渡せる形にする。"""
    meta = _meta(theme_name)
    return str(_THEME_DIR / meta["file"]) if meta else theme_name

_KEYS = ("primaryColor", "primaryLightColor", "secondaryColor",
         "secondaryLightColor", "secondaryDarkColor", "primaryTextColor",
         "secondaryTextColor")


def read_env() -> dict[str, str]:
    """`apply_stylesheet()` が立てた `QTMATERIAL_*` を読む。"""
    return {k: os.environ.get("QTMATERIAL_" + k.upper(), "") for k in _KEYS}


def is_dark(theme_name: str | None = None) -> bool:
    """そのテーマが暗いか。名前を渡さなければ**いま当たっているテーマ**。

    引数なしのときに `QTMATERIAL_THEME` を見てはいけない（2026-09-09 実機で
    発覚）── 自前テーマは**フルパス**を渡して当てるので、環境変数にも
    パスが入り、`"dark" in name` が偽になる。結果、別窓（デザインラボ・
    編集ウィンドウ）のタイトルバーがレトロでも白いままだった。
    `set_palette()` が立てる `STATE["is_dark"]` が唯一の正。
    """
    if theme_name is None:
        return bool(T.STATE.get("is_dark", False))
    meta = CUSTOM_THEMES.get(theme_name)
    if meta is not None:
        return bool(meta["dark"])       # 名前に "dark" が入らない自前テーマ用
    return "dark" in theme_name


def dim(fg_hex: str, ground_hex: str, target: float) -> str:
    """`fg_hex` を地へ寄せて、コントラスト比が `target` になる色。

    **前景を 1 色で作るスキン**（レトロ）で「同じ色の薄いもの」を作るのに使う。
    `contrast_step` は ink の極から作るので色相を保てない ── こちらは
    指定した色そのものを薄める。目標がその色の持ち分を超えていたらそのまま返す。
    """
    if T.contrast(fg_hex, ground_hex) <= target:
        return fg_hex
    lo, hi = 0.0, 1.0        # mix(fg, ground, t) は t について単調減少
    for _ in range(30):
        mid = (lo + hi) / 2
        if T.contrast(T.mix(fg_hex, ground_hex, mid), ground_hex) > target:
            lo = mid
        else:
            hi = mid
    return T.mix(fg_hex, ground_hex, (lo + hi) / 2)


def derive_tokens(src: dict[str, str], *, dark: bool,
                  cr: dict[str, float] | None = None,
                  mono: bool = False) -> dict[str, str]:
    """qt-material の 7 色から画面が使う色トークン一式を作る。

    **純粋関数**（Qt に触れない）ので、全テーマぶんの値を流し込んでテストできる。
    `cr` は濃さの表（省略すると既定の `CR`）── 自前スキンだけ差し替える。
    `mono` は「**前景は 1 色**」＝枠も文字も記号も種の `primaryColor` で作る
    （原作の画面がそう。色ちがいは種を差し替えるだけで済む）。
    """
    CR_ = cr or CR
    ground = src.get("secondaryColor") or ("#232629" if dark else "#f5f5f5")
    accent = src.get("primaryColor") or "#4dd0e1"

    step = T.contrast_step
    ink = accent if mono else T.readable_ink(ground)

    tokens: dict[str, str] = {
        # --- 面 ------------------------------------------------------ #
        "bg": ground,                                   # 窓・ペインの地
        "sidebar_bg": ground,                           # サイドバーも同じ地（帯で分けない）
        "row_normal": ground,                           # 行は地に溶け込む（フラット）
        "row_hover": step(ground, CR_["row_hover"]),
        "card_face": T.elevated_face(ground, CR_["card_face"]),
        "card_edge": step(ground, CR_["card_edge"]),
        # --- 線 ------------------------------------------------------ #
        "divider": step(ground, CR_["divider"]),
        "rail": step(ground, CR_["rail"]),
        "input_border": step(ground, CR_["input_border"]),
        # ペインを囲う枠（`T.frame_width()` が 0 のテーマでは描かれない）
        "frame": step(ground, CR_["frame"]),
        # --- 文字 ---------------------------------------------------- #
        "ink": ink,
        "sub": step(ground, CR_["sub_ink"]),
        "faint": step(ground, CR_["faint_ink"]),
        # --- アクセント（選択・フォーカス。**色はここに予約されている**） --- #
        "accent": accent,
        # アクセントは彩度が高く中間輝度のものがある。2 極では AA に届かないので
        # 純黒・純白までエスカレートする `on_color` を使う（実測: #2979ff / #ff4081）。
        "on_accent": T.on_color(accent),
        "accent_soft": T.mix(accent, ground, 0.82),
        # --- 実行フィードバック（3 層の層2）。色相だけ意味に固定 ------- #
        "row_running": T.state_tone("running", "surface", dark=dark),
        "row_ok": T.state_tone("ok", "surface", dark=dark),
        "row_fail": T.state_tone("fail", "surface", dark=dark),
    }
    # 状態面の上に載る要約文字は**その面**から決める（地から決めると読めない）
    for state in ("running", "ok", "fail"):
        tokens[state + "_ink"] = T.tinted_ink(tokens["row_" + state])
    tokens["run_ink"] = tokens.pop("running_ink")   # 既存の呼び名に合わせる
    if mono:
        # **前景は 1 色。**「線・枠」は色そのまま、「二次テキスト・仕切り」は
        # 同じ色を地へ寄せて薄める（`dim`）── 目標コントラストは `CR_` のまま
        # なので、白でも黄でもオレンジでも読める濃さに揃う。
        tokens.update({
            "ink": accent,
            "sub": dim(accent, ground, CR_["sub_ink"]),
            "faint": dim(accent, ground, CR_["faint_ink"]),
            "frame": accent,
            "card_edge": accent,
            "input_border": accent,
            "divider": dim(accent, ground, CR_["divider"]),
            "rail": dim(accent, ground, CR_["rail"]),
            "accent_soft": T.mix(accent, ground, 0.82),
        })
    return tokens


def apply(app, theme_name: str, *, font_family: str | None = None) -> dict[str, str]:
    """テーマを当てて `PALETTE` を差し替える。戻り値は作ったトークン。

    `app` は `QApplication`。この関数だけが qt-material に触る。
    """
    import qt_material                      # PySide6 の後に import する（既知の癖）

    load_bundled_fonts()                    # スキンが固定する書体（レトロ）を使えるように
    qt_material.apply_stylesheet(
        app, theme=_resolve(theme_name),
        invert_secondary=theme_name.startswith("light"))
    # **スキンを先に決める** ── 書体をスキンが固定していることがあるので、
    # `_restore_font()` はそれを見てから走る必要がある。
    meta = _meta(theme_name)
    T.set_skin(str(meta.get("skin", "material")))
    _restore_font(app, font_family)

    dark = is_dark(theme_name)
    tokens = derive_tokens(read_env(), dark=dark, cr=meta.get("cr"),
                           mono=bool(meta.get("mono")))
    T.set_palette(tokens, dark=dark)
    T.STATE["qt_theme"] = theme_name      # 永続化（PERSIST_KEYS に入っている）
    return tokens


def current_theme() -> str:
    return str(T.STATE.get("qt_theme", "dark_cyan.xml"))


def list_themes() -> list[str]:
    """選べるテーマ名の一覧（qt-material の 26 種 ＋ 自前のもの）。

    テストはここを回して**全テーマ × 全トークン**を機械検証するので、自前の
    テーマも必ず含める。
    """
    import qt_material

    return list(qt_material.list_themes()) + list(CUSTOM_THEMES)


_FONT_DIR = _bundled_dir("fonts")
_bundled_fonts_loaded = False


def load_bundled_fonts() -> None:
    """同梱の書体を Qt に登録する（**OS にインストールしない**）。

    レトロスキンが使う PixelMplus12（M+ FONT LICENSE。`viewqt/fonts/` に
    ttf と LICENSE を置いてある）。Windows にドット字体が入っていないので
    同梱するしかないが、**pip 依存は増えない** ── `addApplicationFont` で
    プロセスの中だけに読み込む。

    何度呼んでも 1 回しか読まない。ファイルが無い環境でも黙って諦める
    （書体が無いだけで画面は成立する）。
    """
    global _bundled_fonts_loaded
    if _bundled_fonts_loaded:
        return
    _bundled_fonts_loaded = True
    try:
        from PySide6.QtGui import QFontDatabase

        for path in sorted(_FONT_DIR.glob("*.ttf")):
            QFontDatabase.addApplicationFont(str(path))
    except Exception:  # noqa: BLE001
        pass       # 書体が読めなくても起動は止めない


def _font_family() -> str:
    """いま使う書体。**スキンが固定していればそれが優先**。"""
    return T.skin_font() or str(T.STATE.get("font_family", "Yu Gothic UI"))


def _restore_font(app, family: str | None) -> None:
    """`apply_stylesheet()` がフォントを上書きするので和文フォントへ戻す（既知の癖）。

    **スキンが固定する書体はここでは使わない。** アプリ全体の既定フォントは
    パネル（デザインラボ・設定・各ダイアログ）にも効くが、そちらは今までどおりに
    しておく ── レトロで変えるのはメイン画面の行だけ（2026-09-09 ユーザー指定）。
    """
    from PySide6.QtGui import QFont, QFontDatabase

    fams = set(QFontDatabase.families())
    want = family or str(T.STATE.get("font_family", "Yu Gothic UI"))
    pick = next((f for f in (want, "Yu Gothic UI", "Meiryo UI", "Meiryo", "MS UI Gothic")
                 if f in fams), None)
    if pick:
        app.setFont(QFont(pick, int(T.STATE.get("font_size", 10))))


def font_css(delta: int = 0) -> str:
    """`T.STATE` のフォント設定を QSS の宣言片に変換する。

    `delta` は文字の大きさの差分（`-1` で 1pt 小さく）。**場所の名前**として
    弱く出したい見出し（サイドバーの `Menu` / `Tools`）に使う。

    **メイン画面の行の文字は `QApplication.setFont()` だけでは変わらない**
    （qt-material がグローバル QSS で `font-family` を指定しており、QSS が
    ウィジェット自身の `setFont()` より強い。2026-09-05 実機で発覚）。
    行を作り直さずに反映するには、**自分の QSS にも同じ値を書く**しかない
    （`_WorkRow` / `TaskRow` の `_restyle()` が使う）。
    """
    fam = _font_family().replace("'", "")
    px = T.skin_font_px()
    if px:
        # ドット字体は**設計グリッドの整数倍**でないと縁がぼやけるので px で指定する。
        # `delta`（見出しを 1pt 小さく）は**無視する** ── グリッドの外の大きさに
        # なるうえ、参考にした画面では窓の名前も本文と同じ大きさだった。
        return "font-family:'%s';font-size:%dpx;" % (fam, px)
    size = max(6, int(T.STATE.get("font_size", 10)) + delta)
    return "font-family:'%s';font-size:%dpt;" % (fam, size)
