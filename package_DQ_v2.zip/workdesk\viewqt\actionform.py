"""動作（タスクにぶら下がる処理）の入力フォーム。Tk 版 `view/actiondialog.py` の
`ActionForm` を Qt へ移したもの（Phase 4d）。

- 種類コンボ ＋ 種類別の入力欄を組む再利用コンポーネント。
  `collect() -> (action_id, args)`（不正なら `ValueError`）。
- **「適用」ボタンは持たない**。選択が動くとき・窓を閉じるときに呼び出し側が
  `collect()` する（Tk 版と同じ「移動時の自動保存」。入力漏れなら移動をブロックする）。
  そのため `dirty`（ユーザーが1つでも触ったか）を自分で追う ── 未変更なら
  `collect()` すら呼ばない＝暗号化コピーの再暗号化を無駄に走らせない。
- コピーのオプション: ワンタイム / 書式（HTMLテンプレート）/ 暗号化 / Slackメンション。
  **書式・暗号化・メンションは三者排他**（ワンタイムはどれとも併用可）。
- 暗号化 ON: **登録済みの一覧から選ぶ**（2026-09-09。それまでは動作ごとに
  入力＋確認再入力していた）。args に入るのは `secret_id` だけで、これは
  `secrets.json` の項目への**参照** ── 同じ文字列を複数の動作から指せるので、
  パスワードが変わったら「設定」→ 暗号化した文字列 で**1 か所直せば済む**。
  その場で登録したいときは「新規登録…」（`host.register_secret()` へ委ねる）。
  **中身は復号して見せない**（平文・文字数をランチャーに残さない。2026-09-01）。

**配色は親（編集ウィンドウ）の QSS が当たる**ので、ここでは色を書かない
（hex 直書き禁止に加え、QSS の二重管理も避ける）。
"""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel, QLineEdit,
    QPlainTextEdit, QPushButton, QSizePolicy, QVBoxLayout, QWidget,
)

from . import actionmeta, uikit


class ActionForm(QWidget):
    """種類選択＋種類別入力欄。`collect()` で `(action_id, args)`。"""

    kindChanged = Signal()      # 種類コンボが変わった（要約の描き直しに使う）

    def __init__(self, host, action, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        uikit.transparent(self)
        self._host = host
        self._action = action
        self.dirty = False

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(8)

        # 「種類」も種類別の入力欄と**同じ `QFormLayout`** に入れる。別立てにすると
        # 列幅がそれぞれ別に計算され、ラベルの右端が揃わない（2026-09-05 実機で発覚）。
        form_widget = uikit.transparent(QWidget())
        self._form = QFormLayout(form_widget)
        self._form.setContentsMargins(0, 0, 0, 0)
        self._form.setSpacing(8)
        # 右揃えだと項目名の文字数がまちまちで右端しか揃わず、逆に「ズレて」見える
        # （2026-09-05 実機の指摘）。左揃えにして開始位置を統一する。
        self._form.setLabelAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self._form.setFieldGrowthPolicy(QFormLayout.AllNonFixedFieldsGrow)
        v.addWidget(form_widget)

        self.type_cb = QComboBox()
        self.type_cb.addItems(actionmeta.LABELS)
        cur = actionmeta.LABEL_BY_ID.get(
            action.action_id if action is not None else "open_file", actionmeta.LABELS[0])
        self.type_cb.setCurrentText(cur)
        self.type_cb.activated.connect(self._on_kind_changed)
        self._add_row("種類", self.type_cb)

        self._v = v
        self._collect = None
        self._extra: QWidget | None = None   # フォームの外＝全幅で出す部品（コピーの文字列欄）
        self._build_body()

    def _add_row(self, label: str, widget: QWidget) -> None:
        """`QFormLayout.addRow` の薄いラッパ。

        自動生成されるラベルは既定だと行の高さいっぱいまで伸びず、フィールドより
        少し上に寄って見える（`labelAlignment` の縦センターだけでは効かなかった。
        2026-09-05 実機の指摘・実測で確認）。ラベルを縦方向に伸縮可能にして、
        行の高さいっぱいの中でテキストが縦センターされるようにする。
        """
        self._form.addRow(label, widget)
        item = self._form.itemAt(self._form.rowCount() - 1, QFormLayout.LabelRole)
        lbl = item.widget() if item is not None else None
        if isinstance(lbl, QLabel):
            lbl.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
            # 編集ウィンドウの QSS が `#rowLabel` に文字サイズを当てる
            # （"タスク名"/"説明" と同じ 14px に揃える）。
            lbl.setObjectName("rowLabel")

    # --- 種類 -------------------------------------------------------- #
    def _on_kind_changed(self, _index: int) -> None:
        self._mark_dirty()
        self._build_body()
        self.kindChanged.emit()

    def kind(self) -> str:
        return actionmeta.ID_BY_LABEL[self.type_cb.currentText()]

    def _args(self) -> dict:
        return dict(self._action.args) if self._action is not None else {}

    def _mark_dirty(self) -> None:
        self.dirty = True

    # --- 入力部品（dirty 追跡つき） ---------------------------------- #
    def _line(self, text: str = "", *, password: bool = False) -> QLineEdit:
        e = QLineEdit(str(text))
        if password:
            e.setEchoMode(QLineEdit.Password)
        e.textEdited.connect(lambda _t: self._mark_dirty())
        return e

    def _check(self, text: str, on) -> QCheckBox:
        c = QCheckBox(text)
        c.setChecked(bool(on))
        c.clicked.connect(lambda _on: self._mark_dirty())
        return c

    def _note(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("formNote")
        lbl.setWordWrap(True)
        return lbl

    def _browse(self, edit: QLineEdit, mode: str, *, exe: bool = False) -> QPushButton:
        """「参照…」。`QFileDialog` は Qt の標準機能に寄せる方針どおりそのまま使う。"""
        btn = QPushButton("参照…")
        btn.setObjectName("browseButton")

        def pick() -> None:
            if mode == "dir":
                p = QFileDialog.getExistingDirectory(self, "フォルダを選択")
            else:
                flt = "実行ファイル (*.exe);;すべて (*.*)" if exe else "すべて (*.*)"
                p, _ = QFileDialog.getOpenFileName(self, "ファイルを選択", "", flt)
            if p:
                edit.setText(p)
                self._mark_dirty()

        btn.clicked.connect(pick)
        return btn

    @staticmethod
    def _with_browse(edit: QLineEdit, btn: QPushButton) -> QWidget:
        w = uikit.transparent(QWidget())
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(6)
        h.addWidget(edit, 1)
        h.addWidget(btn)
        return w

    # --- 本体の組み立て ---------------------------------------------- #
    def _build_body(self) -> None:
        """種類別の行だけ作り直す。**「種類」の行（先頭）は残す** ── ラベル列の幅は
        フォーム全体で 1 つなので、種類だけ独立させると列幅がまた食い違う。"""
        while self._form.rowCount() > 1:
            self._form.removeRow(1)
        if self._extra is not None:
            self._v.removeWidget(self._extra)
            self._extra.setParent(None)
            self._extra.deleteLater()
            self._extra = None

        kind = self.kind()
        if kind in ("open_file", "open_folder"):
            self._collect = self._body_path(kind)
        elif kind == "open_url":
            self._collect = self._body_url()
        elif kind == "os_exec":
            self._collect = self._body_single("実行対象", "target")
        elif kind == "launch_app":
            self._collect = self._body_launch_app()
        elif kind == "copy":
            self._collect = self._body_copy()
        elif kind == "wait":
            self._collect = self._body_wait()
        else:
            self._collect = dict
        # 作り直したコンボ（書式テンプレート等）のポップアップを塗る。
        # **祖先の QSS は届かない**ので、作るたびに当て直す（2026-09-06）。
        uikit.style_combo_popups(self)

    # --- 種類別ボディ ------------------------------------------------ #
    def _body_single(self, label: str, key: str):
        ent = self._line(self._args().get(key, ""))
        self._add_row(label, ent)

        def collect() -> dict:
            v = ent.text().strip()
            if not v:
                raise ValueError("%s を入力してください" % label)
            return {key: v}

        return collect

    def _body_path(self, kind: str):
        ent = self._line(self._args().get("path", ""))
        btn = self._browse(ent, "dir" if kind == "open_folder" else "file")
        self._add_row("パス", self._with_browse(ent, btn))

        def collect() -> dict:
            v = ent.text().strip()
            if not v:
                raise ValueError("パスを入力してください")
            return {"path": v}

        return collect

    def _body_url(self):
        a = self._args()
        ent = self._line(a.get("url", ""))
        self._add_row("URL", ent)
        nw = self._check("新規ウィンドウで開く", a.get("new_window"))
        self._add_row("", nw)
        self._add_row("", self._note(
            "複数ページをまとめて開くとき、先頭の URL だけ ON にすると"
            "その新しいウィンドウに残りがタブで入ります（既存の窓を汚さない）。"))

        def collect() -> dict:
            v = ent.text().strip()
            if not v:
                raise ValueError("URL を入力してください")
            if "://" not in v:
                raise ValueError("URL の形式が不正です（scheme:// が必要）")
            out: dict = {"url": v}
            if nw.isChecked():
                out["new_window"] = True
            return out

        return collect

    def _body_wait(self):
        ent = self._line(self._args().get("seconds", "1"))
        self._add_row("待機秒数", ent)
        self._add_row("", self._note(
            "秒。この動作が終わるまで次の動作は始まりません"
            "（例: URL を開く動作の間に挟むと 1 本ずつ順に開く）。"))

        def collect() -> dict:
            raw = ent.text().strip()
            try:
                v = float(raw)
            except ValueError as e:
                raise ValueError("待機秒数は数値で入力してください") from e
            if v < 0:
                raise ValueError("待機秒数は 0 以上で入力してください")
            return {"seconds": v}

        return collect

    def _body_launch_app(self):
        """exe を直接実行（`os.startfile` で開けない業務アプリ向け）。引数・作業フォルダは任意。"""
        a = self._args()
        e_path = self._line(a.get("path", ""))
        self._add_row("exe パス", self._with_browse(
            e_path, self._browse(e_path, "file", exe=True)))
        e_args = self._line(a.get("args", ""))
        self._add_row("引数（任意）", e_args)
        e_wd = self._line(a.get("workdir", ""))
        self._add_row("作業フォルダ（任意）", self._with_browse(
            e_wd, self._browse(e_wd, "dir")))
        self._add_row("", self._note("未指定なら exe のあるフォルダで起動します。"))

        def collect() -> dict:
            p = e_path.text().strip()
            if not p:
                raise ValueError("exe パスを入力してください")
            out: dict = {"path": p}
            if e_args.text().strip():
                out["args"] = e_args.text().strip()
            if e_wd.text().strip():
                out["workdir"] = e_wd.text().strip()
            return out

        return collect

    # --- コピー ------------------------------------------------------ #
    def _body_copy(self):
        a = self._args()
        self.e_label = self._line(a.get("label", ""))
        self.e_label.setPlaceholderText("ワンタイムの窓に出す短い呼称（ID / パスワード など）")
        self._add_row("呼称（任意）", self.e_label)

        opts = uikit.transparent(QWidget())
        h = QHBoxLayout(opts)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(12)
        self.cb_onetime = self._check("ワンタイム", a.get("onetime"))
        self.cb_html = self._check("書式", a.get("format") == "html")
        self.cb_enc = self._check("暗号化", a.get("encrypt"))
        self.cb_mention = self._check("Slackメンション", a.get("mention"))
        for c in (self.cb_onetime, self.cb_html, self.cb_enc, self.cb_mention):
            h.addWidget(c)
        h.addStretch(1)
        # 書式 / 暗号化 / メンションは三者排他（ワンタイムはどれとも併用可）
        self.cb_html.clicked.connect(lambda _on: self._copy_exclusive(self.cb_html))
        self.cb_enc.clicked.connect(lambda _on: self._copy_exclusive(self.cb_enc))
        self.cb_mention.clicked.connect(lambda _on: self._copy_exclusive(self.cb_mention))
        self._add_row("オプション", opts)

        # **フォームの外**（2 列レイアウトの右列ではなく全幅）へ置く（2026-09-05 指摘）。
        # 「文字列」は複数行の入力なので、狭い右列に押し込めず左端から使えるように。
        self.copy_fields = uikit.transparent(QWidget())
        self._extra = self.copy_fields
        self._copy_v = QVBoxLayout(self.copy_fields)
        self._copy_v.setContentsMargins(0, 0, 0, 0)
        self._copy_v.setSpacing(6)
        self._v.addWidget(self.copy_fields)
        self._render_copy_fields()
        return self._collect_copy

    def _copy_exclusive(self, on_widget: QCheckBox) -> None:
        if on_widget.isChecked():
            for c in (self.cb_html, self.cb_enc, self.cb_mention):
                if c is not on_widget:
                    c.setChecked(False)
        self._render_copy_fields()

    def _clear_copy_fields(self) -> None:
        while self._copy_v.count():
            item = self._copy_v.takeAt(0)
            w = item.widget()
            if w is not None:
                w.setParent(None)
                w.deleteLater()

    def _render_copy_fields(self) -> None:
        self._clear_copy_fields()
        a = self._args()
        self._tmpl_cb = None
        self._sec_cb = None

        if self.cb_enc.isChecked():
            self._build_secret_picker(a)
            return

        if self.cb_html.isChecked():
            # **名前しか要らない**ので `template_names()` を使う ── `list()` は
            # 本文（メール本文まるごと）まで読む（`services/templates.py`）。
            names = sorted(self._host.template_names().items(), key=lambda kv: kv[1])
            if not names:
                warn = self._note("※ テンプレートが未登録です。\n"
                                  "「設定」→ 書式付きコピー（テンプレート）で登録してください。")
                warn.setObjectName("formWarn")
                self._copy_v.addWidget(warn)
                return
            self._tmpl_cb = QComboBox()
            # id は `userData` に持たせる（同じ名前のテンプレートがあっても
            # 取り違えない）。暗号文のコンボと同じ作り。
            for tid, name in names:
                self._tmpl_cb.addItem(name, tid)
            self._tmpl_cb.activated.connect(lambda _i: self._mark_dirty())
            idx = self._tmpl_cb.findData(a.get("template_id"))
            self._tmpl_cb.setCurrentIndex(idx if idx >= 0 else 0)
            self._copy_v.addWidget(QLabel("テンプレート"))
            self._copy_v.addWidget(self._tmpl_cb)
            return

        self.t_text = QPlainTextEdit(str(a.get("text", "")))
        self.t_text.setFixedHeight(84)
        self.t_text.textChanged.connect(self._mark_dirty)
        self._copy_v.addWidget(QLabel("文字列"))
        self._copy_v.addWidget(self.t_text)

    # --- 暗号化した文字列の選択（2026-09-09） ------------------------ #
    def _secret_entries(self) -> list[tuple[str, str]]:
        """`(secret_id, 一覧に出す名前)` の並び。名前つきが先・名前なしが後。

        名前が無いのは動作フォームから作った古い暗号文 ── 同じ「（名称未設定）」が
        並ぶと選べないので、`secret_id` の頭を添えて見分けられるようにする。
        """
        names = self._host.secret_names()
        named = sorted(((sid, n) for sid, n in names.items() if n), key=lambda kv: kv[1])
        anon = [(sid, "（名称未設定 %s）" % sid[:6]) for sid, n in names.items() if not n]
        return named + sorted(anon, key=lambda kv: kv[1])

    def _build_secret_picker(self, a: dict) -> None:
        """暗号化した文字列を**一覧から選ぶ**（2026-09-09）。

        以前はここで動作ごとに入力＋確認再入力し、動作ごとに別の `secret_id` を
        採番していた ── 同じパスワードを複数の動作で使うと、変わったときに
        動作の数だけ直すことになっていた。
        """
        entries = self._secret_entries()
        self._copy_v.addWidget(QLabel("暗号化した文字列"))
        row = uikit.transparent(QWidget())
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(8)
        self._sec_cb = QComboBox()
        cur = str(a.get("secret_id") or "")
        # 参照先が消えている（一覧から削除された）ときは**黙って別のものへ
        # すり替えない** ── 空の項目を先頭に出して選び直させる。
        if not cur or cur not in dict(entries):
            self._sec_cb.addItem(
                "（選択してください）" if not cur else "（登録されていません）", "")
        for sid, name in entries:
            self._sec_cb.addItem(name, sid)
        idx = self._sec_cb.findData(cur)
        self._sec_cb.setCurrentIndex(idx if idx >= 0 else 0)
        self._sec_cb.activated.connect(lambda _i: self._mark_dirty())
        h.addWidget(self._sec_cb, 1)
        btn = QPushButton("新規登録…")
        btn.setObjectName("browseButton")
        btn.clicked.connect(self._register_secret)
        h.addWidget(btn)
        self._copy_v.addWidget(row)
        uikit.style_combo_popups(self)
        if not entries:
            warn = self._note("※ 暗号化した文字列が未登録です。\n"
                              "「新規登録…」か、「設定」→ 暗号化した文字列 で登録してください。")
            warn.setObjectName("formWarn")
            self._copy_v.addWidget(warn)
        else:
            self._copy_v.addWidget(self._note(
                "中身は表示しません。値を変えるときは「設定」→ 暗号化した文字列 で"
                "更新してください（この文字列を使う動作すべてに効きます）。"))

    def _register_secret(self) -> None:
        """その場で 1 つ登録して選ぶ（窓を出すのは `MainWindow` の口）。"""
        sid = self._host.register_secret()
        if not sid:
            return
        self._mark_dirty()
        self._render_copy_fields()
        if self._sec_cb is not None:
            idx = self._sec_cb.findData(sid)
            if idx >= 0:
                self._sec_cb.setCurrentIndex(idx)

    def _collect_copy(self) -> dict:
        args: dict = {}
        lbl = self.e_label.text().strip()
        if lbl:
            args["label"] = lbl
        if self.cb_onetime.isChecked():
            args["onetime"] = True
        if self.cb_mention.isChecked():
            args["mention"] = True

        if self.cb_enc.isChecked():
            # **参照を書くだけ**（2026-09-09）。暗号化そのものは登録のときに
            # 済んでいるので、ここで鍵を要求しない ＝ 解錠していなくても
            # 動作の編集はできる。
            sid = self._sec_cb.currentData() if self._sec_cb is not None else ""
            if not sid:
                raise ValueError(
                    "暗号化した文字列を選んでください"
                    "（未登録なら「新規登録…」か「設定」→ 暗号化した文字列 で登録）")
            args.update({"encrypt": True, "secret_id": sid})
            return args

        # 非暗号化。**暗号文はここでは消さない**（2026-09-08）── 暗号文は
        # 設定パネルの一覧で管理するものになったので、動作のチェックを外した
        # だけで消えると、同じ文字列を使う他の動作まで巻き添えになる。
        # 要らなくなったものは一覧から明示的に消す。

        if self.cb_html.isChecked():
            tid = self._tmpl_cb.currentData() if self._tmpl_cb is not None else None
            if not tid:
                raise ValueError("テンプレートを選択してください"
                                 "（未登録なら「設定」→ 書式付きコピー（テンプレート）で登録）")
            args.update({"format": "html", "template_id": tid})
        else:
            args["text"] = self.t_text.toPlainText().rstrip("\n")
        return args

    # ----------------------------------------------------------------- #
    def collect(self) -> tuple[str, dict]:
        """`(action_id, args)` を返す。不正なら `ValueError`。"""
        return self.kind(), self._collect()
