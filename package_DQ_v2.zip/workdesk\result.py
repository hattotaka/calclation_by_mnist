"""実行結果ステータスと、機能が投げてよい例外。"""

from __future__ import annotations

from dataclasses import dataclass


class Status:
    OK = "OK"                 # 成功が確定
    DISPATCHED = "DISPATCHED"  # 起動依頼は完了、結果は原理的に不明（成功扱い）
    FAILED = "FAILED"         # 失敗が確定


@dataclass
class Result:
    status: str
    message: str = ""   # タスク名下（層3）に出す文言
    detail: str = ""    # ログのエラー概要


class PreflightError(Exception):
    """事前チェックで失敗。dispatcher が Result(FAILED) に正規化する。"""

    def __init__(self, user_message: str, detail: str = "") -> None:
        super().__init__(user_message)
        self.user_message = user_message
        self.detail = detail or user_message


class SequenceAbort(Exception):
    """ワンタイム中止など。dispatcher は残りの動作列を打ち切る。"""

    def __init__(self, reason: str = "中止しました") -> None:
        super().__init__(reason)
        self.reason = reason
