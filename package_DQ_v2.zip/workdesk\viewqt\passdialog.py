"""パスフレーズ入力ダイアログ。Tk 版 `view/passdialog.py` の置き換え（Phase 4d）。

- `ask_new_passphrase` … 新規設定（入力 ＋ 確認再入力）
- `ask_passphrase` … 1 回入力（別端末での解錠など）
- `ask_change_passphrase` … 現在 ＋ 新規 ＋ 確認（設定パネルから）

パスフレーズは前後の空白も有効な文字なので **strip しない**。伏字表示。
不一致はその場で知らせて `None` を返す（呼び出し側が必要ならやり直す）。

入力欄の並べ方と配色は `uikit.ask_fields` に寄せてある
（**操作要素は qt-material の既定スタイルに任せない**＝2026-09-05 の恒久ルール）。
"""

from __future__ import annotations

from PySide6.QtWidgets import QMessageBox

from .uikit import ask_fields


def ask_passphrase(parent, prompt: str) -> str | None:
    """1 回だけ入力させる（解錠用）。空ならキャンセル扱い。"""
    res = ask_fields(parent, "パスフレーズ", [("p", prompt)],
                     password=True, strip=False)
    if not res:
        return None
    return res["p"] or None


def ask_new_passphrase(parent) -> str | None:
    """新規設定（入力＋確認）。不一致・空なら知らせて None。"""
    res = ask_fields(parent, "パスフレーズの設定",
                     [("p1", "新しいパスフレーズ:"), ("p2", "確認のためもう一度:")],
                     password=True, strip=False)
    if not res or not res["p1"]:
        return None
    if res["p1"] != res["p2"]:
        QMessageBox.warning(parent, "パスフレーズの設定",
                            "一致しません。もう一度お試しください。")
        return None
    return res["p1"]


def ask_change_passphrase(parent) -> tuple[str, str] | None:
    """`(現在のパスフレーズ, 新しいパスフレーズ)`。キャンセル / 不一致で None。"""
    res = ask_fields(parent, "パスフレーズの変更",
                     [("cur", "現在のパスフレーズ:"),
                      ("new1", "新しいパスフレーズ:"),
                      ("new2", "確認のためもう一度:")],
                     password=True, strip=False)
    if not res or not res["cur"] or not res["new1"]:
        return None
    if res["new1"] != res["new2"]:
        QMessageBox.warning(parent, "パスフレーズの変更",
                            "新しいパスフレーズが一致しません。")
        return None
    return res["cur"], res["new1"]
