# WorkDeskLauncher（Qt 版）— 受け渡しパッケージ

このフォルダは **そのまま動く一式**です。開発リポジトリの `qt/` から
実行に要るものだけを取り出してあります（テスト・開発メモ・実データは入っていません）。

## 中身

```
main.py                    エントリポイント
workdesk\                  本体（GUI は workdesk\viewqt\）
data\workdesk.sample.json  初回起動時に読む見本データ
requirements.txt           実行時の依存
build\                     exe を作るスクリプト一式
```

## そのまま Python で動かす

```
py -3 -m pip install -r requirements.txt
py -3 main.py
```

Python 3.11 以上・Windows 専用です。依存は 3 つだけ
（`PySide6-Essentials` / `qt-material` / `cryptography`）。

## exe を作る

```
build\build.bat
```

- ビルドの中間物と成果物は **`%TEMP%\wdl-build-qt\`** に出ます
  （OneDrive の同期フォルダをビルドの書き込みで荒らさないため）。
- 出来上がり: `%TEMP%\wdl-build-qt\onedir\dist\WorkDeskLauncher\`
  と、それを固めた `WorkDeskLauncher-onedir.zip`。
- **onedir（フォルダごと配布）だけ**を用意しています。単一 exe（onefile）は
  起動のたびに自己展開するためウイルス対策ソフトのヒューリスティック検知を
  受けた実績があり、Qt 版は展開量も大きいので採っていません。

## データの置き場所

exe と**同じフォルダ**に作られます（初回起動時に見本から始まります）。

| ファイル | 中身 |
|---|---|
| `workdesk.json` | 階層（業務／タスク／動作）＋設定 |
| `secrets.json` | 暗号化コピーの暗号文（鍵は入っていない） |
| `templates\` | 書式付きコピーのテンプレート |

暗号鍵は Windows の**資格情報マネージャー**（target `WorkDeskLauncher`）に入ります。
パスフレーズそのものは保存されません。**別の端末で使うときは、初回にパスフレーズの
入力を求められます**（`secrets.json` を持って行っただけでは復号できません）。

実行ログは `%LOCALAPPDATA%\WorkDeskLauncher\logs\workdesk.log`。

## 既知の制限

- コード署名なし・アイコン（`.ico`）なし。SmartScreen の警告が出ることがあります。
- 複数端末でデータフォルダを共有する運用（マイドライブ等）の
  コンフリクト対応は未実装です。
