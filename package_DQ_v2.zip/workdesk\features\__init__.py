"""機能パッケージ。

ここで各機能モジュールを明示 import し、`@register` を発火させる。
（import 漏れ＝機能が黙って消える、を防ぐ。数が増えたら pkgutil 走査へ）
"""

from . import copy as _copy  # noqa: F401
from . import launch_app as _launch_app  # noqa: F401
from . import open_targets as _open_targets  # noqa: F401
from . import wait as _wait  # noqa: F401
from .registry import get, known, register  # noqa: F401

__all__ = ["get", "known", "register"]
