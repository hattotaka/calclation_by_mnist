"""Context: 機能に注入する共有資源のまとめ。

機能は他機能を import せず、この Context 経由で共有サービスにアクセスする。
`settings` / `clipboard` / `log` は必須、`onetime` / `crypto` / `templates` /
`mention_directory` は None 可（headless では省略できる）。
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from .model import TaskLocation
from .settings import SettingsReader


class ClipboardLike(Protocol):
    def clear(self) -> None: ...
    def set_text(self, text: str, *, private: bool = False) -> None: ...
    def set_html(
        self, html: str, plain_fallback: str = "", *, private: bool = False
    ) -> None: ...
    def auto_clear_after(self, seconds: float) -> None: ...


class LoggerLike(Protocol):
    def task_start(self, loc: TaskLocation) -> None: ...
    def action(self, loc: TaskLocation, feature_name: str, status: str, detail: str = "") -> None: ...
    def task_finish(self, loc: TaskLocation, outcome: str) -> None: ...


class OneTimeLike(Protocol):
    def begin_sequence(self, total: int) -> None: ...
    def end_sequence(self) -> None: ...
    def gate_paste(self, label: str, payload) -> None: ...
    def cancel(self) -> None: ...


class CryptoLike(Protocol):
    def is_configured(self) -> bool: ...
    @property
    def unlocked(self) -> bool: ...
    def has_secret(self, secret_id: str) -> bool: ...
    def decrypt(self, secret_id: str) -> str: ...


class TemplateStoreLike(Protocol):
    def get(self, template_id: str): ...
    def list(self): ...
    def names(self) -> dict[str, str]: ...


class MentionDirectoryLike(Protocol):
    def pick(self, preview: str = "") -> str: ...


@dataclass
class Context:
    settings: SettingsReader
    clipboard: ClipboardLike
    log: LoggerLike
    onetime: OneTimeLike | None = None
    crypto: CryptoLike | None = None
    templates: TemplateStoreLike | None = None
    mention_directory: MentionDirectoryLike | None = None
