"""待機（sleep）機能: 設定した秒数だけ待ってから次の動作へ進む。

同期。ワーカースレッドで `time.sleep` するだけ（UI スレッドは止まらない）。
「URL を一気に全部開く」を「1 秒ずつ順に開く」に変えるための部品
（design-notes 冒頭『原子的な単機能を組み合わせる』方針そのもの）。
"""

from __future__ import annotations

import time
from typing import Any

from ..result import PreflightError, Result, Status
from .base import Feature
from .registry import register

_MAX_SECONDS = 600.0   # 10 分。無限待ちの事故防止


@register("wait")
class WaitFeature(Feature):
    feature_name = "待機する"

    @staticmethod
    def _seconds(args: dict[str, Any]) -> float:
        try:
            return float(args.get("seconds", 0))
        except (TypeError, ValueError):
            return -1.0

    def preflight(self, args: dict[str, Any], ctx) -> None:
        s = self._seconds(args)
        if s < 0:
            raise PreflightError("待機秒数が不正です")
        if s > _MAX_SECONDS:
            raise PreflightError(f"待機秒数が長すぎます（最大 {_MAX_SECONDS:g} 秒）")

    def execute(self, args: dict[str, Any], ctx) -> Result:
        s = self._seconds(args)
        if s > 0:
            time.sleep(s)
        return Result(Status.OK, message=f"{s:g} 秒待機しました")
