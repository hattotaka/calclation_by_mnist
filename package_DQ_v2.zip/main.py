"""WorkDeskLauncher（Qt 版）エントリポイント。

Tk 版 `main.py` と同じ考え方: 実行フォルダに `workdesk.json` があればそれ、
無ければ同梱の `data/workdesk.sample.json` を読む。
"""

from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication      # qt_material より先に import する

from workdesk import persistence
from workdesk.viewqt.app import MainWindow


def bundle_dir() -> Path:
    meipass = getattr(sys, "_MEIPASS", None)
    return Path(meipass) if meipass else Path(__file__).resolve().parent


def resolve_data_path() -> Path:
    real = persistence.default_path()
    return real if real.exists() else bundle_dir() / "data" / "workdesk.sample.json"


def main() -> int:
    app = QApplication(sys.argv)
    win = MainWindow(resolve_data_path())
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
