"""機能の共通契約（§14.2）。

機能は「正常なら Result を返す／異常なら raise」だけを考える。
例外の Result(FAILED) への正規化は dispatcher が行う。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ..result import Result

if TYPE_CHECKING:
    from ..context import Context


class Feature:
    action_id: str = ""
    feature_name: str = ""
    # ※ 「同期 / 非同期」は `execute()` がすぐ返るかどうかで表現する（起動系は
    #    `Status.DISPATCHED` を返して即座に戻る）。dispatcher は動作列を常に逐次実行
    #    するので、種別を宣言するフラグは持たない（2026-09-02 に `is_async` を撤去）。

    def is_interactive(self, args: dict[str, Any]) -> bool:
        """この呼び出しが Ctrl+V 待ちでブロックするか。自分の args だけを見る。
        dispatcher が k/N の N を数えるのに使う（動作間の結合は生じない）。"""
        return False

    def preflight(self, args: dict[str, Any], ctx: "Context") -> None:
        """事前チェック。問題あれば raise（PreflightError 推奨）。既定 no-op。"""

    def execute(self, args: dict[str, Any], ctx: "Context") -> Result:
        raise NotImplementedError
