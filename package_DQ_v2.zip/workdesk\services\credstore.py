"""Windows 資格情報マネージャー（Credential Manager）への鍵の保存（ctypes / advapi32）。

- `CRED_TYPE_GENERIC` ＋ `CRED_PERSIST_LOCAL_MACHINE`（この端末に限定。
  別 PC では再度パスフレーズから鍵を導出する想定）。
- 保存する blob は「パスフレーズから導出した 32byte の鍵」。パスフレーズ自体は保存しない。
"""

from __future__ import annotations

import ctypes
from ctypes import wintypes

_advapi32 = ctypes.WinDLL("advapi32", use_last_error=True)

CRED_TYPE_GENERIC = 1
CRED_PERSIST_LOCAL_MACHINE = 2


class _FILETIME(ctypes.Structure):
    _fields_ = [("dwLowDateTime", wintypes.DWORD), ("dwHighDateTime", wintypes.DWORD)]


class _CREDENTIAL(ctypes.Structure):
    _fields_ = [
        ("Flags", wintypes.DWORD),
        ("Type", wintypes.DWORD),
        ("TargetName", wintypes.LPWSTR),
        ("Comment", wintypes.LPWSTR),
        ("LastWritten", _FILETIME),
        ("CredentialBlobSize", wintypes.DWORD),
        ("CredentialBlob", ctypes.POINTER(ctypes.c_byte)),
        ("Persist", wintypes.DWORD),
        ("AttributeCount", wintypes.DWORD),
        ("Attributes", ctypes.c_void_p),
        ("TargetAlias", wintypes.LPWSTR),
        ("UserName", wintypes.LPWSTR),
    ]


_PCREDENTIAL = ctypes.POINTER(_CREDENTIAL)

_advapi32.CredWriteW.argtypes = [_PCREDENTIAL, wintypes.DWORD]
_advapi32.CredWriteW.restype = wintypes.BOOL
_advapi32.CredReadW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, ctypes.POINTER(_PCREDENTIAL)]
_advapi32.CredReadW.restype = wintypes.BOOL
_advapi32.CredFree.argtypes = [ctypes.c_void_p]
_advapi32.CredDeleteW.argtypes = [wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD]
_advapi32.CredDeleteW.restype = wintypes.BOOL


def set_secret(target: str, blob: bytes) -> None:
    buf = (ctypes.c_byte * len(blob)).from_buffer_copy(blob)
    cred = _CREDENTIAL()
    cred.Type = CRED_TYPE_GENERIC
    cred.TargetName = target
    cred.CredentialBlobSize = len(blob)
    cred.CredentialBlob = ctypes.cast(buf, ctypes.POINTER(ctypes.c_byte))
    cred.Persist = CRED_PERSIST_LOCAL_MACHINE
    cred.UserName = target
    if not _advapi32.CredWriteW(ctypes.byref(cred), 0):
        raise OSError(f"CredWriteW failed (err={ctypes.get_last_error()})")


def get_secret(target: str) -> bytes | None:
    pcred = _PCREDENTIAL()
    if not _advapi32.CredReadW(target, CRED_TYPE_GENERIC, 0, ctypes.byref(pcred)):
        return None
    try:
        c = pcred.contents
        if not c.CredentialBlobSize:
            return b""
        return ctypes.string_at(c.CredentialBlob, c.CredentialBlobSize)
    finally:
        _advapi32.CredFree(pcred)


def delete_secret(target: str) -> bool:
    return bool(_advapi32.CredDeleteW(target, CRED_TYPE_GENERIC, 0))
