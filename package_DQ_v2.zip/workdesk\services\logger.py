"""実行ログ（人間が読むテキスト）。

- 動作単位の行 ＋ タスク開始/終了行の両方（§12）。
- 行内容: 時刻 / 階層情報 / 機能名 / 結果 / エラー概要。
- ローテーション: 行数ベース。既定 1万行 × 3世代。
- 配置: %LOCALAPPDATA%\\WorkDeskLauncher\\logs\\workdesk.log
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from ..model import TaskLocation

MAX_LINES = 10_000
GENERATIONS = 3

_OUTCOME_JA = {
    "all_ok": "成功",
    "has_failure": "失敗あり",
    "aborted": "中止",
}


def default_log_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    return Path(base) / "WorkDeskLauncher" / "logs"


class Logger:
    def __init__(self, path: str | os.PathLike[str] | None = None,
                 max_lines: int = MAX_LINES, generations: int = GENERATIONS) -> None:
        self.path = Path(path) if path else default_log_dir() / "workdesk.log"
        self.max_lines = max_lines
        self.generations = generations
        self._line_count = self._count_lines()

    # --- 公開 API --------------------------------------------------- #
    def task_start(self, loc: TaskLocation) -> None:
        self._write(loc, "タスク開始")

    def action(self, loc: TaskLocation, feature_name: str, status: str, detail: str = "") -> None:
        cell = f"{feature_name:<12} {status}"
        if detail:
            cell += f"  {detail}"
        self._write(loc, cell)

    def task_finish(self, loc: TaskLocation, outcome: str) -> None:
        self._write(loc, f"タスク終了（{_OUTCOME_JA.get(outcome, outcome)}）")

    # --- 内部 ----------------------------------------------------- #
    def _write(self, loc: TaskLocation, cell: str) -> None:
        # 1 行ごとに open → append → close する（ハンドルを開きっぱなしにしない）。
        # 動作 10 個のタスクで 12 回の open/close になるが、**意図した選択**:
        # ログはマイドライブ配下ではなく %LOCALAPPDATA% に置くとはいえ、
        # ランチャーは常駐 × 多重起動されうるので、書き込みを行単位で完結させておくと
        # プロセスが落ちても取りこぼさず、他プロセスと同時に開いても壊れない。
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"{ts}  [{loc.path_label()}]  {cell}\n"
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open("a", encoding="utf-8", newline="\n") as f:
            f.write(line)
        self._line_count += 1
        if self._line_count >= self.max_lines:
            self._rotate()

    def _count_lines(self) -> int:
        if not self.path.exists():
            return 0
        with self.path.open(encoding="utf-8") as f:
            return sum(1 for _ in f)

    def _rotate(self) -> None:
        oldest = self.path.with_suffix(self.path.suffix + f".{self.generations}")
        if oldest.exists():
            oldest.unlink()
        for i in range(self.generations - 1, 0, -1):
            src = self.path.with_suffix(self.path.suffix + f".{i}")
            if src.exists():
                src.rename(self.path.with_suffix(self.path.suffix + f".{i + 1}"))
        self.path.rename(self.path.with_suffix(self.path.suffix + ".1"))
        self._line_count = 0


class NullLogger:
    """テスト・ヘッドレス用。"""

    def task_start(self, loc: TaskLocation) -> None: ...
    def action(self, loc: TaskLocation, feature_name: str, status: str, detail: str = "") -> None: ...
    def task_finish(self, loc: TaskLocation, outcome: str) -> None: ...
