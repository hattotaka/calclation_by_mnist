"""services が「人に選ばせる／人に知らせる」ために使う UI の口（Protocol だけ）。

**このモジュールは GUI ツールキットを一切 import しない。** services 層は「いつ何を尋ねるか」
だけを持ち、「どう描くか」は view 側の実装（`view/popups.py`）が持つ。

背景（design-notes「2026-09-04 PySide6 + qt-material への UI 移行」Phase 2a）:
`services/onetime.py` と `services/mention.py` が `import tkinter` して Toplevel を自前で
建てていた。層としては `run_on_ui` / `colors=` 注入で守っていたが、**ウィジェット生成そのものが
services に居る**ため、ツールキットを替えると services も書き換えになる。ここを Protocol で
切り、Tk 実装／Qt 実装を差し替えられるようにする。

実装側の約束:
- `open` / `update` / `close` は **UI スレッドでのみ**呼ばれる（services が `run_on_ui` で回す）。
- `close()` は**何度呼ばれても安全**であること（既に閉じているなら何もしない）。
- 例外を投げないこと（配色やジオメトリの取得失敗で貼り付け・選択を止めない）。
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol


class OneTimePopup(Protocol):
    """ワンタイム（順次貼り付け）の進行を出す小窓。

    `OneTimeService` が gate ごとに `open()` → `update()` を呼び、動作列の終わりに `close()`。
    「中止」の押下は実装側が構築時に受け取ったコールバックで通知する
    （services 側は `OneTimeService.cancel` を渡す）。
    """

    def open(self) -> None:
        """開く。既に開いていれば何もしない。"""

    def update(self, label: str, index: int, total: int) -> None:
        """進行の表示を差し替える（「〜をコピー中（k/N）」）。"""

    def close(self) -> None:
        """閉じる。閉じていれば何もしない（**冪等**）。"""


class MentionPicker(Protocol):
    """Slack メンションの宛先を 1 つ選ばせる窓。

    `MentionDirectory.pick()` がワーカースレッドをブロックしている間、UI スレッドで開く。
    選択が確定したら `on_choose` を**必ず一度**呼ぶ（「メンション無し」は `""`、
    強制終了は `None`）。
    """

    def open(
        self,
        rows: list[tuple[str, str]],
        preview: str,
        on_choose: Callable[[str | None], None],
    ) -> None:
        """`rows` = `[(表示名, メンション文字列), ...]`。`preview` = コピーする文字列の先頭。"""

    def close(self) -> None:
        """閉じる。閉じていれば何もしない（**冪等**）。"""
