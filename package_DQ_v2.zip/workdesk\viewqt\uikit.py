"""viewqt の共有パーツ。**同じ処理を 2 つのモジュールに書き写さない**ための置き場
（CLAUDE.md §11「重複したら uikit へ寄せる」）。

置いてあるもの:

- `pal()` … `PALETTE` から色を 1 つ読む（各モジュールは `as _pal` で取り込む）
- `transparent()` … 素の `QWidget` に乗る qt-material の既定の地色を消す
- `panel_qss()` / `selection_qss()` / `combo_popup_qss()` / `style_combo_popups()`
  … パネル・ダイアログの配色。**qt-material の既定に任せない**（恒久ルール）
- `form_row()` … 「右寄せの見出し ＋ 中身」の 1 行
- `inline_rename()` … 行の名前ラベルの上に入力欄をかぶせて**その場で改名**する
- `apply_scrollbar_mode()` … `STATE["scrollbar_mode"]` を `QScrollArea` に当てる
- `hint_band()` / `sync_scroll_hints()` … 一覧の上下に出す「まだ続きがある」の合図
- `restore_scroll()` … 一覧を作り直したあとスクロール位置を戻す
- `ask_fields()` / `ask_text()` … n 個の入力欄を並べる小さなモーダル
- `ask_secret_value()` … 暗号化する文字列を伏字で 2 回聞く（確認つき）

`QInputDialog` を使わない理由: 1 欄なら足りるが 2〜3 欄のものがあり、伏字の指定も要る。
"""

from __future__ import annotations

from collections.abc import Callable

from PySide6.QtCore import QPoint, Qt, QTimer
from PySide6.QtGui import QFont, QPixmap
from PySide6.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea, QVBoxLayout,
    QWidget,
)

from .. import theme_tokens as T
from . import icons, qtheme

HINT_GAP = 18          # 合図の置き場（帯の高さ）。両ペインで同じ
HINT_ICON = 13         # 合図そのものの大きさ（うるさくならない範囲で）


def hint_band(name: str) -> QLabel:
    """`∧` `∨` の置き場になる帯を 1 つ作る（中身は `sync_scroll_hints` が入れる）。

    一覧の上下に置く。**帯そのものは常にある**（出たり消えたりすると一覧の高さが
    変わってしまう）── 変わるのは中身だけ。
    """
    lbl = QLabel()
    lbl.setObjectName(name)
    lbl.setFixedHeight(HINT_GAP)
    lbl.setAlignment(Qt.AlignCenter)
    return lbl


def sync_scroll_hints(scroll: QScrollArea, up: QLabel, down: QLabel) -> None:
    """**続きがある側にだけ**小さな `∧` `∨` を出す。

    色は `faint`（プレースホルダと同じ濃さ）＝**目に入るが読ませない**。端まで
    送ったらその側は消える。メインパネル（2026-09-06）とサイドバー（2026-09-07）
    で同じ処理なのでここに置く。
    """
    bar = scroll.verticalScrollBar()
    for label, name, show in ((up, "chevron_up", bar.value() > bar.minimum()),
                              (down, "chevron_down", bar.value() < bar.maximum())):
        pm = icons.pixmap(name, pal("faint"), HINT_ICON) if show else None
        label.setPixmap(pm if pm is not None else QPixmap())


def restore_scroll(scroll: QScrollArea, value: int) -> None:
    """一覧を**作り直したあと**、スクロール位置を元に戻す（2026-09-08 要望）。

    サイドバー・メインパネルは `render()` で中身をまるごと作り直す。そのままだと
    業務やタスクを 1 つ足しただけでも一覧が一番上へ飛び、下の方を見ていた手が
    迷子になる（実機で指摘）。選択は保たれているのに位置だけ失われる、という
    一番分かりにくい形だった。

    `setWidget()` の直後は中身の実寸がまだ決まっておらず、スクロールのレンジが
    0 のまま＝`setValue()` が 0 に丸められる。先に `adjustSize()` で実寸を確定
    させ、それでも届かないときだけ次のターンでもう一度当てる。
    """
    if value <= 0:
        return
    body = scroll.widget()
    if body is not None:
        body.adjustSize()
    bar = scroll.verticalScrollBar()
    bar.setValue(value)
    if bar.value() != value:
        QTimer.singleShot(0, lambda: bar.setValue(value))


def pal(key: str, fallback: str = "#808080") -> str:
    """`PALETTE` から色を 1 つ読む。**都度読む**（モジュール定数へ束縛しない
    ＝テーマ切替で凍結する。CLAUDE.md §9）。

    以前は viewqt の 9 ファイルに同じ 2 行が書き写されていた（2026-09-06 に集約）。
    各モジュールは `from .uikit import pal as _pal` で取り込む ── 呼び出し側の
    `_pal(...)` という書き方はそのまま。
    """
    return str(T.PALETTE.get(key, fallback))


def frame_css() -> str:
    """ペインを囲う枠の QSS 宣言片（`border:…`）。**枠が無いスキンでは
    `border:none`** ＝ qt-material の 26 テーマでは今までどおり枠を描かない。

    ドラクエの戦闘ウィンドウ風スキン（2026-09-09）が `Menu` / `Tools` /
    メインパネルを白枠で囲うために足した。太さ・角丸は `theme_tokens.SKIN`、
    色は `PALETTE["frame"]` ── **hex は書かない**（CLAUDE.md §10bis）。
    """
    w = T.frame_width()
    if w <= 0:
        return "border:none;"
    return "border:%dpx solid %s;border-radius:%dpx;" % (w, pal("frame"),
                                                         T.frame_radius())


def pixel_font(w: QWidget) -> None:
    """ドット字体のスキンでは**アンチエイリアスを切る**。

    PixelMplus のような「アウトラインで四角い画素を描いた」書体は、
    アンチエイリアス（とくに Windows のサブピクセル）が掛かると縁に赤や青の
    にじみが出て、ドットの角が丸まる。QSS では字形の描き方を指定できないので、
    ウィジェットの `QFont` に `NoAntialias` を立てる（家族名・大きさは QSS が
    決めるので、ここで触るのは描き方だけ）。

    **子ウィジェットにも 1 つずつ当てる。** 親に立てても伝わらない ── QSS で
    `font-family` を持つウィジェットは自分の font を組み直すため（2026-09-09 に
    実測: 親だけだと色付き画素が 1211 個のまま、ラベル自身に当てると 0）。

    枠の無いスキンでは既定へ戻す ── テーマを行き来しても残らないように。
    """
    want = (QFont.NoAntialias if T.skin_font_grid() else QFont.PreferDefault)
    for target in (w, *w.findChildren(QWidget)):
        f = target.font()
        if f.styleStrategy() != want:
            f.setStyleStrategy(want)
            target.setFont(f)


#: `▶` と次の文字のあいだに空ける距離（px）
CURSOR_GAP = 10


def fit_cursor(label: QLabel) -> None:
    """選択を示す `▶` の枠を、**いまの文字の大きさに合わせて**広げる。

    固定幅にしていたら、文字を大きくしたときに記号が枠からはみ出して名前と
    重なった（2026-09-09 実機で発覚）。実際に描かれる幅を測り、右に
    `CURSOR_GAP` の隙間を足す ── 記号は左寄せなので、余りは全部その隙間になる。

    **QSS を当てたあとに呼ぶこと**（大きさは QSS が決める）。
    """
    label.ensurePolished()
    mark = T.CURSOR_MARK
    label.setFixedWidth(label.fontMetrics().horizontalAdvance(mark) + CURSOR_GAP)


_transparent_seq = 0


def transparent(w: QWidget) -> QWidget:
    """**包みの地色を消す。**

    ただの `QWidget` で包むと qt-material のグローバル QSS
    （`QWidget{background-color:#31363b}` 相当）が地色を塗り、こちらの地色と
    食い違って帯に見える（2026-09-05 実機で発覚。editwindow / designlab /
    actionform で重複していたので uikit へ寄せた。CLAUDE.md §11）。
    包む必要がある場所（行のラッパー・ボタンの並び等）は必ずこれを通す。
    """
    global _transparent_seq
    _transparent_seq += 1
    name = "transparentWrap%d" % _transparent_seq
    w.setObjectName(name)
    w.setStyleSheet("#%s{background:transparent;border:none;}" % name)
    return w


def selection_qss() -> str:
    """**選択中の文字が読める**ことを保証する（qt-material の既定に任せない）。

    Windows では一覧の項目・入力欄の選択文字に **`color` ではなく
    `selection-color`** が効く（qt-material のテンプレート自身が
    `/* For Windows */` と注記して両方指定している）。`color` だけ上書きすると
    **面はこちらのアクセント・文字は qt-material の既定**という組み合わせになり、
    `dark_yellow` では白文字が黄色の上に乗って CR 1.07 になる（2026-09-06 実測）。

    塗った面の上の文字は `on_accent`（26/26 テーマで AA を満たす）。
    """
    c = {"accent": pal("accent"), "on": pal("on_accent"),
         "face": pal("card_face"), "ink": pal("ink"),
         "border": pal("input_border")}
    return (
        # 入力欄の選択（`*` の規則を上書きする）
        "QLineEdit,QTextEdit,QPlainTextEdit,QAbstractSpinBox{"
        "selection-background-color:%(accent)s;selection-color:%(on)s;}"
        # 一覧の項目
        "QListView::item:selected,QListWidget::item:selected{"
        "background:%(accent)s;color:%(on)s;"
        "selection-background-color:%(accent)s;selection-color:%(on)s;}"
        # プルダウンを開いたときの一覧（ポップアップは別ウィンドウだが
        # コンボの子なので、この QSS が届く）
        "QComboBox QAbstractItemView{background:%(face)s;color:%(ink)s;"
        "border:1px solid %(border)s;outline:none;"
        "selection-background-color:%(accent)s;selection-color:%(on)s;}"
        "QComboBox QAbstractItemView::item{color:%(ink)s;selection-color:%(on)s;}"
        "QComboBox QAbstractItemView::item:selected{background:%(accent)s;"
        "color:%(on)s;selection-color:%(on)s;}"
        % c
    )


def combo_popup_qss() -> str:
    """プルダウンを開いたときの一覧の配色（**ビュー自身に当てる**）。"""
    return (
        "QAbstractItemView{background:%(face)s;color:%(ink)s;"
        "border:1px solid %(border)s;outline:none;"
        "selection-background-color:%(accent)s;selection-color:%(on)s;}"
        "QAbstractItemView::item{color:%(ink)s;selection-color:%(on)s;"
        "padding:4px 6px;border:none;}"
        "QAbstractItemView::item:selected{background:%(accent)s;color:%(on)s;"
        "selection-color:%(on)s;}"
        % {"accent": pal("accent"), "on": pal("on_accent"),
           "face": pal("card_face"), "ink": pal("ink"),
           "border": pal("input_border")}
    )


def style_combo_popups(root) -> None:
    """`root` 配下のすべての `QComboBox` のポップアップを塗る。

    **子孫セレクタでは届かない。** ポップアップ（`combo.view()`）は
    `Qt::Popup` の別ウィンドウへ載せ替えられるので、ダイアログやパネルに
    書いた `QComboBox QAbstractItemView{...}` は無視される（コンボ自身か
    `QApplication` に設定したときだけ効く）。ビューに直接当てる。

    さらに、**コンボが自前で用意したビューには `::item` の QSS が効かない**
    （項目をメニュー項目として描く経路に入るため。実測で確認）。`QListView` を
    自分で差し込むと効くようになるので、コンボ 1 つにつき一度だけ差し替える。

    **コンボを作り直したら呼び直すこと**（`ActionForm._build_body` が手本）。
    """
    from PySide6.QtWidgets import QComboBox, QListView

    qss = combo_popup_qss()
    combos = list(root.findChildren(QComboBox))
    if isinstance(root, QComboBox):
        combos.append(root)
    for cb in combos:
        if not cb.property("wdlOwnView"):
            cb.setView(QListView())          # 一度だけ（差し替えると古いビューは消える）
            cb.setProperty("wdlOwnView", True)
        cb.view().setStyleSheet(qss)


def panel_qss() -> str:
    """パネル・ダイアログ共通の配色（**自分のトークンで塗る**）。

    `QDialog` の QSS は子ウィジェットにも当たるので、パネル側はこれを土台にして
    足りないものだけ足す。
    """
    return (
        "QDialog{background:%(bg)s;}"
        "QLabel{color:%(ink)s;background:transparent;border:none;}"
        "#panelNote{color:%(sub)s;}"
        "#panelHead{color:%(ink)s;font-weight:600;}"
        "QLineEdit{background:%(face)s;color:%(ink)s;border:1px solid %(border)s;"
        "border-radius:5px;padding:6px 8px;}"
        "QLineEdit:focus{border:1px solid %(accent)s;}"
        "QPushButton{background:%(face)s;color:%(ink)s;border:1px solid %(border)s;"
        "border-radius:5px;padding:5px 12px;}"
        "QPushButton:hover{background:%(hover)s;}"
        "QPushButton:disabled{color:%(faint)s;}"
        "#primaryButton{background:%(accent)s;color:%(on_accent)s;"
        "border:1px solid %(accent)s;}"
        % {"bg": pal("bg"), "ink": pal("ink"), "sub": pal("sub"),
           "face": pal("card_face"), "border": pal("input_border"),
           "accent": pal("accent"), "on_accent": pal("on_accent"),
           "hover": pal("row_hover"), "faint": pal("faint")}
        + selection_qss()
    )


def form_row(label: str, widget, *, label_width: int) -> QWidget:
    """「右寄せの見出し ＋ 中身」の 1 行を作る。

    デザインラボ（見出し幅 96）と編集ウィンドウ（同 72）で同じものを書いて
    いたので寄せた（2026-09-06）。幅だけが違う ── 窓ごとに見出しの語の長さが
    違うため、そこは呼び出し側が決める。
    """
    w = transparent(QWidget())
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    h.setSpacing(12)
    lbl = QLabel(label)
    lbl.setObjectName("rowLabel")
    # `fit_label_column()` が後から実幅に詰める目印（`rowLabel` は動作フォームの
    # ラベルとも共有しているので、こちらだけを選べるようにする）。
    lbl.setProperty("fitColumn", True)
    lbl.setFixedWidth(label_width)
    lbl.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
    h.addWidget(lbl)
    h.addWidget(widget, 1)
    return w


class _InlineEdit(QLineEdit):
    """行の上にかぶせる一時的な入力欄（`inline_rename` が建てる）。

    Enter / フォーカスが外れる＝確定、Esc＝取り消し。**空文字では確定しない**
    （名前が消えると行が見えなくなる）。確定でも取り消しでも自分を片付ける。
    """

    def __init__(self, parent: QWidget, text: str,
                 on_commit: Callable[[str], None]) -> None:
        super().__init__(text, parent)
        self._on_commit: Callable[[str], None] | None = on_commit
        self._done = False
        self.returnPressed.connect(self._commit)

    def _finish(self) -> str | None:
        """自分を畳んで、確定するテキストを返す（取り消し・二重確定なら None）。"""
        if self._done:
            return None
        self._done = True
        cb, self._on_commit = self._on_commit, None
        text = self.text().strip()
        self.hide()
        self.setParent(None)        # deleteLater だけだと残る（既知の癖）
        self.deleteLater()
        return text if (cb is not None and text) else None

    def _commit(self) -> None:
        cb = self._on_commit
        text = self._finish()
        if text is not None and cb is not None:
            cb(text)

    def _cancel(self) -> None:
        self._on_commit = None
        self._finish()

    def keyPressEvent(self, e) -> None:   # noqa: N802
        if e.key() == Qt.Key_Escape:
            self._cancel()
            return
        super().keyPressEvent(e)

    def focusOutEvent(self, e) -> None:   # noqa: N802
        super().focusOutEvent(e)
        self._commit()


def inline_rename(row: QWidget, label: QLabel,
                  on_commit: Callable[[str], None]) -> QLineEdit:
    """`label` の位置に入力欄をかぶせて、その場で名前を変えられるようにする。

    設定モードで行をダブルクリックしたときに使う（2026-09-06 要望＝「対象の
    上で直接変えたい」）。編集ウィンドウの名前欄は**残してある**ので、
    どちらからでも変えられる。

    行そのものを入力欄に作り替えないのは、行が持っている状態（選択・ホバー・
    実行中の面）を壊さないため ── かぶせて、閉じたら元の行がそのまま残る。
    """
    pos = label.mapTo(row, QPoint(0, 0))
    height = max(label.height() + 4, 24)
    width = max(120, row.width() - pos.x() - 8)
    ed = _InlineEdit(row, label.text(), on_commit)
    ed.setObjectName("inlineRename")
    ed.setStyleSheet(
        "#inlineRename{background:%s;color:%s;border:1px solid %s;border-radius:4px;"
        "padding:1px 6px;%s}" % (pal("card_face"), pal("ink"), pal("accent"),
                                 qtheme.font_css())
        + selection_qss())
    ed.setGeometry(pos.x(), pos.y() - 2, width, height)
    ed.show()
    ed.setFocus(Qt.OtherFocusReason)
    ed.selectAll()
    return ed


def fit_label_column(root: QWidget, *, pad: int = 6) -> None:
    """`form_row()` の見出し列を**実際の文字幅**に詰める（2026-09-06 要望）。

    固定幅（96 / 72）は「いちばん長い見出し」に合わせた値なので、短い見出し
    ばかりの窓では**左に使われない帯**が残っていた（実測でデザインラボ 27px /
    編集ウィンドウ 29px）。

    **QSS を当てたあとに呼ぶこと** ── 文字サイズは QSS が決めるので、
    先に測ると別のフォントの幅になる。
    """
    labels = [w for w in root.findChildren(QLabel) if w.property("fitColumn")]
    if not labels:
        return
    width = 0
    for lb in labels:
        lb.ensurePolished()                 # QSS のフォントを反映させてから測る
        width = max(width, lb.fontMetrics().horizontalAdvance(lb.text()))
    for lb in labels:
        lb.setFixedWidth(width + pad)


def apply_scrollbar_mode(scroll) -> None:
    """`STATE["scrollbar_mode"]` を `QScrollArea` に当てる（Tk 版からの移植）。

    - `always` … 常に出す
    - `auto` … 要るときだけ（既定）
    - `thin` … 要るときだけ・細く
    - `hover` … 要るときだけ・**触れるまでつまみを透明にする**
      （Tk 版は「ペインにポインタが入ったら出す」だったが、Qt では
      スクロールバー自身のホバーで代用する。出したい気持ちは同じ）

    **スクロールバーを持たないスキン**（レトロ）では出さない ── 続きがあることは
    一覧の上下の `∧` `∨` が知らせる（2026-09-09 ユーザー指定）。
    """
    from PySide6.QtCore import Qt

    if not T.scrollbars_visible():
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        return
    mode = str(T.STATE.get("scrollbar_mode", "auto"))
    scroll.setVerticalScrollBarPolicy(
        Qt.ScrollBarAlwaysOn if mode == "always" else Qt.ScrollBarAsNeeded)
    width = 6 if mode == "thin" else 10
    handle = "transparent" if mode == "hover" else pal("divider")
    scroll.verticalScrollBar().setStyleSheet(
        "QScrollBar:vertical{background:transparent;width:%(w)dpx;margin:0;border:none;}"
        "QScrollBar::handle:vertical{background:%(h)s;border-radius:%(r)dpx;"
        "min-height:24px;}"
        "QScrollBar::handle:vertical:hover{background:%(hv)s;}"
        "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;border:none;}"
        "QScrollBar::add-page:vertical,QScrollBar::sub-page:vertical"
        "{background:transparent;}"
        % {"w": width, "h": handle, "r": width // 2, "hv": pal("rail")})


class _FieldsDialog(QDialog):
    """入力欄を n 個並べるだけの小さなモーダル。"""

    def __init__(self, parent, title: str, fields, *, password: bool) -> None:
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(380)
        self.values: dict[str, str] | None = None

        v = QVBoxLayout(self)
        v.setContentsMargins(18, 16, 18, 14)
        v.setSpacing(8)
        self._edits: dict[str, QLineEdit] = {}
        for f in fields:
            key, label = f[0], f[1]
            initial = f[2] if len(f) > 2 else ""
            lbl = QLabel(label)
            lbl.setWordWrap(True)
            v.addWidget(lbl)
            ed = QLineEdit(str(initial))
            if password:
                ed.setEchoMode(QLineEdit.Password)
            ed.returnPressed.connect(self._on_ok)
            v.addWidget(ed)
            self._edits[key] = ed

        btns = QHBoxLayout()
        btns.addStretch(1)
        cancel = QPushButton("キャンセル")
        cancel.clicked.connect(self.reject)
        ok = QPushButton("OK")
        ok.setObjectName("primaryButton")
        ok.setDefault(True)
        ok.clicked.connect(self._on_ok)
        btns.addWidget(cancel)
        btns.addWidget(ok)
        v.addLayout(btns)

        self.setStyleSheet(panel_qss())
        if self._edits:
            first = next(iter(self._edits.values()))
            first.setFocus()
            first.selectAll()

    def _on_ok(self) -> None:
        self.values = {k: e.text() for k, e in self._edits.items()}
        self.accept()


def ask_fields(parent, title: str, fields, *, password: bool = False,
               strip: bool = True) -> dict[str, str] | None:
    """`fields` = `(key, ラベル[, 初期値])` の並び。キャンセルなら None。

    `strip=False` はパスフレーズ用（**前後の空白も有効な文字**なので削らない）。
    """
    dlg = _FieldsDialog(parent, title, list(fields), password=password)
    if dlg.exec() != QDialog.Accepted or dlg.values is None:
        return None
    if not strip:
        return dlg.values
    return {k: v.strip() for k, v in dlg.values.items()}


def ask_secret_value(parent, title: str) -> tuple[str | None, str]:
    """暗号化する文字列を**伏字で 2 回**聞く。`(値, エラー文)` を返す。

    キャンセルは `(None, "")`。前後の空白も有効な文字なので `strip=False`
    （パスフレーズと同じ扱い）。**知らせるのは呼び出し側**（窓を出す口を
    `MainWindow` に一本化してあるため）。
    """
    res = ask_fields(parent, title, [("v", "文字列:"), ("v2", "確認:")],
                     password=True, strip=False)
    if not res:
        return None, ""
    v1, v2 = res["v"], res["v2"]
    if not v1:
        return None, "文字列を入力してください。"
    if v1 != v2:
        return None, "確認の入力が一致しません。"
    return v1, ""


def ask_text(parent, title: str, label: str, initial: str = "") -> str | None:
    """1 欄だけ聞く。空ならキャンセル扱い。"""
    res = ask_fields(parent, title, [("v", label, initial)])
    if not res:
        return None
    return res["v"] or None
