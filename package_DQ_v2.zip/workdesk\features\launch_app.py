"""アプリ起動（exe を直接実行する）。

`open_file` は ShellExecute（`os.startfile`）任せで、関連付けや作業フォルダの
都合で起動しない exe がある（リソースを cwd から読むタイプ、コンソール系など）。
この機能は `subprocess.Popen` で **CreateProcess を直接**呼び、既定で exe のある
フォルダを作業ディレクトリにして起動する。

- 原子的な単機能（design-notes 冒頭のスコープ）。引数・作業フォルダは任意。
- 引数は Windows のコマンドライン規則で解釈させる（文字列のまま CreateProcess へ渡す）
  ＝ユーザーがコマンドプロンプトに打つのと同じ感覚。バックスラッシュも壊れない。
- 非同期（投げっぱなし）。起動呼び出し自体が失敗したら FAILED（dispatcher が正規化）。
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any

from ..result import PreflightError, Result, Status
from .base import Feature
from .registry import register


@register("launch_app")
class LaunchAppFeature(Feature):
    """exe を直接実行する（`args`＝コマンドライン引数 / `workdir`＝作業フォルダ、いずれも任意）。"""

    feature_name = "アプリ起動"

    def preflight(self, args: dict[str, Any], ctx) -> None:
        path = args.get("path", "")
        if not path:
            raise PreflightError("実行ファイルが指定されていません")
        if not Path(path).is_file():
            raise PreflightError("実行ファイルが見つかりません", f"not a file: {path}")
        wd = args.get("workdir", "")
        if wd and not Path(wd).is_dir():
            raise PreflightError("作業フォルダが見つかりません", f"not a dir: {wd}")

    def execute(self, args: dict[str, Any], ctx) -> Result:
        exe = args["path"]
        extra = (args.get("args") or "").strip()
        # exe はスペース対策でクォート。引数はそのまま連結し、Windows に解釈させる。
        cmdline = f'"{exe}"' + (f" {extra}" if extra else "")
        cwd = args.get("workdir") or str(Path(exe).parent)
        subprocess.Popen(cmdline, cwd=cwd)  # noqa: S603  (ユーザー指定の業務アプリ起動)
        return Result(Status.DISPATCHED)
