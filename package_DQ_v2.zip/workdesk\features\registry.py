"""機能レジストリ。`@register(action_id)` でクラスを登録する。

- action_id と実装クラスが同じ場所にある（局所性）。
- dispatcher は `get(action_id)` で実装を引くだけ。具体的な機能を知らない。
- import 漏れを防ぐため、features/__init__.py で各機能モジュールを明示 import する
  （数が増えたら pkgutil 走査へ）。
"""

from __future__ import annotations

from .base import Feature

_REGISTRY: dict[str, Feature] = {}


def register(action_id: str):
    def deco(cls: type[Feature]) -> type[Feature]:
        if action_id in _REGISTRY:
            raise ValueError(f"action_id が重複しています: {action_id!r}")
        instance = cls()
        instance.action_id = action_id
        _REGISTRY[action_id] = instance
        return cls

    return deco


def get(action_id: str) -> Feature:
    return _REGISTRY[action_id]


def known() -> list[str]:
    """登録済み action_id の一覧（デバッグ用）。"""
    return sorted(_REGISTRY)
