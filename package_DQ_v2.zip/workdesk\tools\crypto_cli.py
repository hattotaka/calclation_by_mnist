"""開発用: secrets.json にパスフレーズ初期化と暗号文を仕込む。

動作の編集 UI（次工程）ができるまで、暗号化コピーを手で試すための足場。

  python -m workdesk.tools.crypto_cli setup <passphrase>
  python -m workdesk.tools.crypto_cli put <secret_id> <text>
  python -m workdesk.tools.crypto_cli get <secret_id>
  python -m workdesk.tools.crypto_cli list

対象ファイルは実行フォルダの ./secrets.json、鍵は資格情報マネージャー("WorkDeskLauncher")。
"""

from __future__ import annotations

import sys
from pathlib import Path

from ..services.crypto import CryptoService

SECRETS = Path.cwd() / "secrets.json"


def _svc() -> CryptoService:
    return CryptoService(SECRETS)


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 2
    cmd, *rest = argv
    svc = _svc()

    if cmd == "setup":
        if svc.is_configured():
            print("すでに初期化済みです。")
            return 1
        svc.setup(rest[0])
        print(f"初期化しました: {SECRETS}")
        return 0

    # setup 以外は解錠が必要
    if not svc.is_configured():
        print("未初期化です。先に setup してください。")
        return 1
    if not svc.load_from_store():
        pp = input("パスフレーズ: ")
        if not svc.unlock(pp):
            print("パスフレーズが違います。")
            return 1

    if cmd == "put":
        svc.encrypt(rest[0], rest[1])
        print(f"暗号化して保存: {rest[0]}")
        return 0
    if cmd == "get":
        print(svc.decrypt(rest[0]))
        return 0
    if cmd == "list":
        for sid in sorted(svc._data.get("secrets", {})):  # noqa: SLF001  開発ツール
            print(sid)
        return 0

    print(f"不明なコマンド: {cmd}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
